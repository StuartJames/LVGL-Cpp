/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= ===========================================
 * SJ    2025/08/18   1.a.1    Original 
 *
 */


/////////////////////////////////////////////////////////////////////////////////////
#define _MAIN_

#define LV_SQUARELINE_MOD__SWIPE 1  //if defined or 1, reverts back to LVGL8.3 swipe-gesture behaviour (LVGL-9.1 abandons swipe too early if it finds/leaves a new object in the swipe-path)

#include "LEGLDemo.h"

extern "C" {
  void app_main(void);
}

/////////////////////////////////////////////////////////////////////////////////////

static const char *_TAG = "[Main  ]";

/////////////////////////////////////////////////////////////////////////////////////

void app_main(void)
{
	ESP_LOGI(_TAG, "***************************");
  ESP_LOGI(_TAG, "*    LEGL Widget Demo     *");
  ESP_LOGI(_TAG, "*  (c) HydraSystems 2025  *");
  ESP_LOGI(_TAG, "* Written by Stuart James *");
  ESP_LOGI(_TAG, "***************************");
  ESP_LOGI(_TAG, "\n\nFree memory: %ld bytes", esp_get_free_heap_size());
  ESP_LOGI(_TAG, "IDF version: %s", esp_get_idf_version());
  esp_log_level_set("gpio", ESP_LOG_NONE);  // Disable default gpio logging messages
  
  if(CheckNVS() == ESP_OK) g_NVSAvailable = true;

	g_SystemFlags = xEventGroupCreate();
  if(g_SystemFlags == NULL){
    ESP_LOGE(_TAG, "Failed to create system flags.");
		while(true) vTaskDelay(pdMS_TO_TICKS(1000));
  }

	g_SDMMCObj.Initialise(c_pMountPoint);
	g_SDMMCObj.GetFlashSize();
	g_PwrKeyObj.Initialise(c_PowerKeyPin, c_PowerControlPin);

	BaseType_t id = xTaskCreatePinnedToCore(DisplayThread, "Display thread", 4096, NULL, 8, NULL, 0);         
  if(id == 0L){
    ESP_LOGE(_TAG, "Failed to create display thread.");
		while(true) vTaskDelay(pdMS_TO_TICKS(1000));
  }
  xEventGroupWaitBits(g_SystemFlags, SYSFLAG_DISPLAY_READY, pdFALSE, pdTRUE, portMAX_DELAY); // wait for display thread to become ready

	xEventGroupSetBits(g_SystemFlags, SYSFLAG_SYSTEM_UP | SYSFLAG_GET_WEATHER);
	ESP_LOGI(_TAG, "System Initialised.");
  ESP_LOGI(_TAG, "Free memory: %ld bytes", esp_get_free_heap_size());
	while(true) {
		vTaskDelay(pdMS_TO_TICKS(1000));	
	}
}
