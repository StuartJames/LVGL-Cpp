/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= ===========================================
 * SJ    2025/08/18   1.a.1    Original ESP Demo
 *
 */


#include "LEGLDemo.h"

/////////////////////////////////////////////////////////////////////////////////////

#define APP_DISP_DEFAULT_BRIGHTNESS 20
#define ONE_SECOND_PERIOD_MS				1000

/////////////////////////////////////////////////////////////////////////////////////

static const char *_TAG = "[DISP  ]";

/////////////////////////////////////////////////////////////////////////////////////

static void OneSecondTimer(void)
{
//  QueueSysEvent(SYS_MSG_EV_TIME_UPDATE, NULL);
}

static const esp_timer_create_args_t OneSecondTimerArgs = {
  .callback = (esp_timer_cb_t)&OneSecondTimer,
	.arg = NULL,                     
  .dispatch_method = ESP_TIMER_TASK,
  .name = "One Second Timer",
	.skip_unhandled_events = false
};

/////////////////////////////////////////////////////////////////////////////////////

void DisplayThread(void *arg)
{
esp_timer_handle_t hOneSecondTimer;

	ESP_ERROR_CHECK(esp_timer_create(&OneSecondTimerArgs, &hOneSecondTimer));
	ESP_ERROR_CHECK(esp_timer_start_periodic(hOneSecondTimer, ONE_SECOND_PERIOD_MS * 1000));  // here time is in micro seconds
	DisplayStart();																			// Initialize display and EGL 
	SetBacklightLevel(APP_DISP_DEFAULT_BRIGHTNESS);	// Set default display brightness 
	DisplayLock(0);
	EG_WidgetsDemo();
	DisplayUnlock();
  xEventGroupSetBits(g_SystemFlags, SYSFLAG_DISPLAY_READY);
	ESP_LOGI(_TAG, "Display thread started.");
//	while(true) vTaskDelay(pdMS_TO_TICKS(1000));
  xEventGroupWaitBits(g_SystemFlags, SYSFLAG_SYSTEM_UP, pdFALSE, pdTRUE, portMAX_DELAY); // wait for system ready
  while(true){
		vTaskDelay(pdMS_TO_TICKS(20));                 // once every 20ms
	}
}

