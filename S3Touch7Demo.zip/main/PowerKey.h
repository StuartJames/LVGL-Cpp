/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= ===========================================
 * SJ    2025/08/18   1.a.1    Original ESP Demo
 *
 */

#pragma once

/////////////////////////////////////////////////////////////////////////////////////

const int DeviceSleepTime_c     = 10;
const int DeviceRestartTime_c   = 15;
const int DeviceShutdownTime_c  = 20;

/////////////////////////////////////////////////////////////////////////////////////

class PowerKey
{
public:
              PowerKey(void);
  void        Initialise(gpio_num_t CntrlPin, gpio_num_t InputPin);
  void        Read(void);
  void        FallAsleep(void);
  void        Shutdown(void);
  void        Restart(void);

private:
  void        ConfigurePin(gpio_num_t Pin, gpio_mode_t Mode);

  gpio_num_t  m_PowerControlPin;
  gpio_num_t  m_PowerInputPin;
  uint8_t     m_ButtonState;
  uint8_t     m_DeviceState;
  uint16_t    m_LongPress;
  
  
};