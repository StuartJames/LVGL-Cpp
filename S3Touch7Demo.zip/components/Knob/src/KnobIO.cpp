/*
 *              EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#include "esp_log.h"
#include "esp_sleep.h"
#include "esp_check.h"
#include "driver/gpio.h"
#include "Knob.h"

/////////////////////////////////////////////////////////////////////////////////////

static const char *TAG = "[KnobIO]";

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t  ESPQuadKnob::InitialiseIO(gpio_num_t GPIONumber)
{
	gpio_config_t gpio_cfg = {};
	gpio_cfg.pin_bit_mask = (1ULL << GPIONumber);
	gpio_cfg.mode = GPIO_MODE_INPUT;
	gpio_cfg.intr_type = GPIO_INTR_DISABLE;
	gpio_cfg.pull_up_en = GPIO_PULLUP_ENABLE;
	esp_err_t ret = gpio_config(&gpio_cfg);
	return ret;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPQuadKnob::DeinitialiseIO(gpio_num_t GPIONumber)
{
	return gpio_reset_pin(GPIONumber);
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t ESPQuadKnob::GetKeyLevel(gpio_num_t GPIONumber)
{
	return (uint8_t)gpio_get_level(GPIONumber);
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPQuadKnob::InitialiseIntrrupt(gpio_num_t GPIONumber, gpio_int_type_t InterruptType, gpio_isr_t hISR, void *ControlPin)
{
	gpio_set_intr_type(GPIONumber, InterruptType);
	if(!m_InterruptServiceInstalled) {
		gpio_install_isr_service(ESP_INTR_FLAG_IRAM);
		m_InterruptServiceInstalled = true;
	}
	gpio_isr_handler_add(GPIONumber, hISR, ControlPin);
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPQuadKnob::SetInterruptType(gpio_num_t GPIONumber, gpio_int_type_t InterruptType)
{
	return gpio_set_intr_type(GPIONumber, InterruptType);
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPQuadKnob::InterruptControl(gpio_num_t GPIONumber, bool Enable)
{
	if(Enable) gpio_intr_enable(GPIONumber);
	else gpio_intr_disable(GPIONumber);
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPQuadKnob::WakeupControl(gpio_num_t GPIONumber, uint8_t WakeupLevel, bool Enable)
{
esp_err_t ret;

	if(Enable) {
#if CONFIG_PM_POWER_DOWN_PERIPHERAL_IN_LIGHT_SLEEP
#if SOC_PM_SUPPORT_EXT1_WAKEUP
		ret = esp_sleep_enable_ext1_wakeup_io((1ULL << GPIONumber), WakeupLevel == 0 ? ESP_EXT1_WAKEUP_ANY_LOW : ESP_EXT1_WAKEUP_ANY_HIGH);
#else
		/*!< Not support etc: esp32c2, esp32c3. Target must support ext1 wakeup */
		ret = ESP_FAIL;
		ESP_RETURN_ON_FALSE(ret == ESP_OK, ESP_FAIL, TAG, "Target must support ext1 wakeup");
#endif
#endif
		/* Enable wake up from GPIO */
		ret = gpio_wakeup_enable(GPIONumber, WakeupLevel == 0 ? GPIO_INTR_LOW_LEVEL : GPIO_INTR_HIGH_LEVEL);
	}
	else {
#if CONFIG_PM_POWER_DOWN_PERIPHERAL_IN_LIGHT_SLEEP
#if SOC_PM_SUPPORT_EXT1_WAKEUP
		ret = esp_sleep_disable_ext1_wakeup_io(1ULL << GPIONumber);
#endif
#endif
		ret = gpio_wakeup_disable(GPIONumber);
	}
	return ret;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPQuadKnob::InitialiseWakeup(gpio_num_t GPIONumber, uint8_t WakeupLevel)
{
#if CONFIG_PM_POWER_DOWN_PERIPHERAL_IN_LIGHT_SLEEP
	if(!esp_sleep_is_valid_wakeup_gpio(GPIONumber)) {
		ESP_LOGE(TAG, "GPIO %ld is not a valid wakeup source under CONFIG_PM_POWER_DOWN_PERIPHERAL_IN_LIGHT_SLEEP", GPIONumber);
		return ESP_FAIL;
	}
	gpio_hold_en(GPIONumber);
#endif
	/* Enable wake up from GPIO */
	esp_err_t ret = gpio_wakeup_enable(GPIONumber, WakeupLevel == 0 ? GPIO_INTR_LOW_LEVEL : GPIO_INTR_HIGH_LEVEL);
	ESP_RETURN_ON_FALSE(ret == ESP_OK, ESP_FAIL, TAG, "Enable gpio wakeup failed");

#if CONFIG_PM_POWER_DOWN_PERIPHERAL_IN_LIGHT_SLEEP
#if SOC_PM_SUPPORT_EXT1_WAKEUP
	ret = esp_sleep_enable_ext1_wakeup_io((1ULL << GPIONumber), WakeupLevel == 0 ? ESP_EXT1_WAKEUP_ANY_LOW : ESP_EXT1_WAKEUP_ANY_HIGH);
#else
	/*!< Not support etc: esp32c2, esp32c3. Target must support ext1 wakeup */
	ret = ESP_FAIL;
	ESP_RETURN_ON_FALSE(ret == ESP_OK, ESP_FAIL, TAG, "Target must support ext1 wakeup");
#endif
#else
	ret = esp_sleep_enable_gpio_wakeup();
	ESP_RETURN_ON_FALSE(ret == ESP_OK, ESP_FAIL, TAG, "esp sleep enable gpio wakeup failed");
#endif
	return ESP_OK;
}
