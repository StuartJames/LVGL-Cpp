/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_check.h"
#include "driver/gpio.h"
#include "driver/i2c.h"
#include "esp_lcd_panel_io.h"
#include "ESPEGPort.h"
#include "ESPEGTouchGT911.h"

/////////////////////////////////////////////////////////////////////////////////////

static const char *_TAG = "[GT911 ]";

/////////////////////////////////////////////////////////////////////////////////////

ESPGLTouchGT911::ESPGLTouchGT911(void) : ESPGLTouchController(),
  m_IntPinLevel(0)
{
  EG_ZeroMem(&m_Data, sizeof(ESPGLTouchData_t));
  m_Data.Lock.owner = portMUX_FREE_VAL;
}

/////////////////////////////////////////////////////////////////////////////////////

ESPGLTouchGT911::~ESPGLTouchGT911(void)
{
	if(m_Config.InterruptPin != GPIO_NUM_NC) {  // Reset GPIO pin settings
		gpio_reset_pin(m_Config.InterruptPin);
		gpio_isr_handler_remove(m_Config.InterruptPin);
	}
	if(m_Config.ResetPin != GPIO_NUM_NC) {  // Reset GPIO pin settings
		gpio_reset_pin(m_Config.ResetPin);
	}
}

////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchGT911::EnterSleep(void)
{
uint8_t SetSleep = 0x05;

  esp_err_t Result = i2cWrite(ESP_LCD_TOUCH_GT911_ENTER_SLEEP, &SetSleep, 1);
  ESP_RETURN_ON_ERROR(Result, _TAG, "Enter Sleep failed!");
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchGT911::ExitSleep(void)
{
esp_err_t Result;
gpio_config_t int_gpio;

  if(I2CTouchIntIO_c != GPIO_NUM_NC) {
    int_gpio.mode = GPIO_MODE_OUTPUT;
    int_gpio.pin_bit_mask = BIT64(I2CTouchIntIO_c);
    Result = gpio_config(&int_gpio);
    ESP_RETURN_ON_ERROR(Result, _TAG, "High GPIO config failed");
    gpio_set_level(I2CTouchIntIO_c, 1);
    vTaskDelay(pdMS_TO_TICKS(5));
    int_gpio.mode = GPIO_MODE_OUTPUT_OD;
    int_gpio.pin_bit_mask = BIT64(I2CTouchIntIO_c);
    Result = gpio_config(&int_gpio);
    ESP_RETURN_ON_ERROR(Result, _TAG, "Float GPIO config failed");
  }
  return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchGT911::ReadData(void)
{
esp_err_t Result;
uint8_t Buffer[41];
uint8_t touch_cnt = 0;
uint8_t clear = 0;
size_t i = 0;

	Result = i2cRead(ESP_LCD_TOUCH_GT911_READ_XY_REG, Buffer, 1);
	ESP_RETURN_ON_ERROR(Result, _TAG, "I2C read error!");
	if((Buffer[0] & 0x80) == 0x00) {                            // Any touch data?
		i2cWrite(ESP_LCD_TOUCH_GT911_READ_XY_REG, &clear, 1);  // No touch data
#if(CONFIG_BSP_LCD_TOUCH_MAX_BUTTONS > 0)
    }
    else if ((Buffer[0] & 0x10) == 0x10) {        // Read all keys 
      uint8_t KeyMax = ((ESP_GT911_TOUCH_MAX_BUTTONS < CONFIG_BSP_LCD_TOUCH_MAX_BUTTONS) ? \
                          (ESP_GT911_TOUCH_MAX_BUTTONS) : (CONFIG_BSP_LCD_TOUCH_MAX_BUTTONS));
      Result = i2cRead(ESP_LCD_TOUCH_GT911_READ_KEY_REG, &Buffer[0], KeyMax);
      ESP_RETURN_ON_ERROR(Result, _TAG, "I2C read error!");
      i2cWrite(ESP_LCD_TOUCH_GT911_READ_XY_REG, &clear, 1);     // Clear all 
      ESP_RETURN_ON_ERROR(Result, _TAG, "I2C write error!");
      portENTER_CRITICAL(&m_Data.Lock);
      m_Data.Buttons = KeyMax;      // Buttons count 
      for (i = 0; i < KeyMax; i++) {
          m_Data.ButtonArray[i].Status = Buffer[0] ? 1 : 0;
      }
      portEXIT_CRITICAL(&m_Data.Lock);
#endif
	}
	else {
		if((Buffer[0] & 0x80) == 0x80) {
#if (CONFIG_BSP_LCD_TOUCH_MAX_BUTTONS > 0)
      portENTER_CRITICAL(&m_Data.Lock);
			for(i = 0; i < CONFIG_BSP_LCD_TOUCH_MAX_BUTTONS; i++) {
				m_Data.ButtonArray[i].Status = 0;
			}
      portEXIT_CRITICAL(&m_Data.Lock);
#endif	
			touch_cnt = Buffer[0] & 0x0f;  // Count of touched points
			if(touch_cnt > 5 || touch_cnt == 0) {
				i2cWrite(ESP_LCD_TOUCH_GT911_READ_XY_REG, &clear, 1);
				return ESP_OK;
			}
			Result = i2cRead(ESP_LCD_TOUCH_GT911_READ_XY_REG + 1, &Buffer[1], touch_cnt * 8);
			ESP_RETURN_ON_ERROR(Result, _TAG, "I2C read error!");
			Result = i2cWrite(ESP_LCD_TOUCH_GT911_READ_XY_REG, &clear, 1);  // Clear all
			ESP_RETURN_ON_ERROR(Result, _TAG, "I2C read error!");
      portENTER_CRITICAL(&m_Data.Lock);
			if(touch_cnt > CONFIG_ESP_LCD_TOUCH_MAX_POINTS) touch_cnt = CONFIG_ESP_LCD_TOUCH_MAX_POINTS;  // Number of touched points
			m_Data.Points = (uint8_t)touch_cnt;
			for(i = 0; i < touch_cnt; i++) {  // Fill all coordinates
				m_Data.Coords[i].X = (uint16_t)(((uint16_t)Buffer[(i * 8) + 3] << 8) + Buffer[(i * 8) + 2]);
				m_Data.Coords[i].Y = (uint16_t)(((uint16_t)Buffer[(i * 8) + 5] << 8) + Buffer[(i * 8) + 4]);
				m_Data.Coords[i].Strength = (((uint16_t)Buffer[(i * 8) + 7] << 8) + Buffer[(i * 8) + 6]);
			}
      portEXIT_CRITICAL(&m_Data.Lock);
		}
	}
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

bool ESPGLTouchGT911::GetCoordinates(uint16_t *pX, uint16_t *pY, uint16_t *pStrength, uint8_t *pCount, uint8_t MaxCount)
{
	assert(pX != NULL);
	assert(pY != NULL);
	assert(pCount != NULL);
	assert(MaxCount > 0);
   portENTER_CRITICAL(&m_Data.Lock);
	*pCount = (m_Data.Points > MaxCount) ? MaxCount : m_Data.Points;
	for(size_t i = 0; i < *pCount; i++) {
		pX[i] = m_Data.Coords[i].X;
		pY[i] = m_Data.Coords[i].Y;
		if(pStrength) {
			pStrength[i] = m_Data.Coords[i].Strength;
		}
	}
	m_Data.Points = 0;  // Invalidate
  portEXIT_CRITICAL(&m_Data.Lock);
	return (*pCount > 0);
}

/////////////////////////////////////////////////////////////////////////////////////

#if(CONFIG_BSP_LCD_TOUCH_MAX_BUTTONS > 0)
esp_err_t ESPGLTouchGT911::GetButtonState(uint8_t Index, uint8_t *pState)
{
esp_err_t Result = ESP_OK;

	assert(pState != nullptr);
	*pState = 0;
	if(m_Config.InterruptPin != GPIO_NUM_NC) gpio_intr_enable(m_Config.InterruptPin);
	if(Index > m_Data.Buttons) Result = ESP_ERR_INVALID_ARG;
	else *pState = m_Data.ButtonArray[Index].Status;
	if(m_Config.InterruptPin != GPIO_NUM_NC) gpio_intr_enable(m_Config.InterruptPin);
	return Result;
}
#endif

/////////////////////////////////////////////////////////////////////////////////////

void ESPGLTouchGT911::ReadConfig(void)
{
uint8_t Buffer[4];

	i2cRead(ESP_LCD_TOUCH_GT911_PRODUCT_ID_REG, (uint8_t *)&Buffer[0], 3);
	i2cRead(ESP_LCD_TOUCH_GT911_CONFIG_REG, (uint8_t *)&Buffer[3], 1);
	ESP_LOGI(_TAG, "TouchPad ID: 0x%02x-0x%02x-0x%02x", Buffer[0], Buffer[1], Buffer[2]);
	ESP_LOGI(_TAG, "TouchPad Config Version: %d", Buffer[3]);
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchGT911::i2cRead(uint16_t Register, uint8_t *pData, uint8_t Length)
{
	assert(pData != NULL);
	return esp_lcd_panel_io_rx_param(m_hIO, Register, pData, Length);
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchGT911::i2cWrite(uint16_t Register, uint8_t *pData, uint8_t Length)
{
	assert(pData != NULL);
	return esp_lcd_panel_io_tx_param(m_hIO, Register, pData, Length);
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchGT911::I2CInit(uint16_t Addr)
{
#ifdef GT911_CONFIGURE_I2C_PORT
i2c_config_t i2cConf = {
  .mode = I2C_MODE_MASTER,
  .sda_io_num = I2CTouchSdaIO_c,
  .scl_io_num = I2CTouchSclIO_c,
  .sda_pullup_en = GPIO_PULLUP_ENABLE,
  .scl_pullup_en = GPIO_PULLUP_ENABLE,
  .master{
    .clk_speed = I2C_MASTER_FREQ_HZ,
  },
  .clk_flags = I2C_SCLK_SRC_FLAG_FOR_NOMAL
};

	i2c_param_config(I2CTouchMaster_c, &i2cConf);                        // Configure I2C parameters
	return i2c_driver_install(I2CTouchMaster_c, i2cConf.mode, 0, 0, 0);  // Install I2C driver
#else
  return ESP_OK;
#endif
}

/////////////////////////////////////////////////////////////////////////////////////

// Reset controller
esp_err_t ESPGLTouchGT911::Reset(void)
{
	// Reset the touch screen. It is recommended to reset the touch screen before using it.
	gpio_set_level(I2CTouchIntIO_c, 0); 
	pCH422->WriteControl(0x01);
	pCH422->WriteOutput(0x2C);  // set reset low
	esp_rom_delay_us(100 * 1000);
	gpio_set_level(I2CTouchIntIO_c, m_IntPinLevel); 
	esp_rom_delay_us(100 * 1000);
	pCH422->WriteOutput(0x2E);  // set reset high
	esp_rom_delay_us(200 * 1000);
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchGT911::Configure(const esp_lcd_panel_io_handle_t hIO, const ESPGL_LCDTouchConfig_t *pConfig)
{
esp_err_t ret = ESP_OK;
gpio_config_t io_conf = {};  // Zero-initialize the config structure

	assert(hIO != nullptr);
	assert(pConfig != nullptr);
	m_hIO = hIO;                                                 // Communication interface
	memcpy(&m_Config, pConfig, sizeof(ESPGL_LCDTouchConfig_t));  // Save config
	if(m_Config.ResetPin != GPIO_NUM_NC) {
		io_conf.intr_type = GPIO_INTR_DISABLE;
		io_conf.pin_bit_mask = BIT64(m_Config.ResetPin);
		io_conf.mode = GPIO_MODE_OUTPUT;
		ret = gpio_config(&io_conf);
		ESP_GOTO_ON_ERROR(ret, err, _TAG, "GPIO config failed");
	}
  if(ESP_I2C_GT911_ADDRESS_ALT == m_Config.DeviceAddress)	m_IntPinLevel = 1;
  else if(ESP_I2C_GT911_ADDRESS == m_Config.DeviceAddress) m_IntPinLevel = 0;
  else {
    m_IntPinLevel = 0;
    ESP_LOGE(_TAG, "Addr (0x%X) is invalid", m_Config.DeviceAddress);
  }
	if(m_Config.ResetPin != GPIO_NUM_NC && m_Config.InterruptPin != GPIO_NUM_NC) {
    ESP_LOGI(_TAG, "Using IO reset pin to initialize the I2C address");
		io_conf.mode = GPIO_MODE_OUTPUT; /* Prepare pin for touch controller int */
		io_conf.intr_type = GPIO_INTR_DISABLE;
		io_conf.pull_down_en = GPIO_PULLDOWN_DISABLE;
		io_conf.pull_up_en = GPIO_PULLUP_ENABLE;
		io_conf.pin_bit_mask = BIT64(m_Config.InterruptPin);
		ret = gpio_config(&io_conf);
		ESP_GOTO_ON_ERROR(ret, err, _TAG, "GPIO config failed");
		ESP_RETURN_ON_ERROR(gpio_set_level(m_Config.ResetPin, m_Config.Levels.Reset), _TAG, "GPIO set level error!");
		ESP_RETURN_ON_ERROR(gpio_set_level(m_Config.InterruptPin, 0), _TAG, "GPIO set level error!");
		vTaskDelay(pdMS_TO_TICKS(10));
		ESP_RETURN_ON_ERROR(gpio_set_level(m_Config.InterruptPin, m_IntPinLevel), _TAG, "GPIO set level error!");
		vTaskDelay(pdMS_TO_TICKS(1));
		ESP_RETURN_ON_ERROR(gpio_set_level(m_Config.ResetPin, !m_Config.Levels.Reset), _TAG, "GPIO set level error!");
		vTaskDelay(pdMS_TO_TICKS(60));
	}
	else{
  	if(m_Config.InterruptPin != GPIO_NUM_NC) {
      ESP_LOGI(_TAG, "Using external reset pin to initialize the I2C address");
      io_conf.mode = GPIO_MODE_OUTPUT; /* Prepare pin for touch controller int */
      io_conf.intr_type = GPIO_INTR_DISABLE;
      io_conf.pull_down_en = GPIO_PULLDOWN_DISABLE;
      io_conf.pull_up_en = GPIO_PULLUP_ENABLE;
      io_conf.pin_bit_mask = BIT64(m_Config.InterruptPin);
      ret = gpio_config(&io_conf);
      ESP_GOTO_ON_ERROR(ret, err, _TAG, "GPIO config failed");
  		ESP_RETURN_ON_ERROR(gpio_set_level(m_Config.InterruptPin, 0), _TAG, "GPIO set level error!");
      pCH422->WriteControl(0x01);
      pCH422->WriteOutput(0x2C);  // set reset low
  		vTaskDelay(pdMS_TO_TICKS(10));
  		ESP_RETURN_ON_ERROR(gpio_set_level(m_Config.InterruptPin, m_IntPinLevel), _TAG, "GPIO set level error!");
  		vTaskDelay(pdMS_TO_TICKS(1));
      pCH422->WriteOutput(0x2E);  // set reset high
  		vTaskDelay(pdMS_TO_TICKS(60));
    }
    else{
      ESP_LOGW(_TAG, "Unable to initialize the I2C address");
      ret = Reset();  // Reset controller
      ESP_GOTO_ON_ERROR(ret, err, _TAG, "GT911 reset failed");
    }
  }
	if(m_Config.InterruptPin != GPIO_NUM_NC) { // Prepare pin for touch interrupt 
		io_conf.mode = GPIO_MODE_INPUT;
		io_conf.intr_type = (m_Config.Levels.Interrupt ? GPIO_INTR_POSEDGE : GPIO_INTR_NEGEDGE);
		io_conf.pin_bit_mask = BIT64(m_Config.InterruptPin);
		ret = gpio_config(&io_conf);
		ESP_GOTO_ON_ERROR(ret, err, _TAG, "GPIO config failed");
		if(m_Config.InterruptCB) {	// Register interrupt callback 
			RegisterInterruptCB(m_Config.InterruptCB);
		}
	}
	ReadConfig();

err:
	if(ret != ESP_OK) {
		ESP_LOGE(_TAG, "Error (0x%x)! Touch controller GT911 initialization failed!", ret);
	}
	return ret;
}

/////////////////////////////////////////////////////////////////////////////////////

void ESPGLTouchGT911::Initialise(void)
{
	ESP_LOGI(_TAG, "Initialize touch IO (I2C)");
	esp_lcd_panel_io_handle_t hIO = nullptr;
	esp_lcd_panel_io_i2c_config_t IOConfig = ESP_LCD_TOUCH_IO_I2C_GT911_CONFIG();
  I2CInit(IOConfig.dev_addr);
 	esp_lcd_new_panel_io_i2c((uint32_t)I2CTouchMaster_c, &IOConfig, &hIO);
	ESPGL_LCDTouchConfig_t HWConfig = {
		.MaxX = LCD_TOUCH_V_RES,
		.MaxY = LCD_TOUCH_H_RES,
		.ResetPin = I2CTouchResetIO_c,
		.InterruptPin = I2CTouchIntIO_c,
		.Levels = {
			.Reset = 0,
			.Interrupt = 0,
		},
		.Flags = {
			.SwapXY = 0, .MirrorX = 0, .MirrorY = 0,
		},
		.InterruptCB = NULL,
    .DeviceAddress = IOConfig.dev_addr
  };
	m_ScaleX = 1.0;
	m_ScaleY = 1.0;
	ESP_LOGI(_TAG, "Initialize touch controller GT911");
	ESP_ERROR_CHECK(Configure(hIO, &HWConfig));
}
