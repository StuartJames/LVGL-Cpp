/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#pragma once

#include "driver/gpio.h"
#include "driver/sdmmc_host.h"
#include "esp_lcd_types.h"
#include "sdkconfig.h"
#include "I2CDriver.h"
#include "EGL.h"
#include "ESPEGPort.h"
#include "ESPEGTouchGT911.h"
#include "CH422Driver.h"

/**************************************************************************************************
 *  BSP BOARD_ESP32_S3_TOUCH_LCD_7 Capabilities 
 **************************************************************************************************/

const gpio_num_t 	      c_I2CSCLPin         = GPIO_NUM_9;     // GPIO number used for I2C master clock 
const gpio_num_t 	      c_I2CSDAPin         = GPIO_NUM_8;     // GPIO number used for I2C master data  
const i2c_port_t 	      c_I2CPort           = I2C_NUM_0;       // I2C master i2c port number

#define BSP_LCD_COLOR_FORMAT_RGB565    	(1)
#define BSP_LCD_COLOR_FORMAT_RGB888    	(2)

#define BSP_LCD_COLOR_BITS_RGB565       (16)
#define BSP_LCD_COLOR_BITS_RGB666       (18)
#define BSP_LCD_COLOR_BITS_RGB888       (24)

#define BSP_LCD_H_RES               		(800)
#define BSP_LCD_V_RES               		(480)

#define BSP_CAPS_DISPLAY        1
#define BSP_CAPS_TOUCH          0
#define BSP_CAPS_BUTTONS        1
#define BSP_CAPS_AUDIO          0
#define BSP_CAPS_AUDIO_SPEAKER  0
#define BSP_CAPS_AUDIO_MIC      0
#define BSP_CAPS_LED            1
#define BSP_CAPS_SDCARD         1
#define BSP_CAPS_IMU            0

#define BSP_LCD_DRAW_BUFF_SIZE      BSP_LCD_H_RES * 30 // default, maybe modified
#define BSP_LCD_DRAW_BUFF_DOUBLE    1

#define BSP_SPIFFS_MOUNT_POINT      CONFIG_BSP_SPIFFS_MOUNT_POINT
#define BSP_SD_MOUNT_POINT      		CONFIG_BSP_SD_MOUNT_POINT

// RGB bus
#define BSP_LCD_RGB_HPW             (4)
#define BSP_LCD_RGB_HBP             (8)
#define BSP_LCD_RGB_HFP             (8)
#define BSP_LCD_RGB_VPW             (4)
#define BSP_LCD_RGB_VBP             (8)
#define BSP_LCD_RGB_VFP             (8)
#define BSP_LCD_RGB_PCLK_ACTIVE_NEG (1)     // 0: rising edge, 1: falling edge. Typically set to 0
#define BSP_RGB_BOUNCE_BUFFER_SIZE  (BSP_LCD_H_RES * CONFIG_BSP_LCD_RGB_BOUNCE_BUFFER_HEIGHT)
                                                    // Bounce buffer size in bytes. It is used to avoid screen drift
                                                    // for ESP32-S3. Typically set to `ESP_PANEL_BOARD_WIDTH * 10`
                                                    // The size should satisfy `size * N = LCD_width * LCD_height`,
                                                    // where N is an even number.
                                                    // For more details, see: https://github.com/esp-arduino-libs/ESP32_Display_Panel/blob/master/docs/FAQ.md#how-to-fix-screen-drift-issue-when-driving-rgb-lcd-with-esp32-s3
#define BSP_LCD_PIXEL_CLOCK_HZ      (16 * 1000 * 1000)
#define BSP_LCD_IO_RGB_DISP         (-1)            // -1 if not used
#define BSP_LCD_IO_RGB_VSYNC        (GPIO_NUM_3)
#define BSP_LCD_IO_RGB_HSYNC        (GPIO_NUM_46)
#define BSP_LCD_IO_RGB_DE           (GPIO_NUM_5)
#define BSP_LCD_IO_RGB_PCLK         (GPIO_NUM_7)
#define BSP_LCD_IO_RGB_DISP         (-1)            // -1 if not used. Typically set to -1

                                                                  // The following sheet shows the valid combinations of
                                                                  // data width and pixel bits:
                                                                  // ┏---------------------------------┳- -------------------------------┓
#define BSP_RGB_DATA_WIDTH          (16)                          // |                16               |               8                 |
#define BSP_LCD_RGB_PIXEL_BITS      (BSP_LCD_COLOR_BITS_RGB565)   // | ESP_PANEL_LCD_COLOR_BITS_RGB565 | ESP_PANEL_LCD_COLOR_BITS_RGB888 |
                                                                  // ┗---------------------------------┻---------------------------------┛

                                                    // The following sheet shows the mapping of ESP GPIOs to
                                                    // LCD data pins with different data width and color form
                                                    // ┏------┳- ------------┳--------------------------┓
                                                    // | ESP: | 8-bit RGB888 |      16-bit RGB565       |
                                                    // |------|--------------|--------------------------|
                                                    // | LCD: |    RGB888    | RGB565 | RGB666 | RGB888 |
                                                    // ┗------|--------------|--------|--------|--------|
#define BSP_LCD_IO_RGB_DATA0        (GPIO_NUM_14)   //        |      D0      |   B0   |  B0-1  |   B0-3 |
#define BSP_LCD_IO_RGB_DATA1        (GPIO_NUM_38)   //        |      D1      |   B1   |  B2    |   B4   |
#define BSP_LCD_IO_RGB_DATA2        (GPIO_NUM_18)   //        |      D2      |   B2   |  B3    |   B5   |
#define BSP_LCD_IO_RGB_DATA3        (GPIO_NUM_17)   //        |      D3      |   B3   |  B4    |   B6   |
#define BSP_LCD_IO_RGB_DATA4        (GPIO_NUM_10)   //        |      D4      |   B4   |  B5    |   B7   |
#define BSP_LCD_IO_RGB_DATA5        (GPIO_NUM_39)   //        |      D5      |   G0   |  G0    |   G0-2 |
#define BSP_LCD_IO_RGB_DATA6        (GPIO_NUM_0)    //        |      D6      |   G1   |  G1    |   G3   |
#define BSP_LCD_IO_RGB_DATA7        (GPIO_NUM_45)   //        |      D7      |   G2   |  G2    |   G4   |
//                                                            ┗--------------┫--------|--------|--------|
#define BSP_LCD_IO_RGB_DATA8        (GPIO_NUM_48)   //                       |   G3   |  G3    |   G5   |
#define BSP_LCD_IO_RGB_DATA9        (GPIO_NUM_47)   //                       |   G4   |  G4    |   G6   |
#define BSP_LCD_IO_RGB_DATA10       (GPIO_NUM_21)   //                       |   G5   |  G5    |   G7   |
#define BSP_LCD_IO_RGB_DATA11       (GPIO_NUM_1)    //                       |   R0   |  R0-1  |   R0-3 |
#define BSP_LCD_IO_RGB_DATA12       (GPIO_NUM_2)    //                       |   R1   |  R2    |   R4   |
#define BSP_LCD_IO_RGB_DATA13       (GPIO_NUM_42)   //                       |   R2   |  R3    |   R5   |
#define BSP_LCD_IO_RGB_DATA14       (GPIO_NUM_41)   //                       |   R3   |  R4    |   R6   |
#define BSP_LCD_IO_RGB_DATA15       (GPIO_NUM_40)   //                       |   R4   |  R5    |   R7   |
                                                    //                       ┗--------┻--------┻--------┛

// LCD color configuration
#define BSP_LCD_BIGENDIAN           (1) 				// LCD display color bytes endianess 
#define BSP_LCD_BITS_PER_PIXEL      (16)        // LCD display color bits 

#define BSP_LCD_COLOR_SPACE         (ESP_LCD_COLOR_SPACE_RGB) // LCD display color space 

#define BSP_LCD_COLOR_FORMAT        (BSP_LCD_COLOR_FORMAT_RGB888)   // BSP_LCD_COLOR_FORMAT_RGB565/RGB666/RGB888
#define BSP_LCD_COLOR_BGR_ORDER     (0)             // 0: RGB, 1: BGR
#define BSP_LCD_COLOR_INEVRT_BIT    (0)             // 0/1

// LCD transformation configuration
#define BSP_LCD_SWAP_XY             (0)     // 0/1
#define BSP_LCD_MIRROR_X            (0)     // 0/1
#define BSP_LCD_MIRROR_Y            (0)     // 0/1
#define BSP_LCD_GAP_X               (0)     // [0, ESP_PANEL_BOARD_WIDTH]
#define BSP_LCD_GAP_Y               (0)     // [0, ESP_PANEL_BOARD_HEIGHT]

// LCD reset pin and Backlight configuration
#define BSP_LCD_IO_RST              (-1)            // -1 if not used
#define BSP_BACK_LIGHT_PIN          (GPIO_NUM_2)    // -1 if not used
#define BSP_BACK_LIGHT_ON_LEVEL     (1)
#define BSP_BACK_LIGHT_OFF_LEVEL    !BSP_LCD_BK_LIGHT_ON_LEVEL

// Touch I2C bus
#define BSP_TOUCH_I2C_HOST_ID       (0)     // Typically set to 0
#define BSP_TOUCH_I2C_CLK_HZ        (400 * 1000)
                                            // Typically set to 400K
#define BSP_TOUCH_I2C_SCL_PULLUP    (1)     // 0/1. Typically set to 1
#define BSP_TOUCH_I2C_SDA_PULLUP    (1)     // 0/1. Typically set to 1
#define BSP_TOUCH_I2C_IO_SCL        (9)
#define BSP_TOUCH_I2C_IO_SDA        (8)
// For panel 
#define BSP_TOUCH_I2C_ADDRESS       (0)     // Typically set to 0 to use the default address.
                                                            // - For touchs with only one address, set to 0
                                                            // - For touchs with multiple addresses, set to 0 or
                                                            //   the address. Like GT911, there are two addresses:
                                                            //   0x5D(default) and 0x14

#define BSP_TOUCH_SWAP_XY           (0)     // 0/1
#define BSP_TOUCH_MIRROR_X          (0)     // 0/1
#define BSP_TOUCH_MIRROR_Y          (0)     // 0/1

//Touch panel control pins
#define BSP_TOUCH_RST_IO            (-1)    // Reset pin, -1 if not used or controled by external IO
#define BSP_TOUCH_RST_LEVEL         (0)     // Reset active level, 0: low, 1: high
#define BSP_TOUCH_INT_PIN           (GPIO_NUM_4)     // Interrupt pin, -1 if not used
#define BSP_TOUCH_INT_LEVEL         (0)     // Interrupt active level, 0: low, 1: high


#define BSP_CH422_NC                  0x01     
#define BSP_CH422_TP_RES              0x02
#define BSP_CH422_DISP_EN             0x04
#define BSP_CH422_LCD_RES             0x08
#define BSP_CH422_SDCARD_SEL          0x10
#define BSP_CH422_USB_SEL             0x20
#define BSP_CH422_LCD_VDD_EN          0x40

/////////////////////////////////////////////////////////////////////////////////////

typedef enum bsp_led_t {
    BSP_LED_RED = GPIO_NUM_0,
    BSP_LED_GREEN = GPIO_NUM_2,
    BSP_LED_BLUE = GPIO_NUM_4
} bsp_led_t;

typedef enum {
  BSP_BUTTON_BOOT,
  BSP_BUTTON_NUM
} bsp_button_t;

/////////////////////////////////////////////////////////////////////////////////////

extern sdmmc_card_t *pSDCard;
extern I2CDriver    *pi2cDev;
extern CH422Driver  *pCH422;

/////////////////////////////////////////////////////////////////////////////////////


esp_err_t     LED_Initialise(void);
esp_err_t 		Set_LED(const bsp_led_t LEDRef, const bool State);
esp_err_t 		MountSPIFFS(void);
esp_err_t 		UnmountSPIFFS(void);
esp_err_t 		MountSDCard(void);
esp_err_t 		UnmountSDCard(void);
esp_err_t 		BacklightIntialise(gpio_num_t BackLightPin);
esp_err_t 		SetBacklightLevel(int Intensity);
esp_err_t 		BacklightOn(void);
esp_err_t 		BacklightOff(void);
esp_err_t 		InitialiseDisplayIO(esp_lcd_panel_handle_t *hPanel);
EGDisplay* 		LCD_Initialise(void);
EGDisplay 	  *DisplayStart(void);
EGInputDevice	*GetInputDevice(void);
bool 					DisplayLock(uint32_t Timeout);
void 					DisplayUnlock(void);
void 					DisplayRotate(EGDisplay *pDisplay, EG_DisplayRotation_e Rotation);

