/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by Espressif Systems (Shanghai) CO LTD
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#pragma once

#include <inttypes.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>

#include "esp_bit_defs.h"
#include "esp_check.h"
#include "esp_log.h"

#include "I2CDriver.h"
#include "esp_err.h"

////////////////////////////////////////////////////////////////////////

#define IO_COUNT                (8)

/* Register address */
#define CH422G_REG_CONTROL      (0x24)
#define CH422G_REG_IN           (0x26)
#define CH422G_REG_OUT          (0x38)
#define CH422G_REG_OC           (0x23)

/* Default register value on power-up */
#define DIR_REG_DEFAULT_VAL     (0xff)
#define OUT_REG_DEFAULT_VAL     (0xdf)

#define VALID_IO_COUNT()        (m_IOCount <= IO_COUNT ? m_IOCount : IO_COUNT)


////////////////////////////////////////////////////////////////////////

class CH422Driver
{
public:
                    CH422Driver(I2CDriver *pi2cBus);
                    ~CH422Driver(void){};
  esp_err_t         WriteControl(uint8_t Value);
  esp_err_t         ReadInput(uint8_t *pValue);
  esp_err_t         WriteOutput(uint8_t Data);
  esp_err_t         WriteOC(uint8_t Data);
  esp_err_t         Reset(void);

private:
 
	I2CDriver 	      *m_pI2C;
};

