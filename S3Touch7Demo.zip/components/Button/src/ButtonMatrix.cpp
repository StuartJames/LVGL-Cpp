/*
 *              EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#include <inttypes.h>
#include "esp_log.h"
#include "esp_check.h"
#include "driver/gpio.h"
#include "ButtonMatrix.h"

/////////////////////////////////////////////////////////////////////////////////////

static const char *TAG = "[Butrix]";

/////////////////////////////////////////////////////////////////////////////////////

typedef struct {
	gpio_num_t row_gpio_num; /**< row gpio */
	gpio_num_t col_gpio_num; /**< col gpio */
} button_matrix_obj;

/////////////////////////////////////////////////////////////////////////////////////

ButtonMatrix::ButtonMatrix(void)
{
}

/////////////////////////////////////////////////////////////////////////////////////

ButtonMatrix::~ButtonMatrix()
{
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t ButtonMatrix::GetKeyLevel(int Index)
{
	gpio_set_level(m_pRowList[Index], 1);
	uint8_t level = gpio_get_level(m_pColumnList[Index]);
	gpio_set_level(m_pRowList[Index], 0);
	return level;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ButtonMatrix::Delete(int Index)
{
	//Reset an gpio to default state (select gpio function, enable pullup and disable input and output).
	gpio_reset_pin(m_pRowList[Index]);
	gpio_reset_pin(m_pRowList[Index]);
	delete m_pMatrix[Index];
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

/* This function initializes and configures a button matrix device using the specified row and column GPIOs.
 * Each button in the matrix is represented as an independent button object, and its handle is returned in the `ret_button` array. */
esp_err_t ButtonMatrix::Create(const ButtonConfig_t *pConfig, const ButtonMatrixConfig_t *pMatrixConfig, size_t *pSize)
{
esp_err_t ret = ESP_OK;
ESPButton *pButton = nullptr;

  m_RowCount = pMatrixConfig->RowCount;
  m_ColumnCount = pMatrixConfig->ColumnCount;
  m_pRowList = (gpio_num_t*)calloc(m_RowCount, sizeof(gpio_num_t));
  m_pColumnList = (gpio_num_t*)calloc(m_ColumnCount, sizeof(gpio_num_t));
  *m_pMatrix = (ESPButton*)calloc(*pSize, sizeof(ESPButton));
	for(int i = 0; i < m_RowCount; i++) InitialiseIO(pMatrixConfig->pRowList[i], GPIO_MODE_OUTPUT);
	for(int i = 0; i < m_ColumnCount; i++) InitialiseIO(pMatrixConfig->pColumnList[i], GPIO_MODE_INPUT);
	for(int i = 0; i < *pSize; i++) {
		m_pRowList[i] = pMatrixConfig->pRowList[i / pMatrixConfig->RowCount];
		m_pColumnList[i] = pMatrixConfig->pColumnList[i % pMatrixConfig->ColumnCount];
		ESP_LOGD(TAG, "row_gpio_num: %" PRId32 ", col_gpio_num: %" PRId32 "", m_pRowList[i], m_pColumnList[i]);
		ret = NewButton(pConfig, pButton);
		ESP_GOTO_ON_FALSE(ret == ESP_OK, ESP_FAIL, err, TAG, "Create button failed");
    pButton->m_MatrixIndex = i;
    m_pMatrix[i] = pButton;
	}
	*pSize = m_RowCount * m_ColumnCount;
	return ESP_OK;

err:
	if(*m_pMatrix) free(*m_pMatrix);
	if(m_pColumnList) free(m_pColumnList);
	if(m_pRowList) free(m_pRowList);
  return ret;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ButtonMatrix::InitialiseIO(int32_t gpio_num, gpio_mode_t mode)
{
	ESP_RETURN_ON_FALSE(GPIO_IS_VALID_GPIO(gpio_num), ESP_ERR_INVALID_ARG, TAG, "gpio_num error");
	gpio_config_t gpio_conf = {};
	gpio_conf.intr_type = GPIO_INTR_DISABLE;
	gpio_conf.pull_down_en = GPIO_PULLDOWN_ENABLE;
	gpio_conf.pin_bit_mask = (1ULL << gpio_num);
	gpio_conf.mode = mode;
	gpio_config(&gpio_conf);
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

/* This function initializes and configures a button matrix device using the specified row and column GPIOs.
 * Each button in the matrix is represented as an independent button object, and its handle is returned in the `ret_button` array. */
esp_err_t NewMatrix(const ButtonConfig_t *pConfig, const ButtonMatrixConfig_t *pMatrixConfig, ButtonMatrix *pMatrix, size_t *pSize)
{
	ESP_RETURN_ON_FALSE(pConfig && pMatrixConfig && pMatrix, ESP_ERR_INVALID_ARG, TAG, "Invalid argument");
	ESP_RETURN_ON_FALSE(pMatrixConfig->pRowList && pMatrixConfig->pColumnList, ESP_ERR_INVALID_ARG, TAG, "Invalid matrix config");
	ESP_RETURN_ON_FALSE(pMatrixConfig->RowCount > 0 && pMatrixConfig->ColumnCount > 0, ESP_ERR_INVALID_ARG, TAG, "Invalid matrix config");
	ESP_RETURN_ON_FALSE(*pSize == pMatrixConfig->RowCount * pMatrixConfig->ColumnCount, ESP_ERR_INVALID_ARG, TAG, "Invalid size");
  pMatrix = new ButtonMatrix;
  return pMatrix->Create(pConfig, pMatrixConfig, pSize);
}

