/*
 *              EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#pragma once

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/timers.h"
#include "driver/gpio.h"
#include "esp_timer.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_check.h"
#include "Button.h"
#include "sdkconfig.h"

/////////////////////////////////////////////////////////////////////////////////////

#define BTN_CHECK(a, str, ret_val)                             \
	if(!(a)) {                                                   \
		ESP_LOGE(_TAG, "%s(%d): %s", __FUNCTION__, __LINE__, str); \
		return (ret_val);                                          \
	}

/////////////////////////////////////////////////////////////////////////////////////

enum {
	PRESS_DOWN_CHECK = 0,
	PRESS_UP_CHECK,
	PRESS_REPEAT_DOWN_CHECK,
	PRESS_REPEAT_UP_CHECK,
	PRESS_LONG_PRESS_UP_CHECK,
};

typedef enum {
    BUTTON_PRESS_DOWN = 0,
    BUTTON_PRESS_UP,
    BUTTON_PRESS_REPEAT,
    BUTTON_PRESS_REPEAT_DONE,
    BUTTON_SINGLE_CLICK,
    BUTTON_DOUBLE_CLICK,
    BUTTON_MULTIPLE_CLICK,
    BUTTON_LONG_PRESS_START,
    BUTTON_LONG_PRESS_HOLD,
    BUTTON_LONG_PRESS_UP,
    BUTTON_PRESS_END,
    BUTTON_EVENT_MAX,
    BUTTON_NONE_PRESS,
} ButtonEvent_e;

enum {
    BUTTON_INACTIVE = 0,
    BUTTON_ACTIVE,
};

typedef enum {
    BUTTON_LONG_PRESS_TIME_MS = 0,
    BUTTON_SHORT_PRESS_TIME_MS,
    BUTTON_PARAM_MAX,
} ButtonParam_e;

/////////////////////////////////////////////////////////////////////////////////////

typedef void (* ButtonCB_t)(void *phandle, void *pUserData);
typedef void (* ButtonPowerSaveCB_t)(void *pUserData);

typedef struct {
    ButtonPowerSaveCB_t EnterPowerSaveCB;  // Callback function when entering power save mode 
    void *pUserData;                              // User data for the callback 
} ButtonPowerSaveConfig_t;

struct ButtonDriver_t {
  bool        PowerSave;    // (optional) Need Support Power Save 
  uint8_t     (*GetKeyLevel)(void);    // (necessary) Get key level 
  esp_err_t   (*EnterPowerSave)(void);   // (optional) Enter Power Save cb 
};

typedef struct {
    uint16_t LongPressTime;          // Trigger time(ms) for long press, if 0 default to BUTTON_LONG_PRESS_TIME_MS 
    uint16_t ShortPressTime;         // Trigger time(ms) for short press, if 0 default to BUTTON_SHORT_PRESS_TIME_MS 
} ButtonConfig_t;

typedef union {
    struct long_press_t {
        uint16_t PressTime;    // press time(ms) for the corresponding callback to trigger 
    } LongPress;               // long press struct, for event BUTTON_LONG_PRESS_START and BUTTON_LONG_PRESS_UP 
    struct multiple_clicks_t {
        uint16_t Clicks;        // number of clicks, to trigger the callback 
    } MultipleClicks;          // multiple clicks struct, for event BUTTON_MULTIPLE_CLICK 
} ButtonEventArgs_t;

typedef struct {
	ButtonCB_t Callback;
	void *pUserData;
	ButtonEventArgs_t EventArgs;
} ButtonCBInfo_t;

/////////////////////////////////////////////////////////////////////////////////////

class ESPButton;

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t NewButton(const ButtonConfig_t *pConfig, ESPButton *pButton);
esp_err_t DeleteButton(ESPButton *pButton);

size_t    ButtonCountCB(ESPButton *pButton);
size_t    ButtonCountEventCB(ESPButton *pButton, ButtonEvent_e Event);

/////////////////////////////////////////////////////////////////////////////////////

class ESPButton
{
public:
                      ESPButton(void);
  virtual             ~ESPButton();
  esp_err_t           Create(const ButtonConfig_t *pConfig);
  ButtonEvent_e       GetEvent(void);
  const char*         GetEventString(ButtonEvent_e event);
  esp_err_t           PrintEvent(void);
  uint8_t             GetRepeat(void);
  uint32_t            GetTicksTime(void);
  uint16_t            GetLongPressHoldCount(void);
  esp_err_t           SetParameters(ButtonParam_e Param, void *pValue);
  esp_err_t           Resume(void);
  esp_err_t           Stop(void);
  void                EventHandler(void);

  virtual uint8_t     GetKeyLevel(void);

  esp_err_t           (*PowerSaveFunc)(ESPButton *pButton);   // (optional) Enter Power Save cb 

  uint32_t            m_Ticks;              // Count for the current button state. 
	uint32_t            m_LongPressTicks;     // Trigger ticks for long press,  
	uint32_t            m_ShortPressTicks;    // Trigger ticks for repeat press 
	uint32_t            m_LongPressHoldCount; // Record long press hold count 
	uint8_t             m_Repeat;
	uint8_t             m_State : 3;
	uint8_t             m_DebounceCount : 4;  // Max 15 
	uint8_t             m_Level : 1;
	ButtonEvent_e       m_Event;
  bool                m_PowerSave;          // (optional) Require support for power save 
	ButtonCBInfo_t     *m_CallbackInfo[BUTTON_EVENT_MAX];
	size_t              m_EventSize[BUTTON_EVENT_MAX];
	int                 m_Count[2];
	ESPButton          *m_pNext;
  int                 m_MatrixIndex;        // only used when button is part of a matrix

  static ESPButton   *m_pListHead;          //button handle list head.
  static esp_timer_handle_t   m_hTimer;
  static bool         m_TimeIsRunning;

private:

  esp_err_t           RegisterPowerSaveCB(const ButtonPowerSaveConfig_t *pConfig);
  esp_err_t           RegisterCB(ButtonEvent_e Event, ButtonEventArgs_t *pEventArgs, ButtonCB_t Callback, void *pUserData);
  esp_err_t           UnregisterCB(ButtonEvent_e Event, ButtonEventArgs_t *pEventArgs);
  void                CallEventFunctio(ButtonEvent_e Event);
};

/////////////////////////////////////////////////////////////////////////////////////

inline void ESPButton::CallEventFunctio(ButtonEvent_e Event)
{
	if(m_CallbackInfo[Event]) {                                      
		for(int i = 0; i < m_EventSize[Event]; i++) {        
			m_CallbackInfo[Event][i].Callback(this, m_CallbackInfo[Event][i].pUserData);
		}                                     
	}
};

/////////////////////////////////////////////////////////////////////////////////////






