/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= ===========================================
 * SJ    2025/08/18   1.a.1    Original by ESP
 *
 */

 #pragma once

#include <stdint.h>
#include <string.h>  // For memcpy
#include <esp_log.h>
#include <driver/gpio.h>
#include <driver/i2c.h>

/////////////////////////////////////////////////////////////////////////////////////

class I2CDriver
{
public:
                  I2CDriver();
  void            Initialise(gpio_num_t SCL, gpio_num_t SDA, i2c_port_t Port);
  esp_err_t       Write(uint8_t Address, const uint8_t *pData, uint32_t Length);
  esp_err_t       Write(uint8_t Address, uint8_t Register, const uint8_t *pData, uint32_t Length);
  esp_err_t       Write16(uint8_t Address, uint16_t Register, const uint8_t *pData, uint32_t Length);
  esp_err_t       Read(uint8_t Address, uint8_t *pData, uint32_t Length);
  esp_err_t       Read(uint8_t Address, uint8_t Register, uint8_t *pData, uint32_t Length);
  esp_err_t       Read16(uint8_t Address, uint16_t Register, uint8_t *pData, uint32_t Length);

private:
  i2c_port_t                m_Port;
  gpio_num_t                m_SCLPin;      // GPIO number used for I2C master clock 
  gpio_num_t                m_SDAPin;      // GPIO number used for I2C master data  
};