/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= ===========================================
 * SJ    2025/08/18   1.a.1    Original by ESP
 *
 */

#include "SD_MMC.h"

/////////////////////////////////////////////////////////////////////////////////////

const gpio_num_t CARD_SLOT_PIN_CLK = GPIO_NUM_14;
const gpio_num_t CARD_SLOT_PIN_CMD = GPIO_NUM_17;
const gpio_num_t CARD_SLOT_PIN_D0 = GPIO_NUM_16;
const gpio_num_t CARD_SLOT_PIN_D1 = GPIO_NUM_NC;
const gpio_num_t CARD_SLOT_PIN_D2 = GPIO_NUM_NC;
const gpio_num_t CARD_SLOT_PIN_D3 = GPIO_NUM_NC;

/////////////////////////////////////////////////////////////////////////////////////

static const char *_TAG = "[SD    ]";

/////////////////////////////////////////////////////////////////////////////////////

SDMMCDevice::SDMMCDevice(void)
{
	m_FlashSize = 0;
	m_SDCardSize = 0;
}

/////////////////////////////////////////////////////////////////////////////////////

// Options for mounting the filesystem.
// If format_if_mount_failed is set to true, SD card will be partitioned and formatted in case when mounting fails.  false true
// By default, SD card frequency is initialized to SDMMC_FREQ_DEFAULT (20MHz)
// For setting a specific frequency, use host.max_freq_khz (range 400kHz - 20MHz for SDSPI)
// Example: for fixed frequency of 10MHz, use host.max_freq_khz = 10000;
// This initializes the slot without card detect (CD) and write protect (WP) signals.
// Modify slot_config.gpio_cd and slot_config.gpio_wp if your board has these signals.
void SDMMCDevice::Initialise(const char *pMountPoint)
{
esp_err_t Ret;
esp_vfs_fat_sdmmc_mount_config_t MountConfig = {
	.format_if_mount_failed = true,
	.max_files = 5,
	.allocation_unit_size = 16 * 1024,
	.disk_status_check_enable = false,
	.use_one_fat = false
};
sdmmc_card_t *pCard;

	ESP_LOGI(_TAG, "Initializing SD card");
	m_pMountPoint = pMountPoint;
	sdmmc_host_t Host = SDMMC_HOST_DEFAULT();
	sdmmc_slot_config_t SlotConfig = SDMMC_SLOT_CONFIG_DEFAULT();
	SlotConfig.width = 1;  // 1-wire  / 4-wire   SlotConfig.width = 4;
	SlotConfig.clk = CARD_SLOT_PIN_CLK;
	SlotConfig.cmd = CARD_SLOT_PIN_CMD;
	SlotConfig.d0 = CARD_SLOT_PIN_D0;
	SlotConfig.d1 = CARD_SLOT_PIN_D1;
	SlotConfig.d2 = CARD_SLOT_PIN_D2;
	SlotConfig.d3 = CARD_SLOT_PIN_D3;
	SlotConfig.flags |= SDMMC_SLOT_FLAG_INTERNAL_PULLUP;
	ESP_LOGI(_TAG, "Mounting filesystem");
	Ret = esp_vfs_fat_sdmmc_mount(pMountPoint, &Host, &SlotConfig, &MountConfig, &pCard);
	if(Ret != ESP_OK) {
		if(Ret == ESP_FAIL) ESP_LOGE(_TAG, "Failed to mount filesystem. ");
		else ESP_LOGE(_TAG, "Failed to initialize the card (%s). ", esp_err_to_name(Ret));
		return;
	}
	ESP_LOGI(_TAG, "Filesystem mounted");
	sdmmc_card_print_info(stdout, pCard);	// Card has been initialized, print its properties
	m_SDCardSize = ((uint64_t)pCard->csd.capacity) * pCard->csd.sector_size / (1024 * 1024);
}

/////////////////////////////////////////////////////////////////////////////////////

void SDMMCDevice::GetFlashSize(void)
{
	if(esp_flash_get_physical_size(NULL, &m_FlashSize) == ESP_OK) {
		m_FlashSize = m_FlashSize / (uint32_t)(1024 * 1024);
		ESP_LOGI(_TAG, "Flash size: %ld MB", m_FlashSize);
	}
	else ESP_LOGI(_TAG, "Get flash size failed");
}

/////////////////////////////////////////////////////////////////////////////////////

FILE* SDMMCDevice::OpenFile(const char *pFilePath, const char *pMode)
{
FILE* pFile = NULL;

	ESP_LOGI(_TAG, "Attempting to open file: %s:%s", pFilePath, pMode);
	pFile = fopen(pFilePath, pMode);  
	if(pFile == NULL)	ESP_LOGE(_TAG, "Failed to open file %s. Error: %s", pFilePath, strerror(errno));
	else ESP_LOGI(_TAG, "File %s was successfully opened.", pFilePath);
	return pFile;
}

/////////////////////////////////////////////////////////////////////////////////////

void SDMMCDevice::CloseFile(FILE *pFile)
{
	fclose(pFile);
	ESP_LOGI(_TAG, "File closed");
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t SDMMCDevice::WriteRaw(FILE *pFile, char *pSrce, int Count)
{
	if(pFile == NULL) {
		ESP_LOGE(_TAG, "No file open for writing");
		return ESP_FAIL;
	}
	fwrite(pSrce, sizeof(char), Count, pFile);
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t SDMMCDevice::ReadRaw(FILE *pFile, char *pDest, int Count)
{
	if(pFile == NULL) {
		ESP_LOGE(_TAG, "No file open for reading");
		return ESP_FAIL;
	}
	fread(pDest, sizeof(char), Count, pFile);
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t SDMMCDevice::RetreiveFolder(const char *pDirectory, const char *pFileExtension, char FileName[][MAX_FILE_NAME_SIZE], uint16_t MaxFiles)
{
uint16_t FileCount = 0; 
struct dirent *pEntry;    // Directory entry pointer

	DIR *dir = opendir(pDirectory);  // Opens the specified directory
	if(dir == NULL){
		ESP_LOGE(_TAG, "Path: <%s> does not exist", pDirectory);
		return 0;
	}
	while((pEntry = readdir(dir)) != NULL && FileCount < MaxFiles) {
		if(strcmp(pEntry->d_name, ".") == 0 || strcmp(pEntry->d_name, "..") == 0){	// Skip "." and ".." Special directory
		continue;
		}
		const char *dot = strrchr(pEntry->d_name, '.');
		if(dot != NULL && dot != pEntry->d_name) {
			if(strcasecmp(dot, pFileExtension) == 0) {
				strncpy(FileName[FileCount], pEntry->d_name, MAX_FILE_NAME_SIZE - 1);
				FileName[FileCount][MAX_FILE_NAME_SIZE - 1] = '\0';
				char FilePath[MAX_PATH_SIZE];
				snprintf(FilePath, MAX_PATH_SIZE, "%s/%s", pDirectory, pEntry->d_name);
				ESP_LOGI(_TAG, "File found: %s\n", FilePath);
				FileCount++;
			}
		}
		else {										// The extension name was not found
			ESP_LOGI(_TAG, "No extension found for file: %s", pEntry->d_name);
		}
	}
	closedir(dir);  
	if(FileCount > 0) {
		ESP_LOGI(_TAG, "Retrieved %d files with extension '%s'", FileCount, pFileExtension); 
	}
	else {
		ESP_LOGW(_TAG, "No files with extension '%s' found in directory: %s", pFileExtension, pDirectory);  
	}
	return FileCount;
}

