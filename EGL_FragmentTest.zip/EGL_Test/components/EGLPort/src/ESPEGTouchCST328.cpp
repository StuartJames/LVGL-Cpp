/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_check.h"
#include "driver/gpio.h"
#include "driver/i2c.h"
#include "esp_lcd_panel_io.h"
#include "ESPEGPort.h"
#include "ESPEGTouchCST328.h"

/////////////////////////////////////////////////////////////////////////////////////

static const char *_TAG = "[CST328]";

/////////////////////////////////////////////////////////////////////////////////////

ESPGLTouchCST328::ESPGLTouchCST328(void) : ESPGLTouchController()
{
}

/////////////////////////////////////////////////////////////////////////////////////

ESPGLTouchCST328::~ESPGLTouchCST328(void)
{
	if(m_Config.InterruptPin != GPIO_NUM_NC) {  // Reset GPIO pin settings 
		gpio_reset_pin(m_Config.InterruptPin);
	}
	if(m_Config.ResetPin != GPIO_NUM_NC) {	    // Reset GPIO pin settings 
		gpio_reset_pin(m_Config.ResetPin);
	}
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchCST328::ReadData(void)
{
esp_err_t err;
uint8_t buf[41];
uint8_t touch_cnt = 0;
uint8_t clear = 0;
size_t i = 0, num = 0;

	err = i2cRead(ESP_LCD_TOUCH_CST328_READ_Number_REG, buf, 1);
	ESP_RETURN_ON_ERROR(err, _TAG, "I2C read error!");
	// CST328i2cWrite(hDevice, ESP_LCD_TOUCH_CST328_READ_XY_REG, &Over, 1);
	if((buf[0] & 0x0F) == 0x00) {	// Any touch data? 
		i2cWrite(ESP_LCD_TOUCH_CST328_READ_Number_REG, &clear, 1);  // No touch data
	}
	else {
		touch_cnt = buf[0] & 0x0F;		// Count of touched points 
		if(touch_cnt > 5 || touch_cnt == 0) {
			i2cWrite(ESP_LCD_TOUCH_CST328_READ_Number_REG, &clear, 1);
			return ESP_OK;
		}
		// err = CST328i2cRead(hDevice, ESP_LCD_TOUCH_CST328_READ_XY_REG, &buf[1], touch_cnt * 5 + 2);		// Read all points 
		err = i2cRead(ESP_LCD_TOUCH_CST328_READ_XY_REG, &buf[1], 27);
		ESP_RETURN_ON_ERROR(err, _TAG, "I2C read error!");
		// CST328i2cWrite(hDevice, ESP_LCD_TOUCH_CST328_READ_XY_REG, &Over, 1);
		err = i2cWrite(ESP_LCD_TOUCH_CST328_READ_Number_REG, &clear, 1);	// Clear all 
		ESP_RETURN_ON_ERROR(err, _TAG, "I2C read error!");
		if(m_Config.InterruptPin != GPIO_NUM_NC) gpio_intr_disable(m_Config.InterruptPin);
		if(touch_cnt > CONFIG_ESP_LCD_TOUCH_MAX_POINTS)	touch_cnt = CONFIG_ESP_LCD_TOUCH_MAX_POINTS;	// Number of touched points 
		m_Data.Points = (uint8_t)touch_cnt;
		for(i = 0; i < touch_cnt; i++) {		// Fill all coordinates 
			if(i > 0) num = 2;
			m_Data.Coords[i].X = (uint16_t)(((uint16_t)buf[(i * 5) + 2 + num] << 4) + ((buf[(i * 5) + 4 + num] & 0xF0) >> 4));
			m_Data.Coords[i].Y = (uint16_t)(((uint16_t)buf[(i * 5) + 3 + num] << 4) + (buf[(i * 5) + 4 + num] & 0x0F));
			m_Data.Coords[i].Strength = ((uint16_t)buf[(i * 5) + 5 + num]);
		}
		if(m_Config.InterruptPin != GPIO_NUM_NC) gpio_intr_enable(m_Config.InterruptPin);
	}
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

bool ESPGLTouchCST328::GetCoordinates(uint16_t *pX, uint16_t *pY, uint16_t *pStrength, uint8_t *pCount, uint8_t MaxCount)
{
	assert(pX != NULL);
	assert(pY != NULL);
	assert(pCount != NULL);
	assert(MaxCount > 0);
	if(m_Config.InterruptPin != GPIO_NUM_NC) gpio_intr_disable(m_Config.InterruptPin);
	if(m_Data.Points > MaxCount)	m_Data.Points = MaxCount;	// Count of points 
	for(size_t i = 0; i < m_Data.Points; i++) {
		pX[i] = m_Data.Coords[i].X;
		pY[i] = m_Data.Coords[i].Y;
		if(pStrength) {
			pStrength[i] = m_Data.Coords[i].Strength;
		}
	}
	*pCount = m_Data.Points;
	m_Data.Points = 0;																							// Invalidate 
	if(m_Config.InterruptPin != GPIO_NUM_NC) gpio_intr_enable(m_Config.InterruptPin);
	return (*pCount > 0);
}

/////////////////////////////////////////////////////////////////////////////////////

// Reset controller 
esp_err_t ESPGLTouchCST328::Reset(void)
{
	ESP_RETURN_ON_ERROR(gpio_set_level(m_Config.ResetPin, !m_Config.Levels.Reset), _TAG, "GPIO set level error!");
	vTaskDelay(pdMS_TO_TICKS(10));
	ESP_RETURN_ON_ERROR(gpio_set_level(m_Config.ResetPin, m_Config.Levels.Reset), _TAG, "GPIO set level error!");
	vTaskDelay(pdMS_TO_TICKS(10));
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

void ESPGLTouchCST328::ReadConfig(void)
{
uint8_t buf[24];

	i2cWrite(CST328_REG_DEBUG_INFO_MODE, buf, 0);
	i2cRead(CST328_REG_DEBUG_INFO_BOOT_TIME, (uint8_t *)&buf[0], 4);
//	ESP_LOGI(_TAG, "TouchPad_ID:0x%02x,0x%02x,0x%02x,0x%02x", buf[0], buf[1], buf[2], buf[3]);
	i2cRead(CST328_REG_DEBUG_INFO_RES_X, (uint8_t *)&buf[0], 1);
	i2cRead( CST328_REG_DEBUG_INFO_RES_X + 1, (uint8_t *)&buf[1], 1);
//	ESP_LOGI(_TAG, "TouchPad_X_MAX:%d", buf[1] * 256 + buf[0]);
	i2cRead(CST328_REG_DEBUG_INFO_RES_Y, (uint8_t *)&buf[2], 1);
	i2cRead(CST328_REG_DEBUG_INFO_RES_Y + 1, (uint8_t *)&buf[3], 1);
//	ESP_LOGI(_TAG, "TouchPad_Y_MAX:%d", buf[3] * 256 + buf[2]);
	i2cRead(CST328_REG_DEBUG_INFO_TP_NTX, buf, 24);
//	ESP_LOGI(_TAG, "D1F4:0x%02x,0x%02x,0x%02x,0x%02x", buf[0], buf[1], buf[2], buf[3]);
//	ESP_LOGI(_TAG, "D1F8:0x%02x,0x%02x,0x%02x,0x%02x", buf[4], buf[5], buf[6], buf[7]);
//	ESP_LOGI(_TAG, "D1FC:0x%02x,0x%02x,0x%02x,0x%02x", buf[8], buf[9], buf[10], buf[11]);
//	ESP_LOGI(_TAG, "D200:0x%02x,0x%02x,0x%02x,0x%02x", buf[12], buf[13], buf[14], buf[15]);
//	ESP_LOGI(_TAG, "D204:0x%02x,0x%02x,0x%02x,0x%02x", buf[16], buf[17], buf[18], buf[19]);
//	ESP_LOGI(_TAG, "D208:0x%02x,0x%02x,0x%02x,0x%02x", buf[20], buf[21], buf[22], buf[23]);
	i2cWrite(CST328_REG_NORMAL_MODE, buf, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchCST328::i2cRead(uint16_t Register, uint8_t *pData, uint8_t Length)
{
	assert(pData != NULL);
	return esp_lcd_panel_io_rx_param(m_hIO, Register, pData, Length);	
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchCST328::i2cWrite(uint16_t Register, uint8_t *pData, uint8_t Length)
{
	assert(pData != NULL);
	return esp_lcd_panel_io_tx_param(m_hIO, Register, pData, Length);
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchCST328::I2CInit(void)
{
i2c_port_t i2cPort = I2CTouchMaster_c;
i2c_config_t Config = {
	.mode = I2C_MODE_MASTER,
	.sda_io_num = I2CTouchSdaIO_c,
	.scl_io_num = I2CTouchSclIO_c,
	.sda_pullup_en = GPIO_PULLUP_ENABLE,
	.scl_pullup_en = GPIO_PULLUP_ENABLE,
	.master = {
		.clk_speed = I2C_MASTER_FREQ_HZ,
	},
	.clk_flags = I2C_SCLK_SRC_FLAG_FOR_NOMAL,
};

	i2c_param_config(i2cPort, &Config);
	return i2c_driver_install(i2cPort, Config.mode, I2C_MASTER_RX_BUF_DISABLE, I2C_MASTER_TX_BUF_DISABLE, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchCST328::Configure(const esp_lcd_panel_io_handle_t hIO, const ESPGL_LCDTouchConfig_t *pConfig)
{
	esp_err_t ret = ESP_OK;

	assert(hIO != NULL);
	assert(pConfig != NULL);
	m_hIO = hIO;	                          // Communication interface 
	m_Lock.owner = portMUX_FREE_VAL;	  // Mutex 
	memcpy(&m_Config, pConfig, sizeof(ESPGL_LCDTouchConfig_t));	// Save config 
	if(m_Config.InterruptPin != GPIO_NUM_NC) {	// Prepare pin for touch interrupt 
	  ESP_LOGI(_TAG, "Setting CST328 interrupts");
		const gpio_config_t int_gpio_config = {
			.pin_bit_mask = BIT64(m_Config.InterruptPin),
			.mode = GPIO_MODE_INPUT,
    	.pull_up_en = GPIO_PULLUP_ENABLE,
    	.pull_down_en = GPIO_PULLDOWN_DISABLE,
			.intr_type = GPIO_INTR_NEGEDGE,
		};
		ret = gpio_config(&int_gpio_config);
		ESP_GOTO_ON_ERROR(ret, err, _TAG, "GPIO config failed");
		if(m_Config.InterruptCB != NULL){		// Register interrupt callback 
		  RegisterInterruptCB(m_Config.InterruptCB);
		}
	}
	ret = Reset();	// Reset controller 
	ESP_GOTO_ON_ERROR(ret, err, _TAG, "CST328 reset failed");
	ReadConfig();

err:
	if(ret != ESP_OK) {
		ESP_LOGE(_TAG, "Error (0x%x)! Touch controller CST328 initialization failed!", ret);
	}
	return ret;
}

/////////////////////////////////////////////////////////////////////////////////////

void ESPGLTouchCST328::Initialise(void)
{
  ESP_ERROR_CHECK(I2CInit());
	ESP_LOGI(_TAG, "I2C initialized successfully");
	esp_lcd_panel_io_handle_t hIO = NULL;
	esp_lcd_panel_io_i2c_config_t IOConfig = ESP_LCD_TOUCH_IO_I2C_CST328_CONFIG();
	ESP_LOGI(_TAG, "Initialize touch IO (I2C)");
//	ESP_ERROR_CHECK(esp_lcd_new_panel_io_i2c((uint32_t)I2CTouchMaster_c, &IOConfig, &hIO));
	esp_lcd_new_panel_io_i2c((uint32_t)I2CTouchMaster_c, &IOConfig, &hIO);
	ESPGL_LCDTouchConfig_t HWConfig = {
		.MaxX = LCD_TOUCH_V_RES,
		.MaxY = LCD_TOUCH_H_RES,
		.ResetPin = I2CTouchResetIO_c,
		.InterruptPin = I2CTouchIntIO_c,
		.Levels = {
			.Reset = 0,
			.Interrupt = 0,
		},
		.Flags = {
			.SwapXY = 0,
			.MirrorX = 0,
			.MirrorY = 0,
		},
    .InterruptCB = NULL
	};
	m_ScaleX = 1.0;
	m_ScaleY = 1.0;
	ESP_LOGI(_TAG, "Initialize touch controller CST328");
	ESP_ERROR_CHECK(Configure(hIO, &HWConfig));
}


