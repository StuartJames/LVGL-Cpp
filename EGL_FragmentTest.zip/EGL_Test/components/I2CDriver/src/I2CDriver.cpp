/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= ===========================================
 * SJ    2025/08/18   1.a.1    Original by ESP
 *
 */

#include "I2CDriver.h"

/////////////////////////////////////////////////////////////////////////////////////

const uint32_t 		I2C_Frequency_c = 400000;          // I2C master clock frequency 
const size_t 			I2C_TX_Buffer_c = 0;               // I2C master doesn't need buffer 
const size_t 			I2C_RX_Buffer_c = 0;               // I2C master doesn't need buffer 
const TickType_t 	I2C_Timeout_c 	= 1000;

/////////////////////////////////////////////////////////////////////////////////////

static const char *_TAG = "[I2C   ]";

/////////////////////////////////////////////////////////////////////////////////////

I2CDriver::I2CDriver(void)
{
	m_Port = I2C_NUM_0;
  m_SCLPin = GPIO_NUM_NC;     
  m_SDAPin = GPIO_NUM_NC;     
}

/////////////////////////////////////////////////////////////////////////////////////

void I2CDriver::Initialise(gpio_num_t SCL, gpio_num_t SDA, i2c_port_t Port)
{
i2c_config_t conf;
esp_err_t Res;

	m_Port = Port;
  m_SCLPin = SCL;     
  m_SDAPin = SDA;     
  memset(&conf, 0, sizeof(i2c_config_t));
	conf.mode = I2C_MODE_MASTER;
	conf.sda_io_num = m_SDAPin;
	conf.scl_io_num = m_SCLPin;
	conf.sda_pullup_en = GPIO_PULLUP_ENABLE;
	conf.scl_pullup_en = GPIO_PULLUP_ENABLE;
	conf.master.clk_speed = I2C_Frequency_c;

	i2c_param_config(m_Port, &conf);
	if((Res = i2c_driver_install(m_Port, conf.mode, I2C_RX_Buffer_c, I2C_TX_Buffer_c, 0)) != ESP_OK){
		ESP_LOGE(_TAG, "I2C initialize failed: %d.", Res);
		return;
	}
	else	ESP_LOGI(_TAG, "I2C initialized successfully");
}


/////////////////////////////////////////////////////////////////////////////////////

esp_err_t I2CDriver::Write(uint8_t Address, uint8_t Register, const uint8_t *pData, uint32_t Length)
{
uint8_t buf[Length + 1];

	buf[0] = Register;
	memcpy(&buf[1], pData, Length);																// Copy data to buf
	return i2c_master_write_to_device(m_Port, Address, buf, Length + 1, I2C_Timeout_c / portTICK_PERIOD_MS);
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t I2CDriver::Read(uint8_t Address, uint8_t Register, uint8_t *pData, uint32_t Length)
{
	return i2c_master_write_read_device(m_Port, Address, &Register, 1, pData, Length, I2C_Timeout_c / portTICK_PERIOD_MS);
}
