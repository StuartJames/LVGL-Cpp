/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= ===========================================
 * SJ    2025/08/18   1.a.1    Original by ESP
 *
 */

 #pragma once

#include <esp_log.h>
#include <esp_adc/adc_oneshot.h>
#include <esp_adc/adc_cali.h>
#include <esp_adc/adc_cali_scheme.h>

/////////////////////////////////////////////////////////////////////////////////////

const float Measurementoffset_c = 0.994500;

/////////////////////////////////////////////////////////////////////////////////////

class Battery
{
public:
							Battery();
	void 				Initialise(adc_channel_t Channel, adc_atten_t Atten);
	float 			Read(void);
	float 			GetVolts(void){ return m_ScaledVoltage; };

private:
	bool 				ADCCalibrationInit(adc_unit_t unit, adc_channel_t channel, adc_atten_t atten, adc_cali_handle_t *pHandle);
//	void 		ADCCalibrationDeinit(adc_cali_handle_t Handle);
	float 										m_ScaledVoltage = 0;
	adc_oneshot_unit_handle_t m_hADC1OneShot;
	adc_cali_handle_t 				m_hADC1Calibration = NULL;
	adc_channel_t							m_Channel;
	int 											m_RawADC[2][10];
	int 											m_Voltage[2][10];
	bool 											m_DoCalibration;

	const char *_TAG = "[ADC   ]";
};