/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= ===========================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#include "EGLTest.h"


/////////////////////////////////////////////////////////////////////////////

#ifdef GRIDNAV_TEST

/////////////////////////////////////////////////////////////////////////////

void EG_GridNavTest(void)
{
	EGDisplay *pDisp = EGDisplay::GetDefault();
  pDisp->SetRotation(EG_DISP_ROT_NONE);
#if EG_USE_THEME_DEFAULT
	EGDefTheme::SetTheme(EG_MainPalette(EG_PALETTE_BLUE), EG_MainPalette(EG_PALETTE_RED), EG_THEME_DEFAULT_DARK, EG_FONT_DEFAULT, pDisp);
#endif
  EGGroup *pGroup = EGGroup::Create();
  pGroup->SetAsDefault();
  EGObject *pScreen = EGDisplay::GetActiveScreen(pDisp);

  EGObject *pCont1 = new EGObject(pScreen);
  EGGridNav::Install(pCont1, EG_GRIDNAV_CTRL_NONE);

    // Use flex here, but works with grid or manually placed objects as well
  EGFlexLayout::SetObjFlow(pCont1, EG_FLEX_FLOW_ROW_WRAP);
  pCont1->SetStyleBackColor(EG_LightPalette(EG_PALETTE_BLUE, 5), EG_STATE_FOCUSED);
  pCont1->SetSize(EG_PCT(50), EG_PCT(100));

    // Only the container needs to be in a group
  EGGroup::GetDefault()->AddObject(pCont1);

  EGLabel *pLabel = new EGLabel(pCont1);
  pLabel->SetFormatText("No rollover");

  for(uint32_t i = 0; i < 10; i++){
    EGButton *pButton = new EGButton(pCont1);
    pButton->SetSize(70, EG_SIZE_CONTENT);
    pButton->AddFlag(EG_OBJ_FLAG_CHECKABLE);
    pGroup->RemoveObject(pButton);   // Not needed, we use the gridnav instead

    pLabel = new EGLabel(pButton);
    pLabel->SetFormatText("%d", i);
    pLabel->Center();
  }

    // Create a second container with rollover grid nav mode.
    EGObject *pCont2 = new EGObject(pScreen);
    EGGridNav::Install(pCont2, EG_GRIDNAV_CTRL_ROLLOVER);
    pCont2->SetStyleBackColor(EG_LightPalette(EG_PALETTE_BLUE, 5), EG_STATE_FOCUSED);
    pCont2->SetSize(EG_PCT(50), EG_PCT(100));
    pCont2->Align(EG_ALIGN_RIGHT_MID, 0, 0);

    pLabel = new EGLabel(pCont2);
    pLabel->SetWidth(EG_PCT(100));
    pLabel->SetFormatText("Rollover\nUse tab to focus the other container");

    // Only the container needs to be in a group
    pGroup->AddObject(pCont2);

    // Add and place some children manually
    EGEdit *pEdit = new EGEdit(pCont2);
    pEdit->SetSize(EG_PCT(100), 80);
    pEdit->SetPosition(0, 80);
    pGroup->RemoveObject(pEdit);   // Not needed, we use the gridnav instead

    EGCheckbox *pCheck = new EGCheckbox(pCont2);
    pCheck->SetPosition(0, 170);
    pGroup->RemoveObject(pCheck);   // Not needed, we use the gridnav instead

    EGSwitch *pSwitch = new EGSwitch(pCont2);
    pSwitch->SetPosition(0, 200);
    pGroup->RemoveObject(pSwitch);   // Not needed, we use the gridnav instead

    pSwitch = new EGSwitch(pCont2);
    pSwitch->SetPosition(EG_PCT(50), 200);
    pGroup->RemoveObject(pSwitch);   // Not needed, we use the gridnav instead
}

#endif


