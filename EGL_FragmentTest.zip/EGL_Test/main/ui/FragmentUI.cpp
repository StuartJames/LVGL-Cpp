/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= ===========================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#include "EGLTest.h"


/////////////////////////////////////////////////////////////////////////////

#ifdef FRAGMENT_TEST

//#define SIMPLE_VERSION

#ifdef SIMPLE_VERSION

class TestFragment : public EGFragment // simple derived fragment class
{
public:
                    TestFragment(void *pArgs); 
                    ~TestFragment(void){};

  virtual EGObject* CreateObject(EGObject *pContainer);

  const char    *m_pName;
};

static char Title[] = "Fragment";

#else

static void PushClickCB(EGEvent *pEvent);
static void PopClickCB(EGEvent *pEvent);
static void IncrementClick(EGEvent *pEvent);

////////////////////////////////////////////////////////////////////////////

class TestFragment : public EGFragment // simple derived fragment class
{
public:
                    TestFragment(void *pArgs); 
//                    ~TestFragment(void){};

  virtual EGObject* CreateContent(EGObject *pContainer);

  static void       DeleteAssertionCB(EGEvent *event);

  EGLabel          *m_pLabel;
  int               m_Depth;
  int               m_Counter;
};

static EGObject *g_pContainer = nullptr;

#endif

static EGObject *pRoot = nullptr;

////////////////////////////////////////////////////////////////////////////

void EG_FragmentTest(void)
{
	EGDisplay *pDisp = EGDisplay::GetDefault();
  pDisp->SetRotation(EG_DISP_ROT_NONE);
#if EG_USE_THEME_DEFAULT
	EGDefTheme::SetTheme(EG_MainPalette(EG_PALETTE_BLUE), EG_MainPalette(EG_PALETTE_RED), EG_THEME_DEFAULT_DARK, EG_FONT_DEFAULT, pDisp);
#endif
  EGGroup *pGroup = EGGroup::Create();
  pGroup->SetAsDefault();
  EGObject *pScreen = EGDisplay::GetActiveScreen(pDisp);
  pRoot = new EGObject(pScreen);
  pRoot->SetSize(EG_PCT(100), EG_PCT(100));
#ifdef SIMPLE_VERSION
  EGFragmentExec *pManager = new EGFragmentExec(nullptr);
    // Clean up the fragment manager before objects in containers get deleted 
  EGEvent::AddEventCB(pRoot, TestFragment::DeleteAssertion, EG_EVENT_DELETE, pManager);
  EGFragment *pFragment = new EGFragment(Title);
  pManager->Replace(pFragment, pRoot);
#else
int Depth = 0;

  pRoot->SetLayout(EGGridLayout::m_Reference);
  static const EG_Coord_t ColomnProps[] = {EG_GRID_FR(1), EG_GRID_FR(1), EG_GRID_TEMPLATE_LAST};
  static const EG_Coord_t RowProps[] = {EG_GRID_FR(1), EG_GRID_CONTENT, EG_GRID_TEMPLATE_LAST};
	EGGridLayout::SetObjGridParams(pRoot, ColomnProps, RowProps);
  g_pContainer = new EGObject(pRoot);
  g_pContainer->RemoveAllStyles();
  EGGridLayout::SetObjCell(g_pContainer, EG_GRID_ALIGN_STRETCH, 0, 2, EG_GRID_ALIGN_STRETCH, 0, 1);

  EGButton *pPushButton = new EGButton(pRoot);
  EGLabel *pLabel = new EGLabel(pPushButton);
  pLabel->SetText("Push");

  EGButton *pPopButton = new EGButton(pRoot);
  pLabel = new EGLabel(pPopButton);
  pLabel->SetText("Pop");
  EGGridLayout::SetObjCell(pPushButton, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_CENTER, 1, 1);
  EGGridLayout::SetObjCell(pPopButton, EG_GRID_ALIGN_END, 1, 1, EG_GRID_ALIGN_CENTER, 1, 1);

  EGFragmentExec *pManager = new EGFragmentExec(nullptr);
    // Clean up the fragment manager before objects in containers get deleted 
  EGEvent::AddEventCB(pRoot, TestFragment::DeleteAssertionCB, EG_EVENT_DELETE, pManager);

  TestFragment *pFragment = new TestFragment(&Depth);   // generate first fragment
  pManager->Push(pFragment, g_pContainer);                      // and register it in the executive
  EGEvent::AddEventCB(pPushButton, PushClickCB, EG_EVENT_CLICKED, pManager);
  EGEvent::AddEventCB(pPopButton, PopClickCB, EG_EVENT_CLICKED, pManager);

#endif
}

///////////////////////////////////////////////////////////////////////////////

#ifdef SIMPLE_VERSION

TestFragment::TestFragment(void *pArgs) :
  EGFragment(pArgs),
  m_pName(nullptr)
{
  m_pName = (const char*)pArgs
}

///////////////////////////////////////////////////////////////////////////////

EGObject* TestFragment::CreateObject(EGObject *pParent)
{
  EGLabel *pLabel = new EGLabel(pParent);
  pLabel->SetStyleBackOPA(EG_OPA_COVER, 0);
  pLabel->SetFormatText("Hello, %s!", m_pName);
  return pLabel;
}

///////////////////////////////////////////////////////////////////////////////

#else

TestFragment::TestFragment(void *pArgs) :
  EGFragment(pArgs),
  m_pLabel(nullptr),
  m_Depth(0),
  m_Counter(0)
{
  m_Depth = *((int *)pArgs);
  m_Counter = 0;
}

///////////////////////////////////////////////////////////////////////////////

EGObject* TestFragment::CreateContent(EGObject *pParent)
{
  EGObject *pContent = new EGObject(pParent);
  pContent->RemoveAllStyles();
  pContent->SetStyleBackOPA(EG_OPA_50, 0);
  pContent->SetStyleBackColor(EG_MainPalette(EG_PALETTE_YELLOW), 0);
  pContent->SetSize(EG_PCT(100), EG_PCT(100));
  EGFlexLayout::SetObjFlow(pContent, EG_FLEX_FLOW_COLUMN);
  EGLabel *pLabel = new EGLabel(pContent);
  pLabel->SetFormatText("Depth: %d", m_Depth);
  m_pLabel = new EGLabel(pContent);
  m_pLabel->SetFormatText("Button pressed %d times", m_Counter);
  EGButton *pButton = new EGButton(pContent);
  pLabel = new EGLabel(pButton);
  pLabel->SetText("+1");
  EGEvent::AddEventCB(pButton, IncrementClick, EG_EVENT_CLICKED, this);
  return pContent;
}

///////////////////////////////////////////////////////////////////////////////

static void PushClickCB(EGEvent *pEvent)
{
  EGFragmentExec *pManager = (EGFragmentExec*)pEvent->GetExtParam();
  size_t StackSize = pManager->GetStackSize();
  TestFragment *pFragment = new TestFragment(&StackSize);
  pManager->Push(pFragment, g_pContainer);
}

///////////////////////////////////////////////////////////////////////////////

static void PopClickCB(EGEvent *pEvent)
{
  EGFragmentExec *pManager = (EGFragmentExec*) pEvent->GetExtParam();
  pManager->Pop();
}

///////////////////////////////////////////////////////////////////////////////

static void IncrementClick(EGEvent *pEvent)
{
  TestFragment *pFragment = (TestFragment*)pEvent->GetExtParam();
  pFragment->m_Counter++;
  pFragment->m_pLabel->SetFormatText("Button pressed %d times", pFragment->m_Counter);
}

#endif

///////////////////////////////////////////////////////////////////////////////

void TestFragment::DeleteAssertionCB(EGEvent *pEvent)
{
  EGFragmentExec *pManager = (EGFragmentExec*) pEvent->GetExtParam();
  delete pManager;
}

#endif


