/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= ===========================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#include "EGLTest.h"

#ifdef WIDGET_TEST

#if EG_USE_STDLIB_MALLOC == EG_STDLIB_BUILTIN && EG_MEM_SIZE < (38ul * 1024ul)
#error Insufficient memory for EG_demo_widgets. Please set EG_MEM_SIZE to at least 38KB (38ul * 1024ul).  48KB is recommended.
#endif

typedef enum {
    DISP_SMALL,
    DISP_MEDIUM,
    DISP_LARGE,
} disp_size_t;


/////////////////////////////////////////////////////////////////////////////

static uint8_t DisplaySize;

EGDisplay *pDisp = nullptr;
EGObject  *pPanel = nullptr;
EGLabel   *pLabel1 = nullptr;
EGLabel   *pLabel2 = nullptr;
EGLabel   *pLabel3 = nullptr;
EGEdit    *pEdit1 = nullptr;
EGEdit    *pEdit2 = nullptr;
EGEdit    *pEdit3 = nullptr;
EGStyle   StyleTextMuted;
EGStyle   StyleTitle;
EGStyle   StyleIcon;
EGStyle   StyleBullet;
EGKeyboard  *pKeyboard;


static const EG_Font_t *pFontLarge;
static const EG_Font_t *pFontNormal;

void EditEvent(EGEvent *pEvent);

/////////////////////////////////////////////////////////////////////////////

void EG_WidgetsDemo(void)
{
	if(EG_HORZ_RES <= 320)	DisplaySize = DISP_SMALL;
	else if(EG_HORZ_RES < 720)	DisplaySize = DISP_MEDIUM;
	else DisplaySize = DISP_LARGE;
	pFontLarge = EG_FONT_DEFAULT;
	pFontNormal = EG_FONT_DEFAULT;
	if(DisplaySize == DISP_LARGE) {
#if EG_FontMontserrat24
		pFontLarge = &EG_FontMontserrat24;
#else
		EG_LOG_WARN("EG_FontMontserrat24 is not enabled for the widgets demo. Using EG_FONT_DEFAULT instead.");
#endif
#if EG_FontMontserrat16
		pFontNormal = &EG_FontMontserrat16;
#else
		EG_LOG_WARN("EG_FontMontserrat16 is not enabled for the widgets demo. Using EG_FONT_DEFAULT instead.");
#endif
	}
	else if(DisplaySize == DISP_MEDIUM) {
#if EG_FontMontserrat20
		pFontLarge = &EG_FontMontserrat20;
#else
		EG_LOG_WARN("EG_FontMontserrat20 is not enabled for the widgets demo. Using EG_FONT_DEFAULT instead.");
#endif
#if EG_FontMontserrat14
		pFontNormal = &EG_FontMontserrat14;
#else
		EG_LOG_WARN("EG_FontMontserrat14 is not enabled for the widgets demo. Using EG_FONT_DEFAULT instead.");
#endif
	}
	else { //  DisplaySize == DISP_SMALL 
#if EG_FontMontserrat18
		pFontLarge = &EG_FontMontserrat18;
#else
		EG_LOG_WARN("EG_FontMontserrat18 is not enabled for the widgets demo. Using EG_FONT_DEFAULT instead.");
#endif
#if EG_FontMontserrat12
		pFontNormal = &EG_FontMontserrat12;
#else
		EG_LOG_WARN("EG_FontMontserrat12 is not enabled for the widgets demo. Using EG_FONT_DEFAULT instead.");
#endif
	}

	pDisp = EGDisplay::GetDefault();
  pDisp->SetRotation(EG_DISP_ROT_NONE);
#if EG_USE_THEME_DEFAULT
	EGDefTheme::SetTheme(EG_MainPalette(EG_PALETTE_BLUE), EG_MainPalette(EG_PALETTE_RED), EG_THEME_DEFAULT_DARK, EG_FONT_DEFAULT, pDisp);
#endif
  EGGroup *pGroup = EGGroup::Create();
  pGroup->SetAsDefault();
	StyleTextMuted.SetTextOPA(EG_OPA_80);
	StyleTitle.SetTextFont(pFontLarge);
	StyleIcon.SetTextColor(EGDefTheme::GetColorPrimary(nullptr));
	StyleIcon.SetTextFont(pFontLarge);
	StyleBullet.SetBorderWidth(0);
	StyleBullet.SetRadius(EG_RADIUS_CIRCLE);

  EGObject *pScreen = EGDisplay::GetActiveScreen(pDisp);
 	pScreen->SetStyleTextFont(pFontNormal, 0);

  pPanel = new EGObject(pScreen);
  pPanel->SetWidth(EG_PCT(100));
  pPanel->SetHeight(EG_PCT(100));
  pPanel->SetAlign(EG_ALIGN_TOP_MID);
 //  pPanel->ClearFlag(EG_OBJ_FLAG_SCROLLABLE);      

	EGLabel *pTitle = new EGLabel(pPanel);
	pTitle->SetText("Edit Test");
	pTitle->AddStyle(&StyleTitle, 0);
  pLabel1 = new EGLabel(pPanel);
	pLabel1->SetWidth(EG_PCT(45));
	pLabel1->SetHeight(EG_SIZE_CONTENT);  
	pLabel1->SetX(-60);
	pLabel1->SetY(-77);
	pLabel1->SetAlign(EG_ALIGN_CENTER);
	pLabel1->SetText("Edit 1:");
	pLabel1->SetStyleTextFont(&EG_FontMontserrat18, EG_PART_MAIN | EG_STATE_DEFAULT);

	pEdit1 = new EGEdit(pPanel);
	pEdit1->SetHeight(EG_SIZE_CONTENT);  
	pEdit1->SetWidth(EG_PCT(45));
	pEdit1->SetX(54);
	pEdit1->SetY(-77);
	pEdit1->SetOneLineMode(true);
	pEdit1->SetAlign(EG_ALIGN_CENTER);
	pEdit1->AddFlag(EG_OBJ_FLAG_SCROLL_ON_FOCUS); 
  pEdit1->SetNumericMode(); 

  pLabel2 = new EGLabel(pPanel);
	pLabel2->SetWidth(EG_PCT(45));
	pLabel2->SetHeight(EG_SIZE_CONTENT);  
	pLabel2->SetX(-60);
	pLabel2->SetY(-17);
	pLabel2->SetAlign(EG_ALIGN_CENTER);
	pLabel2->SetText("Edit 2:");
	pLabel2->SetStyleTextFont(&EG_FontMontserrat18, EG_PART_MAIN | EG_STATE_DEFAULT);

	pEdit2 = new EGEdit(pPanel);
	pEdit2->SetHeight(EG_SIZE_CONTENT);  
	pEdit2->SetWidth(EG_PCT(45));
	pEdit2->SetX(54);
	pEdit2->SetY(-17);
	pEdit2->SetOneLineMode(true);
	pEdit2->SetAlign(EG_ALIGN_CENTER);
	pEdit2->AddFlag(EG_OBJ_FLAG_SCROLL_ON_FOCUS); 
  pEdit2->SetNumericMode(); 

  pLabel3 = new EGLabel(pPanel);
	pLabel3->SetWidth(EG_PCT(45));
	pLabel3->SetHeight(EG_SIZE_CONTENT);  
	pLabel3->SetX(-60);
	pLabel3->SetY(77);
	pLabel3->SetAlign(EG_ALIGN_CENTER);
	pLabel3->SetText("Edit 3:");
	pLabel3->SetStyleTextFont(&EG_FontMontserrat18, EG_PART_MAIN | EG_STATE_DEFAULT);

	pEdit3 = new EGEdit(pPanel);
	pEdit3->SetHeight(EG_SIZE_CONTENT);  
	pEdit3->SetWidth(EG_PCT(45));
	pEdit3->SetX(54);
	pEdit3->SetY(77);
	pEdit3->SetOneLineMode(true);
	pEdit3->SetAlign(EG_ALIGN_CENTER);
	pEdit3->AddFlag(EG_OBJ_FLAG_SCROLL_ON_FOCUS); 
  pEdit3->SetNumericMode(); 

  pKeyboard = new EGKeyboard(EGDisplay::GetActiveScreen(nullptr));
	pKeyboard->AddFlag(EG_OBJ_FLAG_HIDDEN);

  EGEvent::AddEventCB(pEdit1, EditEvent, EG_EVENT_ALL, pKeyboard);
  EGEvent::AddEventCB(pEdit2, EditEvent, EG_EVENT_ALL, pKeyboard);
  EGEvent::AddEventCB(pEdit3, EditEvent, EG_EVENT_ALL, pKeyboard);

	static EG_Coord_t PanelColumnProps[] = {EG_GRID_FR(1), EG_GRID_FR(1), EG_GRID_TEMPLATE_LAST};
	static EG_Coord_t PanelRowProps[] = {
    EG_GRID_CONTENT, // Title
    5,               // Separator
    EG_GRID_CONTENT, // Box title
    5,              // Box
    EG_GRID_CONTENT, // Box title
    5,              // Box
    EG_GRID_CONTENT, // Box title
    5,              // Box
    EG_GRID_TEMPLATE_LAST};

	EGGridLayout::SetObjGridParams(pPanel, PanelColumnProps, PanelRowProps);
  EGGridLayout::SetObjCell(pTitle, EG_GRID_ALIGN_START, 0, 2, EG_GRID_ALIGN_CENTER, 0, 1);
  EGGridLayout::SetObjCell(pLabel1, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 2, 1);
  EGGridLayout::SetObjCell(pEdit1, EG_GRID_ALIGN_STRETCH, 1, 1, EG_GRID_ALIGN_START, 2, 1);
  EGGridLayout::SetObjCell(pLabel2, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 4, 1);
  EGGridLayout::SetObjCell(pEdit2, EG_GRID_ALIGN_STRETCH, 1, 1, EG_GRID_ALIGN_START, 4, 1);
  EGGridLayout::SetObjCell(pLabel3, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 6, 1);
  EGGridLayout::SetObjCell(pEdit3, EG_GRID_ALIGN_STRETCH, 1, 1, EG_GRID_ALIGN_START, 6, 1);
}

/////////////////////////////////////////////////////////////////////////////

void EditEvent(EGEvent *pEvent)
{
	EG_EventCode_e Code = pEvent->GetCode();
	EGEdit *pEdit = (EGEdit*)pEvent->GetTarget();
	EGKeyboard *pKeyboard = (EGKeyboard*)pEvent->GetExtParam();
  EGObject *pPanel = pEdit->GetParent();
	if(Code == EG_EVENT_FOCUSED) {
		if(EGInputDevice::GetActive()->GetType() != EG_INDEV_TYPE_KEYPAD) {
			pKeyboard->SetEditCtrl(pEdit);
			pKeyboard->SetStyleMaxHeight(EG_HORZ_RES * 2 / 3, 0);
      pKeyboard->SetMode(EG_KEYBOARD_MODE_NUMBER);
			pPanel->UpdateLayout(); // Be sure the sizes are recalculated
			pPanel->SetHeight(EG_VERT_RES - pKeyboard->GetHeight());
			pKeyboard->ClearFlag(EG_OBJ_FLAG_HIDDEN);
			pEdit->ScrollToViewRecursive(EG_ANIM_OFF);
		}
	}
	else if(Code == EG_EVENT_DEFOCUSED) {
		pKeyboard->SetEditCtrl(nullptr);
		pPanel->SetHeight(EG_VERT_RES);
		pKeyboard->AddFlag(EG_OBJ_FLAG_HIDDEN);
		EGInputDevice::Reset(nullptr, pEdit);
	}
	else if(Code == EG_EVENT_READY || Code == EG_EVENT_CANCEL) {
		pPanel->SetHeight(EG_VERT_RES);
		pKeyboard->AddFlag(EG_OBJ_FLAG_HIDDEN);
		pEdit->ClearState(EG_STATE_FOCUSED);
		EGInputDevice::Reset(nullptr, pEdit); // Forget the last clicked object to make it focusable again
	}
}

#endif