/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= ===========================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#include "EGLTest.h"

/////////////////////////////////////////////////////////////////////////////////////

PowerKey::PowerKey(void)
{
  m_PowerControlPin = GPIO_NUM_NC;
  m_PowerInputPin = GPIO_NUM_NC;
  m_ButtonState = 0;
  m_DeviceState = 0;
  m_LongPress = 0;
}

/////////////////////////////////////////////////////////////////////////////////////

void PowerKey::Read(void)
{
	if(m_ButtonState) {
		if(!gpio_get_level(m_PowerInputPin)) {
			if(m_ButtonState == 2) {
				m_LongPress++;
				if(m_LongPress >= DeviceSleepTime_c){
					if(m_LongPress < DeviceRestartTime_c) m_DeviceState = 1;
					else if((m_LongPress >= DeviceRestartTime_c) && (m_LongPress < DeviceShutdownTime_c)) m_DeviceState = 2;
					else if(m_LongPress >= DeviceShutdownTime_c) Shutdown();
				}
			}
		}
		else {
			if(m_ButtonState == 1) m_ButtonState = 2;
			m_LongPress = 0;
		}
	}
}

/////////////////////////////////////////////////////////////////////////////////////

void PowerKey::FallAsleep(void)
{
}

/////////////////////////////////////////////////////////////////////////////////////

void PowerKey::Restart(void)
{
}

/////////////////////////////////////////////////////////////////////////////////////

void PowerKey::Shutdown(void)
{
	gpio_set_level(m_PowerControlPin, false);
//	g_DisplayObj.SetLevel(0);
}

/////////////////////////////////////////////////////////////////////////////////////

void PowerKey::ConfigurePin(gpio_num_t Pin, gpio_mode_t Mode)
{
	gpio_reset_pin(Pin);
	gpio_set_direction(Pin, Mode);
}

/////////////////////////////////////////////////////////////////////////////////////

void PowerKey::Initialise(gpio_num_t CntrlPin, gpio_num_t InputPin)
{
  m_PowerControlPin = CntrlPin;
  m_PowerInputPin = InputPin;
	ConfigurePin(m_PowerInputPin, GPIO_MODE_INPUT);
	ConfigurePin(m_PowerControlPin, GPIO_MODE_OUTPUT);
	gpio_set_level(m_PowerControlPin, false);
	vTaskDelay(100);
	if(!gpio_get_level(m_PowerInputPin)) {
		m_ButtonState = 1;
		gpio_set_level(m_PowerControlPin, true);
	}
}
