/*****************************************************************************
* | File      	:   PCF85063.c
* | Author      :   Waveshare team
* | Function    :   PCF85063 driver
* | Info        :
*----------------
* |	This version:   V1.0
* | Date        :   2024-02-02
* | Info        :   Basic version
*
******************************************************************************/
#include "RTCDevice.h"

/////////////////////////////////////////////////////////////////////////////////////

const unsigned char MonthStr[12][4] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov","Dec"};

/////////////////////////////////////////////////////////////////////////////////////

// Initiate Normal Mode, RTC Run, NO reset, No correction , 24hr format, Internal load capacitane 12.5pf
void RTCDevice::Initialise(I2CDriver *pI2C)
{
uint8_t Value = RTC_CTRL_1_DEFAULT | RTC_CTRL_1_CAP_SEL;

	m_pI2C = pI2C;
	ESP_ERROR_CHECK(m_pI2C->Write(PCF85063_ADDRESS, RTC_CTRL_1_ADDR, &Value, 1));
/*  DateTime_t TestTime = {0};
	TestTime.year = 2024;
	TestTime.month = 9;
	TestTime.day = 20;
	TestTime.dotw = 5;
	TestTime.hour = 9;
	TestTime.minute = 50;
	TestTime.second = 0;
	PCF85063_Set_All(TestTime);*/
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::Reset()
{
	uint8_t Value = RTC_CTRL_1_DEFAULT|RTC_CTRL_1_CAP_SEL|RTC_CTRL_1_SR;
	ESP_ERROR_CHECK(m_pI2C->Write(PCF85063_ADDRESS, RTC_CTRL_1_ADDR, &Value, 1));
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::Read(DateTime_t *pTime)
{
uint8_t Buffer[7] = {0};

	ESP_ERROR_CHECK(m_pI2C->Read(PCF85063_ADDRESS, RTC_SECOND_ADDR, Buffer, 7));
	pTime->second = BCDToDec(Buffer[0] & 0x7F);
	pTime->minute = BCDToDec(Buffer[1] & 0x7F);
	pTime->hour = BCDToDec(Buffer[2] & 0x3F);
	pTime->day = BCDToDec(Buffer[3] & 0x3F);
	pTime->dotw = BCDToDec(Buffer[4] & 0x07);
	pTime->month = BCDToDec(Buffer[5] & 0x1F);
	pTime->year = BCDToDec(Buffer[6])+YEAR_OFFSET;
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::Read(void)
{
  Read(&m_DateTime);
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::Read(tm *pTime)
{

  Read(&m_DateTime);
	pTime->tm_sec = m_DateTime.second;
	pTime->tm_min = m_DateTime.minute;
	pTime->tm_hour = m_DateTime.hour;
	pTime->tm_mday = m_DateTime.day;
	pTime->tm_wday = m_DateTime.dotw;
	pTime->tm_mon = m_DateTime.month;
	pTime->tm_year = m_DateTime.year;
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::SetTime(DateTime_t Time)
{
uint8_t Buffer[3] = {
	DecToBcd(Time.second),
	DecToBcd(Time.minute),
	DecToBcd(Time.hour)
};

	ESP_ERROR_CHECK(m_pI2C->Write(PCF85063_ADDRESS, RTC_SECOND_ADDR, Buffer, 3));
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::SetDate(DateTime_t Time)
{
uint8_t Buffer[4] = {
	DecToBcd(Time.day),
	DecToBcd(Time.dotw),
	DecToBcd(Time.month),
	DecToBcd(Time.year - YEAR_OFFSET)
};

	ESP_ERROR_CHECK(m_pI2C->Write(PCF85063_ADDRESS, RTC_SECOND_ADDR, Buffer, 7));
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::SetClock(DateTime_t Time)
{
uint8_t Buffer[7] = {
	DecToBcd(Time.second),
	DecToBcd(Time.minute),
	DecToBcd(Time.hour),
	DecToBcd(Time.day),
	DecToBcd(Time.dotw),
	DecToBcd(Time.month),
	DecToBcd(Time.year - YEAR_OFFSET)
};

	ESP_ERROR_CHECK(m_pI2C->Write(PCF85063_ADDRESS, RTC_SECOND_ADDR, Buffer, 7));
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::SetClock(tm Time)
{
uint8_t Buffer[7] = {
	DecToBcd(Time.tm_sec),
	DecToBcd(Time.tm_min),
	DecToBcd(Time.tm_hour),
	DecToBcd(Time.tm_yday),
	DecToBcd(Time.tm_wday),
	DecToBcd(Time.tm_mon),
	DecToBcd(Time.tm_year - YEAR_OFFSET)
};

	ESP_ERROR_CHECK(m_pI2C->Write(PCF85063_ADDRESS, RTC_SECOND_ADDR, Buffer, 7));
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::EnableAlarm()
{
	uint8_t Value = RTC_CTRL_2_DEFAULT | RTC_CTRL_2_AIE;
	Value &= ~RTC_CTRL_2_AF;
	ESP_ERROR_CHECK(m_pI2C->Write(PCF85063_ADDRESS, RTC_CTRL_2_ADDR, &Value, 1));
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t RTCDevice::GetAlarmFlag()
{
uint8_t Value = 0;

	ESP_ERROR_CHECK(m_pI2C->Read(PCF85063_ADDRESS, RTC_CTRL_2_ADDR, &Value, 1));
	//printf("Value = 0x%x",Value);
	Value &= RTC_CTRL_2_AF | RTC_CTRL_2_AIE;
	return Value;
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::SetAlarm(DateTime_t Time)
{

	uint8_t Buffer[5] ={
		static_cast<uint8_t>(DecToBcd(Time.second) & ~RTC_ALARM),	
		static_cast<uint8_t>(DecToBcd(Time.minute) & ~RTC_ALARM),	
		static_cast<uint8_t>(DecToBcd(Time.hour) & ~RTC_ALARM),
		//decToBcd(time.day) & (uint8_t)(~RTC_ALARM),
		//decToBcd(time.dotw) & (uint8_t)(~RTC_ALARM)
		RTC_ALARM, 	//disalbe day
		RTC_ALARM	//disalbe weekday
	};
	ESP_ERROR_CHECK(m_pI2C->Write(PCF85063_ADDRESS, RTC_SECOND_ALARM, Buffer, 6));
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::ReadAlarm(DateTime_t *pTime)
{
uint8_t Buffer[6] = {0};

	ESP_ERROR_CHECK(m_pI2C->Read(PCF85063_ADDRESS, RTC_SECOND_ALARM, Buffer, 6));
	pTime->second = BCDToDec(Buffer[0] & 0x7F);
	pTime->minute = BCDToDec(Buffer[1] & 0x7F);
	pTime->hour = BCDToDec(Buffer[2] & 0x3F);
	pTime->day = BCDToDec(Buffer[3] & 0x3F);
	pTime->dotw = BCDToDec(Buffer[4] & 0x07);
}


/////////////////////////////////////////////////////////////////////////////////////

uint8_t RTCDevice::DecToBcd(int Val)
{
	return (uint8_t)((Val / 10 * 16) + (Val % 10));
}

/////////////////////////////////////////////////////////////////////////////////////

int RTCDevice::BCDToDec(uint8_t Val)
{
	return (int)((Val / 16 * 10) + (Val % 16));
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::DateTimeStr(char *pString, DateTime_t Time)
{
	sprintf(pString, " %d/%d/%d  %d %d:%d:%d ", Time.year, Time.month, Time.day, Time.dotw, Time.hour, Time.minute, Time.second);
}