/**
 * GENERATED FILE, DO NOT EDIT IT!
 * @file EG_IntrnlConfig.h
 * Make sure all the defines of EG_Config.h have a default value
**/

#pragma once
/* clang-format off */

#include <stdint.h>

/* Handle special Kconfig options */
#ifndef EG_KCONFIG_IGNORE
    #include "EG_ConfKconfig.h"
    #ifdef CONFIG_EG_CONF_SKIP
        #define EG_CONF_SKIP
    #endif
#endif

/*If "EG_Config.h" is available from here try to use it later.*/
#ifdef __has_include
    #if __has_include("EG_Config.h")
        #ifndef EG_CONF_INCLUDE_SIMPLE
            #define EG_CONF_INCLUDE_SIMPLE
        #endif
    #endif
#endif

/*If EG_Config.h is not skipped include it*/
#ifndef EG_CONF_SKIP
    #ifdef EG_CONF_PATH                           /*If there is a path defined for EG_Config.h use it*/
        #define __EG_TO_STR_AUX(x) #x
        #define __EG_TO_STR(x) __EG_TO_STR_AUX(x)
        #include __EG_TO_STR(EG_CONF_PATH)
        #undef __EG_TO_STR_AUX
        #undef __EG_TO_STR
    #elif defined(EG_CONF_INCLUDE_SIMPLE)         /*Or simply include EG_Config.h is enabled*/
        #include "EG_Config.h"
    #else
        #include "../../EG_Config.h"                /*Else assume EG_Config.h is next to the lvgl folder*/
    #endif
    #if !defined(EG_CONF_H) && !defined(EG_CONF_SUPPRESS_DEFINE_CHECK)
        /* #include will sometimes silently fail when __has_include is used */
        /* https://gcc.gnu.org/bugzilla/show_bug.cgi?id=80753 */
        #pragma message("Possible failure to include EG_Config.h, please read the comment in this file if you get errors")
    #endif
#endif

#ifdef CONFIG_EG_COLOR_DEPTH
    #define _EG_KCONFIG_PRESENT
#endif

/*----------------------------------
 * Start parsing EG_ConfTemplate.h
 -----------------------------------*/

#include <stdint.h>

/*====================
   COLOR SETTINGS
 *====================*/

/*Color depth: 1 (1 byte per pixel), 8 (RGB332), 16 (RGB565), 32 (ARGB8888)*/
#ifndef EG_COLOR_DEPTH
    #ifdef CONFIG_EG_COLOR_DEPTH
        #define EG_COLOR_DEPTH CONFIG_EG_COLOR_DEPTH
    #else
        #define EG_COLOR_DEPTH 16
    #endif
#endif

/*Swap the 2 bytes of RGB565 color. Useful if the display has an 8-bit interface (e.g. SPI)*/
#ifndef EG_COLOR_16_SWAP
    #ifdef CONFIG_EG_COLOR_16_SWAP
        #define EG_COLOR_16_SWAP CONFIG_EG_COLOR_16_SWAP
    #else
        #define EG_COLOR_16_SWAP 0
    #endif
#endif

/*Enable features to draw on transparent background.
 *It's required if opa, and transform_* style properties are used.
 *Can be also used if the UI is above another layer, e.g. an OSD menu or video player.*/
#ifndef EG_COLOR_SCREEN_TRANSP
    #ifdef CONFIG_EG_COLOR_SCREEN_TRANSP
        #define EG_COLOR_SCREEN_TRANSP CONFIG_EG_COLOR_SCREEN_TRANSP
    #else
        #define EG_COLOR_SCREEN_TRANSP 0
    #endif
#endif

/* Adjust color mix functions rounding. GPUs might calculate color mix (blending) differently.
 * 0: round down, 64: round up from x.75, 128: round up from half, 192: round up from x.25, 254: round up */
#ifndef EG_COLOR_MIX_ROUND_OFS
    #ifdef CONFIG_EG_COLOR_MIX_ROUND_OFS
        #define EG_COLOR_MIX_ROUND_OFS CONFIG_EG_COLOR_MIX_ROUND_OFS
    #else
        #define EG_COLOR_MIX_ROUND_OFS 0
    #endif
#endif

/*Images pixels with this color will not be drawn if they are chroma keyed)*/
#ifndef EG_COLOR_CHROMA_KEY
    #ifdef CONFIG_EG_COLOR_CHROMA_KEY
        #define EG_COLOR_CHROMA_KEY CONFIG_EG_COLOR_CHROMA_KEY
    #else
        #define EG_COLOR_CHROMA_KEY EG_ColorHex(0x00ff00)         /*pure green*/
    #endif
#endif

/*=========================
   MEMORY SETTINGS
 *=========================*/

/*1: use custom malloc/free, 0: use the built-in `EG_AllocMem()` and `EG_FreeMem()`*/
#ifndef EG_MEM_CUSTOM
    #ifdef CONFIG_EG_MEM_CUSTOM
        #define EG_MEM_CUSTOM CONFIG_EG_MEM_CUSTOM
    #else
        #define EG_MEM_CUSTOM 0
    #endif
#endif
#if EG_MEM_CUSTOM == 0
    /*Size of the memory available for `EG_AllocMem()` in bytes (>= 2kB)*/
    #ifndef EG_MEM_SIZE
        #ifdef CONFIG_EG_MEM_SIZE
            #define EG_MEM_SIZE CONFIG_EG_MEM_SIZE
        #else
            #define EG_MEM_SIZE (48U * 1024U)          /*[bytes]*/
        #endif
    #endif

    /*Set an address for the memory pool instead of allocating it as a normal array. Can be in external SRAM too.*/
    #ifndef EG_MEM_ADR
        #ifdef CONFIG_EG_MEM_ADR
            #define EG_MEM_ADR CONFIG_EG_MEM_ADR
        #else
            #define EG_MEM_ADR 0     /*0: unused*/
        #endif
    #endif
    /*Instead of an address give a memory allocator that will be called to get a memory pool for LEGL. E.g. my_malloc*/
    #if EG_MEM_ADR == 0
        #ifndef EG_MEM_POOL_INCLUDE
            #ifdef CONFIG_EG_MEM_POOL_INCLUDE
                #define EG_MEM_POOL_INCLUDE CONFIG_EG_MEM_POOL_INCLUDE
            #else
                #undef EG_MEM_POOL_INCLUDE
            #endif
        #endif
        #ifndef EG_MEM_POOL_ALLOC
            #ifdef CONFIG_EG_MEM_POOL_ALLOC
                #define EG_MEM_POOL_ALLOC CONFIG_EG_MEM_POOL_ALLOC
            #else
                #undef EG_MEM_POOL_ALLOC
            #endif
        #endif
    #endif

#else       /*EG_MEM_CUSTOM*/
    #ifndef EG_MEM_CUSTOM_INCLUDE
        #ifdef CONFIG_EG_MEM_CUSTOM_INCLUDE
            #define EG_MEM_CUSTOM_INCLUDE CONFIG_EG_MEM_CUSTOM_INCLUDE
        #else
            #define EG_MEM_CUSTOM_INCLUDE <stdlib.h>   /*Header for the dynamic memory function*/
        #endif
    #endif
    #ifndef EG_MEM_CUSTOM_ALLOC
        #ifdef CONFIG_EG_MEM_CUSTOM_ALLOC
            #define EG_MEM_CUSTOM_ALLOC CONFIG_EG_MEM_CUSTOM_ALLOC
        #else
            #define EG_MEM_CUSTOM_ALLOC   malloc
        #endif
    #endif
    #ifndef EG_MEM_CUSTOM_FREE
        #ifdef CONFIG_EG_MEM_CUSTOM_FREE
            #define EG_MEM_CUSTOM_FREE CONFIG_EG_MEM_CUSTOM_FREE
        #else
            #define EG_MEM_CUSTOM_FREE    free
        #endif
    #endif
    #ifndef EG_MEM_CUSTOM_REALLOC
        #ifdef CONFIG_EG_MEM_CUSTOM_REALLOC
            #define EG_MEM_CUSTOM_REALLOC CONFIG_EG_MEM_CUSTOM_REALLOC
        #else
            #define EG_MEM_CUSTOM_REALLOC realloc
        #endif
    #endif
#endif     /*EG_MEM_CUSTOM*/

/*Number of the intermediate memory buffer used during rendering and other internal processing mechanisms.
 *You will see an error log message if there wasn't enough buffers. */
#ifndef EG_MEM_BUF_MAX_NUM
    #ifdef CONFIG_EG_MEM_BUF_MAX_NUM
        #define EG_MEM_BUF_MAX_NUM CONFIG_EG_MEM_BUF_MAX_NUM
    #else
        #define EG_MEM_BUF_MAX_NUM 16
    #endif
#endif

/*Use the standard `memcpy` and `memset` instead of LEGL's own functions. (Might or might not be faster).*/
#ifndef EG_MEMCPY_MEMSET_STD
    #ifdef CONFIG_EG_MEMCPY_MEMSET_STD
        #define EG_MEMCPY_MEMSET_STD CONFIG_EG_MEMCPY_MEMSET_STD
    #else
        #define EG_MEMCPY_MEMSET_STD 0
    #endif
#endif

/*====================
   HAL SETTINGS
 *====================*/

/*Default display refresh period. LVG will redraw changed areas with this period time*/
#ifndef EG_DISP_DEF_REFR_PERIOD
    #ifdef CONFIG_EG_DISP_DEF_REFR_PERIOD
        #define EG_DISP_DEF_REFR_PERIOD CONFIG_EG_DISP_DEF_REFR_PERIOD
    #else
        #define EG_DISP_DEF_REFR_PERIOD 30      /*[ms]*/
    #endif
#endif

/*Input device read period in milliseconds*/
#ifndef EG_INDEV_DEF_READ_PERIOD
    #ifdef CONFIG_EG_INDEV_DEF_READ_PERIOD
        #define EG_INDEV_DEF_READ_PERIOD CONFIG_EG_INDEV_DEF_READ_PERIOD
    #else
        #define EG_INDEV_DEF_READ_PERIOD 30     /*[ms]*/
    #endif
#endif

/*Use a custom tick source that tells the elapsed time in milliseconds.
 *It removes the need to manually update the tick with `EG_IncrementTick()`)*/
#ifndef EG_TICK_CUSTOM
    #ifdef CONFIG_EG_TICK_CUSTOM
        #define EG_TICK_CUSTOM CONFIG_EG_TICK_CUSTOM
    #else
        #define EG_TICK_CUSTOM 0
    #endif
#endif
#if EG_TICK_CUSTOM
    #ifndef EG_TICK_CUSTOM_INCLUDE
        #ifdef CONFIG_EG_TICK_CUSTOM_INCLUDE
            #define EG_TICK_CUSTOM_INCLUDE CONFIG_EG_TICK_CUSTOM_INCLUDE
        #else
            #define EG_TICK_CUSTOM_INCLUDE "Arduino.h"         /*Header for the system time function*/
        #endif
    #endif
    #ifndef EG_TICK_CUSTOM_SYS_TIME_EXPR
        #ifdef CONFIG_EG_TICK_CUSTOM_SYS_TIME_EXPR
            #define EG_TICK_CUSTOM_SYS_TIME_EXPR CONFIG_EG_TICK_CUSTOM_SYS_TIME_EXPR
        #else
            #define EG_TICK_CUSTOM_SYS_TIME_EXPR (millis())    /*Expression evaluating to current system time in ms*/
        #endif
    #endif
    /*If using lvgl as ESP32 component*/
    // #define EG_TICK_CUSTOM_INCLUDE "esp_timer.h"
    // #define EG_TICK_CUSTOM_SYS_TIME_EXPR ((esp_timer_get_time() / 1000LL))
#endif   /*EG_TICK_CUSTOM*/

/*Default Dot Per Inch. Used to initialize default sizes such as widgets sized, style paddings.
 *(Not so important, you can adjust it to modify default sizes and spaces)*/
#ifndef EG_DPI_DEF
    #ifdef CONFIG_EG_DPI_DEF
        #define EG_DPI_DEF CONFIG_EG_DPI_DEF
    #else
        #define EG_DPI_DEF 130     /*[px/inch]*/
    #endif
#endif

/*=======================
 * FEATURE CONFIGURATION
 *=======================*/

/*-------------
 * Drawing
 *-----------*/

/*Enable complex draw engine.
 *Required to draw shadow, gradient, rounded corners, circles, arc, skew lines, image transformations or any masks*/
#ifndef EG_DRAW_COMPLEX
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_DRAW_COMPLEX
            #define EG_DRAW_COMPLEX CONFIG_EG_DRAW_COMPLEX
        #else
            #define EG_DRAW_COMPLEX 0
        #endif
    #else
        #define EG_DRAW_COMPLEX 1
    #endif
#endif
#if EG_DRAW_COMPLEX != 0

    /*Allow buffering some shadow calculation.
    *EG_SHADOW_CACHE_SIZE is the max. shadow size to buffer, where shadow size is `shadow_width + radius`
    *Caching has EG_SHADOW_CACHE_SIZE^2 RAM cost*/
    #ifndef EG_SHADOW_CACHE_SIZE
        #ifdef CONFIG_EG_SHADOW_CACHE_SIZE
            #define EG_SHADOW_CACHE_SIZE CONFIG_EG_SHADOW_CACHE_SIZE
        #else
            #define EG_SHADOW_CACHE_SIZE 0
        #endif
    #endif

    /* Set number of maximally cached circle data.
    * The circumference of 1/4 circle are saved for anti-aliasing
    * radius * 4 bytes are used per circle (the most often used radiuses are saved)
    * 0: to disable caching */
    #ifndef EG_CIRCLE_CACHE_SIZE
        #ifdef CONFIG_EG_CIRCLE_CACHE_SIZE
            #define EG_CIRCLE_CACHE_SIZE CONFIG_EG_CIRCLE_CACHE_SIZE
        #else
            #define EG_CIRCLE_CACHE_SIZE 4
        #endif
    #endif
#endif /*EG_DRAW_COMPLEX*/

/**
 * "Simple layers" are used when a widget has `style_opa < 255` to buffer the widget into a layer
 * and blend it as an image with the given opacity.
 * Note that `bg_opa`, `text_opa` etc don't require buffering into layer)
 * The widget can be buffered in smaller chunks to avoid using large buffers.
 *
 * - EG_LAYER_SIMPLE_BUF_SIZE: [bytes] the optimal target buffer size. LEGL will try to allocate it
 * - EG_LAYER_SIMPLE_FALLBACK_BUF_SIZE: [bytes]  used if `EG_LAYER_SIMPLE_BUF_SIZE` couldn't be allocated.
 *
 * Both buffer sizes are in bytes.
 * "Transformed layers" (where transform_angle/zoom properties are used) use larger buffers
 * and can't be drawn in chunks. So these settings affects only widgets with opacity.
 */
#ifndef EG_LAYER_SIMPLE_BUF_SIZE
    #ifdef CONFIG_EG_LAYER_SIMPLE_BUF_SIZE
        #define EG_LAYER_SIMPLE_BUF_SIZE CONFIG_EG_LAYER_SIMPLE_BUF_SIZE
    #else
        #define EG_LAYER_SIMPLE_BUF_SIZE          (24 * 1024)
    #endif
#endif
#ifndef EG_LAYER_SIMPLE_FALLBACK_BUF_SIZE
    #ifdef CONFIG_EG_LAYER_SIMPLE_FALLBACK_BUF_SIZE
        #define EG_LAYER_SIMPLE_FALLBACK_BUF_SIZE CONFIG_EG_LAYER_SIMPLE_FALLBACK_BUF_SIZE
    #else
        #define EG_LAYER_SIMPLE_FALLBACK_BUF_SIZE (3 * 1024)
    #endif
#endif

/*Default image cache size. Image caching keeps the images opened.
 *If only the built-in image formats are used there is no real advantage of caching. (I.e. if no new image decoder is added)
 *With complex image decoders (e.g. PNG or JPG) caching can save the continuous open/decode of images.
 *However the opened images might consume additional RAM.
 *0: to disable caching*/
#ifndef EG_IMG_CACHE_DEF_SIZE
    #ifdef CONFIG_EG_IMG_CACHE_DEF_SIZE
        #define EG_IMG_CACHE_DEF_SIZE CONFIG_EG_IMG_CACHE_DEF_SIZE
    #else
        #define EG_IMG_CACHE_DEF_SIZE 0
    #endif
#endif

/*Number of stops allowed per gradient. Increase this to allow more stops.
 *This adds (sizeof(EG_Color_t) + 1) bytes per additional stop*/
#ifndef EG_GRADIENT_MAX_STOPS
    #ifdef CONFIG_EG_GRADIENT_MAX_STOPS
        #define EG_GRADIENT_MAX_STOPS CONFIG_EG_GRADIENT_MAX_STOPS
    #else
        #define EG_GRADIENT_MAX_STOPS 2
    #endif
#endif

/*Default gradient buffer size.
 *When LEGL calculates the gradient "maps" it can save them into a cache to avoid calculating them again.
 *EG_GRAD_CACHE_DEF_SIZE sets the size of this cache in bytes.
 *If the cache is too small the map will be allocated only while it's required for the drawing.
 *0 mean no caching.*/
#ifndef EG_GRAD_CACHE_DEF_SIZE
    #ifdef CONFIG_EG_GRAD_CACHE_DEF_SIZE
        #define EG_GRAD_CACHE_DEF_SIZE CONFIG_EG_GRAD_CACHE_DEF_SIZE
    #else
        #define EG_GRAD_CACHE_DEF_SIZE 0
    #endif
#endif

/*Allow dithering the gradients (to achieve visual smooth color gradients on limited color depth display)
 *EG_DITHER_GRADIENT implies allocating one or two more lines of the object's rendering surface
 *The increase in memory consumption is (32 bits * object width) plus 24 bits * object width if using error diffusion */
#ifndef EG_DITHER_GRADIENT
    #ifdef CONFIG_EG_DITHER_GRADIENT
        #define EG_DITHER_GRADIENT CONFIG_EG_DITHER_GRADIENT
    #else
        #define EG_DITHER_GRADIENT 0
    #endif
#endif
#if EG_DITHER_GRADIENT
    /*Add support for error diffusion dithering.
     *Error diffusion dithering gets a much better visual result, but implies more CPU consumption and memory when drawing.
     *The increase in memory consumption is (24 bits * object's width)*/
    #ifndef EG_DITHER_ERROR_DIFFUSION
        #ifdef CONFIG_EG_DITHER_ERROR_DIFFUSION
            #define EG_DITHER_ERROR_DIFFUSION CONFIG_EG_DITHER_ERROR_DIFFUSION
        #else
            #define EG_DITHER_ERROR_DIFFUSION 0
        #endif
    #endif
#endif

/*Maximum buffer size to allocate for rotation.
 *Only used if software rotation is enabled in the display driver.*/
#ifndef EG_DISP_ROT_MAX_BUF
    #ifdef CONFIG_EG_DISP_ROT_MAX_BUF
        #define EG_DISP_ROT_MAX_BUF CONFIG_EG_DISP_ROT_MAX_BUF
    #else
        #define EG_DISP_ROT_MAX_BUF (10*1024)
    #endif
#endif

/*-------------
 * GPU
 *-----------*/

/*Use Arm's 2D acceleration library Arm-2D */
#ifndef EG_USE_GPU_ARM2D
    #ifdef CONFIG_EG_USE_GPU_ARM2D
        #define EG_USE_GPU_ARM2D CONFIG_EG_USE_GPU_ARM2D
    #else
        #define EG_USE_GPU_ARM2D 0
    #endif
#endif

/*Use STM32's DMA2D (aka Chrom Art) GPU*/
#ifndef EG_USE_GPU_STM32_DMA2D
    #ifdef CONFIG_EG_USE_GPU_STM32_DMA2D
        #define EG_USE_GPU_STM32_DMA2D CONFIG_EG_USE_GPU_STM32_DMA2D
    #else
        #define EG_USE_GPU_STM32_DMA2D 0
    #endif
#endif
#if EG_USE_GPU_STM32_DMA2D
    /*Must be defined to include path of CMSIS header of target processor
    e.g. "stm32f7xx.h" or "stm32f4xx.h"*/
    #ifndef EG_GPU_DMA2D_CMSIS_INCLUDE
        #ifdef CONFIG_EG_GPU_DMA2D_CMSIS_INCLUDE
            #define EG_GPU_DMA2D_CMSIS_INCLUDE CONFIG_EG_GPU_DMA2D_CMSIS_INCLUDE
        #else
            #define EG_GPU_DMA2D_CMSIS_INCLUDE
        #endif
    #endif
#endif

/*Enable RA6M3 G2D GPU*/
#ifndef EG_USE_GPU_RA6M3_G2D
    #ifdef CONFIG_EG_USE_GPU_RA6M3_G2D
        #define EG_USE_GPU_RA6M3_G2D CONFIG_EG_USE_GPU_RA6M3_G2D
    #else
        #define EG_USE_GPU_RA6M3_G2D 0
    #endif
#endif
#if EG_USE_GPU_RA6M3_G2D
    /*include path of target processor
    e.g. "hal_data.h"*/
    #ifndef EG_GPU_RA6M3_G2D_INCLUDE
        #ifdef CONFIG_EG_GPU_RA6M3_G2D_INCLUDE
            #define EG_GPU_RA6M3_G2D_INCLUDE CONFIG_EG_GPU_RA6M3_G2D_INCLUDE
        #else
            #define EG_GPU_RA6M3_G2D_INCLUDE "hal_data.h"
        #endif
    #endif
#endif

/*Use SWM341's DMA2D GPU*/
#ifndef EG_USE_GPU_SWM341_DMA2D
    #ifdef CONFIG_EG_USE_GPU_SWM341_DMA2D
        #define EG_USE_GPU_SWM341_DMA2D CONFIG_EG_USE_GPU_SWM341_DMA2D
    #else
        #define EG_USE_GPU_SWM341_DMA2D 0
    #endif
#endif
#if EG_USE_GPU_SWM341_DMA2D
    #ifndef EG_GPU_SWM341_DMA2D_INCLUDE
        #ifdef CONFIG_EG_GPU_SWM341_DMA2D_INCLUDE
            #define EG_GPU_SWM341_DMA2D_INCLUDE CONFIG_EG_GPU_SWM341_DMA2D_INCLUDE
        #else
            #define EG_GPU_SWM341_DMA2D_INCLUDE "SWM341.h"
        #endif
    #endif
#endif

/*Use NXP's PXP GPU iMX RTxxx platforms*/
#ifndef EG_USE_GPU_NXP_PXP
    #ifdef CONFIG_EG_USE_GPU_NXP_PXP
        #define EG_USE_GPU_NXP_PXP CONFIG_EG_USE_GPU_NXP_PXP
    #else
        #define EG_USE_GPU_NXP_PXP 0
    #endif
#endif
#if EG_USE_GPU_NXP_PXP
    /*1: Add default bare metal and FreeRTOS interrupt handling routines for PXP (lv_gpu_nxp_pxp_osa.c)
    *   and call lv_gpu_nxp_pxp_init() automatically during EG_Init(). Note that symbol SDK_OS_FREE_RTOS
    *   has to be defined in order to use FreeRTOS OSA, otherwise bare-metal implementation is selected.
    *0: lv_gpu_nxp_pxp_init() has to be called manually before EG_Init()
    */
    #ifndef EG_USE_GPU_NXP_PXP_AUTO_INIT
        #ifdef CONFIG_EG_USE_GPU_NXP_PXP_AUTO_INIT
            #define EG_USE_GPU_NXP_PXP_AUTO_INIT CONFIG_EG_USE_GPU_NXP_PXP_AUTO_INIT
        #else
            #define EG_USE_GPU_NXP_PXP_AUTO_INIT 0
        #endif
    #endif
#endif

/*Use NXP's VG-Lite GPU iMX RTxxx platforms*/
#ifndef EG_USE_GPU_NXP_VG_LITE
    #ifdef CONFIG_EG_USE_GPU_NXP_VG_LITE
        #define EG_USE_GPU_NXP_VG_LITE CONFIG_EG_USE_GPU_NXP_VG_LITE
    #else
        #define EG_USE_GPU_NXP_VG_LITE 0
    #endif
#endif

/*Use SDL renderer API*/
#ifndef EG_USE_GPU_SDL
    #ifdef CONFIG_EG_USE_GPU_SDL
        #define EG_USE_GPU_SDL CONFIG_EG_USE_GPU_SDL
    #else
        #define EG_USE_GPU_SDL 0
    #endif
#endif
#if EG_USE_GPU_SDL
    #ifndef EG_GPU_SDL_INCLUDE_PATH
        #ifdef CONFIG_EG_GPU_SDL_INCLUDE_PATH
            #define EG_GPU_SDL_INCLUDE_PATH CONFIG_EG_GPU_SDL_INCLUDE_PATH
        #else
            #define EG_GPU_SDL_INCLUDE_PATH <SDL2/SDL.h>
        #endif
    #endif
    /*Texture cache size, 8MB by default*/
    #ifndef EG_GPU_SDL_LRU_SIZE
        #ifdef CONFIG_EG_GPU_SDL_LRU_SIZE
            #define EG_GPU_SDL_LRU_SIZE CONFIG_EG_GPU_SDL_LRU_SIZE
        #else
            #define EG_GPU_SDL_LRU_SIZE (1024 * 1024 * 8)
        #endif
    #endif
    /*Custom blend mode for mask drawing, disable if you need to link with older SDL2 lib*/
    #ifndef EG_GPU_SDL_CUSTOM_BLEND_MODE
        #ifdef CONFIG_EG_GPU_SDL_CUSTOM_BLEND_MODE
            #define EG_GPU_SDL_CUSTOM_BLEND_MODE CONFIG_EG_GPU_SDL_CUSTOM_BLEND_MODE
        #else
            #define EG_GPU_SDL_CUSTOM_BLEND_MODE (SDL_VERSION_ATLEAST(2, 0, 6))
        #endif
    #endif
#endif

/*-------------
 * Logging
 *-----------*/

/*Enable the log module*/
#ifndef EG_USE_LOG
    #ifdef CONFIG_EG_USE_LOG
        #define EG_USE_LOG CONFIG_EG_USE_LOG
    #else
        #define EG_USE_LOG 0
    #endif
#endif
#if EG_USE_LOG

    /*How important log should be added:
    *EG_LOG_LEVEL_TRACE       A lot of logs to give detailed information
    *EG_LOG_LEVEL_INFO        Log important events
    *EG_LOG_LEVEL_WARN        Log if something unwanted happened but didn't cause a problem
    *EG_LOG_LEVEL_ERROR       Only critical issue, when the system may fail
    *EG_LOG_LEVEL_USER        Only logs added by the user
    *EG_LOG_LEVEL_NONE        Do not log anything*/
    #ifndef EG_LOG_LEVEL
        #ifdef CONFIG_EG_LOG_LEVEL
            #define EG_LOG_LEVEL CONFIG_EG_LOG_LEVEL
        #else
            #define EG_LOG_LEVEL EG_LOG_LEVEL_WARN
        #endif
    #endif

    /*1: Print the log with 'printf';
    *0: User need to register a callback with `EG_RegisterLogPrintCB()`*/
    #ifndef EG_LOG_PRINTF
        #ifdef CONFIG_EG_LOG_PRINTF
            #define EG_LOG_PRINTF CONFIG_EG_LOG_PRINTF
        #else
            #define EG_LOG_PRINTF 0
        #endif
    #endif

    /*Enable/disable EG_LOG_TRACE in modules that produces a huge number of logs*/
    #ifndef EG_LOG_TRACE_MEM
        #ifdef _EG_KCONFIG_PRESENT
            #ifdef CONFIG_EG_LOG_TRACE_MEM
                #define EG_LOG_TRACE_MEM CONFIG_EG_LOG_TRACE_MEM
            #else
                #define EG_LOG_TRACE_MEM 0
            #endif
        #else
            #define EG_LOG_TRACE_MEM        1
        #endif
    #endif
    #ifndef EG_LOG_TRACE_TIMER
        #ifdef _EG_KCONFIG_PRESENT
            #ifdef CONFIG_EG_LOG_TRACE_TIMER
                #define EG_LOG_TRACE_TIMER CONFIG_EG_LOG_TRACE_TIMER
            #else
                #define EG_LOG_TRACE_TIMER 0
            #endif
        #else
            #define EG_LOG_TRACE_TIMER      1
        #endif
    #endif
    #ifndef EG_LOG_TRACE_INDEV
        #ifdef _EG_KCONFIG_PRESENT
            #ifdef CONFIG_EG_LOG_TRACE_INDEV
                #define EG_LOG_TRACE_INDEV CONFIG_EG_LOG_TRACE_INDEV
            #else
                #define EG_LOG_TRACE_INDEV 0
            #endif
        #else
            #define EG_LOG_TRACE_INDEV      1
        #endif
    #endif
    #ifndef EG_LOG_TRACE_DISP_REFR
        #ifdef _EG_KCONFIG_PRESENT
            #ifdef CONFIG_EG_LOG_TRACE_DISP_REFR
                #define EG_LOG_TRACE_DISP_REFR CONFIG_EG_LOG_TRACE_DISP_REFR
            #else
                #define EG_LOG_TRACE_DISP_REFR 0
            #endif
        #else
            #define EG_LOG_TRACE_DISP_REFR  1
        #endif
    #endif
    #ifndef EG_LOG_TRACE_EVENT
        #ifdef _EG_KCONFIG_PRESENT
            #ifdef CONFIG_EG_LOG_TRACE_EVENT
                #define EG_LOG_TRACE_EVENT CONFIG_EG_LOG_TRACE_EVENT
            #else
                #define EG_LOG_TRACE_EVENT 0
            #endif
        #else
            #define EG_LOG_TRACE_EVENT      1
        #endif
    #endif
    #ifndef EG_LOG_TRACE_OBJ_CREATE
        #ifdef _EG_KCONFIG_PRESENT
            #ifdef CONFIG_EG_LOG_TRACE_OBJ_CREATE
                #define EG_LOG_TRACE_OBJ_CREATE CONFIG_EG_LOG_TRACE_OBJ_CREATE
            #else
                #define EG_LOG_TRACE_OBJ_CREATE 0
            #endif
        #else
            #define EG_LOG_TRACE_OBJ_CREATE 1
        #endif
    #endif
    #ifndef EG_LOG_TRACE_LAYOUT
        #ifdef _EG_KCONFIG_PRESENT
            #ifdef CONFIG_EG_LOG_TRACE_LAYOUT
                #define EG_LOG_TRACE_LAYOUT CONFIG_EG_LOG_TRACE_LAYOUT
            #else
                #define EG_LOG_TRACE_LAYOUT 0
            #endif
        #else
            #define EG_LOG_TRACE_LAYOUT     1
        #endif
    #endif
    #ifndef EG_LOG_TRACE_ANIM
        #ifdef _EG_KCONFIG_PRESENT
            #ifdef CONFIG_EG_LOG_TRACE_ANIM
                #define EG_LOG_TRACE_ANIM CONFIG_EG_LOG_TRACE_ANIM
            #else
                #define EG_LOG_TRACE_ANIM 0
            #endif
        #else
            #define EG_LOG_TRACE_ANIM       1
        #endif
    #endif

#endif  /*EG_USE_LOG*/

/*-------------
 * Asserts
 *-----------*/

/*Enable asserts if an operation is failed or an invalid data is found.
 *If EG_USE_LOG is enabled an error message will be printed on failure*/
#ifndef EG_USE_ASSERT_NULL
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_ASSERT_NULL
            #define EG_USE_ASSERT_NULL CONFIG_EG_USE_ASSERT_NULL
        #else
            #define EG_USE_ASSERT_NULL 0
        #endif
    #else
        #define EG_USE_ASSERT_NULL          1   /*Check if the parameter is NULL. (Very fast, recommended)*/
    #endif
#endif
#ifndef EG_USE_ASSERT_MALLOC
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_ASSERT_MALLOC
            #define EG_USE_ASSERT_MALLOC CONFIG_EG_USE_ASSERT_MALLOC
        #else
            #define EG_USE_ASSERT_MALLOC 0
        #endif
    #else
        #define EG_USE_ASSERT_MALLOC        1   /*Checks is the memory is successfully allocated or no. (Very fast, recommended)*/
    #endif
#endif
#ifndef EG_USE_ASSERT_STYLE
    #ifdef CONFIG_EG_USE_ASSERT_STYLE
        #define EG_USE_ASSERT_STYLE CONFIG_EG_USE_ASSERT_STYLE
    #else
        #define EG_USE_ASSERT_STYLE         0   /*Check if the styles are properly initialized. (Very fast, recommended)*/
    #endif
#endif
#ifndef EG_USE_ASSERT_MEM_INTEGRITY
    #ifdef CONFIG_EG_USE_ASSERT_MEM_INTEGRITY
        #define EG_USE_ASSERT_MEM_INTEGRITY CONFIG_EG_USE_ASSERT_MEM_INTEGRITY
    #else
        #define EG_USE_ASSERT_MEM_INTEGRITY 0   /*Check the integrity of `EG_Memory` after critical operations. (Slow)*/
    #endif
#endif
#ifndef EG_USE_ASSERT_OBJ
    #ifdef CONFIG_EG_USE_ASSERT_OBJ
        #define EG_USE_ASSERT_OBJ CONFIG_EG_USE_ASSERT_OBJ
    #else
        #define EG_USE_ASSERT_OBJ           0   /*Check the object's type and existence (e.g. not deleted). (Slow)*/
    #endif
#endif

/*Add a custom handler when assert happens e.g. to restart the MCU*/
#ifndef EG_ASSERT_HANDLER_INCLUDE
    #ifdef CONFIG_EG_ASSERT_HANDLER_INCLUDE
        #define EG_ASSERT_HANDLER_INCLUDE CONFIG_EG_ASSERT_HANDLER_INCLUDE
    #else
        #define EG_ASSERT_HANDLER_INCLUDE <stdint.h>
    #endif
#endif
#ifndef EG_ASSERT_HANDLER
    #ifdef CONFIG_EG_ASSERT_HANDLER
        #define EG_ASSERT_HANDLER CONFIG_EG_ASSERT_HANDLER
    #else
        #define EG_ASSERT_HANDLER while(1);   /*Halt by default*/
    #endif
#endif

/*-------------
 * Others
 *-----------*/

/*1: Show CPU usage and FPS count*/
#ifndef EG_USE_PERF_MONITOR
    #ifdef CONFIG_EG_USE_PERF_MONITOR
        #define EG_USE_PERF_MONITOR CONFIG_EG_USE_PERF_MONITOR
    #else
        #define EG_USE_PERF_MONITOR 0
    #endif
#endif
#if EG_USE_PERF_MONITOR
    #ifndef EG_USE_PERF_MONITOR_POS
        #ifdef CONFIG_EG_USE_PERF_MONITOR_POS
            #define EG_USE_PERF_MONITOR_POS CONFIG_EG_USE_PERF_MONITOR_POS
        #else
            #define EG_USE_PERF_MONITOR_POS EG_ALIGN_BOTTOM_RIGHT
        #endif
    #endif
#endif

/*1: Show the used memory and the memory fragmentation
 * Requires EG_MEM_CUSTOM = 0*/
#ifndef EG_USE_MEM_MONITOR
    #ifdef CONFIG_EG_USE_MEM_MONITOR
        #define EG_USE_MEM_MONITOR CONFIG_EG_USE_MEM_MONITOR
    #else
        #define EG_USE_MEM_MONITOR 0
    #endif
#endif
#if EG_USE_MEM_MONITOR
    #ifndef EG_USE_MEM_MONITOR_POS
        #ifdef CONFIG_EG_USE_MEM_MONITOR_POS
            #define EG_USE_MEM_MONITOR_POS CONFIG_EG_USE_MEM_MONITOR_POS
        #else
            #define EG_USE_MEM_MONITOR_POS EG_ALIGN_BOTTOM_LEFT
        #endif
    #endif
#endif

/*1: Draw random colored rectangles over the redrawn areas*/
#ifndef EG_USE_REFR_DEBUG
    #ifdef CONFIG_EG_USE_REFR_DEBUG
        #define EG_USE_REFR_DEBUG CONFIG_EG_USE_REFR_DEBUG
    #else
        #define EG_USE_REFR_DEBUG 0
    #endif
#endif

/*Change the built in (v)snprintf functions*/
#ifndef EG_SPRINTF_CUSTOM
    #ifdef CONFIG_EG_SPRINTF_CUSTOM
        #define EG_SPRINTF_CUSTOM CONFIG_EG_SPRINTF_CUSTOM
    #else
        #define EG_SPRINTF_CUSTOM 0
    #endif
#endif
#if EG_SPRINTF_CUSTOM
    #ifndef EG_SPRINTF_INCLUDE
        #ifdef CONFIG_EG_SPRINTF_INCLUDE
            #define EG_SPRINTF_INCLUDE CONFIG_EG_SPRINTF_INCLUDE
        #else
            #define EG_SPRINTF_INCLUDE <stdio.h>
        #endif
    #endif
    #ifndef eg_snprintf
        #ifdef CONFIG_EG_SNPRINTF
            #define eg_snprintf CONFIG_EG_SNPRINTF
        #else
            #define eg_snprintf  snprintf
        #endif
    #endif
    #ifndef eg_vsnprintf
        #ifdef CONFIG_EG_VSNPRINTF
            #define eg_vsnprintf CONFIG_EG_VSNPRINTF
        #else
            #define eg_vsnprintf vsnprintf
        #endif
    #endif
#else   /*EG_SPRINTF_CUSTOM*/
    #ifndef EG_SPRINTF_USE_FLOAT
        #ifdef CONFIG_EG_SPRINTF_USE_FLOAT
            #define EG_SPRINTF_USE_FLOAT CONFIG_EG_SPRINTF_USE_FLOAT
        #else
            #define EG_SPRINTF_USE_FLOAT 0
        #endif
    #endif
#endif  /*EG_SPRINTF_CUSTOM*/

#ifndef EG_USE_USER_DATA
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_USER_DATA
            #define EG_USE_USER_DATA CONFIG_EG_USE_USER_DATA
        #else
            #define EG_USE_USER_DATA 0
        #endif
    #else
        #define EG_USE_USER_DATA 1
    #endif
#endif

/*Garbage Collector settings
 *Used if lvgl is bound to higher level language and the memory is managed by that language*/
#ifndef EG_ENABLE_GC
    #ifdef CONFIG_EG_ENABLE_GC
        #define EG_ENABLE_GC CONFIG_EG_ENABLE_GC
    #else
        #define EG_ENABLE_GC 0
    #endif
#endif
#if EG_ENABLE_GC != 0
    #ifndef EG_GC_INCLUDE
        #ifdef CONFIG_EG_GC_INCLUDE
            #define EG_GC_INCLUDE CONFIG_EG_GC_INCLUDE
        #else
            #define EG_GC_INCLUDE "gc.h"                           /*Include Garbage Collector related things*/
        #endif
    #endif
#endif /*EG_ENABLE_GC*/

/*=====================
 *  COMPILER SETTINGS
 *====================*/

/*For big endian systems set to 1*/
#ifndef EG_BIG_ENDIAN_SYSTEM
    #ifdef CONFIG_EG_BIG_ENDIAN_SYSTEM
        #define EG_BIG_ENDIAN_SYSTEM CONFIG_EG_BIG_ENDIAN_SYSTEM
    #else
        #define EG_BIG_ENDIAN_SYSTEM 0
    #endif
#endif

/*Define a custom attribute to `EG_IncrementTick` function*/
#ifndef EG_ATTRIBUTE_TICK_INC
    #ifdef CONFIG_EG_ATTRIBUTE_TICK_INC
        #define EG_ATTRIBUTE_TICK_INC CONFIG_EG_ATTRIBUTE_TICK_INC
    #else
        #define EG_ATTRIBUTE_TICK_INC
    #endif
#endif

/*Define a custom attribute to `EG_TimerHandler` function*/
#ifndef EG_ATTRIBUTE_TIMER_HANDLER
    #ifdef CONFIG_EG_ATTRIBUTE_TIMER_HANDLER
        #define EG_ATTRIBUTE_TIMER_HANDLER CONFIG_EG_ATTRIBUTE_TIMER_HANDLER
    #else
        #define EG_ATTRIBUTE_TIMER_HANDLER
    #endif
#endif

/*Define a custom attribute to `EG_DispFlushReady` function*/
#ifndef EG_ATTRIBUTE_FLUSH_READY
    #ifdef CONFIG_EG_ATTRIBUTE_FLUSH_READY
        #define EG_ATTRIBUTE_FLUSH_READY CONFIG_EG_ATTRIBUTE_FLUSH_READY
    #else
        #define EG_ATTRIBUTE_FLUSH_READY
    #endif
#endif

/*Required alignment size for buffers*/
#ifndef EG_ATTRIBUTE_MEM_ALIGN_SIZE
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_ATTRIBUTE_MEM_ALIGN_SIZE
            #define EG_ATTRIBUTE_MEM_ALIGN_SIZE CONFIG_EG_ATTRIBUTE_MEM_ALIGN_SIZE
        #else
            #define EG_ATTRIBUTE_MEM_ALIGN_SIZE 0
        #endif
    #else
        #define EG_ATTRIBUTE_MEM_ALIGN_SIZE 1
    #endif
#endif

/*Will be added where memories needs to be aligned (with -Os data might not be aligned to boundary by default).
 * E.g. __attribute__((aligned(4)))*/
#ifndef EG_ATTRIBUTE_MEM_ALIGN
    #ifdef CONFIG_EG_ATTRIBUTE_MEM_ALIGN
        #define EG_ATTRIBUTE_MEM_ALIGN CONFIG_EG_ATTRIBUTE_MEM_ALIGN
    #else
        #define EG_ATTRIBUTE_MEM_ALIGN
    #endif
#endif

/*Attribute to mark large constant arrays for example font's bitmaps*/
#ifndef EG_ATTRIBUTE_LARGE_CONST
    #ifdef CONFIG_EG_ATTRIBUTE_LARGE_CONST
        #define EG_ATTRIBUTE_LARGE_CONST CONFIG_EG_ATTRIBUTE_LARGE_CONST
    #else
        #define EG_ATTRIBUTE_LARGE_CONST
    #endif
#endif

/*Compiler prefix for a big array declaration in RAM*/
#ifndef EG_ATTRIBUTE_LARGE_RAM_ARRAY
    #ifdef CONFIG_EG_ATTRIBUTE_LARGE_RAM_ARRAY
        #define EG_ATTRIBUTE_LARGE_RAM_ARRAY CONFIG_EG_ATTRIBUTE_LARGE_RAM_ARRAY
    #else
        #define EG_ATTRIBUTE_LARGE_RAM_ARRAY
    #endif
#endif

/*Place performance critical functions into a faster memory (e.g RAM)*/
#ifndef EG_ATTRIBUTE_FAST_MEM
    #ifdef CONFIG_EG_ATTRIBUTE_FAST_MEM
        #define EG_ATTRIBUTE_FAST_MEM CONFIG_EG_ATTRIBUTE_FAST_MEM
    #else
        #define EG_ATTRIBUTE_FAST_MEM
    #endif
#endif

/*Prefix variables that are used in GPU accelerated operations, often these need to be placed in RAM sections that are DMA accessible*/
#ifndef EG_ATTRIBUTE_DMA
    #ifdef CONFIG_EG_ATTRIBUTE_DMA
        #define EG_ATTRIBUTE_DMA CONFIG_EG_ATTRIBUTE_DMA
    #else
        #define EG_ATTRIBUTE_DMA
    #endif
#endif

/*Export integer constant to binding. This macro is used with constants in the form of EG_<CONST> that
 *should also appear on LEGL binding API such as Micropython.*/
#ifndef EG_EXPORT_CONST_INT
    #ifdef CONFIG_EG_EXPORT_CONST_INT
        #define EG_EXPORT_CONST_INT CONFIG_EG_EXPORT_CONST_INT
    #else
        #define EG_EXPORT_CONST_INT(int_value) struct _silence_gcc_warning /*The default value just prevents GCC warning*/
    #endif
#endif

/*Extend the default -32k..32k coordinate range to -4M..4M by using int32_t for coordinates instead of int16_t*/
#ifndef EG_USE_LARGE_COORD
    #ifdef CONFIG_EG_USE_LARGE_COORD
        #define EG_USE_LARGE_COORD CONFIG_EG_USE_LARGE_COORD
    #else
        #define EG_USE_LARGE_COORD 0
    #endif
#endif

/*==================
 *   FONT USAGE
 *===================*/

/*Montserrat fonts with ASCII range and some symbols using bpp = 4
 *https://fonts.google.com/specimen/Montserrat*/
#ifndef EG_FONT_MONTSERRAT_8
    #ifdef CONFIG_EG_FONT_MONTSERRAT_8
        #define EG_FONT_MONTSERRAT_8 CONFIG_EG_FONT_MONTSERRAT_8
    #else
        #define EG_FONT_MONTSERRAT_8  0
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_10
    #ifdef CONFIG_EG_FONT_MONTSERRAT_10
        #define EG_FONT_MONTSERRAT_10 CONFIG_EG_FONT_MONTSERRAT_10
    #else
        #define EG_FONT_MONTSERRAT_10 0
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_12
    #ifdef CONFIG_EG_FONT_MONTSERRAT_12
        #define EG_FONT_MONTSERRAT_12 CONFIG_EG_FONT_MONTSERRAT_12
    #else
        #define EG_FONT_MONTSERRAT_12 0
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_14
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_FONT_MONTSERRAT_14
            #define EG_FONT_MONTSERRAT_14 CONFIG_EG_FONT_MONTSERRAT_14
        #else
            #define EG_FONT_MONTSERRAT_14 0
        #endif
    #else
        #define EG_FONT_MONTSERRAT_14 1
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_16
    #ifdef CONFIG_EG_FONT_MONTSERRAT_16
        #define EG_FONT_MONTSERRAT_16 CONFIG_EG_FONT_MONTSERRAT_16
    #else
        #define EG_FONT_MONTSERRAT_16 0
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_18
    #ifdef CONFIG_EG_FONT_MONTSERRAT_18
        #define EG_FONT_MONTSERRAT_18 CONFIG_EG_FONT_MONTSERRAT_18
    #else
        #define EG_FONT_MONTSERRAT_18 0
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_20
    #ifdef CONFIG_EG_FONT_MONTSERRAT_20
        #define EG_FONT_MONTSERRAT_20 CONFIG_EG_FONT_MONTSERRAT_20
    #else
        #define EG_FONT_MONTSERRAT_20 0
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_22
    #ifdef CONFIG_EG_FONT_MONTSERRAT_22
        #define EG_FONT_MONTSERRAT_22 CONFIG_EG_FONT_MONTSERRAT_22
    #else
        #define EG_FONT_MONTSERRAT_22 0
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_24
    #ifdef CONFIG_EG_FONT_MONTSERRAT_24
        #define EG_FONT_MONTSERRAT_24 CONFIG_EG_FONT_MONTSERRAT_24
    #else
        #define EG_FONT_MONTSERRAT_24 0
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_26
    #ifdef CONFIG_EG_FONT_MONTSERRAT_26
        #define EG_FONT_MONTSERRAT_26 CONFIG_EG_FONT_MONTSERRAT_26
    #else
        #define EG_FONT_MONTSERRAT_26 0
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_28
    #ifdef CONFIG_EG_FONT_MONTSERRAT_28
        #define EG_FONT_MONTSERRAT_28 CONFIG_EG_FONT_MONTSERRAT_28
    #else
        #define EG_FONT_MONTSERRAT_28 0
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_30
    #ifdef CONFIG_EG_FONT_MONTSERRAT_30
        #define EG_FONT_MONTSERRAT_30 CONFIG_EG_FONT_MONTSERRAT_30
    #else
        #define EG_FONT_MONTSERRAT_30 0
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_32
    #ifdef CONFIG_EG_FONT_MONTSERRAT_32
        #define EG_FONT_MONTSERRAT_32 CONFIG_EG_FONT_MONTSERRAT_32
    #else
        #define EG_FONT_MONTSERRAT_32 0
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_34
    #ifdef CONFIG_EG_FONT_MONTSERRAT_34
        #define EG_FONT_MONTSERRAT_34 CONFIG_EG_FONT_MONTSERRAT_34
    #else
        #define EG_FONT_MONTSERRAT_34 0
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_36
    #ifdef CONFIG_EG_FONT_MONTSERRAT_36
        #define EG_FONT_MONTSERRAT_36 CONFIG_EG_FONT_MONTSERRAT_36
    #else
        #define EG_FONT_MONTSERRAT_36 0
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_38
    #ifdef CONFIG_EG_FONT_MONTSERRAT_38
        #define EG_FONT_MONTSERRAT_38 CONFIG_EG_FONT_MONTSERRAT_38
    #else
        #define EG_FONT_MONTSERRAT_38 0
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_40
    #ifdef CONFIG_EG_FONT_MONTSERRAT_40
        #define EG_FONT_MONTSERRAT_40 CONFIG_EG_FONT_MONTSERRAT_40
    #else
        #define EG_FONT_MONTSERRAT_40 0
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_42
    #ifdef CONFIG_EG_FONT_MONTSERRAT_42
        #define EG_FONT_MONTSERRAT_42 CONFIG_EG_FONT_MONTSERRAT_42
    #else
        #define EG_FONT_MONTSERRAT_42 0
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_44
    #ifdef CONFIG_EG_FONT_MONTSERRAT_44
        #define EG_FONT_MONTSERRAT_44 CONFIG_EG_FONT_MONTSERRAT_44
    #else
        #define EG_FONT_MONTSERRAT_44 0
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_46
    #ifdef CONFIG_EG_FONT_MONTSERRAT_46
        #define EG_FONT_MONTSERRAT_46 CONFIG_EG_FONT_MONTSERRAT_46
    #else
        #define EG_FONT_MONTSERRAT_46 0
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_48
    #ifdef CONFIG_EG_FONT_MONTSERRAT_48
        #define EG_FONT_MONTSERRAT_48 CONFIG_EG_FONT_MONTSERRAT_48
    #else
        #define EG_FONT_MONTSERRAT_48 0
    #endif
#endif

/*Demonstrate special features*/
#ifndef EG_FONT_MONTSERRAT_12_SUBPX
    #ifdef CONFIG_EG_FONT_MONTSERRAT_12_SUBPX
        #define EG_FONT_MONTSERRAT_12_SUBPX CONFIG_EG_FONT_MONTSERRAT_12_SUBPX
    #else
        #define EG_FONT_MONTSERRAT_12_SUBPX      0
    #endif
#endif
#ifndef EG_FONT_MONTSERRAT_28_COMPRESSED
    #ifdef CONFIG_EG_FONT_MONTSERRAT_28_COMPRESSED
        #define EG_FONT_MONTSERRAT_28_COMPRESSED CONFIG_EG_FONT_MONTSERRAT_28_COMPRESSED
    #else
        #define EG_FONT_MONTSERRAT_28_COMPRESSED 0  /*bpp = 3*/
    #endif
#endif
#ifndef EG_FONT_DEJAVU_16_PERSIAN_HEBREW
    #ifdef CONFIG_EG_FONT_DEJAVU_16_PERSIAN_HEBREW
        #define EG_FONT_DEJAVU_16_PERSIAN_HEBREW CONFIG_EG_FONT_DEJAVU_16_PERSIAN_HEBREW
    #else
        #define EG_FONT_DEJAVU_16_PERSIAN_HEBREW 0  /*Hebrew, Arabic, Persian letters and all their forms*/
    #endif
#endif
#ifndef EG_FONT_SIMSUN_16_CJK
    #ifdef CONFIG_EG_FONT_SIMSUN_16_CJK
        #define EG_FONT_SIMSUN_16_CJK CONFIG_EG_FONT_SIMSUN_16_CJK
    #else
        #define EG_FONT_SIMSUN_16_CJK            0  /*1000 most common CJK radicals*/
    #endif
#endif

/*Pixel perfect monospace fonts*/
#ifndef EG_FONT_UNSCII_8
    #ifdef CONFIG_EG_FONT_UNSCII_8
        #define EG_FONT_UNSCII_8 CONFIG_EG_FONT_UNSCII_8
    #else
        #define EG_FONT_UNSCII_8  0
    #endif
#endif
#ifndef EG_FONT_UNSCII_16
    #ifdef CONFIG_EG_FONT_UNSCII_16
        #define EG_FONT_UNSCII_16 CONFIG_EG_FONT_UNSCII_16
    #else
        #define EG_FONT_UNSCII_16 0
    #endif
#endif

/*Optionally declare custom fonts here.
 *You can use these fonts as default font too and they will be available globally.
 *E.g. #define EG_FONT_CUSTOM_DECLARE   EG_FONT_DECLARE(my_font_1) EG_FONT_DECLARE(my_font_2)*/
#ifndef EG_FONT_CUSTOM_DECLARE
    #ifdef CONFIG_EG_FONT_CUSTOM_DECLARE
        #define EG_FONT_CUSTOM_DECLARE CONFIG_EG_FONT_CUSTOM_DECLARE
    #else
        #define EG_FONT_CUSTOM_DECLARE
    #endif
#endif

/*Always set a default font*/
#ifndef EG_FONT_DEFAULT
    #ifdef CONFIG_EG_FONT_DEFAULT
        #define EG_FONT_DEFAULT CONFIG_EG_FONT_DEFAULT
    #else
        #define EG_FONT_DEFAULT &EG_FontMontserrat14
    #endif
#endif

/*Enable handling large font and/or fonts with a lot of characters.
 *The limit depends on the font size, font face and bpp.
 *Compiler error will be triggered if a font needs it.*/
#ifndef EG_FONT_FMT_TXT_LARGE
    #ifdef CONFIG_EG_FONT_FMT_TXT_LARGE
        #define EG_FONT_FMT_TXT_LARGE CONFIG_EG_FONT_FMT_TXT_LARGE
    #else
        #define EG_FONT_FMT_TXT_LARGE 0
    #endif
#endif

/*Enables/disables support for compressed fonts.*/
#ifndef EG_USE_FONT_COMPRESSED
    #ifdef CONFIG_EG_USE_FONT_COMPRESSED
        #define EG_USE_FONT_COMPRESSED CONFIG_EG_USE_FONT_COMPRESSED
    #else
        #define EG_USE_FONT_COMPRESSED 0
    #endif
#endif

/*Enable subpixel rendering*/
#ifndef EG_USE_FONT_SUBPX
    #ifdef CONFIG_EG_USE_FONT_SUBPX
        #define EG_USE_FONT_SUBPX CONFIG_EG_USE_FONT_SUBPX
    #else
        #define EG_USE_FONT_SUBPX 0
    #endif
#endif
#if EG_USE_FONT_SUBPX
    /*Set the pixel order of the display. Physical order of RGB channels. Doesn't matter with "normal" fonts.*/
    #ifndef EG_FONT_SUBPX_BGR
        #ifdef CONFIG_EG_FONT_SUBPX_BGR
            #define EG_FONT_SUBPX_BGR CONFIG_EG_FONT_SUBPX_BGR
        #else
            #define EG_FONT_SUBPX_BGR 0  /*0: RGB; 1:BGR order*/
        #endif
    #endif
#endif

/*Enable drawing placeholders when glyph dsc is not found*/
#ifndef EG_USE_FONT_PLACEHOLDER
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_FONT_PLACEHOLDER
            #define EG_USE_FONT_PLACEHOLDER CONFIG_EG_USE_FONT_PLACEHOLDER
        #else
            #define EG_USE_FONT_PLACEHOLDER 0
        #endif
    #else
        #define EG_USE_FONT_PLACEHOLDER 1
    #endif
#endif

/*=================
 *  TEXT SETTINGS
 *=================*/

/**
 * Select a character encoding for strings.
 * Your IDE or editor should have the same character encoding
 * - EG_TXT_ENC_UTF8
 * - EG_TXT_ENC_ASCII
 */
#ifndef EG_TXT_ENC
    #ifdef CONFIG_EG_TXT_ENC
        #define EG_TXT_ENC CONFIG_EG_TXT_ENC
    #else
        #define EG_TXT_ENC EG_TXT_ENC_UTF8
    #endif
#endif

/*Can break (wrap) texts on these chars*/
#ifndef EG_TXT_BREAK_CHARS
    #ifdef CONFIG_EG_TXT_BREAK_CHARS
        #define EG_TXT_BREAK_CHARS CONFIG_EG_TXT_BREAK_CHARS
    #else
        #define EG_TXT_BREAK_CHARS " ,.;:-_"
    #endif
#endif

/*If a word is at least this long, will break wherever "prettiest"
 *To disable, set to a value <= 0*/
#ifndef EG_TXT_LINE_BREAK_LONG_LEN
    #ifdef CONFIG_EG_TXT_LINE_BREAK_LONG_LEN
        #define EG_TXT_LINE_BREAK_LONG_LEN CONFIG_EG_TXT_LINE_BREAK_LONG_LEN
    #else
        #define EG_TXT_LINE_BREAK_LONG_LEN 0
    #endif
#endif

/*Minimum number of characters in a long word to put on a line before a break.
 *Depends on EG_TXT_LINE_BREAK_LONG_LEN.*/
#ifndef EG_TXT_LINE_BREAK_LONG_PRE_MIN_LEN
    #ifdef CONFIG_EG_TXT_LINE_BREAK_LONG_PRE_MIN_LEN
        #define EG_TXT_LINE_BREAK_LONG_PRE_MIN_LEN CONFIG_EG_TXT_LINE_BREAK_LONG_PRE_MIN_LEN
    #else
        #define EG_TXT_LINE_BREAK_LONG_PRE_MIN_LEN 3
    #endif
#endif

/*Minimum number of characters in a long word to put on a line after a break.
 *Depends on EG_TXT_LINE_BREAK_LONG_LEN.*/
#ifndef EG_TXT_LINE_BREAK_LONG_POST_MIN_LEN
    #ifdef CONFIG_EG_TXT_LINE_BREAK_LONG_POST_MIN_LEN
        #define EG_TXT_LINE_BREAK_LONG_POST_MIN_LEN CONFIG_EG_TXT_LINE_BREAK_LONG_POST_MIN_LEN
    #else
        #define EG_TXT_LINE_BREAK_LONG_POST_MIN_LEN 3
    #endif
#endif

/*The control character to use for signalling text recoloring.*/
#ifndef EG_TXT_COLOR_CMD
    #ifdef CONFIG_EG_TXT_COLOR_CMD
        #define EG_TXT_COLOR_CMD CONFIG_EG_TXT_COLOR_CMD
    #else
        #define EG_TXT_COLOR_CMD "#"
    #endif
#endif

/*Support bidirectional texts. Allows mixing Left-to-Right and Right-to-Left texts.
 *The direction will be processed according to the Unicode Bidirectional Algorithm:
 *https://www.w3.org/International/articles/inline-bidi-markup/uba-basics*/
#ifndef EG_USE_BIDI
    #ifdef CONFIG_EG_USE_BIDI
        #define EG_USE_BIDI CONFIG_EG_USE_BIDI
    #else
        #define EG_USE_BIDI 0
    #endif
#endif
#if EG_USE_BIDI
    /*Set the default direction. Supported values:
    *`EG_BASE_DIR_LTR` Left-to-Right
    *`EG_BASE_DIR_RTL` Right-to-Left
    *`EG_BASE_DIR_AUTO` detect texts base direction*/
    #ifndef EG_BIDI_BASE_DIR_DEF
        #ifdef CONFIG_EG_BIDI_BASE_DIR_DEF
            #define EG_BIDI_BASE_DIR_DEF CONFIG_EG_BIDI_BASE_DIR_DEF
        #else
            #define EG_BIDI_BASE_DIR_DEF EG_BASE_DIR_AUTO
        #endif
    #endif
#endif

/*Enable Arabic/Persian processing
 *In these languages characters should be replaced with an other form based on their position in the text*/
#ifndef EG_USE_ARABIC_PERSIAN_CHARS
    #ifdef CONFIG_EG_USE_ARABIC_PERSIAN_CHARS
        #define EG_USE_ARABIC_PERSIAN_CHARS CONFIG_EG_USE_ARABIC_PERSIAN_CHARS
    #else
        #define EG_USE_ARABIC_PERSIAN_CHARS 0
    #endif
#endif

/*==================
 *  WIDGET USAGE
 *================*/

/*Documentation of the widgets: https://docs.lvgl.io/latest/en/html/widgets/index.html*/

#ifndef EG_USE_ARC
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_ARC
            #define EG_USE_ARC CONFIG_EG_USE_ARC
        #else
            #define EG_USE_ARC 0
        #endif
    #else
        #define EG_USE_ARC        1
    #endif
#endif

#ifndef EG_USE_BAR
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_BAR
            #define EG_USE_BAR CONFIG_EG_USE_BAR
        #else
            #define EG_USE_BAR 0
        #endif
    #else
        #define EG_USE_BAR        1
    #endif
#endif

#ifndef EG_USE_BTN
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_BTN
            #define EG_USE_BTN CONFIG_EG_USE_BTN
        #else
            #define EG_USE_BTN 0
        #endif
    #else
        #define EG_USE_BTN        1
    #endif
#endif

#ifndef EG_USE_BTNMATRIX
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_BTNMATRIX
            #define EG_USE_BTNMATRIX CONFIG_EG_USE_BTNMATRIX
        #else
            #define EG_USE_BTNMATRIX 0
        #endif
    #else
        #define EG_USE_BTNMATRIX  1
    #endif
#endif

#ifndef EG_USE_CANVAS
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_CANVAS
            #define EG_USE_CANVAS CONFIG_EG_USE_CANVAS
        #else
            #define EG_USE_CANVAS 0
        #endif
    #else
        #define EG_USE_CANVAS     1
    #endif
#endif

#ifndef EG_USE_CHECKBOX
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_CHECKBOX
            #define EG_USE_CHECKBOX CONFIG_EG_USE_CHECKBOX
        #else
            #define EG_USE_CHECKBOX 0
        #endif
    #else
        #define EG_USE_CHECKBOX   1
    #endif
#endif

#ifndef EG_USE_DROPDOWN
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_DROPDOWN
            #define EG_USE_DROPDOWN CONFIG_EG_USE_DROPDOWN
        #else
            #define EG_USE_DROPDOWN 0
        #endif
    #else
        #define EG_USE_DROPDOWN   1   /*Requires: EGLabel*/
    #endif
#endif

#ifndef EG_USE_IMG
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_IMG
            #define EG_USE_IMG CONFIG_EG_USE_IMG
        #else
            #define EG_USE_IMG 0
        #endif
    #else
        #define EG_USE_IMG        1   /*Requires: EGLabel*/
    #endif
#endif

#ifndef EG_USE_LABEL
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_LABEL
            #define EG_USE_LABEL CONFIG_EG_USE_LABEL
        #else
            #define EG_USE_LABEL 0
        #endif
    #else
        #define EG_USE_LABEL      1
    #endif
#endif
#if EG_USE_LABEL
    #ifndef EG_LABEL_TEXT_SELECTION
        #ifdef _EG_KCONFIG_PRESENT
            #ifdef CONFIG_EG_LABEL_TEXT_SELECTION
                #define EG_LABEL_TEXT_SELECTION CONFIG_EG_LABEL_TEXT_SELECTION
            #else
                #define EG_LABEL_TEXT_SELECTION 0
            #endif
        #else
            #define EG_LABEL_TEXT_SELECTION 1 /*Enable selecting text of the label*/
        #endif
    #endif
    #ifndef EG_LABEL_LONG_TXT_HINT
        #ifdef _EG_KCONFIG_PRESENT
            #ifdef CONFIG_EG_LABEL_LONG_TXT_HINT
                #define EG_LABEL_LONG_TXT_HINT CONFIG_EG_LABEL_LONG_TXT_HINT
            #else
                #define EG_LABEL_LONG_TXT_HINT 0
            #endif
        #else
            #define EG_LABEL_LONG_TXT_HINT 1  /*Store some extra info in labels to speed up drawing of very long texts*/
        #endif
    #endif
#endif

#ifndef EG_USE_LINE
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_LINE
            #define EG_USE_LINE CONFIG_EG_USE_LINE
        #else
            #define EG_USE_LINE 0
        #endif
    #else
        #define EG_USE_LINE       1
    #endif
#endif

#ifndef EG_USE_ROLLER
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_ROLLER
            #define EG_USE_ROLLER CONFIG_EG_USE_ROLLER
        #else
            #define EG_USE_ROLLER 0
        #endif
    #else
        #define EG_USE_ROLLER     1   /*Requires: EGLabel*/
    #endif
#endif
#if EG_USE_ROLLER
    #ifndef EG_ROLLER_INF_PAGES
        #ifdef CONFIG_EG_ROLLER_INF_PAGES
            #define EG_ROLLER_INF_PAGES CONFIG_EG_ROLLER_INF_PAGES
        #else
            #define EG_ROLLER_INF_PAGES 7 /*Number of extra "pages" when the roller is infinite*/
        #endif
    #endif
#endif

#ifndef EG_USE_SLIDER
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_SLIDER
            #define EG_USE_SLIDER CONFIG_EG_USE_SLIDER
        #else
            #define EG_USE_SLIDER 0
        #endif
    #else
        #define EG_USE_SLIDER     1   /*Requires: EGBar*/
    #endif
#endif

#ifndef EG_USE_SWITCH
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_SWITCH
            #define EG_USE_SWITCH CONFIG_EG_USE_SWITCH
        #else
            #define EG_USE_SWITCH 0
        #endif
    #else
        #define EG_USE_SWITCH     1
    #endif
#endif

#ifndef EG_USE_TEXTAREA
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_TEXTAREA
            #define EG_USE_TEXTAREA CONFIG_EG_USE_TEXTAREA
        #else
            #define EG_USE_TEXTAREA 0
        #endif
    #else
        #define EG_USE_TEXTAREA   1   /*Requires: EGLabel*/
    #endif
#endif
#if EG_USE_TEXTAREA != 0
    #ifndef EG_TEXTAREA_DEF_PWD_SHOW_TIME
        #ifdef CONFIG_EG_TEXTAREA_DEF_PWD_SHOW_TIME
            #define EG_TEXTAREA_DEF_PWD_SHOW_TIME CONFIG_EG_TEXTAREA_DEF_PWD_SHOW_TIME
        #else
            #define EG_TEXTAREA_DEF_PWD_SHOW_TIME 1500    /*ms*/
        #endif
    #endif
#endif

#ifndef EG_USE_TABLE
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_TABLE
            #define EG_USE_TABLE CONFIG_EG_USE_TABLE
        #else
            #define EG_USE_TABLE 0
        #endif
    #else
        #define EG_USE_TABLE      1
    #endif
#endif

/*==================
 * EXTRA COMPONENTS
 *==================*/

/*-----------
 * Widgets
 *----------*/
#ifndef EG_USE_ANIMIMG
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_ANIMIMG
            #define EG_USE_ANIMIMG CONFIG_EG_USE_ANIMIMG
        #else
            #define EG_USE_ANIMIMG 0
        #endif
    #else
        #define EG_USE_ANIMIMG    1
    #endif
#endif

#ifndef EG_USE_CALENDAR
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_CALENDAR
            #define EG_USE_CALENDAR CONFIG_EG_USE_CALENDAR
        #else
            #define EG_USE_CALENDAR 0
        #endif
    #else
        #define EG_USE_CALENDAR   1
    #endif
#endif
#if EG_USE_CALENDAR
    #ifndef EG_CALENDAR_WEEK_STARTS_MONDAY
        #ifdef CONFIG_EG_CALENDAR_WEEK_STARTS_MONDAY
            #define EG_CALENDAR_WEEK_STARTS_MONDAY CONFIG_EG_CALENDAR_WEEK_STARTS_MONDAY
        #else
            #define EG_CALENDAR_WEEK_STARTS_MONDAY 0
        #endif
    #endif
    #if EG_CALENDAR_WEEK_STARTS_MONDAY
        #ifndef EG_CALENDAR_DEFAULT_DAY_NAMES
            #ifdef CONFIG_EG_CALENDAR_DEFAULT_DAY_NAMES
                #define EG_CALENDAR_DEFAULT_DAY_NAMES CONFIG_EG_CALENDAR_DEFAULT_DAY_NAMES
            #else
                #define EG_CALENDAR_DEFAULT_DAY_NAMES {"Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"}
            #endif
        #endif
    #else
        #ifndef EG_CALENDAR_DEFAULT_DAY_NAMES
            #ifdef CONFIG_EG_CALENDAR_DEFAULT_DAY_NAMES
                #define EG_CALENDAR_DEFAULT_DAY_NAMES CONFIG_EG_CALENDAR_DEFAULT_DAY_NAMES
            #else
                #define EG_CALENDAR_DEFAULT_DAY_NAMES {"Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"}
            #endif
        #endif
    #endif

    #ifndef EG_CALENDAR_DEFAULT_MONTH_NAMES
        #ifdef CONFIG_EG_CALENDAR_DEFAULT_MONTH_NAMES
            #define EG_CALENDAR_DEFAULT_MONTH_NAMES CONFIG_EG_CALENDAR_DEFAULT_MONTH_NAMES
        #else
            #define EG_CALENDAR_DEFAULT_MONTH_NAMES {"January", "February", "March",  "April", "May",  "June", "July", "August", "September", "October", "November", "December"}
        #endif
    #endif
    #ifndef EG_USE_CALENDAR_MONTH_HEADER
        #ifdef _EG_KCONFIG_PRESENT
            #ifdef CONFIG_EG_USE_CALENDAR_MONTH_HEADER
                #define EG_USE_CALENDAR_MONTH_HEADER CONFIG_EG_USE_CALENDAR_MONTH_HEADER
            #else
                #define EG_USE_CALENDAR_MONTH_HEADER 0
            #endif
        #else
            #define EG_USE_CALENDAR_MONTH_HEADER 1
        #endif
    #endif
    #ifndef EG_USE_CALENDAR_DROPDOWN_HEADER
        #ifdef _EG_KCONFIG_PRESENT
            #ifdef CONFIG_EG_USE_CALENDAR_DROPDOWN_HEADER
                #define EG_USE_CALENDAR_DROPDOWN_HEADER CONFIG_EG_USE_CALENDAR_DROPDOWN_HEADER
            #else
                #define EG_USE_CALENDAR_DROPDOWN_HEADER 0
            #endif
        #else
            #define EG_USE_CALENDAR_DROPDOWN_HEADER 1
        #endif
    #endif
#endif  /*EG_USE_CALENDAR*/

#ifndef EG_USE_CHART
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_CHART
            #define EG_USE_CHART CONFIG_EG_USE_CHART
        #else
            #define EG_USE_CHART 0
        #endif
    #else
        #define EG_USE_CHART      1
    #endif
#endif

#ifndef EG_USE_COLORWHEEL
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_COLORWHEEL
            #define EG_USE_COLORWHEEL CONFIG_EG_USE_COLORWHEEL
        #else
            #define EG_USE_COLORWHEEL 0
        #endif
    #else
        #define EG_USE_COLORWHEEL 1
    #endif
#endif

#ifndef EG_USE_IMGBTN
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_IMGBTN
            #define EG_USE_IMGBTN CONFIG_EG_USE_IMGBTN
        #else
            #define EG_USE_IMGBTN 0
        #endif
    #else
        #define EG_USE_IMGBTN     1
    #endif
#endif

#ifndef EG_USE_KEYBOARD
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_KEYBOARD
            #define EG_USE_KEYBOARD CONFIG_EG_USE_KEYBOARD
        #else
            #define EG_USE_KEYBOARD 0
        #endif
    #else
        #define EG_USE_KEYBOARD   1
    #endif
#endif

#ifndef EG_USE_LED
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_LED
            #define EG_USE_LED CONFIG_EG_USE_LED
        #else
            #define EG_USE_LED 0
        #endif
    #else
        #define EG_USE_LED        1
    #endif
#endif

#ifndef EG_USE_LIST
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_LIST
            #define EG_USE_LIST CONFIG_EG_USE_LIST
        #else
            #define EG_USE_LIST 0
        #endif
    #else
        #define EG_USE_LIST       1
    #endif
#endif

#ifndef EG_USE_MENU
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_MENU
            #define EG_USE_MENU CONFIG_EG_USE_MENU
        #else
            #define EG_USE_MENU 0
        #endif
    #else
        #define EG_USE_MENU       1
    #endif
#endif

#ifndef EG_USE_METER
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_METER
            #define EG_USE_METER CONFIG_EG_USE_METER
        #else
            #define EG_USE_METER 0
        #endif
    #else
        #define EG_USE_METER      1
    #endif
#endif

#ifndef EG_USE_MSGBOX
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_MSGBOX
            #define EG_USE_MSGBOX CONFIG_EG_USE_MSGBOX
        #else
            #define EG_USE_MSGBOX 0
        #endif
    #else
        #define EG_USE_MSGBOX     1
    #endif
#endif

#ifndef EG_USE_SPAN
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_SPAN
            #define EG_USE_SPAN CONFIG_EG_USE_SPAN
        #else
            #define EG_USE_SPAN 0
        #endif
    #else
        #define EG_USE_SPAN       1
    #endif
#endif
#if EG_USE_SPAN
    /*A line text can contain maximum num of span descriptor */
    #ifndef EG_SPAN_SNIPPET_STACK_SIZE
        #ifdef CONFIG_EG_SPAN_SNIPPET_STACK_SIZE
            #define EG_SPAN_SNIPPET_STACK_SIZE CONFIG_EG_SPAN_SNIPPET_STACK_SIZE
        #else
            #define EG_SPAN_SNIPPET_STACK_SIZE 64
        #endif
    #endif
#endif

#ifndef EG_USE_SPINBOX
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_SPINBOX
            #define EG_USE_SPINBOX CONFIG_EG_USE_SPINBOX
        #else
            #define EG_USE_SPINBOX 0
        #endif
    #else
        #define EG_USE_SPINBOX    1
    #endif
#endif

#ifndef EG_USE_SPINNER
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_SPINNER
            #define EG_USE_SPINNER CONFIG_EG_USE_SPINNER
        #else
            #define EG_USE_SPINNER 0
        #endif
    #else
        #define EG_USE_SPINNER    1
    #endif
#endif

#ifndef EG_USE_TABVIEW
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_TABVIEW
            #define EG_USE_TABVIEW CONFIG_EG_USE_TABVIEW
        #else
            #define EG_USE_TABVIEW 0
        #endif
    #else
        #define EG_USE_TABVIEW    1
    #endif
#endif

#ifndef EG_USE_TILEVIEW
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_TILEVIEW
            #define EG_USE_TILEVIEW CONFIG_EG_USE_TILEVIEW
        #else
            #define EG_USE_TILEVIEW 0
        #endif
    #else
        #define EG_USE_TILEVIEW   1
    #endif
#endif

#ifndef EG_USE_WIN
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_WIN
            #define EG_USE_WIN CONFIG_EG_USE_WIN
        #else
            #define EG_USE_WIN 0
        #endif
    #else
        #define EG_USE_WIN        1
    #endif
#endif

/*-----------
 * Themes
 *----------*/

/*A simple, impressive and very complete theme*/
#ifndef EG_USE_THEME_DEFAULT
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_THEME_DEFAULT
            #define EG_USE_THEME_DEFAULT CONFIG_EG_USE_THEME_DEFAULT
        #else
            #define EG_USE_THEME_DEFAULT 0
        #endif
    #else
        #define EG_USE_THEME_DEFAULT 1
    #endif
#endif
#if EG_USE_THEME_DEFAULT

    /*0: Light mode; 1: Dark mode*/
    #ifndef EG_THEME_DEFAULT_DARK
        #ifdef CONFIG_EG_THEME_DEFAULT_DARK
            #define EG_THEME_DEFAULT_DARK CONFIG_EG_THEME_DEFAULT_DARK
        #else
            #define EG_THEME_DEFAULT_DARK 0
        #endif
    #endif

    /*1: Enable grow on press*/
    #ifndef EG_THEME_DEFAULT_GROW
        #ifdef _EG_KCONFIG_PRESENT
            #ifdef CONFIG_EG_THEME_DEFAULT_GROW
                #define EG_THEME_DEFAULT_GROW CONFIG_EG_THEME_DEFAULT_GROW
            #else
                #define EG_THEME_DEFAULT_GROW 0
            #endif
        #else
            #define EG_THEME_DEFAULT_GROW 1
        #endif
    #endif

    /*Default transition time in [ms]*/
    #ifndef EG_THEME_DEFAULT_TRANSITION_TIME
        #ifdef CONFIG_EG_THEME_DEFAULT_TRANSITION_TIME
            #define EG_THEME_DEFAULT_TRANSITION_TIME CONFIG_EG_THEME_DEFAULT_TRANSITION_TIME
        #else
            #define EG_THEME_DEFAULT_TRANSITION_TIME 80
        #endif
    #endif
#endif /*EG_USE_THEME_DEFAULT*/

/*A very simple theme that is a good starting point for a custom theme*/
#ifndef EG_USE_THEME_BASIC
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_THEME_BASIC
            #define EG_USE_THEME_BASIC CONFIG_EG_USE_THEME_BASIC
        #else
            #define EG_USE_THEME_BASIC 0
        #endif
    #else
        #define EG_USE_THEME_BASIC 1
    #endif
#endif

/*A theme designed for monochrome displays*/
#ifndef EG_USE_THEME_MONO
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_THEME_MONO
            #define EG_USE_THEME_MONO CONFIG_EG_USE_THEME_MONO
        #else
            #define EG_USE_THEME_MONO 0
        #endif
    #else
        #define EG_USE_THEME_MONO 1
    #endif
#endif

/*-----------
 * Layouts
 *----------*/

/*A layout similar to Flexbox in CSS.*/
#ifndef EG_USE_FLEX
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_FLEX
            #define EG_USE_FLEX CONFIG_EG_USE_FLEX
        #else
            #define EG_USE_FLEX 0
        #endif
    #else
        #define EG_USE_FLEX 1
    #endif
#endif

/*A layout similar to Grid in CSS.*/
#ifndef EG_USE_GRID
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_USE_GRID
            #define EG_USE_GRID CONFIG_EG_USE_GRID
        #else
            #define EG_USE_GRID 0
        #endif
    #else
        #define EG_USE_GRID 1
    #endif
#endif

/*---------------------
 * 3rd party libraries
 *--------------------*/

/*File system interfaces for common APIs */

/*API for fopen, fread, etc*/
#ifndef EG_USE_FS_STDIO
    #ifdef CONFIG_EG_USE_FS_STDIO
        #define EG_USE_FS_STDIO CONFIG_EG_USE_FS_STDIO
    #else
        #define EG_USE_FS_STDIO 0
    #endif
#endif
#if EG_USE_FS_STDIO
    #ifndef EG_FS_STDIO_LETTER
        #ifdef CONFIG_EG_FS_STDIO_LETTER
            #define EG_FS_STDIO_LETTER CONFIG_EG_FS_STDIO_LETTER
        #else
            #define EG_FS_STDIO_LETTER '\0'     /*Set an upper cased letter on which the drive will accessible (e.g. 'A')*/
        #endif
    #endif
    #ifndef EG_FS_STDIO_PATH
        #ifdef CONFIG_EG_FS_STDIO_PATH
            #define EG_FS_STDIO_PATH CONFIG_EG_FS_STDIO_PATH
        #else
            #define EG_FS_STDIO_PATH ""         /*Set the working directory. File/directory paths will be appended to it.*/
        #endif
    #endif
    #ifndef EG_FS_STDIO_CACHE_SIZE
        #ifdef CONFIG_EG_FS_STDIO_CACHE_SIZE
            #define EG_FS_STDIO_CACHE_SIZE CONFIG_EG_FS_STDIO_CACHE_SIZE
        #else
            #define EG_FS_STDIO_CACHE_SIZE 0    /*>0 to cache this number of bytes in lv_fs_read()*/
        #endif
    #endif
#endif

/*API for open, read, etc*/
#ifndef EG_USE_FS_POSIX
    #ifdef CONFIG_EG_USE_FS_POSIX
        #define EG_USE_FS_POSIX CONFIG_EG_USE_FS_POSIX
    #else
        #define EG_USE_FS_POSIX 0
    #endif
#endif
#if EG_USE_FS_POSIX
    #ifndef EG_FS_POSIX_LETTER
        #ifdef CONFIG_EG_FS_POSIX_LETTER
            #define EG_FS_POSIX_LETTER CONFIG_EG_FS_POSIX_LETTER
        #else
            #define EG_FS_POSIX_LETTER '\0'     /*Set an upper cased letter on which the drive will accessible (e.g. 'A')*/
        #endif
    #endif
    #ifndef EG_FS_POSIX_PATH
        #ifdef CONFIG_EG_FS_POSIX_PATH
            #define EG_FS_POSIX_PATH CONFIG_EG_FS_POSIX_PATH
        #else
            #define EG_FS_POSIX_PATH ""         /*Set the working directory. File/directory paths will be appended to it.*/
        #endif
    #endif
    #ifndef EG_FS_POSIX_CACHE_SIZE
        #ifdef CONFIG_EG_FS_POSIX_CACHE_SIZE
            #define EG_FS_POSIX_CACHE_SIZE CONFIG_EG_FS_POSIX_CACHE_SIZE
        #else
            #define EG_FS_POSIX_CACHE_SIZE 0    /*>0 to cache this number of bytes in lv_fs_read()*/
        #endif
    #endif
#endif

/*API for CreateFile, ReadFile, etc*/
#ifndef EG_USE_FS_WIN32
    #ifdef CONFIG_EG_USE_FS_WIN32
        #define EG_USE_FS_WIN32 CONFIG_EG_USE_FS_WIN32
    #else
        #define EG_USE_FS_WIN32 0
    #endif
#endif
#if EG_USE_FS_WIN32
    #ifndef EG_FS_WIN32_LETTER
        #ifdef CONFIG_EG_FS_WIN32_LETTER
            #define EG_FS_WIN32_LETTER CONFIG_EG_FS_WIN32_LETTER
        #else
            #define EG_FS_WIN32_LETTER '\0'     /*Set an upper cased letter on which the drive will accessible (e.g. 'A')*/
        #endif
    #endif
    #ifndef EG_FS_WIN32_PATH
        #ifdef CONFIG_EG_FS_WIN32_PATH
            #define EG_FS_WIN32_PATH CONFIG_EG_FS_WIN32_PATH
        #else
            #define EG_FS_WIN32_PATH ""         /*Set the working directory. File/directory paths will be appended to it.*/
        #endif
    #endif
    #ifndef EG_FS_WIN32_CACHE_SIZE
        #ifdef CONFIG_EG_FS_WIN32_CACHE_SIZE
            #define EG_FS_WIN32_CACHE_SIZE CONFIG_EG_FS_WIN32_CACHE_SIZE
        #else
            #define EG_FS_WIN32_CACHE_SIZE 0    /*>0 to cache this number of bytes in lv_fs_read()*/
        #endif
    #endif
#endif

/*API for FATFS (needs to be added separately). Uses f_open, f_read, etc*/
#ifndef EG_USE_FS_FATFS
    #ifdef CONFIG_EG_USE_FS_FATFS
        #define EG_USE_FS_FATFS CONFIG_EG_USE_FS_FATFS
    #else
        #define EG_USE_FS_FATFS 0
    #endif
#endif
#if EG_USE_FS_FATFS
    #ifndef EG_FS_FATFS_LETTER
        #ifdef CONFIG_EG_FS_FATFS_LETTER
            #define EG_FS_FATFS_LETTER CONFIG_EG_FS_FATFS_LETTER
        #else
            #define EG_FS_FATFS_LETTER '\0'     /*Set an upper cased letter on which the drive will accessible (e.g. 'A')*/
        #endif
    #endif
    #ifndef EG_FS_FATFS_CACHE_SIZE
        #ifdef CONFIG_EG_FS_FATFS_CACHE_SIZE
            #define EG_FS_FATFS_CACHE_SIZE CONFIG_EG_FS_FATFS_CACHE_SIZE
        #else
            #define EG_FS_FATFS_CACHE_SIZE 0    /*>0 to cache this number of bytes in lv_fs_read()*/
        #endif
    #endif
#endif

/*API for LittleFS (library needs to be added separately). Uses lfs_file_open, lfs_file_read, etc*/
#ifndef EG_USE_FS_LITTLEFS
    #ifdef CONFIG_EG_USE_FS_LITTLEFS
        #define EG_USE_FS_LITTLEFS CONFIG_EG_USE_FS_LITTLEFS
    #else
        #define EG_USE_FS_LITTLEFS 0
    #endif
#endif
#if EG_USE_FS_LITTLEFS
    #ifndef EG_FS_LITTLEFS_LETTER
        #ifdef CONFIG_EG_FS_LITTLEFS_LETTER
            #define EG_FS_LITTLEFS_LETTER CONFIG_EG_FS_LITTLEFS_LETTER
        #else
            #define EG_FS_LITTLEFS_LETTER '\0'     /*Set an upper cased letter on which the drive will accessible (e.g. 'A')*/
        #endif
    #endif
    #ifndef EG_FS_LITTLEFS_CACHE_SIZE
        #ifdef CONFIG_EG_FS_LITTLEFS_CACHE_SIZE
            #define EG_FS_LITTLEFS_CACHE_SIZE CONFIG_EG_FS_LITTLEFS_CACHE_SIZE
        #else
            #define EG_FS_LITTLEFS_CACHE_SIZE 0    /*>0 to cache this number of bytes in lv_fs_read()*/
        #endif
    #endif
#endif

/*PNG decoder library*/
#ifndef EG_USE_PNG
    #ifdef CONFIG_EG_USE_PNG
        #define EG_USE_PNG CONFIG_EG_USE_PNG
    #else
        #define EG_USE_PNG 0
    #endif
#endif

/*BMP decoder library*/
#ifndef EG_USE_BMP
    #ifdef CONFIG_EG_USE_BMP
        #define EG_USE_BMP CONFIG_EG_USE_BMP
    #else
        #define EG_USE_BMP 0
    #endif
#endif

/* JPG + split JPG decoder library.
 * Split JPG is a custom format optimized for embedded systems. */
#ifndef EG_USE_SJPG
    #ifdef CONFIG_EG_USE_SJPG
        #define EG_USE_SJPG CONFIG_EG_USE_SJPG
    #else
        #define EG_USE_SJPG 0
    #endif
#endif

/*GIF decoder library*/
#ifndef EG_USE_GIF
    #ifdef CONFIG_EG_USE_GIF
        #define EG_USE_GIF CONFIG_EG_USE_GIF
    #else
        #define EG_USE_GIF 0
    #endif
#endif

/*QR code library*/
#ifndef EG_USE_QRCODE
    #ifdef CONFIG_EG_USE_QRCODE
        #define EG_USE_QRCODE CONFIG_EG_USE_QRCODE
    #else
        #define EG_USE_QRCODE 0
    #endif
#endif

/*FreeType library*/
#ifndef EG_USE_FREETYPE
    #ifdef CONFIG_EG_USE_FREETYPE
        #define EG_USE_FREETYPE CONFIG_EG_USE_FREETYPE
    #else
        #define EG_USE_FREETYPE 0
    #endif
#endif
#if EG_USE_FREETYPE
    /*Memory used by FreeType to cache characters [bytes] (-1: no caching)*/
    #ifndef EG_FREETYPE_CACHE_SIZE
        #ifdef CONFIG_EG_FREETYPE_CACHE_SIZE
            #define EG_FREETYPE_CACHE_SIZE CONFIG_EG_FREETYPE_CACHE_SIZE
        #else
            #define EG_FREETYPE_CACHE_SIZE (16 * 1024)
        #endif
    #endif
    #if EG_FREETYPE_CACHE_SIZE >= 0
        /* 1: bitmap cache use the sbit cache, 0:bitmap cache use the image cache. */
        /* sbit cache:it is much more memory efficient for small bitmaps(font size < 256) */
        /* if font size >= 256, must be configured as image cache */
        #ifndef EG_FREETYPE_SBIT_CACHE
            #ifdef CONFIG_EG_FREETYPE_SBIT_CACHE
                #define EG_FREETYPE_SBIT_CACHE CONFIG_EG_FREETYPE_SBIT_CACHE
            #else
                #define EG_FREETYPE_SBIT_CACHE 0
            #endif
        #endif
        /* Maximum number of opened FT_Face/FT_Size objects managed by this cache instance. */
        /* (0:use system defaults) */
        #ifndef EG_FREETYPE_CACHE_FT_FACES
            #ifdef CONFIG_EG_FREETYPE_CACHE_FT_FACES
                #define EG_FREETYPE_CACHE_FT_FACES CONFIG_EG_FREETYPE_CACHE_FT_FACES
            #else
                #define EG_FREETYPE_CACHE_FT_FACES 0
            #endif
        #endif
        #ifndef EG_FREETYPE_CACHE_FT_SIZES
            #ifdef CONFIG_EG_FREETYPE_CACHE_FT_SIZES
                #define EG_FREETYPE_CACHE_FT_SIZES CONFIG_EG_FREETYPE_CACHE_FT_SIZES
            #else
                #define EG_FREETYPE_CACHE_FT_SIZES 0
            #endif
        #endif
    #endif
#endif

/*Tiny TTF library*/
#ifndef EG_USE_TINY_TTF
    #ifdef CONFIG_EG_USE_TINY_TTF
        #define EG_USE_TINY_TTF CONFIG_EG_USE_TINY_TTF
    #else
        #define EG_USE_TINY_TTF 0
    #endif
#endif
#if EG_USE_TINY_TTF
    /*Load TTF data from files*/
    #ifndef EG_TINY_TTF_FILE_SUPPORT
        #ifdef CONFIG_EG_TINY_TTF_FILE_SUPPORT
            #define EG_TINY_TTF_FILE_SUPPORT CONFIG_EG_TINY_TTF_FILE_SUPPORT
        #else
            #define EG_TINY_TTF_FILE_SUPPORT 0
        #endif
    #endif
#endif

/*Rlottie library*/
#ifndef EG_USE_RLOTTIE
    #ifdef CONFIG_EG_USE_RLOTTIE
        #define EG_USE_RLOTTIE CONFIG_EG_USE_RLOTTIE
    #else
        #define EG_USE_RLOTTIE 0
    #endif
#endif

/*FFmpeg library for image decoding and playing videos
 *Supports all major image formats so do not enable other image decoder with it*/
#ifndef EG_USE_FFMPEG
    #ifdef CONFIG_EG_USE_FFMPEG
        #define EG_USE_FFMPEG CONFIG_EG_USE_FFMPEG
    #else
        #define EG_USE_FFMPEG 0
    #endif
#endif
#if EG_USE_FFMPEG
    /*Dump input information to stderr*/
    #ifndef EG_FFMPEG_DUMP_FORMAT
        #ifdef CONFIG_EG_FFMPEG_DUMP_FORMAT
            #define EG_FFMPEG_DUMP_FORMAT CONFIG_EG_FFMPEG_DUMP_FORMAT
        #else
            #define EG_FFMPEG_DUMP_FORMAT 0
        #endif
    #endif
#endif

/*-----------
 * Others
 *----------*/

/*1: Enable API to take snapshot for object*/
#ifndef EG_USE_SNAPSHOT
    #ifdef CONFIG_EG_USE_SNAPSHOT
        #define EG_USE_SNAPSHOT CONFIG_EG_USE_SNAPSHOT
    #else
        #define EG_USE_SNAPSHOT 0
    #endif
#endif

/*1: Enable Monkey test*/
#ifndef EG_USE_MONKEY
    #ifdef CONFIG_EG_USE_MONKEY
        #define EG_USE_MONKEY CONFIG_EG_USE_MONKEY
    #else
        #define EG_USE_MONKEY 0
    #endif
#endif

/*1: Enable grid navigation*/
#ifndef EG_USE_GRIDNAV
    #ifdef CONFIG_EG_USE_GRIDNAV
        #define EG_USE_GRIDNAV CONFIG_EG_USE_GRIDNAV
    #else
        #define EG_USE_GRIDNAV 0
    #endif
#endif

/*1: Enable EGObject fragment*/
#ifndef EG_USE_FRAGMENT
    #ifdef CONFIG_EG_USE_FRAGMENT
        #define EG_USE_FRAGMENT CONFIG_EG_USE_FRAGMENT
    #else
        #define EG_USE_FRAGMENT 0
    #endif
#endif

/*1: Support using images as font in label or span widgets */
#ifndef EG_USE_IMGFONT
    #ifdef CONFIG_EG_USE_IMGFONT
        #define EG_USE_IMGFONT CONFIG_EG_USE_IMGFONT
    #else
        #define EG_USE_IMGFONT 0
    #endif
#endif

/*1: Enable a published subscriber based messaging system */
#ifndef EG_USE_MSG
    #ifdef CONFIG_EG_USE_MSG
        #define EG_USE_MSG CONFIG_EG_USE_MSG
    #else
        #define EG_USE_MSG 0
    #endif
#endif

/*1: Enable Pinyin input method*/
/*Requires: EGKeyboard*/
#ifndef EG_USE_IME_PINYIN
    #ifdef CONFIG_EG_USE_IME_PINYIN
        #define EG_USE_IME_PINYIN CONFIG_EG_USE_IME_PINYIN
    #else
        #define EG_USE_IME_PINYIN 0
    #endif
#endif
#if EG_USE_IME_PINYIN
    /*1: Use default thesaurus*/
    /*If you do not use the default thesaurus, be sure to use `lv_ime_pinyin` after setting the thesauruss*/
    #ifndef EG_IME_PINYIN_USE_DEFAULT_DICT
        #ifdef _EG_KCONFIG_PRESENT
            #ifdef CONFIG_EG_IME_PINYIN_USE_DEFAULT_DICT
                #define EG_IME_PINYIN_USE_DEFAULT_DICT CONFIG_EG_IME_PINYIN_USE_DEFAULT_DICT
            #else
                #define EG_IME_PINYIN_USE_DEFAULT_DICT 0
            #endif
        #else
            #define EG_IME_PINYIN_USE_DEFAULT_DICT 1
        #endif
    #endif
    /*Set the maximum number of candidate panels that can be displayed*/
    /*This needs to be adjusted according to the size of the screen*/
    #ifndef EG_IME_PINYIN_CAND_TEXT_NUM
        #ifdef CONFIG_EG_IME_PINYIN_CAND_TEXT_NUM
            #define EG_IME_PINYIN_CAND_TEXT_NUM CONFIG_EG_IME_PINYIN_CAND_TEXT_NUM
        #else
            #define EG_IME_PINYIN_CAND_TEXT_NUM 6
        #endif
    #endif

    /*Use 9 key input(k9)*/
    #ifndef EG_IME_PINYIN_USE_K9_MODE
        #ifdef _EG_KCONFIG_PRESENT
            #ifdef CONFIG_EG_IME_PINYIN_USE_K9_MODE
                #define EG_IME_PINYIN_USE_K9_MODE CONFIG_EG_IME_PINYIN_USE_K9_MODE
            #else
                #define EG_IME_PINYIN_USE_K9_MODE 0
            #endif
        #else
            #define EG_IME_PINYIN_USE_K9_MODE      1
        #endif
    #endif
    #if EG_IME_PINYIN_USE_K9_MODE == 1
        #ifndef EG_IME_PINYIN_K9_CAND_TEXT_NUM
            #ifdef CONFIG_EG_IME_PINYIN_K9_CAND_TEXT_NUM
                #define EG_IME_PINYIN_K9_CAND_TEXT_NUM CONFIG_EG_IME_PINYIN_K9_CAND_TEXT_NUM
            #else
                #define EG_IME_PINYIN_K9_CAND_TEXT_NUM 3
            #endif
        #endif
    #endif // EG_IME_PINYIN_USE_K9_MODE
#endif

/*==================
* EXAMPLES
*==================*/

/*Enable the examples to be built with the library*/
#ifndef EG_BUILD_EXAMPLES
    #ifdef _EG_KCONFIG_PRESENT
        #ifdef CONFIG_EG_BUILD_EXAMPLES
            #define EG_BUILD_EXAMPLES CONFIG_EG_BUILD_EXAMPLES
        #else
            #define EG_BUILD_EXAMPLES 0
        #endif
    #else
        #define EG_BUILD_EXAMPLES 1
    #endif
#endif

/*===================
 * DEMO USAGE
 ====================*/

/*Show some widget. It might be required to increase `EG_MEM_SIZE` */
#ifndef EG_USE_DEMO_WIDGETS
    #ifdef CONFIG_EG_USE_DEMO_WIDGETS
        #define EG_USE_DEMO_WIDGETS CONFIG_EG_USE_DEMO_WIDGETS
    #else
        #define EG_USE_DEMO_WIDGETS 0
    #endif
#endif
#if EG_USE_DEMO_WIDGETS
#ifndef EG_DEMO_WIDGETS_SLIDESHOW
    #ifdef CONFIG_EG_DEMO_WIDGETS_SLIDESHOW
        #define EG_DEMO_WIDGETS_SLIDESHOW CONFIG_EG_DEMO_WIDGETS_SLIDESHOW
    #else
        #define EG_DEMO_WIDGETS_SLIDESHOW 0
    #endif
#endif
#endif

/*Demonstrate the usage of encoder and keyboard*/
#ifndef EG_USE_DEMO_KEYPAD_AND_ENCODER
    #ifdef CONFIG_EG_USE_DEMO_KEYPAD_AND_ENCODER
        #define EG_USE_DEMO_KEYPAD_AND_ENCODER CONFIG_EG_USE_DEMO_KEYPAD_AND_ENCODER
    #else
        #define EG_USE_DEMO_KEYPAD_AND_ENCODER 0
    #endif
#endif

/*Benchmark your system*/
#ifndef EG_USE_DEMO_BENCHMARK
    #ifdef CONFIG_EG_USE_DEMO_BENCHMARK
        #define EG_USE_DEMO_BENCHMARK CONFIG_EG_USE_DEMO_BENCHMARK
    #else
        #define EG_USE_DEMO_BENCHMARK 0
    #endif
#endif
#if EG_USE_DEMO_BENCHMARK
/*Use RGB565A8 images with 16 bit color depth instead of ARGB8565*/
#ifndef EG_DEMO_BENCHMARK_RGB565A8
    #ifdef CONFIG_EG_DEMO_BENCHMARK_RGB565A8
        #define EG_DEMO_BENCHMARK_RGB565A8 CONFIG_EG_DEMO_BENCHMARK_RGB565A8
    #else
        #define EG_DEMO_BENCHMARK_RGB565A8 0
    #endif
#endif
#endif

/*Stress test for LEGL*/
#ifndef EG_USE_DEMO_STRESS
    #ifdef CONFIG_EG_USE_DEMO_STRESS
        #define EG_USE_DEMO_STRESS CONFIG_EG_USE_DEMO_STRESS
    #else
        #define EG_USE_DEMO_STRESS 0
    #endif
#endif

/*Music player demo*/
#ifndef EG_USE_DEMO_MUSIC
    #ifdef CONFIG_EG_USE_DEMO_MUSIC
        #define EG_USE_DEMO_MUSIC CONFIG_EG_USE_DEMO_MUSIC
    #else
        #define EG_USE_DEMO_MUSIC 0
    #endif
#endif
#if EG_USE_DEMO_MUSIC
    #ifndef EG_DEMO_MUSIC_SQUARE
        #ifdef CONFIG_EG_DEMO_MUSIC_SQUARE
            #define EG_DEMO_MUSIC_SQUARE CONFIG_EG_DEMO_MUSIC_SQUARE
        #else
            #define EG_DEMO_MUSIC_SQUARE    0
        #endif
    #endif
    #ifndef EG_DEMO_MUSIC_LANDSCAPE
        #ifdef CONFIG_EG_DEMO_MUSIC_LANDSCAPE
            #define EG_DEMO_MUSIC_LANDSCAPE CONFIG_EG_DEMO_MUSIC_LANDSCAPE
        #else
            #define EG_DEMO_MUSIC_LANDSCAPE 0
        #endif
    #endif
    #ifndef EG_DEMO_MUSIC_ROUND
        #ifdef CONFIG_EG_DEMO_MUSIC_ROUND
            #define EG_DEMO_MUSIC_ROUND CONFIG_EG_DEMO_MUSIC_ROUND
        #else
            #define EG_DEMO_MUSIC_ROUND     0
        #endif
    #endif
    #ifndef EG_DEMO_MUSIC_LARGE
        #ifdef CONFIG_EG_DEMO_MUSIC_LARGE
            #define EG_DEMO_MUSIC_LARGE CONFIG_EG_DEMO_MUSIC_LARGE
        #else
            #define EG_DEMO_MUSIC_LARGE     0
        #endif
    #endif
    #ifndef EG_DEMO_MUSIC_AUTO_PLAY
        #ifdef CONFIG_EG_DEMO_MUSIC_AUTO_PLAY
            #define EG_DEMO_MUSIC_AUTO_PLAY CONFIG_EG_DEMO_MUSIC_AUTO_PLAY
        #else
            #define EG_DEMO_MUSIC_AUTO_PLAY 0
        #endif
    #endif
#endif



/*----------------------------------
 * End of parsing EG_ConfTemplate.h
 -----------------------------------*/

EG_EXPORT_CONST_INT(EG_DPI_DEF);

#undef _EG_KCONFIG_PRESENT


/*Set some defines if a dependency is disabled*/
#if EG_USE_LOG == 0
    #define EG_LOG_LEVEL            EG_LOG_LEVEL_NONE
    #define EG_LOG_TRACE_MEM        0
    #define EG_LOG_TRACE_TIMER      0
    #define EG_LOG_TRACE_INDEV      0
    #define EG_LOG_TRACE_DISP_REFR  0
    #define EG_LOG_TRACE_EVENT      0
    #define EG_LOG_TRACE_OBJ_CREATE 0
    #define EG_LOG_TRACE_LAYOUT     0
    #define EG_LOG_TRACE_ANIM       0
#endif  /*EG_USE_LOG*/


/*If running without EG_Config.h add typedefs with default value*/
#ifdef EG_CONF_SKIP
    #if defined(_MSC_VER) && !defined(_CRT_SECURE_NO_WARNINGS)    /*Disable warnings for Visual Studio*/
        #define _CRT_SECURE_NO_WARNINGS
    #endif
#endif  /*defined(EG_CONF_SKIP)*/
