/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by Espressif Systems (Shanghai) CO LTD
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#include "../include/CH422Driver.h"

////////////////////////////////////////////////////////////////////////

const char *TAG = "[CH422G]";

////////////////////////////////////////////////////////////////////////

CH422Driver::CH422Driver(I2CDriver *pI2C)
{
	m_pI2C = pI2C;
	Reset();
}

////////////////////////////////////////////////////////////////////////

esp_err_t CH422Driver::WriteControl(uint8_t Value)
{

  ESP_RETURN_ON_ERROR(m_pI2C->Write(CH422G_REG_CONTROL, &Value, 1), TAG, "Failed to set control");
	return ESP_OK;
}

////////////////////////////////////////////////////////////////////////

esp_err_t CH422Driver::ReadInput(uint8_t *pValue)
{
  ESP_RETURN_ON_ERROR(m_pI2C->Read(CH422G_REG_IN, pValue, 1), TAG, "Read in reg failed");
	return ESP_OK;
}

////////////////////////////////////////////////////////////////////////

esp_err_t CH422Driver::WriteOutput(uint8_t Data)
{
  ESP_RETURN_ON_ERROR(m_pI2C->Write(CH422G_REG_OUT, &Data, 1), TAG, "Write to out reg failed");
	return ESP_OK;
}

////////////////////////////////////////////////////////////////////////

esp_err_t CH422Driver::WriteOC(uint8_t Data)
{
  ESP_RETURN_ON_ERROR(m_pI2C->Write(CH422G_REG_OC, &Data, 1), TAG, "Write to OC reg failed");
	return ESP_OK;
}

////////////////////////////////////////////////////////////////////////

esp_err_t CH422Driver::Reset(void)
{
  ESP_RETURN_ON_ERROR(WriteControl(0x01), TAG, "Failed to reset");
  ESP_RETURN_ON_ERROR(WriteOutput(OUT_REG_DEFAULT_VAL), TAG, "Failed to reset");
	return ESP_OK;
}

