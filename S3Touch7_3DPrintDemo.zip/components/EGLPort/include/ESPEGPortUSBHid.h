/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#pragma once

#include "esp_err.h"
#include "EGL.h"

#if __has_include ("usb/hid_host.h")
#define ESP_LVGL_PORT_USB_HOST_HID_COMPONENT 1
#endif

#if EG_VERSION_MAJOR == 8
#include "ESPEGPortCompatibility.h"
#endif

#ifdef ESP_LVGL_PORT_USB_HOST_HID_COMPONENT

/////////////////////////////////////////////////////////////////////////////////////

typedef struct {
    lv_display_t *disp;        // LVGL display handle (returned from lvgl_port_add_disp) 
    uint8_t sensitivity;    // Mouse sensitivity (cannot be zero) 
    EGObject *cursor_img;   // Mouse cursor image, if NULL then used default 
} lvgl_port_hid_mouse_cfg_t;


typedef struct {
    lv_display_t *disp;        // LVGL display handle (returned from lvgl_port_add_disp) 
} lvgl_port_hid_keyboard_cfg_t;

/////////////////////////////////////////////////////////////////////////////////////

lv_indev_t      *lvgl_port_add_usb_hid_mouse_input(const lvgl_port_hid_mouse_cfg_t *mouse_cfg);
lv_indev_t      *lvgl_port_add_usb_hid_keyboard_input(const lvgl_port_hid_keyboard_cfg_t *keyboard_cfg);
esp_err_t       lvgl_port_remove_usb_hid_input(lv_indev_t *hid);
#endif


