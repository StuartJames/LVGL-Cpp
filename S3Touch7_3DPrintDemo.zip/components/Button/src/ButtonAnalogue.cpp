/*
 *              EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

 #include <string.h>
#include <inttypes.h>
#include "esp_log.h"
#include "esp_check.h"
#include "esp_timer.h"
#include "esp_idf_version.h"
#include "soc/soc_caps.h"
#include "esp_adc/adc_oneshot.h"
#include "esp_adc/adc_cali.h"
#include "esp_adc/adc_cali_scheme.h"
#include "ButtonAnalogue.h"

/////////////////////////////////////////////////////////////////////////////////////

static const char *_TAG = "[ButAna]";

ADCModule_t AnalogueButton::m_ADCModules[ADC_UNIT_NUM] = {};   // array of channels & buttons in use

/////////////////////////////////////////////////////////////////////////////////////

AnalogueButton::AnalogueButton() :
  m_Module(ADC_UNIT_1),
  m_ADCChannel(ADC_CHANNEL_0),
  m_ButtonIndex(0)
{
}

/////////////////////////////////////////////////////////////////////////////////////

AnalogueButton::~AnalogueButton()
{
uint8_t UnusedButton = 0, UnusedChannel = 0;

	int ChanIndex = FindChannel(m_Module, m_ADCChannel);
	if(ChanIndex <= 0) return;
	m_ADCModules[m_Module].Channel[ChanIndex].Buttons[m_ButtonIndex].MaxVoltage = 0;
	m_ADCModules[m_Module].Channel[ChanIndex].Buttons[m_ButtonIndex].MinVoltage = 0;
	//------------- check button usage on the channel ------------//
	for(size_t i = 0; i < ADC_BUTTON_MAX_BUTTON; i++) if(m_ADCModules[m_Module].Channel[ChanIndex].Buttons[i].MaxVoltage == 0) UnusedButton++;
	if(UnusedButton == ADC_BUTTON_MAX_BUTTON && m_ADCModules[m_Module].Channel[ChanIndex].IsInitialised) { // if all button is unused, deinit the channel 
		m_ADCModules[m_Module].Channel[ChanIndex].IsInitialised = 0;
		m_ADCModules[m_Module].Channel[ChanIndex].Channel = ADC_BUTTON_CHANNEL_MAX;
	}
	// -------------- check channel usage on the adc ----------------//
	for(size_t i = 0; i < ADC_BUTTON_MAX_CHANNEL; i++) if(m_ADCModules[m_Module].Channel[i].IsInitialised == 0) UnusedChannel++;
	if(UnusedChannel == ADC_BUTTON_MAX_CHANNEL && m_ADCModules[m_Module].IsConfigured) { // if all channel is unused, deinit the adc 
		if(m_ADCModules[m_Module].IsConfigured == ADC_INIT_BY_ADC_BUTTON) {
			if(adc_oneshot_del_unit(m_ADCModules[m_Module].hADC) != ESP_OK) return;
			DeintialiseCalibration(m_ADCModules[m_Module].hCalibration);
		}
		m_ADCModules[m_Module].IsConfigured = ADC_NONE_INIT;
		memset(&m_ADCModules[m_Module], 0, sizeof(ADCModule_t));
	}
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t AnalogueButton::Create(const ButtonConfig_t *pConfig, const ButtonADCConfig_t *pADCConfig)
{
esp_err_t ret = ESP_OK;

  m_Module = pADCConfig->UnitID;
  int ChanIndex = FindChannel(m_Module, pADCConfig->ADCChannel);
  if(ChanIndex >= 0){                              // the channel has been initialized 
    ESP_GOTO_ON_FALSE(m_ADCModules[m_Module].Channel[ChanIndex].Buttons[pADCConfig->ButtonIndex].MaxVoltage == 0, ESP_ERR_INVALID_STATE, err, _TAG, "The button_index has been used");
  }
  else{ 
    int UnusedIndex = FindUnusedChannel(pADCConfig->UnitID);
      ESP_GOTO_ON_FALSE(UnusedIndex >= 0, ESP_ERR_INVALID_STATE, err, _TAG, "exceed max channel number, can't create a new channel");
      ChanIndex = UnusedIndex;
    }
    if(m_ADCModules[m_Module].IsConfigured == ADC_NONE_INIT){    // initialize adc 
      if(pADCConfig->hADC == NULL){
        adc_oneshot_unit_init_cfg_t ADCConfig = {           //ADC1 Init
          .unit_id = m_Module,
          .clk_src = ADC_RTC_CLK_SRC_DEFAULT,
          .ulp_mode = ADC_ULP_MODE_DISABLE,
        };
        ret = adc_oneshot_new_unit(&ADCConfig, &m_ADCModules[m_Module].hADC);
        ESP_GOTO_ON_FALSE(ret == ESP_OK, ESP_FAIL, err, _TAG, "adc oneshot new unit fail!");
        m_ADCModules[m_Module].IsConfigured = ADC_INIT_BY_ADC_BUTTON;
      }
      else {
        m_ADCModules[m_Module].hADC = *pADCConfig->hADC;
        ESP_LOGI(_TAG, "ADC1 has been initialized");
        m_ADCModules[m_Module].IsConfigured = ADC_INIT_BY_USER;
      }
    }
    if (m_ADCModules[m_Module].Channel[ChanIndex].IsInitialised == 0) {    // initialize adc channel 
        //---------------- ADC1 Config ---------------------//
        adc_oneshot_chan_cfg_t OneshotConfig = {
          .atten = ADC_BUTTON_ATTEN,
          .bitwidth = (adc_bitwidth_t)ADC_BUTTON_WIDTH,
        };
        esp_err_t ret = adc_oneshot_config_channel(m_ADCModules[m_Module].hADC, pADCConfig->ADCChannel, &OneshotConfig);
        ESP_GOTO_ON_FALSE(ret == ESP_OK, ESP_FAIL, err, _TAG, "adc oneshot config channel fail!");
        //------------- ADC1 Calibration Init ---------------//
        InitialiseCalibration(pADCConfig->ADCChannel, &m_ADCModules[m_Module].hCalibration);
        m_ADCModules[m_Module].Channel[ChanIndex].Channel = pADCConfig->ADCChannel;
        m_ADCModules[m_Module].Channel[ChanIndex].IsInitialised = 1;
        m_ADCModules[m_Module].Channel[ChanIndex].UpdateTime = 0;
    }
    m_ADCModules[m_Module].Channel[ChanIndex].Buttons[pADCConfig->ButtonIndex].MaxVoltage = pADCConfig->MaxVoltage;
    m_ADCModules[m_Module].Channel[ChanIndex].Buttons[pADCConfig->ButtonIndex].MinVoltage = pADCConfig->MinVoltage;
    m_ADCModules[m_Module].ChannelCount++;
    m_ADCChannel = pADCConfig->ADCChannel;
    m_ButtonIndex = pADCConfig->ButtonIndex;
    return ESP_OK;

err:
    return ret;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AnalogueButton::InitialiseCalibration(adc_channel_t Channel, adc_cali_handle_t *pHandle)
{
adc_cali_handle_t hCalibration = NULL;
esp_err_t Ret = ESP_FAIL;
bool Calibrated = false;

#if ADC_CALI_SCHEME_CURVE_FITTING_SUPPORTED
	if(!Calibrated) {
		ESP_LOGD(_TAG, "Calibration scheme version is %s", "Curve Fitting");
		adc_cali_curve_fitting_config_t CaliConfig;
		CaliConfig.unit_id = m_Module;
		CaliConfig.chan = Channel;
		CaliConfig.atten = (adc_atten_t)ADC_BUTTON_ATTEN;
		CaliConfig.bitwidth = ADC_BITWIDTH_DEFAULT;
		Ret = adc_cali_create_scheme_curve_fitting(&CaliConfig, &hCalibration);
		if(Ret == ESP_OK) Calibrated = true;
	}
#endif

#if ADC_CALI_SCHEME_LINE_FITTING_SUPPORTED
	if(!Calibrated) {
		ESP_LOGD(_TAG, "Calibration scheme version is %s", "Line Fitting");
		adc_cali_line_fitting_config_t CaliConfig;
		CaliConfig.unit_id = m_Module;
		CaliConfig.atten = (adc_atten_t)ADC_BUTTON_ATTEN;
		CaliConfig.bitwidth = ADC_BITWIDTH_DEFAULT;
		Ret = adc_cali_create_scheme_line_fitting(&CaliConfig, &hCalibration);
		if(Ret == ESP_OK) Calibrated = true;
	}
#endif

	*pHandle = hCalibration;
	if(Ret == ESP_OK)	ESP_LOGD(_TAG, "Calibration Success");
	else if(Ret == ESP_ERR_NOT_SUPPORTED || !Calibrated) ESP_LOGW(_TAG, "eFuse not burnt, skip software calibration");
	else ESP_LOGE(_TAG, "Invalid arg or no memory");
	return Calibrated;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AnalogueButton::DeintialiseCalibration(adc_cali_handle_t hCalibration)
{
#if ADC_CALI_SCHEME_CURVE_FITTING_SUPPORTED
	if(adc_cali_delete_scheme_curve_fitting(hCalibration) == ESP_OK) {
		return true;
	}
#endif
#if ADC_CALI_SCHEME_LINE_FITTING_SUPPORTED
	if(adc_cali_delete_scheme_line_fitting(handle) == ESP_OK) {
		return true;
	}
#endif
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

uint32_t AnalogueButton::GetVoltage(adc_unit_t UnitID, adc_channel_t Channel)
{
int Voltage = 0;
uint32_t Average = 0;
int Reading = 0;

	for(int i = 0; i < NO_OF_SAMPLES; i++) {
		adc_oneshot_read(m_ADCModules[UnitID].hADC, Channel, &Reading);
		Average += Reading;
	}
	Average /= NO_OF_SAMPLES;
	adc_cali_raw_to_voltage(m_ADCModules[UnitID].hCalibration, Average, &Voltage);	//Convert average reading to voltage in mV
	ESP_LOGV(_TAG, "Avarage: %" PRIu32 "\tVoltage: %dmV", Average, Voltage);
	return Voltage;
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t AnalogueButton::GetKeyLevel(void)
{
static uint16_t RawVoltage = 0;

	ESP_RETURN_ON_FALSE(m_ADCChannel < ADC_BUTTON_CHANNEL_MAX, 0, _TAG, "channel out of range");
	ESP_RETURN_ON_FALSE(m_ButtonIndex < ADC_BUTTON_MAX_BUTTON, 0, _TAG, "button_index out of range");
	int ChanIndex = FindChannel(m_Module, m_ADCChannel);
	ESP_RETURN_ON_FALSE(ChanIndex >= 0, 0, _TAG, "The button_index is not init");
	/** It starts only when the elapsed time is more than 1ms */
	if((esp_timer_get_time() - m_ADCModules[m_Module].Channel[ChanIndex].UpdateTime) > 1000) {
		RawVoltage = GetVoltage(m_Module, m_ADCChannel);
		m_ADCModules[m_Module].Channel[ChanIndex].UpdateTime = esp_timer_get_time();
	}
	if(RawVoltage <= m_ADCModules[m_Module].Channel[ChanIndex].Buttons[m_ButtonIndex].MaxVoltage && RawVoltage >= m_ADCModules[m_Module].Channel[ChanIndex].Buttons[m_ButtonIndex].MinVoltage) {
		return BUTTON_ACTIVE;
	}
	return BUTTON_INACTIVE;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t NewAnalogueButton(const ButtonConfig_t *pConfig, const ButtonADCConfig_t *pADCConfig, AnalogueButton *pButton)
{
	ESP_RETURN_ON_FALSE(pConfig && pADCConfig && pButton, ESP_ERR_INVALID_ARG, _TAG, "Invalid argument");
	ESP_RETURN_ON_FALSE(pADCConfig->UnitID < ADC_UNIT_NUM, ESP_ERR_INVALID_ARG, _TAG, "adc_handle out of range");
	ESP_RETURN_ON_FALSE(pADCConfig->ADCChannel < ADC_BUTTON_CHANNEL_MAX, ESP_ERR_INVALID_ARG, _TAG, "channel out of range");
	ESP_RETURN_ON_FALSE(pADCConfig->ButtonIndex < ADC_BUTTON_MAX_BUTTON, ESP_ERR_INVALID_ARG, _TAG, "button_index out of range");
	ESP_RETURN_ON_FALSE(pADCConfig->MaxVoltage > 0, ESP_ERR_INVALID_ARG, _TAG, "key max voltage invalid");
	pButton = new AnalogueButton;
	ESP_RETURN_ON_FALSE(pButton, ESP_ERR_NO_MEM, _TAG, "New analogue button failed");
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t DeleteAnalogueButton(AnalogueButton *pButton)
{
	if(pButton != NULL) delete pButton;
	return ESP_OK;
}


