/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#include <stdio.h>
#include "esp_vfs_fat.h"
#include "esp_log.h"
#include "esp_check.h"
#include "esp_spiffs.h"
#include "esp_lcd_panel_io.h"
#include "esp_lcd_panel_vendor.h"
#include "esp_lcd_panel_ops.h"
#include "esp_lcd_panel_rgb.h"
#include "driver/ledc.h"

#include "S3Touch7BSP.h"
#include "bsp_err_check.h"
#include "ESPEGPort.h"

/////////////////////////////////////////////////////////////////////////////////////

#define LCD_CMD_BITS 		8
#define LCD_PARAM_BITS 	8
#define LCD_LEDC_CH 		CONFIG_BSP_DISPLAY_BRIGHTNESS_LEDC_CH

static ESPGLPort GLPort;
static ESPGLDisplay *g_pEGDisplay = nullptr;
static ESPGLTouchGT911 *g_pTouchController = nullptr;

/////////////////////////////////////////////////////////////////////////////////////

static const char *_TAG = "[BSP   ]";

sdmmc_card_t  *pSDCard = nullptr;  // Global uSD card handler
I2CDriver     *pi2cDev = nullptr;  // Global i2c port
CH422Driver   *pCH422;

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t LED_Initialise(void)
{
const gpio_config_t led_io_config = {
	.pin_bit_mask = BIT64(BSP_LED_RED) | BIT64(BSP_LED_GREEN) | BIT64(BSP_LED_BLUE),
	.mode = GPIO_MODE_OUTPUT,
	.pull_up_en = GPIO_PULLUP_DISABLE,
	.pull_down_en = GPIO_PULLDOWN_DISABLE,
	.intr_type = GPIO_INTR_DISABLE
};

	BSP_ERROR_CHECK_RETURN_ERR(gpio_config(&led_io_config));
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t Set_LED(const bsp_led_t LEDRef, const bool State)
{
	BSP_ERROR_CHECK_RETURN_ERR(gpio_set_level((gpio_num_t)LEDRef, (uint32_t)State));
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t MountSPIFFS(void)
{
esp_vfs_spiffs_conf_t Config = {
	.base_path = CONFIG_BSP_SPIFFS_MOUNT_POINT,
	.partition_label = CONFIG_BSP_SPIFFS_PARTITION_LABEL,
	.max_files = CONFIG_BSP_SPIFFS_MAX_FILES,
#ifdef CONFIG_BSP_SPIFFS_FORMAT_ON_MOUNT_FAIL
	.format_if_mount_failed = true,
#else
	.format_if_mount_failed = false,
#endif
};

	esp_err_t ret_val = esp_vfs_spiffs_register(&Config);
	BSP_ERROR_CHECK_RETURN_ERR(ret_val);
	size_t total = 0, used = 0;
	ret_val = esp_spiffs_info(Config.partition_label, &total, &used);
	if(ret_val != ESP_OK) {
		ESP_LOGE(_TAG, "Failed to get SPIFFS partition information (%s)", esp_err_to_name(ret_val));
	}
	else {
		ESP_LOGI(_TAG, "Partition size: total: %d, used: %d", total, used);
	}
	return ret_val;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t UnmountSPIFFS(void)
{
	return esp_vfs_spiffs_unregister(CONFIG_BSP_SPIFFS_PARTITION_LABEL);
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t MountSDCard(void)
{
const esp_vfs_fat_sdmmc_mount_config_t Config = {
#ifdef CONFIG_BSP_uSD_FORMAT_ON_MOUNT_FAIL
	.format_if_mount_failed = true,
#else
	.format_if_mount_failed = false,
#endif
	.max_files = 5,
	.allocation_unit_size = 16 * 1024,
	.disk_status_check_enable = 0,
	.use_one_fat = 0,
};

	sdmmc_host_t Host = SDMMC_HOST_DEFAULT();
	sdmmc_slot_config_t SlotConfig = SDMMC_SLOT_CONFIG_DEFAULT();
	SlotConfig.width = 4;
	return esp_vfs_fat_sdmmc_mount(BSP_SD_MOUNT_POINT, &Host, &SlotConfig, &Config, &pSDCard);
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t UnmountSDCard(void)
{
	return esp_vfs_fat_sdcard_unmount(BSP_SD_MOUNT_POINT, pSDCard);
}


/////////////////////////////////////////////////////////////////////////////////////

esp_err_t BacklightIntialise(gpio_num_t BackLightPin)
{
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t SetBacklightLevel(int Intensity)
{
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t BacklightOff(void)
{
  pCH422->WriteControl(0x01);
  pCH422->WriteOutput(0x1A);    //Turn off the screen backlight by pulling the backlight pin low 
  return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t BacklightOn(void)
{
  pCH422->WriteControl(0x01);
  pCH422->WriteOutput(0x1E);    //Pull the backlight pin high to light the screen backlight 
  return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t InitialiseDisplayIO(esp_lcd_panel_handle_t *pPanel)
{
esp_lcd_rgb_panel_config_t PanelConfig = {
	.clk_src = LCD_CLK_SRC_DEFAULT,  // Set the clock source for the panel
	.timings = {
		.pclk_hz = BSP_LCD_PIXEL_CLOCK_HZ,                // Pixel clock frequency
		.h_res = BSP_LCD_H_RES,                           // Horizontal resolution
		.v_res = BSP_LCD_V_RES,                           // Vertical resolution
		.hsync_pulse_width = BSP_LCD_RGB_HPW,             // Horizontal sync pulse width
		.hsync_back_porch = BSP_LCD_RGB_HBP,              // Horizontal back porch
		.hsync_front_porch = BSP_LCD_RGB_HFP,             // Horizontal front porch
		.vsync_pulse_width = BSP_LCD_RGB_VPW,             // Vertical sync pulse width
		.vsync_back_porch = BSP_LCD_RGB_VBP,              // Vertical back porch
		.vsync_front_porch = BSP_LCD_RGB_VFP,             // Vertical front porch
		.flags = {
      .hsync_idle_low = 0,
      .vsync_idle_low = 0,
      .de_idle_high = 0,
			.pclk_active_neg = BSP_LCD_RGB_PCLK_ACTIVE_NEG, // Active low pixel clock
      .pclk_idle_high = 0
		},
	},
	.data_width = BSP_RGB_DATA_WIDTH,                     // Data width for RGB
	.bits_per_pixel = BSP_LCD_RGB_PIXEL_BITS,             // Bits per pixel
	.num_fbs = EGL_PORT_LCD_RGB_BUFFER_NUMS,              // Number of frame buffers
	.bounce_buffer_size_px = BSP_RGB_BOUNCE_BUFFER_SIZE,  // Bounce buffer size in pixels
	.sram_trans_align = 4,                                // SRAM transaction alignment
	.psram_trans_align = 64,                              // PSRAM transaction alignment
	.hsync_gpio_num = BSP_LCD_IO_RGB_HSYNC,               // GPIO number for horizontal sync
	.vsync_gpio_num = BSP_LCD_IO_RGB_VSYNC,               // GPIO number for vertical sync
	.de_gpio_num = BSP_LCD_IO_RGB_DE,                     // GPIO number for data enable
	.pclk_gpio_num = BSP_LCD_IO_RGB_PCLK,                 // GPIO number for pixel clock
	.disp_gpio_num = BSP_LCD_IO_RGB_DISP,                 // GPIO number for display
	.data_gpio_nums = {
		BSP_LCD_IO_RGB_DATA0,
    BSP_LCD_IO_RGB_DATA1,
    BSP_LCD_IO_RGB_DATA2,
    BSP_LCD_IO_RGB_DATA3,
    BSP_LCD_IO_RGB_DATA4,
    BSP_LCD_IO_RGB_DATA5,
    BSP_LCD_IO_RGB_DATA6,
    BSP_LCD_IO_RGB_DATA7,
    BSP_LCD_IO_RGB_DATA8,
    BSP_LCD_IO_RGB_DATA9,
    BSP_LCD_IO_RGB_DATA10,
    BSP_LCD_IO_RGB_DATA11,
    BSP_LCD_IO_RGB_DATA12,
    BSP_LCD_IO_RGB_DATA13,
    BSP_LCD_IO_RGB_DATA14,
    BSP_LCD_IO_RGB_DATA15
	},
	.flags = {
		.disp_active_low = 0,
    .refresh_on_demand = 0,
		.fb_in_psram = 1,  // Use PSRAM for framebuffer
    .double_fb = 0,
    .no_fb = 0,
    .bb_invalidate_cache = 0
	},
};

  ESP_ERROR_CHECK(esp_lcd_new_rgb_panel(&PanelConfig, pPanel));  // Create a new RGB panel with the specified configuration
  ESP_ERROR_CHECK(esp_lcd_panel_init(*pPanel));                  // Initialize the LCD panel
  return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

EGDisplay *LCD_Initialise(void)
{
esp_lcd_panel_handle_t hPanel = nullptr;
ESPGLPortRGBCfg_t RGBConfig = {
  .BounceBufferMode = 0,
  .AvoidTearing = (EGL_PORT_AVOID_TEAR_ENABLE ? 1 : 0),
};
ESPGLPortDisplayCfg_t PortConfig = {
  .BufferSize = BSP_LCD_DRAW_BUFF_SIZE,
  .DoubleBuffer = BSP_LCD_DRAW_BUFF_DOUBLE,
  .TransferSize = 0,
  .HoriResolution = BSP_LCD_H_RES,
  .VertvResolution = BSP_LCD_V_RES,
  .IsMonochrome = false,
  /* Rotation values must be same as used in esp_lcd for initial settings of the screen */
  .Rotation = {
    .SwapXY = false,
#ifdef CONFIG_BSP_LCD_ILI9341
    .mirror_x = true,
#else
    .MirrorX = false,
#endif
    .MirrorY = false,
  },
  .Flags = {
    .BufferDMA = true,
    .BuffersPSRAM = false,
    .SWRotate = 0,
#if EG_VERSION_MAJOR >= 9
    .SwapBytes = (BSP_LCD_BIGENDIAN ? true : false),
#endif
#if EGL_PORT_FULL_REFRESH
    .FullRefresh = 1,
    .DirectMode = 0
#elif EGL_PORT_DIRECT_MODE
    .FullRefresh = 0,
    .DirectMode = 1
#else
    .FullRefresh = 0,
    .DirectMode = 0
#endif
  }
};

	BSP_ERROR_CHECK_RETURN_NULL(InitialiseDisplayIO(&hPanel));
#if ESP_IDF_VERSION < ESP_IDF_VERSION_VAL(5, 0, 0)
	esp_lcd_panel_disp_off(hPanel, false);
#else
	esp_lcd_panel_disp_on_off(hPanel, true);
#endif
	ESP_LOGD(_TAG, "Add LCD screen");	// Add LCD screen 
	return g_pEGDisplay->AddDisplayRGB(hPanel, &PortConfig, &RGBConfig); // merge the display harware and software
}

/////////////////////////////////////////////////////////////////////////////////////

EGDisplay* DisplayStart(void)
{
EGDisplay *pDisplay;

  pi2cDev = new I2CDriver();
  pi2cDev->Initialise(I2CTouchSclIO_c, I2CTouchSdaIO_c, I2CTouchMaster_c);
  pCH422 = new CH422Driver(pi2cDev);
  g_pEGDisplay = new ESPGLDisplay; // get a new display hardware object
  g_pTouchController = new ESPGLTouchGT911;
  GLPort.Initialise(c_TaskPriority, c_TaskStack, c_TaskAffinity, c_TaskMaxSleep, c_TimerPeriod); 
	BSP_NULL_CHECK(pDisplay = LCD_Initialise(), NULL);
	TouchpadInitialise(g_pTouchController, pDisplay);
	return pDisplay;
}

/////////////////////////////////////////////////////////////////////////////////////

EGInputDevice *GetInputDevice(void)
{
	return nullptr;
}

/////////////////////////////////////////////////////////////////////////////////////

void DisplayRotate(EGDisplay *pDisplay, EG_DisplayRotation_e Rotation)
{
	pDisplay->SetRotation((EG_DisplayRotation_t)Rotation);
}

/////////////////////////////////////////////////////////////////////////////////////

bool DisplayLock(uint32_t Timeout)
{
	return GLPort.Lock(Timeout);
}

/////////////////////////////////////////////////////////////////////////////////////

void DisplayUnlock(void)
{
	GLPort.Unlock();
}
