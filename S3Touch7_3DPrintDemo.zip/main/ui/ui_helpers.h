/*
 *              Copyright (c) 2025-2026 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original VanAttitude
 *
 */

#pragma once

#include "ui.h"

#define _UI_TEMPORARY_STRING_BUFFER_SIZE 32
#define _UI_BAR_PROPERTY_VALUE 0
#define _UI_BAR_PROPERTY_VALUE_WITH_ANIM 1
#define _UI_BASIC_PROPERTY_POSITION_X 0
#define _UI_BASIC_PROPERTY_POSITION_Y 1
#define _UI_BASIC_PROPERTY_WIDTH 2
#define _UI_BASIC_PROPERTY_HEIGHT 3
#define _UI_DROPDOWN_PROPERTY_SELECTED 0
#define _UI_IMAGE_PROPERTY_IMAGE 0
#define _UI_LABEL_PROPERTY_TEXT 0
#define _UI_ROLLER_PROPERTY_SELECTED 0
#define _UI_ROLLER_PROPERTY_SELECTED_WITH_ANIM 1
#define _UI_SLIDER_PROPERTY_VALUE 0
#define _UI_SLIDER_PROPERTY_VALUE_WITH_ANIM 1
#define _UI_SWITCH_PROPERTY_VALUE 0
#define _UI_SWITCH_PROPERTY_VALUE_WITH_ANIM 1
#define _UI_MODIFY_FLAG_ADD 0
#define _UI_MODIFY_FLAG_REMOVE 1
#define _UI_MODIFY_FLAG_TOGGLE 2
#define _UI_MODIFY_STATE_ADD 0
#define _UI_MODIFY_STATE_REMOVE 1
#define _UI_MODIFY_STATE_TOGGLE 2
#define UI_MOVE_CURSOR_UP 0
#define UI_MOVE_CURSOR_RIGHT 1
#define UI_MOVE_CURSOR_DOWN 2
#define UI_MOVE_CURSOR_LEFT 3

// Describes an animation
typedef struct UI_AnimateData_t {
    EGObject *pTarget;
    EGImageBuffer **ppImgset;
    int32_t ImgsetSize;
    int32_t Val;
} UI_AnimateData_t;

void UI_BarSetProperty(EGBar * target, int id, int val);
void UI_BasicSetProperty(EGObject * target, int id, int val);
void UI_DropDownSetProperty(EGDropDown * target, int id, int val);
void UI_ImageSetProperty(EGImage * target, int id, uint8_t * val);
void UI_LabelSetProperty(EGLabel * target, int id, const char * val);
void UI_RollerSetProperty(EGRoller * target, int id, int val);
void UI_SliderSetProperty(EGSlider * target, int id, int val);
void UI_SwitchSetProperty(EGSwitch * target, int id, int val);
void UI_ScreenChange(EGObject ** target, EG_ScreenAnimateType_t fademode, int spd, int delay);
void UI_ScreenDelete(EGObject ** target);
void UI_ArcIncrement(EGArc * target, int val);
void UI_BarIncrement(EGBar * target, int val, int anm);
void UI_SliderIncrement(EGSlider * target, int val, int anm);
void UI_KeyboardSetTarget(EGKeyboard * keyboard, EGEdit * textarea);
void UI_FlagModify(EGObject * target, int32_t flag, int value);
void UI_StateModify(EGObject * target, int32_t state, int value);
void UI_EditMoveCursor(EGEdit * target, int val);
void ScreenUnloadedDeleteCB(EGEvent *pEvent);
void UI_OpacitySet(EGObject * target, int val);
void UI_AnimateDeleteCB(EGAnimate *pAnimate);
void UI_AnimateSetXCB(EGAnimate *pAnimate, int32_t v);
void UI_AnimateSetYCB(EGAnimate *pAnimate, int32_t v);
void UI_AnimateSetWidthCB(EGAnimate *pAnimate, int32_t v);
void UI_AnimateSetHeightCB(EGAnimate *pAnimate, int32_t v);
void UI_AnimateSetOpacityCB(EGAnimate *pAnimate, int32_t v);
void UI_AnimateSetImageZoomCB(EGAnimate *pAnimate, int32_t v);
void UI_AnimateSetImageAngleCB(EGAnimate *pAnimate, int32_t v);
void UI_AnimateSetImageFrameCB(EGAnimate *pAnimate, int32_t v);
int32_t UI_AnimateGetXCB(EGAnimate *pAnimate);
int32_t UI_AnimateGetYCB(EGAnimate *pAnimate);
int32_t UI_AnimateGetWidthCB(EGAnimate *pAnimate);
int32_t UI_AnimateGetHeightCB(EGAnimate *pAnimate);
int32_t UI_AnimateGetOpacityCB(EGAnimate *pAnimate);
int32_t UI_AnimateGetImageZoomCB(EGAnimate *pAnimate);
int32_t UI_AnimateGetImageAngleCB(EGAnimate *pAnimate);
int32_t UI_AnimateGetImageFrameCB(EGAnimate *pAnimate);
void UI_ArcSetTextValue(EGLabel * trg, EGArc * src, const char * prefix, const char * postfix);
void UI_SliderSetTextValue(EGLabel * trg, EGSlider * src, const char * prefix, const char * postfix);
void UI_CheckedSetTextValue(EGLabel * trg, EGObject * src, const char * txt_on, const char * txt_off);
void UI_SpinboxStep(EGSpinBox * target, int val);


