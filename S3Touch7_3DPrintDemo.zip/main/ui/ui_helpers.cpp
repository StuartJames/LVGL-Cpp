/*
 *              Copyright (c) 2025-2026 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original VanAttitude
 *
 */

#include "ui_helpers.h"

/////////////////////////////////////////////////////////////////////////////////////

void UI_BarSetProperty(EGBar *target, int id, int val)
{
	if(id == _UI_BAR_PROPERTY_VALUE_WITH_ANIM) target->SetValue(val, EG_ANIM_ON);
	if(id == _UI_BAR_PROPERTY_VALUE) target->SetValue(val, EG_ANIM_OFF);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_BasicSetProperty(EGObject *target, int id, int val)
{
	if(id == _UI_BASIC_PROPERTY_POSITION_X) target->SetX(val);
	if(id == _UI_BASIC_PROPERTY_POSITION_Y) target->SetY(val);
	if(id == _UI_BASIC_PROPERTY_WIDTH) target->SetWidth(val);
	if(id == _UI_BASIC_PROPERTY_HEIGHT) target->SetHeight(val);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_DropDownSetProperty(EGDropDown *target, int id, int val)
{
	if(id == _UI_DROPDOWN_PROPERTY_SELECTED) target->SetSelectedIndex(val);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_ImageSetProperty(EGImage *target, int id, uint8_t *val)
{
	if(id == _UI_IMAGE_PROPERTY_IMAGE) target->SetSource(val);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_LabelSetProperty(EGLabel *target, int id, const char *val)
{
	if(id == _UI_LABEL_PROPERTY_TEXT) target->SetText(val);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_RollerSetProperty(EGRoller *target, int id, int val)
{
	if(id == _UI_ROLLER_PROPERTY_SELECTED_WITH_ANIM) target->SetSelected(val, EG_ANIM_ON);
	if(id == _UI_ROLLER_PROPERTY_SELECTED) target->SetSelected(val, EG_ANIM_OFF);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_SliderSetProperty(EGSlider *target, int id, int val)
{
	if(id == _UI_SLIDER_PROPERTY_VALUE_WITH_ANIM) target->SetValue(val, EG_ANIM_ON);
	if(id == _UI_SLIDER_PROPERTY_VALUE) target->SetValue(val, EG_ANIM_OFF);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_SwitchSetProperty(EGSwitch *target, int id, int val)
{
//	if(id == _UI_SWITCH_PROPERTY_VALUE_WITH_ANIM) target->SetValue(val, EG_ANIM_ON);
//	if(id == _UI_SWITCH_PROPERTY_VALUE) target->SetValue(val, EG_ANIM_OFF);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_ScreenChange(EGObject **target, EG_ScreenAnimateType_t fademode, int spd, int delay)
{
	EGDisplay::LoadAnimation(*target, fademode, spd, delay, false);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_ScreenDelete(EGObject **target)
{
	if(*target == NULL) {
		EGObject::Delete(*target);
		target = NULL;
	}
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_ArcIncrement(EGArc *target, int val)
{
	int old = target->GetValue();
	target->SetValue(old + val);
	EGEvent::EventSend(target, EG_EVENT_VALUE_CHANGED, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_BarIncrement(EGBar *target, int val, int anm)
{
	int old = target->GetValue();
	target->SetValue(old + val, (EG_AnimateEnable_e)anm);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_SliderIncrement(EGSlider *target, int val, int anm)
{
	int old = target->GetValue();
	target->SetValue(old + val, (EG_AnimateEnable_e)anm);
	EGEvent::EventSend(target, EG_EVENT_VALUE_CHANGED, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_KeyboardSetTarget(EGKeyboard *keyboard, EGEdit *textarea)
{
	keyboard->SetEditCtrl(textarea);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_FlagModify(EGObject *target, int32_t flag, int value)
{
	if(value == _UI_MODIFY_FLAG_TOGGLE) {
		if(target->HasFlagSet(flag)) target->ClearFlag(flag);
		else target->AddFlag(flag);
	}
	else if(value == _UI_MODIFY_FLAG_ADD) target->AddFlag(flag);
	else target->ClearFlag(flag);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_StateModify(EGObject *target, int32_t state, int value)
{
	if(value == _UI_MODIFY_STATE_TOGGLE) {
		if(target->HasState(state))target->ClearState(state);
		else target->AddFlag(state);
	}
	else if(value == _UI_MODIFY_STATE_ADD) target->AddFlag(state);
	else target->ClearFlag(state);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_EditMoveCursor(EGEdit *target, int val)
{
	if(val == UI_MOVE_CURSOR_UP) target->CursorUp();
	if(val == UI_MOVE_CURSOR_RIGHT) target->CursorRight();
	if(val == UI_MOVE_CURSOR_DOWN) target->CursorDown();
	if(val == UI_MOVE_CURSOR_LEFT) target->CursorLeft();
	target->AddState(EG_STATE_FOCUSED);
}

/////////////////////////////////////////////////////////////////////////////////////

void ScreenUnloadedDeleteCB(EGEvent *pEvent)
{
	EGObject **var = (EGObject **)pEvent->GetExtParam();
	EGObject::Delete(*var);
	(*var) = NULL;
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_OpacitySet(EGObject *target, int val)
{
	target->SetStyleOPA(val, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_AnimateDeleteCB(EGAnimate *pAnimate)
{
	EG_FreeMem(((EGAnimate*)pAnimate)->m_pItem);
	((EGAnimate*)pAnimate)->m_pItem = nullptr;
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_AnimateSetXCB(EGAnimate *pAnimate, int32_t v)
{
	UI_AnimateData_t *pData = (UI_AnimateData_t*)pAnimate->m_pItem;
	pData->pTarget->SetX(v);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_AnimateSetYCB(EGAnimate *pAnimate, int32_t v)
{
	UI_AnimateData_t *pData = (UI_AnimateData_t*)pAnimate->m_pItem;
	pData->pTarget->SetY(v);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_AnimateSetWidthCB(EGAnimate *pAnimate, int32_t v)
{
	UI_AnimateData_t *pData = (UI_AnimateData_t*)pAnimate->m_pItem;
	pData->pTarget->SetWidth(v);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_AnimateSetHeightCB(EGAnimate *pAnimate, int32_t v)
{
	UI_AnimateData_t *pData = (UI_AnimateData_t*)pAnimate->m_pItem;
	pData->pTarget->SetHeight(v);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_AnimateSetOpacityCB(EGAnimate *pAnimate, int32_t v)
{
	UI_AnimateData_t *pData = (UI_AnimateData_t*)pAnimate->m_pItem;
	pData->pTarget->SetStyleOPA(v, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_AnimateSetImageZoomCB(EGAnimate *pAnimate, int32_t v)
{
	UI_AnimateData_t *pData = (UI_AnimateData_t*)pAnimate->m_pItem;
	((EGImage*)pData->pTarget)->SetZoom(v);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_AnimateSetImageAngleCB(EGAnimate *pAnimate, int32_t v)
{
	UI_AnimateData_t *pData = (UI_AnimateData_t*)pAnimate->m_pItem;
	((EGImage*)pData->pTarget)->SetRotation(v);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_AnimateSetImageFrameCB(EGAnimate *pAnimate, int32_t v)
{
	UI_AnimateData_t *pData = (UI_AnimateData_t*)pAnimate->m_pItem;
	pData->Val = v;
	if(v < 0) v = 0;
	if(v >= pData->ImgsetSize) v = pData->ImgsetSize - 1;
	((EGImage*)pData->pTarget)->SetSource(pData->ppImgset[v]);
}

/////////////////////////////////////////////////////////////////////////////////////

int32_t UI_AnimateGetXCB(EGAnimate *pAnimate)
{
	UI_AnimateData_t *pData = (UI_AnimateData_t*)pAnimate->m_pItem;
	return pData->pTarget->GetAlignedX();
}

/////////////////////////////////////////////////////////////////////////////////////

int32_t UI_AnimateGetYCB(EGAnimate *pAnimate)
{
	UI_AnimateData_t *pData = (UI_AnimateData_t*)pAnimate->m_pItem;
	return ((EGObject*)pData->pTarget)->GetAlignedY();
}

/////////////////////////////////////////////////////////////////////////////////////

int32_t UI_AnimateGetWidthCB(EGAnimate *pAnimate)
{
	UI_AnimateData_t *pData = (UI_AnimateData_t*)pAnimate->m_pItem;
	return ((EGObject*)pData->pTarget)->GetWidth();
}

/////////////////////////////////////////////////////////////////////////////////////

int32_t UI_AnimateGetHeightCB(EGAnimate *pAnimate)
{
	UI_AnimateData_t *pData = (UI_AnimateData_t*)pAnimate->m_pItem;
	return ((EGObject*)pData->pTarget)->GetHeight();
}

/////////////////////////////////////////////////////////////////////////////////////

int32_t UI_AnimateGetOpacityCB(EGAnimate *pAnimate)
{
	UI_AnimateData_t *pData = (UI_AnimateData_t*)pAnimate->m_pItem;
	return ((EGObject*)pData->pTarget)->GetStyleOPA(0);
}

/////////////////////////////////////////////////////////////////////////////////////

int32_t UI_AnimateGetImageZoomCB(EGAnimate *pAnimate)
{
	UI_AnimateData_t *pData = (UI_AnimateData_t*)pAnimate->m_pItem;
	EGScale Scale = ((EGImage*)pData->pTarget)->GetScale();
  return (int32_t)Scale.Minimum();
}

/////////////////////////////////////////////////////////////////////////////////////

int32_t UI_AnimateGetImageAngleCB(EGAnimate *pAnimate)
{
	UI_AnimateData_t *pData = (UI_AnimateData_t*)pAnimate->m_pItem;
	return ((EGImage*)pData->pTarget)->GetRotation();
}

/////////////////////////////////////////////////////////////////////////////////////

int32_t UI_AnimateGetImageFrameCB(EGAnimate *pAnimate)
{
	UI_AnimateData_t *pData = (UI_AnimateData_t*)pAnimate->m_pItem;
	return pData->Val;
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_ArcSetTextValue(EGLabel *trg, EGArc *src, const char *prefix, const char *postfix)
{
	char buf[_UI_TEMPORARY_STRING_BUFFER_SIZE];
	eg_snprintf(buf, sizeof(buf), "%s%d%s", prefix, (int)src->GetValue(), postfix);
	trg->SetText(buf);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_SliderSetTextValue(EGLabel *trg, EGSlider *src, const char *prefix, const char *postfix)
{
	char buf[_UI_TEMPORARY_STRING_BUFFER_SIZE];
	eg_snprintf(buf, sizeof(buf), "%s%d%s", prefix, (int)src->GetValue(), postfix);
	trg->SetText(buf);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_CheckedSetTextValue(EGLabel *trg, EGObject *src, const char *txt_on, const char *txt_off)
{
	if(src->HasState(EG_STATE_CHECKED))	trg->SetText(txt_on);
	else trg->SetText(txt_off);
}

/////////////////////////////////////////////////////////////////////////////////////

void UI_SpinboxStep(EGSpinBox *target, int val)
{
	if(val > 0)	target->Increment();
	else target->Decrement();
	EGEvent::EventSend(target, EG_EVENT_VALUE_CHANGED, 0);
}
