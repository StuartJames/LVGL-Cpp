/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= ===========================================
  * LoBo  2021/11/08   1.a.1   Original PPPoS example with GSM
 *
 */

#pragma once

#include "InternetClock.h"
#include <nvs_flash.h>
#include <nvs.h>

esp_err_t   CheckNVS(void);
esp_err_t   NVSPutInt8(const char *Tag, const uint8_t Var);
esp_err_t   NVSGetInt8(const char *Tag, uint8_t *pVar, uint8_t Default);
esp_err_t   NVSPutShort(const char *Tag, const short Var);
esp_err_t   NVSGetShort(const char *Tag, short *pVar, short Default);
esp_err_t   NVSPutInt(const char *Tag, const int32_t Var);
esp_err_t   NVSGetInt(const char *Tag, int32_t *pVar, int Default);
esp_err_t   NVSPutInt32(const char *Tag, const uint32_t Var);
esp_err_t   NVSGetInt32(const char *Tag, uint32_t *pVar, uint32_t Default);
esp_err_t   NVSPutStr(const char *Tag, const char *pVar);
esp_err_t   NVSGetStr(const char *Tag, char *pVar, size_t Size, const char *pDefault);
esp_err_t   NVSPutArray(const char *Tag, uint8_t *pVar, size_t Count);
esp_err_t   NVSGetArray(const char *Tag, uint8_t *pVar, size_t Count);
