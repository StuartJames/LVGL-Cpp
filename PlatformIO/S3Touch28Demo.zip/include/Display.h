/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= ===========================================
 * SJ    2025/08/18   1.a.1    Original ESP Demo
 *
 */


#pragma once

#include "LEGLDemo28.h"

/////////////////////////////////////////////////////////////////////////////////////

#define LVGL_TICK_PERIOD_MS  1000

/////////////////////////////////////////////////////////////////////////////////////

typedef enum : uint8_t{
	DISP_SMALL,
	DISP_MEDIUM,
	DISP_LARGE,
} DispSize_e;

/////////////////////////////////////////////////////////////////////////////////////

void SetBacklight(EGEvent *pEvent);
void DisplayThread(void *pArg);

