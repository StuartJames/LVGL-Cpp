/*
 *                LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_check.h"
#include "driver/gpio.h"
#include "esp_lcd_panel_io.h"
#include "ESPEGPort.h"
#include "ESPEGTouchFT6336.h"

/////////////////////////////////////////////////////////////////////////////////////

static const char *_TAG = "[FT6336]";

/////////////////////////////////////////////////////////////////////////////////////

ESPGLTouchFT6336::ESPGLTouchFT6336(void) : ESPGLTouchController()
{
  EG_ZeroMem(&m_Data, sizeof(ESPGLTouchData_t));
  m_Data.Lock.owner = portMUX_FREE_VAL;
}

/////////////////////////////////////////////////////////////////////////////////////

ESPGLTouchFT6336::~ESPGLTouchFT6336(void)
{
	if(m_Config.InterruptPin != GPIO_NUM_NC) {  // Reset GPIO pin settings 
		gpio_reset_pin(m_Config.InterruptPin);
	}
	if(m_Config.ResetPin != GPIO_NUM_NC) {	    // Reset GPIO pin settings 
		gpio_reset_pin(m_Config.ResetPin);
	}
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchFT6336::ReadData(void)
{
esp_err_t Res;
uint8_t Buffer[30];
uint8_t Points;
size_t i = 0;

	Res = i2cRead(TOUCH_FT6336_POINTS_REG, &Points, 1);
	ESP_RETURN_ON_ERROR(Res, _TAG, "I2C read error!");
	Points = Points & 0x0F;
	if(Points == 0) return ESP_OK;
	Points = (Points > 2 ? 2 : Points);	// Number of touched Points 

	Res = i2cRead(TOUCH_FT6336_P1_XH_REG, Buffer, 6 * Points);
	ESP_RETURN_ON_ERROR(Res, _TAG, "I2C read error!");
  if(m_Config.InterruptPin != GPIO_NUM_NC) gpio_intr_disable(m_Config.InterruptPin);
	m_Data.Points = Points;
	for(i = 0; i < Points; i++) {
		m_Data.Coords[i].X = (uint16_t)((((uint16_t)Buffer[(i * 6) + 0] & 0x0f) << 8) + Buffer[(i * 6) + 1]);
		m_Data.Coords[i].Y = (uint16_t)((((uint16_t)Buffer[(i * 6) + 2] & 0x0f) << 8) + Buffer[(i * 6) + 3]);
	}
  if(m_Config.InterruptPin != GPIO_NUM_NC) gpio_intr_enable(m_Config.InterruptPin);
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

bool ESPGLTouchFT6336::GetCoordinates(uint16_t *pX, uint16_t *pY, uint16_t *pStrength, uint8_t *pCount, uint8_t MaxCount)
{
	assert(pX != nullptr);
	assert(pY != nullptr);
	assert(pCount != nullptr);
	assert(MaxCount > 0);
	if(m_Config.InterruptPin != GPIO_NUM_NC) gpio_intr_disable(m_Config.InterruptPin);
	if(m_Data.Points > MaxCount)	m_Data.Points = MaxCount;	// Count of Points 
	for(size_t i = 0; i < m_Data.Points; i++) {
		pX[i] = m_Data.Coords[i].X;
		pY[i] = m_Data.Coords[i].Y;
		if(pStrength) {
			pStrength[i] = m_Data.Coords[i].Strength;
		}
	}
	*pCount = m_Data.Points;
	m_Data.Points = 0;																							// Invalidate 
	if(m_Config.InterruptPin != GPIO_NUM_NC) gpio_intr_enable(m_Config.InterruptPin);
	return (*pCount > 0);
}

/////////////////////////////////////////////////////////////////////////////////////

void ESPGLTouchFT6336::i2cConfig(i2c_master_bus_handle_t hi2cBus)
{
i2c_device_config_t i2cDeviceCfg;

  if(hi2cBus == nullptr){
  	ESP_LOGE(_TAG, "The FT6336 requires an i2c port");
    return;
  }
  memset(&i2cDeviceCfg, 0, sizeof(i2c_device_config_t));
  i2cDeviceCfg.dev_addr_length = I2C_ADDR_BIT_LEN_7;
  i2cDeviceCfg.device_address = ESP_LCD_TOUCH_IO_I2C_FT6336_ADDRESS;
  i2cDeviceCfg.scl_speed_hz = 200 * 1000;     // maximum 400kHz 
  i2c_master_bus_add_device(hi2cBus, &i2cDeviceCfg, &m_hDevice);
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchFT6336::i2cWrite(uint8_t Register, uint8_t *pData, uint8_t Length)
{
  uint8_t *pBuffer = (uint8_t*)malloc(Length + 1);
  pBuffer[0] = Register;
  memcpy(&pBuffer[1], pData, Length);
  esp_err_t Res = i2c_master_transmit(m_hDevice, pBuffer, Length +1, 250);
  free(pBuffer);
  return Res;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchFT6336::i2cRead(uint8_t Register, uint8_t *pData, uint8_t Length)
{
	assert(pData != nullptr);
  esp_err_t Res = i2c_master_transmit_receive(m_hDevice, &Register, 1, pData, Length, 250);
  return Res;
}

/////////////////////////////////////////////////////////////////////////////////////

// Reset controller 
esp_err_t ESPGLTouchFT6336::Reset(void)
{
  if(m_Config.ResetPin != GPIO_NUM_NC){
  	ESP_RETURN_ON_ERROR(gpio_set_level(m_Config.ResetPin, !m_Config.Levels.Reset), _TAG, "GPIO set level error!");
	  vTaskDelay(pdMS_TO_TICKS(10));
	  ESP_RETURN_ON_ERROR(gpio_set_level(m_Config.ResetPin, m_Config.Levels.Reset), _TAG, "GPIO set level error!");
	  vTaskDelay(pdMS_TO_TICKS(10));
  }
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchFT6336::Configure(const ESPGL_LCDTouchConfig_t *pConfig)
{
esp_err_t ret = ESP_OK;

	assert(pConfig != nullptr);
	memcpy(&m_Config, pConfig, sizeof(ESPGL_LCDTouchConfig_t));	// Save config 
	if(m_Config.InterruptPin != GPIO_NUM_NC) {	// Prepare pin for touch interrupt 
	  ESP_LOGI(_TAG, "Setting FT6336 interrupts");
		const gpio_config_t int_gpio_config = {
			.pin_bit_mask = BIT64(m_Config.InterruptPin),
			.mode = GPIO_MODE_INPUT,
    	.pull_up_en = GPIO_PULLUP_ENABLE,
    	.pull_down_en = GPIO_PULLDOWN_DISABLE,
			.intr_type = GPIO_INTR_NEGEDGE,
		};
		ret = gpio_config(&int_gpio_config);
		ESP_GOTO_ON_ERROR(ret, err, _TAG, "GPIO config failed");
		if(m_Config.InterruptCB != nullptr){		// Register interrupt callback 
		  RegisterInterruptCB(m_Config.InterruptCB);
		}
	}

	/* Prepare pin for touch controller reset */
	if(m_Config.ResetPin != GPIO_NUM_NC) {	// Prepare pin for touch reset 
		const gpio_config_t rst_gpio_config = {
			.pin_bit_mask = BIT64(m_Config.ResetPin),
			.mode = GPIO_MODE_OUTPUT,
    	.pull_up_en = GPIO_PULLUP_DISABLE,
    	.pull_down_en = GPIO_PULLDOWN_DISABLE,
			.intr_type = GPIO_INTR_DISABLE,
    };
		ret = gpio_config(&rst_gpio_config);
		ESP_GOTO_ON_ERROR(ret, err, _TAG, "GPIO config failed");
	}
	ret = Reset();	// Reset controller 
	ESP_GOTO_ON_ERROR(ret, err, _TAG, "FT6336 reset failed");

err:
	if(ret != ESP_OK) {
		ESP_LOGE(_TAG, "Error (0x%x)! Touch controller FT6336 initialization failed!", ret);
	}
	return ret;
}

/////////////////////////////////////////////////////////////////////////////////////

void ESPGLTouchFT6336::Initialise(void)
{
ESPGL_LCDTouchConfig_t HWConfig = {
  .MaxX = LCD_TOUCH_V_RES,
  .MaxY = LCD_TOUCH_H_RES,
  .ResetPin = I2CTouchResetIO_c,
  .InterruptPin = I2CTouchIntIO_c,
  .Levels = {
    .Reset = 0,
    .Interrupt = 0,
  },
  .Flags = {
    .SwapXY = 0,
    .MirrorX = 0,
    .MirrorY = 0,
  },
  .InterruptCB = nullptr,
  .DeviceAddress = ESP_LCD_TOUCH_IO_I2C_FT6336_ADDRESS
};

	m_ScaleX = 1.0;
	m_ScaleY = 1.0;
	ESP_LOGI(_TAG, "Initialize touch controller FT6336");
	ESP_ERROR_CHECK(Configure(&HWConfig));
}



