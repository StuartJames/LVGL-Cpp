/*
 *                LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by Rob Tillaart
 *  URL: https://github.com/RobTillaart/TCA9554
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by Rob Tillaart
 *
 */

#include "TCA9554.h"

/////////////////////////////////////////////////////////////////////////////////////

static const char *_TAG = "[TCA9554]";
static const uint8_t TCA9554_ADDRESS            = 0x20;

/////////////////////////////////////////////////////////////////////////////////////

TCA9554::TCA9554() :
	m_Address(TCA9554_ADDRESS)  // default for A0:high, A1 & A2 low - 0x21
{
}

/////////////////////////////////////////////////////////////////////////////////////

bool TCA9554::Initialise(i2c_master_bus_handle_t hi2cBus, uint8_t Mode/*= TCA9554_INPUT*/, uint8_t Mask /*= 0x00*/)
{
i2c_device_config_t i2cDeviceCfg;

  if(hi2cBus == nullptr){
  	ESP_LOGE(_TAG, "The TCA9554 object requires an i2c port");
    return false;
  }
  memset(&i2cDeviceCfg, 0, sizeof(i2c_device_config_t));
  i2cDeviceCfg.dev_addr_length = I2C_ADDR_BIT_LEN_7;
  i2cDeviceCfg.device_address = m_Address;
  i2cDeviceCfg.scl_speed_hz = 400 * 1000;
  i2c_master_bus_add_device(hi2cBus, &i2cDeviceCfg, &m_hDevice);
  if(!IsConnected()) return false;
  if(Mode == TCA9554_OUTPUT){
    PinMode8(0x00);
    Write8(Mask);
  } 
  else PinMode8(0xFF);
  return true;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t TCA9554::Write(uint8_t Register, uint8_t Value)
{
uint8_t Buffer[2] = {Register, Value };

  return i2c_master_transmit(m_hDevice, Buffer, 2, -1);
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t TCA9554::Read(uint8_t Register, uint8_t *pValue)
{
  return i2c_master_transmit_receive(m_hDevice, &Register, 1, pValue, 1, -1);
}

/////////////////////////////////////////////////////////////////////////////////////

bool TCA9554::IsConnected()
{
uint8_t Buffer;

  return (Read(TCA9554_INPUT_REGISTER, &Buffer) == ESP_OK);
}

/////////////////////////////////////////////////////////////////////////////////////

bool TCA9554::PinMode1(uint8_t Pin, bool Input)
{
uint8_t Reg;

  if(Pin > 7) return false;
  Read(TCA9554_CONFIGURATION_PORT, &Reg);
  uint8_t Modified = Reg;
  uint8_t Mask = 1 << Pin;
  if(Input) Modified |= Mask;
  else Modified &= ~Mask;
  if(Reg != Modified) return Write(TCA9554_CONFIGURATION_PORT, Modified);
  return true;
}

/////////////////////////////////////////////////////////////////////////////////////

bool TCA9554::Write1(uint8_t Pin, uint8_t Value)
{
uint8_t Reg;

  if(Pin > 7) return false;
  Read(TCA9554_OUTPUT_REGISTER, &Reg);
  uint8_t Modified = Reg;
  uint8_t Mask = 1 << Pin;
  if(Value) Modified |= Mask;  //  all values are HIGH.
  else Modified &= ~Mask;
  if(Reg != Modified) return (Write(TCA9554_OUTPUT_REGISTER, Modified) == ESP_OK);
  return true;
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t TCA9554::Read1(uint8_t Pin)
{
uint8_t Value;

  if(Pin > 7) return TCA9554_INVALID;
  Read(TCA9554_INPUT_REGISTER, &Value);
  uint8_t Mask = 1 << Pin;
  if(Value & Mask) return TCA9554_HIGH;
  return TCA9554_LOW;
}

/////////////////////////////////////////////////////////////////////////////////////

bool TCA9554::SetPolarity(uint8_t Pin, uint8_t Value)
{
uint8_t Reg;

  if(Pin > 7) return false;
  Read(TCA9554_POLARITY_REGISTER, &Reg);
  uint8_t Modified = Reg;
  uint8_t Mask = 1 << Pin;
  if(Value > 0) Modified |= Mask;
  else Modified &= ~Mask;
  if(Reg != Modified) return (Write(TCA9554_POLARITY_REGISTER, Modified) == ESP_OK);
  return true;
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t TCA9554::GetPolarity(uint8_t Pin)
{
uint8_t Mask;

  if(Pin > 7) return false;
  Read(TCA9554_POLARITY_REGISTER, &Mask);
  return (Mask >> Pin) == 0x01;
}

/////////////////////////////////////////////////////////////////////////////////////

bool TCA9554::PinMode8(uint8_t Value)
{
  return Write(TCA9554_CONFIGURATION_PORT, Value);
}

/////////////////////////////////////////////////////////////////////////////////////

bool TCA9554::Write8(uint8_t Value)
{
  return (Write(TCA9554_OUTPUT_REGISTER, Value) == ESP_OK);
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t TCA9554::Read8()
{
uint8_t Value;

  Read(TCA9554_INPUT_REGISTER, &Value);
  return Value;
}

/////////////////////////////////////////////////////////////////////////////////////

bool TCA9554::SetPolarity8(uint8_t Mask)
{
  return (Write(TCA9554_POLARITY_REGISTER, Mask) == ESP_OK);
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t TCA9554::GetPolarity8()
{
uint8_t Value;

  Read(TCA9554_POLARITY_REGISTER, &Value);
  return Value;
}


