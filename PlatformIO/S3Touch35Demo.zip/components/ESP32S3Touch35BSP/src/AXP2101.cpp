/*
 *                LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by Lewis He (lewishe@outlook.com)
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by Rob Tillaart
 *
 */

#include "AXP2101.h"

/////////////////////////////////////////////////////////////////////////////////////

bool pmu_flag = 0;

const uint8_t i2c_sda = CONFIG_PMU_SDA;
const uint8_t i2c_scl = CONFIG_PMU_SCL;
const uint8_t pmu_irq_pin = CONFIG_PMU_IRQ;


static const char *_TAG = "[AXP2101]";

static const char *pSleepStr[] = {
		"ESP_SLEEP_WAKEUP_EXT0",
		"ESP_SLEEP_WAKEUP_EXT1",
		"ESP_SLEEP_WAKEUP_TIMER",
		"ESP_SLEEP_WAKEUP_TOUCHPAD",
		"ESP_SLEEP_WAKEUP_ULP",
		"ESP_SLEEP_WAKEUP_GPIO",
		"ESP_SLEEP_WAKEUP_UART",
		"WAKEUP_UNKNOWN_REASON"
	};
  
static const char *pResetStr[] = {
  "ESP_RST_UNKNOWN",
	"ESP_RST_POWERON",
	"ESP_RST_SW",
	"ESP_RST_PANIC",
	"ESP_RST_INT_WDT",
	"ESP_RST_TASK_WDT",
	"ESP_RST_WDT",
	"ESP_RST_BROWNOUT",
	"ESP_RST_SDIO",
  "RESET_UNKNOWN_REASON"
};

static const char *pPowerDownStr = "voltage power dowm:";
static const char *pPowerKeyStr[] = {"Power key press off time: ", "Power key press on time: "};

/////////////////////////////////////////////////////////////////////////////////////

AXP2101::AXP2101(void) : m_PinIRQ(GPIO_NUM_NC)
{
}

/////////////////////////////////////////////////////////////////////////////////////

AXP2101::~AXP2101(void)
{
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::Initialise(i2c_master_bus_handle_t hi2cBus)
{
i2c_device_config_t i2c_dev_conf;

  if(hi2cBus == nullptr){
  	ESP_LOGE(_TAG, "The AXP2101 object requires an i2c port");
    return false;
  }

  memset(&i2c_dev_conf, 0, sizeof(i2c_device_config_t));
  i2c_dev_conf.dev_addr_length = I2C_ADDR_BIT_LEN_7;
  i2c_dev_conf.device_address = AXP2101_SLAVE_ADDRESS;
  i2c_dev_conf.scl_speed_hz = 400 * 1000;
  i2c_master_bus_add_device(hi2cBus, &i2c_dev_conf, &m_hDevice);

  ESP_LOGI(_TAG, "ID:0x%x", GetChipID());

	// Set the minimum common working voltage of the PMU VBUS input,
	// below this value will turn off the PMU
	SetVbusVoltageLimit(AXP2101_VBUS_VOL_LIM_4V36);

	// Set the maximum current of the PMU VBUS input,
	// higher than this value will turn off the PMU
	SetVbusCurrentLimit(AXP2101_VBUS_CUR_LIM_1500MA);
	SetSysPowerDownVoltage(2600); 	// Set VSYS off voltage as 2600mV , Adjustment range 2600mV ~ 3300mV
	uint16_t Voltage = GetSysPowerDownVoltage();
	ESP_LOGI(_TAG, "Power down voltage: %u", Voltage);

  // DC1 IMAX = 2A
	// 1500~3400mV,100mV/step,20steps
	SetDC1Voltage(3300);

	// DC2 IMAX = 2A
	// 500~1200mV  10mV/step,71steps
	// 1220~1540mV 20mV/step,17steps
	SetDC2Voltage(1000);

	// DC3 IMAX = 2A
	// 500~1200mV,10mV/step,71steps
	// 1220~1540mV,20mV/step,17steps
	// 1600~3400mV,100mV/step,19steps
	SetDC3Voltage(3300);

	// DCDC4 IMAX = 1.5A
	// 500~1200mV,10mV/step,71steps
	// 1220~1840mV,20mV/step,32steps
	SetDC4Voltage(1000);

	// DC5 IMAX = 2A
	// 1200mV
	// 1400~3700mV,100mV/step,24steps
	SetDC5Voltage(3300);

	//ALDO1 IMAX = 300mA
	//500~3500mV, 100mV/step,31steps
	SetALDO1Voltage(3300);

	//ALDO2 IMAX = 300mA
	//500~3500mV, 100mV/step,31steps
	SetALDO2Voltage(3300);

	//ALDO3 IMAX = 300mA
	//500~3500mV, 100mV/step,31steps
	// SetALDO3Voltage(3300);

	//ALDO4 IMAX = 300mA
	//500~3500mV, 100mV/step,31steps
	SetALDO4Voltage(3300);

	//BLDO1 IMAX = 300mA
	//500~3500mV, 100mV/step,31steps
	SetBLDO1Voltage(3300);

	//BLDO2 IMAX = 300mA
	//500~3500mV, 100mV/step,31steps
	SetBLDO2Voltage(3300);

	//CPUSLDO IMAX = 30mA
	//500~1400mV,50mV/step,19steps
	SetCPUSLDOVoltage(1000);

	//DLDO1 IMAX = 300mA
	//500~3400mV, 100mV/step,29steps
	SetDLDO1Voltage(3300);

	//DLDO2 IMAX = 300mA
	//500~1400mV, 50mV/step,2steps
	SetDLDO2Voltage(3300);
	// EnableDC1();
	EnableDC2();
	EnableDC3();
	EnableDC4();
	EnableDC5();
	EnableALDO1();
	EnableALDO2();
	// EnableALDO3(); // This is the speaker
	EnableALDO4();
	EnableBLDO1();
	EnableBLDO2();
	EnableCPUSLDO();
	// EnableDLDO1(); // This is the vibration motor
	// EnableDLDO2();
  ESP_LOGI(_TAG, "\nDCDC ======================================================================");
	ESP_LOGI(_TAG, "DC1  : %s   Voltage:%u mV", IsEnabledDC1() ? "+" : "-", GetDC1Voltage());
	ESP_LOGI(_TAG, "DC2  : %s   Voltage:%u mV", IsEnabledDC2() ? "+" : "-", GetDC2Voltage());
	ESP_LOGI(_TAG, "DC3  : %s   Voltage:%u mV", IsEnabledDC3() ? "+" : "-", GetDC3Voltage());
	ESP_LOGI(_TAG, "DC4  : %s   Voltage:%u mV", IsEnabledDC4() ? "+" : "-", GetDC4Voltage());
	ESP_LOGI(_TAG, "DC5  : %s   Voltage:%u mV", IsEnabledDC5() ? "+" : "-", GetDC5Voltage());
  ESP_LOGI(_TAG, "\nALDO ======================================================================");
	ESP_LOGI(_TAG, "ALDO1: %s   Voltage:%u mV", IsEnabledALDO1() ? "+" : "-", GetALDO1Voltage());
	ESP_LOGI(_TAG, "ALDO2: %s   Voltage:%u mV", IsEnabledALDO2() ? "+" : "-", GetALDO2Voltage());
	ESP_LOGI(_TAG, "ALDO3: %s   Voltage:%u mV", IsEnabledALDO3() ? "+" : "-", GetALDO3Voltage());
	ESP_LOGI(_TAG, "ALDO4: %s   Voltage:%u mV", IsEnabledALDO4() ? "+" : "-", GetALDO4Voltage());
  ESP_LOGI(_TAG, "\nBLDO ======================================================================");
	ESP_LOGI(_TAG, "BLDO1: %s   Voltage:%u mV", IsEnabledBLDO1() ? "+" : "-", GetBLDO1Voltage());
	ESP_LOGI(_TAG, "BLDO2: %s   Voltage:%u mV", IsEnabledBLDO2() ? "+" : "-", GetBLDO2Voltage());
  ESP_LOGI(_TAG, "\nCLDO ======================================================================");
	ESP_LOGI(_TAG, "CPUSLDO: %s Voltage:%u mV", IsEnabledCPUSLDO() ? "+" : "-", GetCPUSLDOVoltage());
  ESP_LOGI(_TAG, "\nDLDO ======================================================================");
	ESP_LOGI(_TAG, "DLDO1: %s   Voltage:%u mV", IsEnabledDLDO1() ? "+" : "-", GetDLDO1Voltage());
	ESP_LOGI(_TAG, "DLDO2: %s   Voltage:%u mV\n", IsEnabledDLDO2() ? "+" : "-", GetDLDO2Voltage());

	SetPowerKeyPressOffTime(AXP2101_POWEROFF_4S);	// Set the time of pressing the button to turn off
	uint8_t Option = GetPowerKeyPressOffTime();
	switch(Option) {
		case AXP2101_POWEROFF_4S:
			ESP_LOGI(_TAG, "%s%s", pPowerKeyStr[0], "4 Second");
			break;
		case AXP2101_POWEROFF_6S:
			ESP_LOGI(_TAG, "%s%s", pPowerKeyStr[0], "6 Second");
			break;
		case AXP2101_POWEROFF_8S:
			ESP_LOGI(_TAG, "%s%s", pPowerKeyStr[0], "8 Second");
			break;
		case AXP2101_POWEROFF_10S:
			ESP_LOGI(_TAG, "%s%s", pPowerKeyStr[0], "10 Second");
			break;
		default:
			break;
	}
	SetPowerKeyPressOnTime(AXP2101_POWERON_128MS);	// Set the button power-on press time
	Option = GetPowerKeyPressOnTime();
	switch(Option) {
		case AXP2101_POWERON_128MS:
			ESP_LOGI(_TAG, "%s%s", pPowerKeyStr[1], "128 Ms");
			break;
		case AXP2101_POWERON_512MS:
			ESP_LOGI(_TAG, "%s%s", pPowerKeyStr[1], "512 Ms");
			break;
		case AXP2101_POWERON_1S:
			ESP_LOGI(_TAG, "%s%s", pPowerKeyStr[1], "1 Second");
			break;
		case AXP2101_POWERON_2S:
			ESP_LOGI(_TAG, "%s%s", pPowerKeyStr[1], "2 Second");
			break;
		default:
			break;
	}
  ESP_LOGI(_TAG, "\n===========================================================================");
	bool en = GetDCHighVoltagePowerDownEn();	// DCDC 120%(130%) high voltage turn off PMIC function
	ESP_LOGI(_TAG, "DC high %s %s", pPowerDownStr, en ? "ENABLE" : "DISABLE");
	en = GetDC1LowVoltagePowerDownEn();	// DCDC1 85% low voltage turn off PMIC function
	ESP_LOGI(_TAG, "DC1 low %s %s", pPowerDownStr, en ? "ENABLE" : "DISABLE");
	en = GetDC2LowVoltagePowerDownEn();	// DCDC2 85% low voltage turn off PMIC function
	ESP_LOGI(_TAG, "DC2 low %s %s", pPowerDownStr, en ? "ENABLE" : "DISABLE");
	en = GetDC3LowVoltagePowerDownEn();	// DCDC3 85% low voltage turn off PMIC function
	ESP_LOGI(_TAG, "DC3 low %s %s", pPowerDownStr, en ? "ENABLE" : "DISABLE");
	en = GetDC4LowVoltagePowerDownEn();	// DCDC4 85% low voltage turn off PMIC function
	ESP_LOGI(_TAG, "DC4 low %s %s", pPowerDownStr, en ? "ENABLE" : "DISABLE");
	en = GetDC5LowVoltagePowerDownEn();	// DCDC5 85% low voltage turn off PMIC function
	ESP_LOGI(_TAG, "DC5 low %s %s", pPowerDownStr, en ? "ENABLE" : "DISABLE");
	// SetDCHighVoltagePowerDowm(true);
	// SetDC1LowVoltagePowerDowm(true);
	// SetDC2LowVoltagePowerDowm(true);
	// SetDC3LowVoltagePowerDowm(true);
	// SetDC4LowVoltagePowerDowm(true);
	// SetDC5LowVoltagePowerDowm(true);
	// It is necessary to disable the detection function of the TS pin on the board
	// without the battery temperature detection function, otherwise it will cause abnormal charging
	DisableTSPinMeasure();
//	EnableTemperatureMeasure();
	EnableBattDetection();	// Enable internal ADC detection
	EnableVbusVoltageMeasure();
	EnableBattVoltageMeasure();
	EnableSystemVoltageMeasure();
	SetChargingLEDMode(AXP2101_CHG_LED_OFF);
	if(m_PinIRQ != GPIO_NUM_NC){
    gpio_set_pull_mode(m_PinIRQ, GPIO_PULLUP_ONLY);  // Force add pull-up
	  gpio_set_intr_type(m_PinIRQ, GPIO_INTR_NEGEDGE);
  }
	DisableIRQ(AXP2101_ALL_IRQ);	// Disable all interrupts
	ClearIRQStatus();	// Clear all interrupt flags
	// Enable the required interrupt function
	EnableIRQ(AXP2101_BAT_INSERT_IRQ | AXP2101_BAT_REMOVE_IRQ |     //BATTERY
		        AXP2101_VBUS_INSERT_IRQ | AXP2101_VBUS_REMOVE_IRQ |   //VBUS
		        AXP2101_PKEY_SHORT_IRQ | AXP2101_PKEY_LONG_IRQ |      //POWER KEY
		        AXP2101_BAT_CHG_DONE_IRQ | AXP2101_BAT_CHG_START_IRQ  //CHARGE
//            AXP2101_PKEY_NEGATIVE_IRQ | AXP2101_PKEY_POSITIVE_IRQ   |   //POWER KEY
	);
	SetPrechargeCurr(AXP2101_PRECHARGE_50MA);	          // Set the precharge charging current
	SetChargerConstantCurr(AXP2101_CHG_CUR_200MA);	    // Set constant current charge current limit
	SetChargerTerminationCurr(AXP2101_CHG_ITERM_25MA);	// Set stop charging termination current
	SetChargeTargetVoltage(AXP2101_CHG_VOL_4V1);	      // Set charge cut-off voltage
	SetWatchdogConfig(AXP2101_WDT_IRQ_TO_PIN);	        // Set the watchdog trigger event type
	SetWatchdogTimeout(AXP2101_WDT_TIMEOUT_4S);	        // Set watchdog timeout
	EnableWatchdog();	                                  // Enable watchdog to trigger interrupt event
	// DisableWatchdog();
	EnableButtonBatteryCharge();	                      // Enable Button Battery charge
	SetButtonBatteryChargeVoltage(3300);	              // Set Button Battery charge voltage
  return true;
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::Status(void)
{
	uint16_t Status1 = ReadRegister(AXP2101_STATUS1) & 0x1F;
	uint16_t Status2 = ReadRegister(AXP2101_STATUS2) & 0x1F;
	return (Status1 << 8) | (Status2);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::Update()
{
  float vbat = GetBattVoltage();
  ESP_LOGD(_TAG, "Got Battery Voltage %f", vbat);

  // The battery percentage may be inaccurate at first use, the PMU will automatically
  // learn the battery curve and will automatically calibrate the battery percentage
  // after a charge and discharge cycle
  float batterylevel;
  if(IsBatteryConnect()) batterylevel = GetBatteryPercent();
  else batterylevel = 100.0 * ((vbat - 3.0) / (4.1 - 3.0));
  ESP_LOGD(_TAG, "Got Battery Level %f", batterylevel);
  if(batterylevel > 100.) batterylevel = 100;
	bool vcharging = IsCharging();
  ESP_LOGD(_TAG, "Got Battery Charging=%s", vcharging ? "true" : "false");
	UpdateBrightness();
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::UpdateBrightness()
{
	if(m_Brightness == m_CurrentBrightness) return;
	ESP_LOGD(_TAG, "Brightness = %f (Curr: %f)", m_Brightness, m_CurrentBrightness);
	m_CurrentBrightness = m_Brightness;
	const uint8_t c_min = 7;
	const uint8_t c_max = 12;
	auto ubri = c_min + static_cast<uint8_t>(m_Brightness * (c_max - c_min));
	if(ubri > c_max) ubri = c_max;
// ADJUST THE BRIGHTNESS
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::GetBatState()
{
	if(Read8bit(0x01) | 0x20)	return true;
	else return false;
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t AXP2101::GetBatData()
{
	return Read8bit(0x75);
}


/////////////////////////////////////////////////////////////////////////////////////

//---------coulombcounter_from_here---------
//enable: void EnableCoulombcounter(void);
//disable: void DisableCOulombcounter(void);
//stop: void StopCoulombcounter(void);
//clear: void ClearCoulombcounter(void);
//get charge data: uint32_t GetCoulombchargeData(void);
//get discharge data: uint32_t GetCoulombdischargeData(void);
//get coulomb val affter calculation: float GetCoulombData(void);
//------------------------------------------
void AXP2101::EnableCoulombcounter(void)
{
	Write1Byte(0xB8, 0x80);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisableCoulombcounter(void)
{
	Write1Byte(0xB8, 0x00);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::StopCoulombcounter(void)
{
	Write1Byte(0xB8, 0xC0);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::ClearCoulombcounter(void)
{
	Write1Byte(0xB8, 0xA0);
}

/////////////////////////////////////////////////////////////////////////////////////

uint32_t AXP2101::GetCoulombchargeData(void)
{
	return Read32bit(0xB0);
}

/////////////////////////////////////////////////////////////////////////////////////

uint32_t AXP2101::GetCoulombdischargeData(void)
{
	return Read32bit(0xB4);
}

/////////////////////////////////////////////////////////////////////////////////////

float AXP2101::GetCoulombData(void)
{
	uint32_t coin = GetCoulombchargeData();
	uint32_t coout = GetCoulombdischargeData();

	//c = 65536 * current_LSB * (coin - coout) / 3600 / ADC rate
	//Adc rate can be read from 84H ,change this variable if you change the ADC reate
	float ccc = 65536 * 0.5 * (coin - coout) / 3600.0 / 25.0;
	return ccc;
}
//----------coulomb_end_at_here----------

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetVbatData(void)
{
	uint16_t vbat = 0;
	uint8_t buf[2];
	ReadBuffer(0x78, 2, buf);
	vbat = ((buf[0] << 4) + buf[1]);  // V
	return vbat;
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetVinData(void)
{
	uint16_t vin = 0;
	uint8_t buf[2];
	ReadBuffer(0x56, 2, buf);
	vin = ((buf[0] << 4) + buf[1]);  // V
	return vin;
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetIinData(void)
{
	uint16_t iin = 0;
	uint8_t buf[2];
	ReadBuffer(0x58, 2, buf);
	iin = ((buf[0] << 4) + buf[1]);
	return iin;
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetVusbinData(void)
{
	uint16_t vin = 0;
	uint8_t buf[2];
	ReadBuffer(0x5a, 2, buf);
	vin = ((buf[0] << 4) + buf[1]);  // V
	return vin;
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetIusbinData(void)
{
	uint16_t iin = 0;
	uint8_t buf[2];
	ReadBuffer(0x5C, 2, buf);
	iin = ((buf[0] << 4) + buf[1]);
	return iin;
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetIchargeData(void)
{
	uint16_t icharge = 0;
	uint8_t buf[2];
	ReadBuffer(0x7A, 2, buf);
	icharge = (buf[0] << 5) + buf[1];
	return icharge;
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetIdischargeData(void)
{
	uint16_t idischarge = 0;
	uint8_t buf[2];
	ReadBuffer(0x7C, 2, buf);
	idischarge = (buf[0] << 5) + buf[1];
	return idischarge;
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetTempData(void)
{
	uint16_t temp = 0;
	uint8_t buf[2];
	ReadBuffer(0x5e, 2, buf);
	temp = ((buf[0] << 4) + buf[1]);
	return temp;
}

/////////////////////////////////////////////////////////////////////////////////////

uint32_t AXP2101::GetPowerbatData(void)
{
	uint32_t power = 0;
	uint8_t buf[3];
	ReadBuffer(0x70, 2, buf);
	power = (buf[0] << 16) + (buf[1] << 8) + buf[2];
	return power;
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetVapsData(void)
{
	uint16_t vaps = 0;
	uint8_t buf[2];
	ReadBuffer(0x7e, 2, buf);
	vaps = ((buf[0] << 4) + buf[1]);
	return vaps;
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetSleep(void)
{
	Write1Byte(0x31, Read8bit(0x31) | (1 << 3));  // Power off voltag 3.0v
	Write1Byte(0x90, Read8bit(0x90) | 0x07);      // GPIO1 floating
	Write1Byte(0x82, 0x00);                       // Disable ADCs
	Write1Byte(0x12, Read8bit(0x12) & 0xA1);      // Disable all outputs but DCDC1
}

/////////////////////////////////////////////////////////////////////////////////////

// -- sleep
void AXP2101::DeepSleep(uint64_t time_in_us)
{
	SetSleep();
	esp_sleep_enable_ext0_wakeup((gpio_num_t)37, 0 /* LOW */);
	if(time_in_us > 0) esp_sleep_enable_timer_wakeup(time_in_us);
	else esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_TIMER);
	(time_in_us == 0) ? esp_deep_sleep_start() : esp_deep_sleep(time_in_us);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::LightSleep(uint64_t time_in_us)
{
	if(time_in_us > 0) esp_sleep_enable_timer_wakeup(time_in_us);
	else esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_TIMER);
	esp_light_sleep_start();
}

/////////////////////////////////////////////////////////////////////////////////////

// 0 not press, 0x01 long press, 0x02 press
uint8_t AXP2101::GetBtnPress()
{
	uint8_t state = Read8bit(0x46);
	if(state) Write1Byte(0x46, 0x03);
	return state;
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t AXP2101::GetWarningLevel(void)
{
	return Read8bit(0x47) & 0x01;
}

/////////////////////////////////////////////////////////////////////////////////////

float AXP2101::GetBatCurrent()
{
	float ADCLSB = 0.5;
	uint16_t CurrentIn = Read13Bit(0x7A);
	uint16_t CurrentOut = Read13Bit(0x7C);
	return (CurrentIn - CurrentOut) * ADCLSB;
}

/////////////////////////////////////////////////////////////////////////////////////

float AXP2101::GetVinVoltage()
{
	float ADCLSB = 1.7 / 1000.0;
	uint16_t ReData = Read12Bit(0x56);
	return ReData * ADCLSB;
}

/////////////////////////////////////////////////////////////////////////////////////

float AXP2101::GetVinCurrent()
{
	float ADCLSB = 0.625;
	uint16_t ReData = Read12Bit(0x58);
	return ReData * ADCLSB;
}

/////////////////////////////////////////////////////////////////////////////////////

float AXP2101::GetVBusVoltage()
{
	float ADCLSB = 1.7 / 1000.0;
	uint16_t ReData = Read12Bit(0x5A);
	return ReData * ADCLSB;
}

/////////////////////////////////////////////////////////////////////////////////////

float AXP2101::GetVBusCurrent()
{
	float ADCLSB = 0.375;
	uint16_t ReData = Read12Bit(0x5C);
	return ReData * ADCLSB;
}

/////////////////////////////////////////////////////////////////////////////////////

float AXP2101::GetTempInAXP2101()
{
	float ADCLSB = 0.1;
	const float OFFSET_DEG_C = -144.7;
	uint16_t ReData = Read12Bit(0x5E);
	return OFFSET_DEG_C + ReData * ADCLSB;
}

/////////////////////////////////////////////////////////////////////////////////////

float AXP2101::GetBatPower()
{
	float VoltageLSB = 1.1;
	float CurrentLCS = 0.5;
	uint32_t ReData = Read24bit(0x70);
	return VoltageLSB * CurrentLCS * ReData / 1000.0;
}

/////////////////////////////////////////////////////////////////////////////////////

float AXP2101::GetBatChargeCurrent()
{
	float ADCLSB = 0.5;
	uint16_t ReData = Read13Bit(0x7A);
	return ReData * ADCLSB;
}

/////////////////////////////////////////////////////////////////////////////////////

float AXP2101::GetAPSVoltage()
{
	float ADCLSB = 1.4 / 1000.0;
	uint16_t ReData = Read12Bit(0x7E);
	return ReData * ADCLSB;
}

/////////////////////////////////////////////////////////////////////////////////////

float AXP2101::GetBatCoulombInput()
{
	uint32_t ReData = Read32bit(0xB0);
	return ReData * 65536 * 0.5 / 3600 / 25.0;
}

/////////////////////////////////////////////////////////////////////////////////////

float AXP2101::GetBatCoulombOut()
{
	uint32_t ReData = Read32bit(0xB4);
	return ReData * 65536 * 0.5 / 3600 / 25.0;
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetCoulombClear()
{
	Write1Byte(0xB8, 0x20);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetLDO2(bool State)
{
	uint8_t buf = Read8bit(0x12);
	if(State == true) buf = (1 << 2) | buf;
	else buf = ~(1 << 2) & buf;
	Write1Byte(0x12, buf);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetLDO3(bool State)
{
	uint8_t buf = Read8bit(0x12);
	if(State == true) buf = (1 << 3) | buf;
	else buf = ~(1 << 3) & buf;
	Write1Byte(0x12, buf);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetChargeCurrent(uint8_t current)
{
	uint8_t buf = Read8bit(0x33);
	buf = (buf & 0xf0) | (current & 0x07);
	Write1Byte(0x33, buf);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::PowerOff()
{
	Write1Byte(0x32, Read8bit(0x32) | 0x80);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetAdcState(bool state)
{
	Write1Byte(0x82, state ? 0xff : 0x00);
}

/////////////////////////////////////////////////////////////////////////////////////

const char* AXP2101::GetStartupReason(void)
{
	esp_reset_reason_t reset_reason = ::esp_reset_reason();
	if(reset_reason == ESP_RST_DEEPSLEEP) {
//		esp_sleep_source_t wake_reason = esp_sleep_get_wakeup_cause();
		uint32_t wake_reason = esp_sleep_get_wakeup_causes();
		if(wake_reason == ESP_SLEEP_WAKEUP_EXT0) return pSleepStr[0];
		if(wake_reason == ESP_SLEEP_WAKEUP_EXT1) return pSleepStr[1];
		if(wake_reason == ESP_SLEEP_WAKEUP_TIMER)	return pSleepStr[2];
		if(wake_reason == ESP_SLEEP_WAKEUP_TOUCHPAD) return pSleepStr[3];
		if(wake_reason == ESP_SLEEP_WAKEUP_ULP)	return pSleepStr[4];
		if(wake_reason == ESP_SLEEP_WAKEUP_GPIO) return pSleepStr[5];
		if(wake_reason == ESP_SLEEP_WAKEUP_UART) return pSleepStr[6];
		return pSleepStr[7];
	}
	if(reset_reason == ESP_RST_UNKNOWN)	return pResetStr[0];
	if(reset_reason == ESP_RST_POWERON)	return pResetStr[1];
	if(reset_reason == ESP_RST_SW) return pResetStr[2];
	if(reset_reason == ESP_RST_PANIC) return pResetStr[3];
	if(reset_reason == ESP_RST_INT_WDT)	return pResetStr[4];
	if(reset_reason == ESP_RST_TASK_WDT) return pResetStr[5];
	if(reset_reason == ESP_RST_WDT)	return pResetStr[6];
	if(reset_reason == ESP_RST_BROWNOUT) return pResetStr[7];
	if(reset_reason == ESP_RST_SDIO) return pResetStr[8];
	return pResetStr[9];
}

/////////////////////////////////////////////////////////////////////////////////////

AXP2101_ChargeStatus_e AXP2101::GetChargerStatus(void)
{
	int val = ReadRegister(AXP2101_STATUS2);
	if(val == -1) return AXP2101_CHG_STOP_STATE;
	val &= 0x07;
	return (AXP2101_ChargeStatus_e)val;
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::EnableInternalDischarge(void)
{
	SetRegisterBit(AXP2101_COMMON_CONFIG, 5);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisableInternalDischarge(void)
{
	ClearRegisterBit(AXP2101_COMMON_CONFIG, 5);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::EnablePwrOkPinPullLow(void)
{
	SetRegisterBit(AXP2101_COMMON_CONFIG, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisablePwrOkPinPullLow(void)
{
	ClearRegisterBit(AXP2101_COMMON_CONFIG, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::EnablePwronShutPMIC(void)
{
	SetRegisterBit(AXP2101_COMMON_CONFIG, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisablePwronShutPMIC(void)
{
	ClearRegisterBit(AXP2101_COMMON_CONFIG, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::Reset(void)
{
	SetRegisterBit(AXP2101_COMMON_CONFIG, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::Shutdown(void)
{
	SetRegisterBit(AXP2101_COMMON_CONFIG, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

// datasheet v1.4 fixed
void AXP2101::EnableBATFET(void)
{
	SetRegisterBit(AXP2101_BATFET_CTRL, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisableBATFET(void)
{
	ClearRegisterBit(AXP2101_BATFET_CTRL, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetDieOverTempLevel1(uint8_t Option)
{
	int val = ReadRegister(AXP2101_DIE_TEMP_CTRL);
	if(val == -1) return;
	val &= 0xF9;
	WriteRegister(AXP2101_DIE_TEMP_CTRL, val | (Option << 1));
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t AXP2101::GetDieOverTempLevel1(void)
{
	return (ReadRegister(AXP2101_DIE_TEMP_CTRL) & 0x06);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::EnableDieOverTempDetect(void)
{
	SetRegisterBit(AXP2101_DIE_TEMP_CTRL, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisableDieOverTempDetect(void)
{
	ClearRegisterBit(AXP2101_DIE_TEMP_CTRL, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

// Linear Charger Vsys voltage dpm
void AXP2101::SetLinearChargerVsysDpm(AXP2101_ChargeDPM_e Option)
{
	int val = ReadRegister(AXP2101_MIN_SYS_VOL_CTRL);
	if(val == -1) return;
	val &= 0x8F;
	WriteRegister(AXP2101_MIN_SYS_VOL_CTRL, val | (Option << 4));
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t AXP2101::GetLinearChargerVsysDpm(void)
{
	int val = ReadRegister(AXP2101_MIN_SYS_VOL_CTRL);
	if(val == -1) return 0;
	val &= 0x70;
	return (val & 0x70) >> 4;
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetVbusVoltageLimit(uint8_t Option)
{
	int val = ReadRegister(AXP2101_INPUT_VOL_LIMIT_CTRL);
	if(val == -1) return;
	val &= 0xF0;
	WriteRegister(AXP2101_INPUT_VOL_LIMIT_CTRL, val | (Option & 0x0F));
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t AXP2101::GetVbusVoltageLimit(void)
{
	return (ReadRegister(AXP2101_INPUT_VOL_LIMIT_CTRL) & 0x0F);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::SetVbusCurrentLimit(uint8_t Option)
{
	int val = ReadRegister(AXP2101_INPUT_CUR_LIMIT_CTRL);
	if(val == -1) return false;
	val &= 0xF8;
	return 0 == WriteRegister(AXP2101_INPUT_CUR_LIMIT_CTRL, val | (Option & 0x07));
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t AXP2101::GetVbusCurrentLimit(void)
{
	return (ReadRegister(AXP2101_INPUT_CUR_LIMIT_CTRL) & 0x07);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::WriteGaugeData(uint8_t *data, uint8_t len)
{
	if(len != 128 || data == NULL) return false;
	// Reset gauge first
	SetRegisterBit(AXP2101_RESET_FUEL_GAUGE, 2);
	ClearRegisterBit(AXP2101_RESET_FUEL_GAUGE, 2);
	// Enabled ROM register
	ClearRegisterBit(AXP2101_FUEL_GAUGE_CTRL, 0);
	SetRegisterBit(AXP2101_FUEL_GAUGE_CTRL, 0);
	// Write data to buffer
	for(uint8_t i = 0; i < 128; i++) {
		WriteRegister(AXP2101_BAT_PARAMS, data[i]);
	}
	// Reenable ROM register
	ClearRegisterBit(AXP2101_FUEL_GAUGE_CTRL, 0);
	SetRegisterBit(AXP2101_FUEL_GAUGE_CTRL, 0);

	return CompareGaugeData(data, len);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::CompareGaugeData(uint8_t *data, uint8_t len)
{
	if(len != 128 || data == NULL) return false;
	// Reset gauge to load new data
	uint8_t buffer[128];
	memset(buffer, 0, sizeof(buffer));
	// Reenable ROM register
	ClearRegisterBit(AXP2101_FUEL_GAUGE_CTRL, 0);
	SetRegisterBit(AXP2101_FUEL_GAUGE_CTRL, 0);
	for(uint8_t i = 0; i < 128; i++) {
		buffer[i] = ReadRegister(AXP2101_BAT_PARAMS);
	}
	// Disable ROM register
	ClearRegisterBit(AXP2101_FUEL_GAUGE_CTRL, 0);
	// Set data interface
	SetRegisterBit(AXP2101_FUEL_GAUGE_CTRL, 4);
	// Reset gauge
	SetRegisterBit(AXP2101_RESET_FUEL_GAUGE, 2);
	ClearRegisterBit(AXP2101_RESET_FUEL_GAUGE, 2);
	return memcmp(data, buffer, 128) == 0;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableButtonBatteryCharge(void)
{
	return SetRegisterBit(AXP2101_CHARGE_GAUGE_WDT_CTRL, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableButtonBatteryCharge(void)
{
	return ClearRegisterBit(AXP2101_CHARGE_GAUGE_WDT_CTRL, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsEnabledButtonBatteryCharge()
{
	return GetRegisterBit(AXP2101_CHARGE_GAUGE_WDT_CTRL, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

//Button battery charge termination voltage setting
bool AXP2101::SetButtonBatteryChargeVoltage(uint16_t millivolt)
{
	if(millivolt % AXP2101_BTN_VOL_STEPS) {
		ESP_LOGE(_TAG, "Button battery charging step voltage is %u mV", AXP2101_BTN_VOL_STEPS);
		return false;
	}
	if(millivolt < AXP2101_BTN_VOL_MIN) {
		ESP_LOGE(_TAG, "The minimum charge termination voltage of the coin cell battery is %u mV", AXP2101_BTN_VOL_MIN);
		return false;
	}
	else if(millivolt > AXP2101_BTN_VOL_MAX) {
		ESP_LOGE(_TAG, "The minimum charge termination voltage of the coin cell battery is %u mV", AXP2101_BTN_VOL_MAX);
		return false;
	}
	int val = ReadRegister(AXP2101_BTN_BAT_CHG_VOL_SET);
	if(val == -1) return 0;
	val &= 0xF8;
	val |= (millivolt - AXP2101_BTN_VOL_MIN) / AXP2101_BTN_VOL_STEPS;
	return 0 == WriteRegister(AXP2101_BTN_BAT_CHG_VOL_SET, val);
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetButtonBatteryVoltage(void)
{
	int val = ReadRegister(AXP2101_BTN_BAT_CHG_VOL_SET);
	if(val == -1) return 0;
	return (val & 0x07) * AXP2101_BTN_VOL_STEPS + AXP2101_BTN_VOL_MIN;
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::EnableCellbatteryCharge(void)
{
	SetRegisterBit(AXP2101_CHARGE_GAUGE_WDT_CTRL, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisableCellbatteryCharge(void)
{
	ClearRegisterBit(AXP2101_CHARGE_GAUGE_WDT_CTRL, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::EnableWatchdog(void)
{
	SetRegisterBit(AXP2101_CHARGE_GAUGE_WDT_CTRL, 0);
	EnableIRQ(AXP2101_WDT_EXPIRE_IRQ);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisableWatchdog(void)
{
	DisableIRQ(AXP2101_WDT_EXPIRE_IRQ);
	ClearRegisterBit(AXP2101_CHARGE_GAUGE_WDT_CTRL, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetWatchdogConfig(AXP2101_WatchDogConfig_e Option)
{
	int val = ReadRegister(AXP2101_WDT_CTRL);
	if(val == -1) return;
	val &= 0xCF;
	WriteRegister(AXP2101_WDT_CTRL, val | (Option << 4));
}

/////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////

uint8_t AXP2101::GetWatchConfig(void)
{
	return (ReadRegister(AXP2101_WDT_CTRL) & 0x30) >> 4;
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::ClearWatchdog(void)
{
	SetRegisterBit(AXP2101_WDT_CTRL, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetWatchdogTimeout(AXP2101_WatchDogTimeout_e Option)
{
	int val = ReadRegister(AXP2101_WDT_CTRL);
	if(val == -1) return;
	val &= 0xF8;
	WriteRegister(AXP2101_WDT_CTRL, val | Option);
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t AXP2101::GetWatchdogTimerout(void)
{
	return ReadRegister(AXP2101_WDT_CTRL) & 0x07;
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetLowBatWarnThreshold(uint8_t percentage)
{
	if(percentage < 5 || percentage > 20) return;
	int val = ReadRegister(AXP2101_LOW_BAT_WARN_SET);
	if(val == -1) return;
	val &= 0x0F;
	WriteRegister(AXP2101_LOW_BAT_WARN_SET, val | ((percentage - 5) << 4));
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t AXP2101::GetLowBatWarnThreshold(void)
{
	int val = ReadRegister(AXP2101_LOW_BAT_WARN_SET);
	if(val == -1) return 0;
	val &= 0xF0;
	val >>= 4;
	return val;
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetLowBatShutdownThreshold(uint8_t Option)
{
	if(Option > 15) {
		Option = 15;
	}
	int val = ReadRegister(AXP2101_LOW_BAT_WARN_SET);
	if(val == -1) return;
	val &= 0xF0;
	WriteRegister(AXP2101_LOW_BAT_WARN_SET, val | Option);
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t AXP2101::GetLowBatShutdownThreshold(void)
{
	return (ReadRegister(AXP2101_LOW_BAT_WARN_SET) & 0x0F);
}

/////////////////////////////////////////////////////////////////////////////////////

//!  PWRON statu  20
// POWERON always high when EN Mode as POWERON Source
bool AXP2101::IsPoweronAlwaysHighSource()
{
	return GetRegisterBit(AXP2101_PWRON_STATUS, 5);
}

/////////////////////////////////////////////////////////////////////////////////////

// Battery Insert and Good as POWERON Source
bool AXP2101::IsBattInsertOnSource()
{
	return GetRegisterBit(AXP2101_PWRON_STATUS, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

// Battery Voltage > 3.3V when Charged as Source
bool AXP2101::IsBattNormalOnSource()
{
	return GetRegisterBit(AXP2101_PWRON_STATUS, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

// Vbus Insert and Good as POWERON Source
bool AXP2101::IsVbusInsertOnSource()
{
	return GetRegisterBit(AXP2101_PWRON_STATUS, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

// IRQ PIN Pull-down as POWERON Source
bool AXP2101::IsIRQLowOnSource()
{
	return GetRegisterBit(AXP2101_PWRON_STATUS, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

// POWERON low for on level when POWERON Mode as POWERON Source
bool AXP2101::IsPwronLowOnSource()
{
	return GetRegisterBit(AXP2101_PWRON_STATUS, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

AXP2101_PowerOnSource_e AXP2101::GetPowerOnSource()
{
	int val = ReadRegister(AXP2101_PWRON_STATUS);
	if(val == -1) return AXP2101_POWERON_SRC_UNKONW;
	return (AXP2101_PowerOnSource_e)val;
}

/////////////////////////////////////////////////////////////////////////////////////

//!  PWROFF status  21
// Die Over Temperature as POWEROFF Source
bool AXP2101::IsOverTemperatureOffSource()
{
	return GetRegisterBit(AXP2101_PWROFF_STATUS, 7);
}

/////////////////////////////////////////////////////////////////////////////////////

// DCDC Over Voltage as POWEROFF Source
bool AXP2101::IsDcOverVoltageOffSource()
{
	return GetRegisterBit(AXP2101_PWROFF_STATUS, 6);
}

/////////////////////////////////////////////////////////////////////////////////////

// DCDC Under Voltage as POWEROFF Source
bool AXP2101::IsDcUnderVoltageOffSource()
{
	return GetRegisterBit(AXP2101_PWROFF_STATUS, 5);
}

/////////////////////////////////////////////////////////////////////////////////////

// VBUS Over Voltage as POWEROFF Source
bool AXP2101::IsVbusOverVoltageOffSource()
{
	return GetRegisterBit(AXP2101_PWROFF_STATUS, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

// Vsys Under Voltage as POWEROFF Source
bool AXP2101::IsVsysUnderVoltageOffSource()
{ 
	return GetRegisterBit(AXP2101_PWROFF_STATUS, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

// POWERON always low when EN Mode as POWEROFF Source
bool AXP2101::IsPwronAlwaysLowOffSource()
{
	return GetRegisterBit(AXP2101_PWROFF_STATUS, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

// Software configuration as POWEROFF Source
bool AXP2101::IsSwConfigOffSource()
{
	return GetRegisterBit(AXP2101_PWROFF_STATUS, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

// POWERON Pull down for off level when POWERON Mode as POWEROFF Source
bool AXP2101::IsPwrSourcePullDown()
{
	return GetRegisterBit(AXP2101_PWROFF_STATUS, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

AXP2101_PowerOffSource_e AXP2101::GetPowerOffSource()
{
	int val = ReadRegister(AXP2101_PWROFF_STATUS);
	if(val == -1) return AXP2101_POWEROFF_SRC_UNKONW;
	return (AXP2101_PowerOffSource_e)val;
}

/////////////////////////////////////////////////////////////////////////////////////

//!REG 22H
void AXP2101::EnableOverTemperatureLevel2PowerOff()
{
	SetRegisterBit(AXP2101_PWROFF_EN, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisableOverTemperaturePowerOff()
{
	ClearRegisterBit(AXP2101_PWROFF_EN, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

// CHANGE:  void enablePwrOnOverVolOffLevelPowerOff()
void AXP2101::EnableLongPressShutdown()
{
	SetRegisterBit(AXP2101_PWROFF_EN, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

// CHANGE:  void disablePwrOnOverVolOffLevelPowerOff()
void AXP2101::DisableLongPressShutdown()
{
	ClearRegisterBit(AXP2101_PWROFF_EN, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

//CHANGE: void enablePwrOffSelectFunction()
void AXP2101::SetLongPressRestart()
{
	SetRegisterBit(AXP2101_PWROFF_EN, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

//CHANGE: void disablePwrOffSelectFunction()
void AXP2101::SetLongPressPowerOFF()
{
	ClearRegisterBit(AXP2101_PWROFF_EN, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

//!REG 23H
// DCDC 120%(130%) high voltage turn off PMIC function
void AXP2101::EnableDCHighVoltageTurnOff()
{
	SetRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 5);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisableDCHighVoltageTurnOff()
{
	ClearRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 5);
}

/////////////////////////////////////////////////////////////////////////////////////

// DCDC5 85% low voltage turn Off PMIC function
void AXP2101::EnableDC5LowVoltageTurnOff()
{
	SetRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisableDC5LowVoltageTurnOff()
{
	ClearRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

// DCDC4 85% low voltage turn Off PMIC function
void AXP2101::EnableDC4LowVoltageTurnOff()
{
	SetRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisableDC4LowVoltageTurnOff()
{
	ClearRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

// DCDC3 85% low voltage turn Off PMIC function
void AXP2101::EnableDC3LowVoltageTurnOff()
{
	SetRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisableDC3LowVoltageTurnOff()
{
	ClearRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

// DCDC2 85% low voltage turn Off PMIC function
void AXP2101::EnableDC2LowVoltageTurnOff()
{
	SetRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisableDC2LowVoltageTurnOff()
{
	ClearRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

// DCDC1 85% low voltage turn Off PMIC function
void AXP2101::EnableDC1LowVoltageTurnOff()
{
	SetRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisableDC1LowVoltageTurnOff()
{
	ClearRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

// Set the minimum system operating voltage inside the PMU,
// below this value will shut down the PMU,Adjustment range 2600mV~3300mV
bool AXP2101::SetSysPowerDownVoltage(uint16_t millivolt)
{
	if(millivolt % AXP2101_VSYS_VOL_THRESHOLD_STEPS) {
		ESP_LOGE(_TAG, "The steps is must %u mV", AXP2101_VSYS_VOL_THRESHOLD_STEPS);
		return false;
	}
	if(millivolt < AXP2101_VSYS_VOL_THRESHOLD_MIN) {
		ESP_LOGE(_TAG, "The minimum settable voltage of VSYS is %u mV", AXP2101_VSYS_VOL_THRESHOLD_MIN);
		return false;
	}
	else if(millivolt > AXP2101_VSYS_VOL_THRESHOLD_MAX) {
		ESP_LOGE(_TAG, "The maximum settable voltage of VSYS is %u mV", AXP2101_VSYS_VOL_THRESHOLD_MAX);
		return false;
	}
	int val = ReadRegister(AXP2101_VOFF_SET);
	if(val == -1) return false;
	val &= 0xF8;
	return 0 == WriteRegister(AXP2101_VOFF_SET, val | ((millivolt - AXP2101_VSYS_VOL_THRESHOLD_MIN) / AXP2101_VSYS_VOL_THRESHOLD_STEPS));
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetSysPowerDownVoltage(void)
{
	int val = ReadRegister(AXP2101_VOFF_SET);
	if(val == -1) return false;
	return (val & 0x07) * AXP2101_VSYS_VOL_THRESHOLD_STEPS + AXP2101_VSYS_VOL_THRESHOLD_MIN;
}

/////////////////////////////////////////////////////////////////////////////////////

//  PWROK setting and PWROFF sequence control 25.
// Check the PWROK Pin enable after all dcdc/ldo output valid 128ms
void AXP2101::EnablePwrOk()
{
	SetRegisterBit(AXP2101_PWROK_SEQU_CTRL, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisablePwrOk()
{
	ClearRegisterBit(AXP2101_PWROK_SEQU_CTRL, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

// POWEROFF Delay 4ms after PWROK enable
void AXP2101::EnablePowerOffDelay()
{
	SetRegisterBit(AXP2101_PWROK_SEQU_CTRL, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

// POWEROFF Delay 4ms after PWROK disable
void AXP2101::DisablePowerOffDelay()
{
	ClearRegisterBit(AXP2101_PWROK_SEQU_CTRL, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

// POWEROFF Sequence Control the reverse of the Startup
void AXP2101::EnablePowerSequence()
{
	SetRegisterBit(AXP2101_PWROK_SEQU_CTRL, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

// POWEROFF Sequence Control at the same time
void AXP2101::DisablePowerSequence()
{
	ClearRegisterBit(AXP2101_PWROK_SEQU_CTRL, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

// Delay of PWROK after all power output good
bool AXP2101::SetPwrOkDelay(AXP2101_PowerOkDelay_e Option)
{
	int val = ReadRegister(AXP2101_PWROK_SEQU_CTRL);
	if(val == -1) return false;
	val &= 0xFC;
	return 0 == WriteRegister(AXP2101_PWROK_SEQU_CTRL, val | Option);
}

/////////////////////////////////////////////////////////////////////////////////////

AXP2101_PowerOkDelay_e AXP2101::GetPwrOkDelay()
{
	int val = ReadRegister(AXP2101_PWROK_SEQU_CTRL);
	if(val == -1) return AXP2101_PWROK_DELAY_8MS;
	return (AXP2101_PowerOkDelay_e)(val & 0x03);
}

/////////////////////////////////////////////////////////////////////////////////////

//  Sleep and 26
void AXP2101::WakeupControl(AXP2101_Wakeup_e Option, bool Enable)
{
	int val = ReadRegister(AXP2101_SLEEP_WAKEUP_CTRL);
	if(val == -1) return;
	Enable ? (val |= Option) : (val &= (~Option));
	WriteRegister(AXP2101_SLEEP_WAKEUP_CTRL, val);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableWakeup(void)
{
	return SetRegisterBit(AXP2101_SLEEP_WAKEUP_CTRL, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableWakeup(void)
{
	return ClearRegisterBit(AXP2101_SLEEP_WAKEUP_CTRL, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableSleep(void)
{
	return SetRegisterBit(AXP2101_SLEEP_WAKEUP_CTRL, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableSleep(void)
{
	return ClearRegisterBit(AXP2101_SLEEP_WAKEUP_CTRL, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

//  RQLEVEL/OFFLEVEL/ONLEVEL setting 27
void AXP2101::SetIRQLevel(uint8_t Option)
{
	int val = ReadRegister(AXP2101_IRQ_OFF_ON_LEVEL_CTRL);
	if(val == -1) return;
	val &= 0xFC;
	WriteRegister(AXP2101_IRQ_OFF_ON_LEVEL_CTRL, val | (Option << 4));
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetOffLevel(uint8_t Option)
{
	int val = ReadRegister(AXP2101_IRQ_OFF_ON_LEVEL_CTRL);
	if(val == -1) return;
	WriteRegister(AXP2101_IRQ_OFF_ON_LEVEL_CTRL, val | (Option << 2));
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetOnLevel(uint8_t Option)
{
	int val = ReadRegister(AXP2101_IRQ_OFF_ON_LEVEL_CTRL);
	if(val == -1) return;
	WriteRegister(AXP2101_IRQ_OFF_ON_LEVEL_CTRL, val | Option);
}

/////////////////////////////////////////////////////////////////////////////////////

// Fast pwron setting 0  28
// Fast Power On Start Sequence
void AXP2101::SetDc4FastStartSequence(AXP2101_StartSequence_e Option)
{
	int val = ReadRegister(AXP2101_FAST_PWRON_SET0);
	if(val == -1) return;
	WriteRegister(AXP2101_FAST_PWRON_SET0, val | ((Option & 0x3) << 6));
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetDc3FastStartSequence(AXP2101_StartSequence_e Option)
{
	int val = ReadRegister(AXP2101_FAST_PWRON_SET0);
	if(val == -1) return;
	WriteRegister(AXP2101_FAST_PWRON_SET0, val | ((Option & 0x3) << 4));
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetDc2FastStartSequence(AXP2101_StartSequence_e Option)
{
	int val = ReadRegister(AXP2101_FAST_PWRON_SET0);
	if(val == -1) return;
	WriteRegister(AXP2101_FAST_PWRON_SET0, val | ((Option & 0x3) << 2));
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetDc1FastStartSequence(AXP2101_StartSequence_e Option)
{
	int val = ReadRegister(AXP2101_FAST_PWRON_SET0);
	if(val == -1) return;
	WriteRegister(AXP2101_FAST_PWRON_SET0, val | (Option & 0x3));
}

/////////////////////////////////////////////////////////////////////////////////////

//  Fast pwron setting 1  29
void AXP2101::SetAldo3FastStartSequence(AXP2101_StartSequence_e Option)
{
	int val = ReadRegister(AXP2101_FAST_PWRON_SET1);
	if(val == -1) return;
	WriteRegister(AXP2101_FAST_PWRON_SET1, val | ((Option & 0x3) << 6));
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetAldo2FastStartSequence(AXP2101_StartSequence_e Option)
{
	int val = ReadRegister(AXP2101_FAST_PWRON_SET1);
	if(val == -1) return;
	WriteRegister(AXP2101_FAST_PWRON_SET1, val | ((Option & 0x3) << 4));
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetAldo1FastStartSequence(AXP2101_StartSequence_e Option)
{
	int val = ReadRegister(AXP2101_FAST_PWRON_SET1);
	if(val == -1) return;
	WriteRegister(AXP2101_FAST_PWRON_SET1, val | ((Option & 0x3) << 2));
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetDc5FastStartSequence(AXP2101_StartSequence_e Option)
{
	int val = ReadRegister(AXP2101_FAST_PWRON_SET1);
	if(val == -1) return;
	WriteRegister(AXP2101_FAST_PWRON_SET1, val | (Option & 0x3));
}

/////////////////////////////////////////////////////////////////////////////////////

//  Fast pwron setting 2  2A
void AXP2101::SetCpuldoFastStartSequence(AXP2101_StartSequence_e Option)
{
	int val = ReadRegister(AXP2101_FAST_PWRON_SET2);
	if(val == -1) return;
	WriteRegister(AXP2101_FAST_PWRON_SET2, val | ((Option & 0x3) << 6));
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetBldo2FastStartSequence(AXP2101_StartSequence_e Option)
{
	int val = ReadRegister(AXP2101_FAST_PWRON_SET2);
	if(val == -1) return;
	WriteRegister(AXP2101_FAST_PWRON_SET2, val | ((Option & 0x3) << 4));
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetBldo1FastStartSequence(AXP2101_StartSequence_e Option)
{
	int val = ReadRegister(AXP2101_FAST_PWRON_SET2);
	if(val == -1) return;
	WriteRegister(AXP2101_FAST_PWRON_SET2, val | ((Option & 0x3) << 2));
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetAldo4FastStartSequence(AXP2101_StartSequence_e Option)
{
	int val = ReadRegister(AXP2101_FAST_PWRON_SET2);
	if(val == -1) return;
	WriteRegister(AXP2101_FAST_PWRON_SET2, val | (Option & 0x3));
}

/////////////////////////////////////////////////////////////////////////////////////

//  Fast pwron setting 3  2B
void AXP2101::SetDldo2FastStartSequence(AXP2101_StartSequence_e Option)
{
	int val = ReadRegister(AXP2101_FAST_PWRON_CTRL);
	if(val == -1) return;
	WriteRegister(AXP2101_FAST_PWRON_CTRL, val | ((Option & 0x3) << 2));
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetDldo1FastStartSequence(AXP2101_StartSequence_e Option)
{
	int val = ReadRegister(AXP2101_FAST_PWRON_CTRL);
	if(val == -1) return;
	WriteRegister(AXP2101_FAST_PWRON_CTRL, val | (Option & 0x3));
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetFastPowerOnLevel(AXP2101_FastOnOption_e Option, AXP2101_StartSequence_e seq_level)
{
	uint8_t val = 0;
	switch(Option) {
		case AXP2101_FAST_DCDC1:
			val = ReadRegister(AXP2101_FAST_PWRON_SET0);
			WriteRegister(AXP2101_FAST_PWRON_SET0, val | seq_level);
			break;
		case AXP2101_FAST_DCDC2:
			val = ReadRegister(AXP2101_FAST_PWRON_SET0);
			WriteRegister(AXP2101_FAST_PWRON_SET0, val | (seq_level << 2));
			break;
		case AXP2101_FAST_DCDC3:
			val = ReadRegister(AXP2101_FAST_PWRON_SET0);
			WriteRegister(AXP2101_FAST_PWRON_SET0, val | (seq_level << 4));
			break;
		case AXP2101_FAST_DCDC4:
			val = ReadRegister(AXP2101_FAST_PWRON_SET0);
			WriteRegister(AXP2101_FAST_PWRON_SET0, val | (seq_level << 6));
			break;
		case AXP2101_FAST_DCDC5:
			val = ReadRegister(AXP2101_FAST_PWRON_SET1);
			WriteRegister(AXP2101_FAST_PWRON_SET1, val | seq_level);
			break;
		case AXP2101_FAST_ALDO1:
			val = ReadRegister(AXP2101_FAST_PWRON_SET1);
			WriteRegister(AXP2101_FAST_PWRON_SET1, val | (seq_level << 2));
			break;
		case AXP2101_FAST_ALDO2:
			val = ReadRegister(AXP2101_FAST_PWRON_SET1);
			WriteRegister(AXP2101_FAST_PWRON_SET1, val | (seq_level << 4));
			break;
		case AXP2101_FAST_ALDO3:
			val = ReadRegister(AXP2101_FAST_PWRON_SET1);
			WriteRegister(AXP2101_FAST_PWRON_SET1, val | (seq_level << 6));
			break;
		case AXP2101_FAST_ALDO4:
			val = ReadRegister(AXP2101_FAST_PWRON_SET2);
			WriteRegister(AXP2101_FAST_PWRON_SET2, val | seq_level);
			break;
		case AXP2101_FAST_BLDO1:
			val = ReadRegister(AXP2101_FAST_PWRON_SET2);
			WriteRegister(AXP2101_FAST_PWRON_SET2, val | (seq_level << 2));
			break;
		case AXP2101_FAST_BLDO2:
			val = ReadRegister(AXP2101_FAST_PWRON_SET2);
			WriteRegister(AXP2101_FAST_PWRON_SET2, val | (seq_level << 4));
			break;
		case AXP2101_FAST_CPUSLDO:
			val = ReadRegister(AXP2101_FAST_PWRON_SET2);
			WriteRegister(AXP2101_FAST_PWRON_SET2, val | (seq_level << 6));
			break;
		case AXP2101_FAST_DLDO1:
			val = ReadRegister(AXP2101_FAST_PWRON_CTRL);
			WriteRegister(AXP2101_FAST_PWRON_CTRL, val | seq_level);
			break;
		case AXP2101_FAST_DLDO2:
			val = ReadRegister(AXP2101_FAST_PWRON_CTRL);
			WriteRegister(AXP2101_FAST_PWRON_CTRL, val | (seq_level << 2));
			break;
		default:
			break;
	}
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisableFastPowerOn(AXP2101_FastOnOption_e Option)
{
	uint8_t val = 0;
	switch(Option) {
		case AXP2101_FAST_DCDC1:
			val = ReadRegister(AXP2101_FAST_PWRON_SET0);
			WriteRegister(AXP2101_FAST_PWRON_SET0, val & 0xFC);
			break;
		case AXP2101_FAST_DCDC2:
			val = ReadRegister(AXP2101_FAST_PWRON_SET0);
			WriteRegister(AXP2101_FAST_PWRON_SET0, val & 0xF3);
			break;
		case AXP2101_FAST_DCDC3:
			val = ReadRegister(AXP2101_FAST_PWRON_SET0);
			WriteRegister(AXP2101_FAST_PWRON_SET0, val & 0xCF);
			break;
		case AXP2101_FAST_DCDC4:
			val = ReadRegister(AXP2101_FAST_PWRON_SET0);
			WriteRegister(AXP2101_FAST_PWRON_SET0, val & 0x3F);
			break;
		case AXP2101_FAST_DCDC5:
			val = ReadRegister(AXP2101_FAST_PWRON_SET1);
			WriteRegister(AXP2101_FAST_PWRON_SET1, val & 0xFC);
			break;
		case AXP2101_FAST_ALDO1:
			val = ReadRegister(AXP2101_FAST_PWRON_SET1);
			WriteRegister(AXP2101_FAST_PWRON_SET1, val & 0xF3);
			break;
		case AXP2101_FAST_ALDO2:
			val = ReadRegister(AXP2101_FAST_PWRON_SET1);
			WriteRegister(AXP2101_FAST_PWRON_SET1, val & 0xCF);
			break;
		case AXP2101_FAST_ALDO3:
			val = ReadRegister(AXP2101_FAST_PWRON_SET1);
			WriteRegister(AXP2101_FAST_PWRON_SET1, val & 0x3F);
			break;
		case AXP2101_FAST_ALDO4:
			val = ReadRegister(AXP2101_FAST_PWRON_SET2);
			WriteRegister(AXP2101_FAST_PWRON_SET2, val & 0xFC);
			break;
		case AXP2101_FAST_BLDO1:
			val = ReadRegister(AXP2101_FAST_PWRON_SET2);
			WriteRegister(AXP2101_FAST_PWRON_SET2, val & 0xF3);
			break;
		case AXP2101_FAST_BLDO2:
			val = ReadRegister(AXP2101_FAST_PWRON_SET2);
			WriteRegister(AXP2101_FAST_PWRON_SET2, val & 0xCF);
			break;
		case AXP2101_FAST_CPUSLDO:
			val = ReadRegister(AXP2101_FAST_PWRON_SET2);
			WriteRegister(AXP2101_FAST_PWRON_SET2, val & 0x3F);
			break;
		case AXP2101_FAST_DLDO1:
			val = ReadRegister(AXP2101_FAST_PWRON_CTRL);
			WriteRegister(AXP2101_FAST_PWRON_CTRL, val & 0xFC);
			break;
		case AXP2101_FAST_DLDO2:
			val = ReadRegister(AXP2101_FAST_PWRON_CTRL);
			WriteRegister(AXP2101_FAST_PWRON_CTRL, val & 0xF3);
			break;
		default:
			break;
	}
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::EnableFastPowerOn(void)
{
	SetRegisterBit(AXP2101_FAST_PWRON_CTRL, 7);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisableFastPowerOn(void)
{
	ClearRegisterBit(AXP2101_FAST_PWRON_CTRL, 7);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::EnableFastWakeup(void)
{
	SetRegisterBit(AXP2101_FAST_PWRON_CTRL, 6);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisableFastWakeup(void)
{
	ClearRegisterBit(AXP2101_FAST_PWRON_CTRL, 6);
}

/////////////////////////////////////////////////////////////////////////////////////

// DCDC 120%(130%) high voltage turn off PMIC function
void AXP2101::SetDCHighVoltagePowerDown(bool en)
{
	en ? SetRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 5) : ClearRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 5);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::GetDCHighVoltagePowerDownEn()
{
	return GetRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 5);
}

/////////////////////////////////////////////////////////////////////////////////////

// DCDCS force PWM control
void AXP2101::SetDcUVPDebounceTime(uint8_t Option)
{
	int val = ReadRegister(AXP2101_DC_FORCE_PWM_CTRL);
	val &= 0xFC;
	WriteRegister(AXP2101_DC_FORCE_PWM_CTRL, val | Option);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SettDC1WorkModeToPwm(uint8_t Enable)
{
	Enable ?
		SetRegisterBit(AXP2101_DC_FORCE_PWM_CTRL, 2) :
		ClearRegisterBit(AXP2101_DC_FORCE_PWM_CTRL, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SettDC2WorkModeToPwm(uint8_t Enable)
{
	Enable ? SetRegisterBit(AXP2101_DC_FORCE_PWM_CTRL, 3) : ClearRegisterBit(AXP2101_DC_FORCE_PWM_CTRL, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SettDC3WorkModeToPwm(uint8_t Enable)
{
	Enable ?
		SetRegisterBit(AXP2101_DC_FORCE_PWM_CTRL, 4) :
		ClearRegisterBit(AXP2101_DC_FORCE_PWM_CTRL, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SettDC4WorkModeToPwm(uint8_t Enable)
{
	Enable ?
		SetRegisterBit(AXP2101_DC_FORCE_PWM_CTRL, 5) :
		ClearRegisterBit(AXP2101_DC_FORCE_PWM_CTRL, 5);
}

/////////////////////////////////////////////////////////////////////////////////////

//1 = 100khz 0=50khz
void AXP2101::SetDCFreqSpreadRange(uint8_t Option)
{
	Option ?
		SetRegisterBit(AXP2101_DC_FORCE_PWM_CTRL, 6) :
		ClearRegisterBit(AXP2101_DC_FORCE_PWM_CTRL, 6);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetDCFreqSpreadRangeEn(bool en)
{
	en ?
		SetRegisterBit(AXP2101_DC_FORCE_PWM_CTRL, 7) :
		ClearRegisterBit(AXP2101_DC_FORCE_PWM_CTRL, 7);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::EnableCCM()
{
	SetRegisterBit(AXP2101_DC_ONOFF_DVM_CTRL, 6);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisableCCM()
{
	ClearRegisterBit(AXP2101_DC_ONOFF_DVM_CTRL, 6);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsEnableCCM()
{
	return GetRegisterBit(AXP2101_DC_ONOFF_DVM_CTRL, 6);
}

/////////////////////////////////////////////////////////////////////////////////////

enum DVMRamp {
	AXP2101_DVM_RAMP_15_625US,
	AXP2101_DVM_RAMP_31_250US,
};

/////////////////////////////////////////////////////////////////////////////////////

//args:enum DVMRamp
void AXP2101::SetDVMRamp(uint8_t Option)
{
	if(Option > 2) return;
	Option == 0 ? ClearRegisterBit(AXP2101_DC_ONOFF_DVM_CTRL, 5) : SetRegisterBit(AXP2101_DC_ONOFF_DVM_CTRL, 5);
}

/////////////////////////////////////////////////////////////////////////////////////

// Power control DCDC1 functions
bool AXP2101::IsEnabledDC1(void)
{
	return GetRegisterBit(AXP2101_DC_ONOFF_DVM_CTRL, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableDC1(void)
{
	return SetRegisterBit(AXP2101_DC_ONOFF_DVM_CTRL, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableDC1(void)
{
	return ClearRegisterBit(AXP2101_DC_ONOFF_DVM_CTRL, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::SetDC1Voltage(uint16_t millivolt)
{
	if(millivolt % AXP2101_DCDC1_VOL_STEPS) {
		ESP_LOGE(_TAG, "The steps is must %u mV", AXP2101_DCDC1_VOL_STEPS);
		return false;
	}
	if(millivolt < AXP2101_DCDC1_VOL_MIN) {
		ESP_LOGE(_TAG, "DC1 minimum voltage is %u mV", AXP2101_DCDC1_VOL_MIN);
		return false;
	}
	else if(millivolt > AXP2101_DCDC1_VOL_MAX) {
		ESP_LOGE(_TAG, "DC1 maximum voltage is %u mV", AXP2101_DCDC1_VOL_MAX);
		return false;
	}
	return 0 == WriteRegister(AXP2101_DC_VOL0_CTRL, (millivolt - AXP2101_DCDC1_VOL_MIN) / AXP2101_DCDC1_VOL_STEPS);
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetDC1Voltage(void)
{
	return (ReadRegister(AXP2101_DC_VOL0_CTRL) & 0x1F) * AXP2101_DCDC1_VOL_STEPS + AXP2101_DCDC1_VOL_MIN;
}

/////////////////////////////////////////////////////////////////////////////////////

// DCDC1 85% low voltage turn off PMIC function
void AXP2101::SetDC1LowVoltagePowerDown(bool en)
{
	en ? SetRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 0) : ClearRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::GetDC1LowVoltagePowerDownEn()
{
	return GetRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

// Power control DCDC2 functions
bool AXP2101::IsEnabledDC2(void)
{
	return GetRegisterBit(AXP2101_DC_ONOFF_DVM_CTRL, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableDC2(void)
{
	return SetRegisterBit(AXP2101_DC_ONOFF_DVM_CTRL, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableDC2(void)
{
	return ClearRegisterBit(AXP2101_DC_ONOFF_DVM_CTRL, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::SetDC2Voltage(uint16_t millivolt)
{
	int val = ReadRegister(AXP2101_DC_VOL1_CTRL);
	if(val == -1) return 0;
	val &= 0x80;
	if(millivolt >= AXP2101_DCDC2_VOL1_MIN && millivolt <= AXP2101_DCDC2_VOL1_MAX) {
		if(millivolt % AXP2101_DCDC2_VOL_STEPS1) {
			ESP_LOGE(_TAG, " The steps is must %umV", AXP2101_DCDC2_VOL_STEPS1);
			return false;
		}
		return 0 == WriteRegister(AXP2101_DC_VOL1_CTRL, val | (millivolt - AXP2101_DCDC2_VOL1_MIN) / AXP2101_DCDC2_VOL_STEPS1);
	}
	else if(millivolt >= AXP2101_DCDC2_VOL2_MIN && millivolt <= AXP2101_DCDC2_VOL2_MAX) {
		if(millivolt % AXP2101_DCDC2_VOL_STEPS2) {
			ESP_LOGE(_TAG, " The steps is must %umV", AXP2101_DCDC2_VOL_STEPS2);
			return false;
		}
		val |= (((millivolt - AXP2101_DCDC2_VOL2_MIN) / AXP2101_DCDC2_VOL_STEPS2) + AXP2101_DCDC2_VOL_STEPS2_BASE);
		return 0 == WriteRegister(AXP2101_DC_VOL1_CTRL, val);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetDC2Voltage(void)
{
	int val = ReadRegister(AXP2101_DC_VOL1_CTRL);
	if(val == -1) return 0;
	val &= 0x7F;
	if(val < AXP2101_DCDC2_VOL_STEPS2_BASE) {
		return (val * AXP2101_DCDC2_VOL_STEPS1) + AXP2101_DCDC2_VOL1_MIN;
	}
	else {
		return (val * AXP2101_DCDC2_VOL_STEPS2) - 200;
	}
	return 0;
}

uint8_t AXP2101::GetDC2WorkMode(void)
{
	return GetRegisterBit(AXP2101_DCDC2_VOL_STEPS2, 7);
}

void AXP2101::SetDC2LowVoltagePowerDown(bool en)
{
	en ? SetRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 1) : ClearRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 1);
}

bool AXP2101::GetDC2LowVoltagePowerDownEn()
{
	return GetRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

// Power control DCDC3 functions
bool AXP2101::IsEnabledDC3(void)
{
	return GetRegisterBit(AXP2101_DC_ONOFF_DVM_CTRL, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableDC3(void)
{
	return SetRegisterBit(AXP2101_DC_ONOFF_DVM_CTRL, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableDC3(void)
{
	return ClearRegisterBit(AXP2101_DC_ONOFF_DVM_CTRL, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

/*      0.5~1.2V,10mV/step,71steps
        1.22~1.54V,20mV/step,17steps
        1.6~3.4V,100mV/step,19steps */
bool AXP2101::SetDC3Voltage(uint16_t millivolt)
{
	int val = ReadRegister(AXP2101_DC_VOL2_CTRL);
	if(val == -1) return false;
	val &= 0x80;
	if(millivolt >= AXP2101_DCDC3_VOL1_MIN && millivolt <= AXP2101_DCDC3_VOL1_MAX) {
		if(millivolt % AXP2101_DCDC3_VOL_STEPS1) {
			ESP_LOGE(_TAG, "The steps is must %umV", AXP2101_DCDC3_VOL_STEPS1);
			return false;
		}
		return 0 == WriteRegister(AXP2101_DC_VOL2_CTRL, val | (millivolt - AXP2101_DCDC3_VOL_MIN) / AXP2101_DCDC3_VOL_STEPS1);
	}
	else if(millivolt >= AXP2101_DCDC3_VOL2_MIN && millivolt <= AXP2101_DCDC3_VOL2_MAX) {
		if(millivolt % AXP2101_DCDC3_VOL_STEPS2) {
			ESP_LOGE(_TAG, "The steps is must %umV", AXP2101_DCDC3_VOL_STEPS2);
			return false;
		}
		val |= (((millivolt - AXP2101_DCDC3_VOL2_MIN) / AXP2101_DCDC3_VOL_STEPS2) + AXP2101_DCDC3_VOL_STEPS2_BASE);
		return 0 == WriteRegister(AXP2101_DC_VOL2_CTRL, val);
	}
	else if(millivolt >= AXP2101_DCDC3_VOL3_MIN && millivolt <= AXP2101_DCDC3_VOL3_MAX) {
		if(millivolt % AXP2101_DCDC3_VOL_STEPS3) {
			ESP_LOGE(_TAG, "The steps is must %umV", AXP2101_DCDC3_VOL_STEPS3);
			return false;
		}
		val |= (((millivolt - AXP2101_DCDC3_VOL3_MIN) / AXP2101_DCDC3_VOL_STEPS3) + AXP2101_DCDC3_VOL_STEPS3_BASE);
		return 0 == WriteRegister(AXP2101_DC_VOL2_CTRL, val);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetDC3Voltage(void)
{
	int val = ReadRegister(AXP2101_DC_VOL2_CTRL) & 0x7F;
	if(val == -1)
		return 0;
	if(val < AXP2101_DCDC3_VOL_STEPS2_BASE) {
		return (val * AXP2101_DCDC3_VOL_STEPS1) + AXP2101_DCDC3_VOL_MIN;
	}
	else if(val >= AXP2101_DCDC3_VOL_STEPS2_BASE && val < AXP2101_DCDC3_VOL_STEPS3_BASE) {
		return (val * AXP2101_DCDC3_VOL_STEPS2) - 200;
	}
	else {
		return (val * AXP2101_DCDC3_VOL_STEPS3) - 7200;
	}
	return 0;
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t AXP2101::GetDC3WorkMode(void)
{
	return GetRegisterBit(AXP2101_DC_VOL2_CTRL, 7);
}

/////////////////////////////////////////////////////////////////////////////////////

// DCDC3 85% low voltage turn off PMIC function
void AXP2101::SetDC3LowVoltagePowerDown(bool en)
{
	en ? SetRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 2) : ClearRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::GetDC3LowVoltagePowerDownEn()
{
	return GetRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

// Power control DCDC4 functions
/**
        0.5~1.2V,10mV/step,71steps
        1.22~1.84V,20mV/step,32steps
     */
bool AXP2101::IsEnabledDC4(void)
{
	return GetRegisterBit(AXP2101_DC_ONOFF_DVM_CTRL, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableDC4(void)
{
	return SetRegisterBit(AXP2101_DC_ONOFF_DVM_CTRL, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableDC4(void)
{
	return ClearRegisterBit(AXP2101_DC_ONOFF_DVM_CTRL, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::SetDC4Voltage(uint16_t millivolt)
{
	int val = ReadRegister(AXP2101_DC_VOL3_CTRL);
	if(val == -1) return false;
	val &= 0x80;
	if(millivolt >= AXP2101_DCDC4_VOL1_MIN && millivolt <= AXP2101_DCDC4_VOL1_MAX) {
		if(millivolt % AXP2101_DCDC4_VOL_STEPS1) {
			ESP_LOGE(_TAG, "The steps is must %umV", AXP2101_DCDC4_VOL_STEPS1);
			return false;
		}
		return 0 == WriteRegister(AXP2101_DC_VOL3_CTRL, val | (millivolt - AXP2101_DCDC4_VOL1_MIN) / AXP2101_DCDC4_VOL_STEPS1);
	}
	else if(millivolt >= AXP2101_DCDC4_VOL2_MIN && millivolt <= AXP2101_DCDC4_VOL2_MAX) {
		if(millivolt % AXP2101_DCDC4_VOL_STEPS2) {
			ESP_LOGE(_TAG, "The steps is must %umV", AXP2101_DCDC4_VOL_STEPS2);
			return false;
		}
		val |= (((millivolt - AXP2101_DCDC4_VOL2_MIN) / AXP2101_DCDC4_VOL_STEPS2) + AXP2101_DCDC4_VOL_STEPS2_BASE);
		return 0 == WriteRegister(AXP2101_DC_VOL3_CTRL, val);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetDC4Voltage(void)
{
	int val = ReadRegister(AXP2101_DC_VOL3_CTRL);
	if(val == -1) return 0;
	val &= 0x7F;
	if(val < AXP2101_DCDC4_VOL_STEPS2_BASE) {
		return (val * AXP2101_DCDC4_VOL_STEPS1) + AXP2101_DCDC4_VOL1_MIN;
	}
	else {
		return (val * AXP2101_DCDC4_VOL_STEPS2) - 200;
	}
	return 0;
}

/////////////////////////////////////////////////////////////////////////////////////

// DCDC4 85% low voltage turn off PMIC function
void AXP2101::SetDC4LowVoltagePowerDown(bool en)
{
	en ? SetRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 3) : ClearRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::GetDC4LowVoltagePowerDownEn()
{
	return GetRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

// Power control DCDC5 functions,Output to gpio pin
bool AXP2101::IsEnabledDC5(void)
{
	return GetRegisterBit(AXP2101_DC_ONOFF_DVM_CTRL, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableDC5(void)
{
	return SetRegisterBit(AXP2101_DC_ONOFF_DVM_CTRL, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableDC5(void)
{
	return ClearRegisterBit(AXP2101_DC_ONOFF_DVM_CTRL, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::SetDC5Voltage(uint16_t millivolt)
{
	if(millivolt % AXP2101_DCDC5_VOL_STEPS) {
		ESP_LOGE(_TAG, "The steps is must %u mV", AXP2101_DCDC5_VOL_STEPS);
		return false;
	}
	if(millivolt != AXP2101_DCDC5_VOL_1200MV && millivolt < AXP2101_DCDC5_VOL_MIN) {
		ESP_LOGE(_TAG, "DC5 minimum voltage is %umV ,%umV", AXP2101_DCDC5_VOL_1200MV, AXP2101_DCDC5_VOL_MIN);
		return false;
	}
	else if(millivolt > AXP2101_DCDC5_VOL_MAX) {
		ESP_LOGE(_TAG, "DC5 maximum voltage is %umV", AXP2101_DCDC5_VOL_MAX);
		return false;
	}

	int val = ReadRegister(AXP2101_DC_VOL4_CTRL);
	if(val == -1) return false;
	val &= 0xE0;
	if(millivolt == AXP2101_DCDC5_VOL_1200MV) {
		return 0 == WriteRegister(AXP2101_DC_VOL4_CTRL, val | AXP2101_DCDC5_VOL_VAL);
	}
	val |= (millivolt - AXP2101_DCDC5_VOL_MIN) / AXP2101_DCDC5_VOL_STEPS;
	return 0 == WriteRegister(AXP2101_DC_VOL4_CTRL, val);
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetDC5Voltage(void)
{
	int val = ReadRegister(AXP2101_DC_VOL4_CTRL);
	if(val == -1) return 0;
	val &= 0x1F;
	if(val == AXP2101_DCDC5_VOL_VAL) return AXP2101_DCDC5_VOL_1200MV;
	return (val * AXP2101_DCDC5_VOL_STEPS) + AXP2101_DCDC5_VOL_MIN;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsDC5FreqCompensationEn(void)
{
	return GetRegisterBit(AXP2101_DC_VOL4_CTRL, 5);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::EnableDC5FreqCompensation()
{
	SetRegisterBit(AXP2101_DC_VOL4_CTRL, 5);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisableFreqCompensation()
{
	ClearRegisterBit(AXP2101_DC_VOL4_CTRL, 5);
}

/////////////////////////////////////////////////////////////////////////////////////

// DCDC4 85% low voltage turn off PMIC function
void AXP2101::SetDC5LowVoltagePowerDown(bool en)
{
	en ? SetRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 4) : ClearRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::GetDC5LowVoltagePowerDownEn()
{
	return GetRegisterBit(AXP2101_DC_OVP_UVP_CTRL, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

// Power control ALDO1 functions
bool AXP2101::IsEnabledALDO1(void)
{
	return GetRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableALDO1(void)
{
	return SetRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableALDO1(void)
{
	return ClearRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::SetALDO1Voltage(uint16_t millivolt)
{
	if(millivolt % AXP2101_ALDO1_VOL_STEPS) {
		ESP_LOGE(_TAG, "The steps is must %u mV", AXP2101_ALDO1_VOL_STEPS);
		return false;
	}
	if(millivolt < AXP2101_ALDO1_VOL_MIN) {
		ESP_LOGE(_TAG, "ALDO1 minimum output voltage is  %umV", AXP2101_ALDO1_VOL_MIN);
		return false;
	}
	else if(millivolt > AXP2101_ALDO1_VOL_MAX) {
		ESP_LOGE(_TAG, "ALDO1 maximum output voltage is  %umV", AXP2101_ALDO1_VOL_MAX);
		return false;
	}
	uint16_t val = ReadRegister(AXP2101_LDO_VOL0_CTRL) & 0xE0;
	val |= (millivolt - AXP2101_ALDO1_VOL_MIN) / AXP2101_ALDO1_VOL_STEPS;
	return 0 == WriteRegister(AXP2101_LDO_VOL0_CTRL, val);
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetALDO1Voltage(void)
{
	uint16_t val = ReadRegister(AXP2101_LDO_VOL0_CTRL) & 0x1F;
	return val * AXP2101_ALDO1_VOL_STEPS + AXP2101_ALDO1_VOL_MIN;
}

/////////////////////////////////////////////////////////////////////////////////////

// Power control ALDO2 functions
bool AXP2101::IsEnabledALDO2(void)
{
	return GetRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableALDO2(void)
{
	return SetRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableALDO2(void)
{
	return ClearRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::SetALDO2Voltage(uint16_t millivolt)
{
	if(millivolt % AXP2101_ALDO2_VOL_STEPS) {
		ESP_LOGE(_TAG, "The steps is must %u mV", AXP2101_ALDO2_VOL_STEPS);
		return false;
	}
	if(millivolt < AXP2101_ALDO2_VOL_MIN) {
		ESP_LOGE(_TAG, "ALDO2 minimum output voltage is  %umV", AXP2101_ALDO2_VOL_MIN);
		return false;
	}
	else if(millivolt > AXP2101_ALDO2_VOL_MAX) {
		ESP_LOGE(_TAG, "ALDO2 maximum output voltage is  %umV", AXP2101_ALDO2_VOL_MAX);
		return false;
	}
	uint16_t val = ReadRegister(AXP2101_LDO_VOL1_CTRL) & 0xE0;
	val |= (millivolt - AXP2101_ALDO2_VOL_MIN) / AXP2101_ALDO2_VOL_STEPS;
	return 0 == WriteRegister(AXP2101_LDO_VOL1_CTRL, val);
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetALDO2Voltage(void)
{
	uint16_t val = ReadRegister(AXP2101_LDO_VOL1_CTRL) & 0x1F;
	return val * AXP2101_ALDO2_VOL_STEPS + AXP2101_ALDO2_VOL_MIN;
}

/////////////////////////////////////////////////////////////////////////////////////

// Power control ALDO3 functions
bool AXP2101::IsEnabledALDO3(void)
{
	return GetRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableALDO3(void)
{
	return SetRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableALDO3(void)
{
	return ClearRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::SetALDO3Voltage(uint16_t millivolt)
{
	if(millivolt % AXP2101_ALDO3_VOL_STEPS) {
		ESP_LOGE(_TAG, "The steps is must %u mV", AXP2101_ALDO3_VOL_STEPS);
		return false;
	}
	if(millivolt < AXP2101_ALDO3_VOL_MIN) {
		ESP_LOGE(_TAG, "ALDO3 minimum output voltage is  %umV", AXP2101_ALDO3_VOL_MIN);
		return false;
	}
	else if(millivolt > AXP2101_ALDO3_VOL_MAX) {
		ESP_LOGE(_TAG, "ALDO3 maximum output voltage is  %umV", AXP2101_ALDO3_VOL_MAX);
		return false;
	}
	uint16_t val = ReadRegister(AXP2101_LDO_VOL2_CTRL) & 0xE0;
	val |= (millivolt - AXP2101_ALDO3_VOL_MIN) / AXP2101_ALDO3_VOL_STEPS;
	return 0 == WriteRegister(AXP2101_LDO_VOL2_CTRL, val);
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetALDO3Voltage(void)
{
	uint16_t val = ReadRegister(AXP2101_LDO_VOL2_CTRL) & 0x1F;
	return val * AXP2101_ALDO3_VOL_STEPS + AXP2101_ALDO3_VOL_MIN;
}

// Power control ALDO4 functions
bool AXP2101::IsEnabledALDO4(void)
{
	return GetRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableALDO4(void)
{
	return SetRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableALDO4(void)
{
	return ClearRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::SetALDO4Voltage(uint16_t millivolt)
{
	if(millivolt % AXP2101_ALDO4_VOL_STEPS) {
		ESP_LOGE(_TAG, "The steps is must %u mV", AXP2101_ALDO4_VOL_STEPS);
		return false;
	}
	if(millivolt < AXP2101_ALDO4_VOL_MIN) {
		ESP_LOGE(_TAG, "ALDO4 minimum output voltage is  %umV", AXP2101_ALDO4_VOL_MIN);
		return false;
	}
	else if(millivolt > AXP2101_ALDO4_VOL_MAX) {
		ESP_LOGE(_TAG, "ALDO4 maximum output voltage is  %umV", AXP2101_ALDO4_VOL_MAX);
		return false;
	}
	uint16_t val = ReadRegister(AXP2101_LDO_VOL3_CTRL) & 0xE0;
	val |= (millivolt - AXP2101_ALDO4_VOL_MIN) / AXP2101_ALDO4_VOL_STEPS;
	return 0 == WriteRegister(AXP2101_LDO_VOL3_CTRL, val);
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetALDO4Voltage(void)
{
	uint16_t val = ReadRegister(AXP2101_LDO_VOL3_CTRL) & 0x1F;
	return val * AXP2101_ALDO4_VOL_STEPS + AXP2101_ALDO4_VOL_MIN;
}

/////////////////////////////////////////////////////////////////////////////////////

// Power control BLDO1 functions
bool AXP2101::IsEnabledBLDO1(void)
{
	return GetRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableBLDO1(void)
{
	return SetRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableBLDO1(void)
{
	return ClearRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::SetBLDO1Voltage(uint16_t millivolt)
{
	if(millivolt % AXP2101_BLDO1_VOL_STEPS) {
		ESP_LOGE(_TAG, "The steps is must %u mV", AXP2101_BLDO1_VOL_STEPS);
		return false;
	}
	if(millivolt < AXP2101_BLDO1_VOL_MIN) {
		ESP_LOGE(_TAG, "BLDO1 minimum output voltage is  %umV", AXP2101_BLDO1_VOL_MIN);
		return false;
	}
	else if(millivolt > AXP2101_BLDO1_VOL_MAX) {
		ESP_LOGE(_TAG, "BLDO1 maximum output voltage is  %umV", AXP2101_BLDO1_VOL_MAX);
		return false;
	}
	int val = ReadRegister(AXP2101_LDO_VOL4_CTRL);
	if(val == -1) return false;
	val &= 0xE0;
	val |= (millivolt - AXP2101_BLDO1_VOL_MIN) / AXP2101_BLDO1_VOL_STEPS;
	return 0 == WriteRegister(AXP2101_LDO_VOL4_CTRL, val);
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetBLDO1Voltage(void)
{
	int val = ReadRegister(AXP2101_LDO_VOL4_CTRL);
	if(val == -1) return 0;
	val &= 0x1F;
	return val * AXP2101_BLDO1_VOL_STEPS + AXP2101_BLDO1_VOL_MIN;
}

/////////////////////////////////////////////////////////////////////////////////////

// Power control BLDO2 functions
bool AXP2101::IsEnabledBLDO2(void)
{
	return GetRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 5);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableBLDO2(void)
{
	return SetRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 5);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableBLDO2(void)
{
	return ClearRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 5);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::SetBLDO2Voltage(uint16_t millivolt)
{
	if(millivolt % AXP2101_BLDO2_VOL_STEPS) {
		ESP_LOGE(_TAG, "The steps is must %u mV", AXP2101_BLDO2_VOL_STEPS);
		return false;
	}
	if(millivolt < AXP2101_BLDO2_VOL_MIN) {
		ESP_LOGE(_TAG, "BLDO2 minimum output voltage is  %umV", AXP2101_BLDO2_VOL_MIN);
		return false;
	}
	else if(millivolt > AXP2101_BLDO2_VOL_MAX) {
		ESP_LOGE(_TAG, "BLDO2 maximum output voltage is  %umV", AXP2101_BLDO2_VOL_MAX);
		return false;
	}
	uint16_t val = ReadRegister(AXP2101_LDO_VOL5_CTRL) & 0xE0;
	val |= (millivolt - AXP2101_BLDO2_VOL_MIN) / AXP2101_BLDO2_VOL_STEPS;
	return 0 == WriteRegister(AXP2101_LDO_VOL5_CTRL, val);
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetBLDO2Voltage(void)
{
	int val = ReadRegister(AXP2101_LDO_VOL5_CTRL);
	if(val == -1) return 0;
	val &= 0x1F;
	return val * AXP2101_BLDO2_VOL_STEPS + AXP2101_BLDO2_VOL_MIN;
}

/////////////////////////////////////////////////////////////////////////////////////

// Power control CPUSLDO functions
bool AXP2101::IsEnabledCPUSLDO(void)
{
	return GetRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 6);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableCPUSLDO(void)
{
	return SetRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 6);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableCPUSLDO(void)
{
	return ClearRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 6);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::SetCPUSLDOVoltage(uint16_t millivolt)
{
	if(millivolt % AXP2101_CPUSLDO_VOL_STEPS) {
		ESP_LOGE(_TAG, "The steps is must %u mV", AXP2101_CPUSLDO_VOL_STEPS);
		return false;
	}
	if(millivolt < AXP2101_CPUSLDO_VOL_MIN) {
		ESP_LOGE(_TAG, "CPULDO minimum output voltage is  %umV", AXP2101_CPUSLDO_VOL_MIN);
		return false;
	}
	else if(millivolt > AXP2101_CPUSLDO_VOL_MAX) {
		ESP_LOGE(_TAG, "CPULDO maximum output voltage is  %umV", AXP2101_CPUSLDO_VOL_MAX);
		return false;
	}
	uint16_t val = ReadRegister(AXP2101_LDO_VOL6_CTRL) & 0xE0;
	val |= (millivolt - AXP2101_CPUSLDO_VOL_MIN) / AXP2101_CPUSLDO_VOL_STEPS;
	return 0 == WriteRegister(AXP2101_LDO_VOL6_CTRL, val);
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetCPUSLDOVoltage(void)
{
	int val = ReadRegister(AXP2101_LDO_VOL6_CTRL);
	if(val == -1) return 0;
	val &= 0x1F;
	return val * AXP2101_CPUSLDO_VOL_STEPS + AXP2101_CPUSLDO_VOL_MIN;
}

/////////////////////////////////////////////////////////////////////////////////////

// Power control DLDO1 functions
bool AXP2101::IsEnabledDLDO1(void)
{
	return GetRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 7);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableDLDO1(void)
{
	return SetRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 7);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableDLDO1(void)
{
	return ClearRegisterBit(AXP2101_LDO_ONOFF_CTRL0, 7);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::SetDLDO1Voltage(uint16_t millivolt)
{
	if(millivolt % AXP2101_DLDO1_VOL_STEPS) {
		ESP_LOGE(_TAG, "The steps is must %u mV", AXP2101_DLDO1_VOL_STEPS);
		return false;
	}
	if(millivolt < AXP2101_DLDO1_VOL_MIN) {
		ESP_LOGE(_TAG, "DLDO1 minimum output voltage is  %umV", AXP2101_DLDO1_VOL_MIN);
		return false;
	}
	else if(millivolt > AXP2101_DLDO1_VOL_MAX) {
		ESP_LOGE(_TAG, "DLDO1 maximum output voltage is  %umV", AXP2101_DLDO1_VOL_MAX);
		return false;
	}
	uint16_t val = ReadRegister(AXP2101_LDO_VOL7_CTRL) & 0xE0;
	val |= (millivolt - AXP2101_DLDO1_VOL_MIN) / AXP2101_DLDO1_VOL_STEPS;
	return 0 == WriteRegister(AXP2101_LDO_VOL7_CTRL, val);
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetDLDO1Voltage(void)
{
	int val = ReadRegister(AXP2101_LDO_VOL7_CTRL);
	if(val == -1) return 0;
	val &= 0x1F;
	return val * AXP2101_DLDO1_VOL_STEPS + AXP2101_DLDO1_VOL_MIN;
}

/////////////////////////////////////////////////////////////////////////////////////

// Power control DLDO2 functions
bool AXP2101::IsEnabledDLDO2(void)
{
	return GetRegisterBit(AXP2101_LDO_ONOFF_CTRL1, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableDLDO2(void)
{
	return SetRegisterBit(AXP2101_LDO_ONOFF_CTRL1, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableDLDO2(void)
{
	return ClearRegisterBit(AXP2101_LDO_ONOFF_CTRL1, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::SetDLDO2Voltage(uint16_t millivolt)
{
	if(millivolt % AXP2101_DLDO2_VOL_STEPS) {
		ESP_LOGE(_TAG, "The steps is must %u mV", AXP2101_DLDO2_VOL_STEPS);
		return false;
	}
	if(millivolt < AXP2101_DLDO2_VOL_MIN) {
		ESP_LOGE(_TAG, "DLDO2 minimum output voltage is  %umV", AXP2101_DLDO2_VOL_MIN);
		return false;
	}
	else if(millivolt > AXP2101_DLDO2_VOL_MAX) {
		ESP_LOGE(_TAG, "DLDO2 maximum output voltage is  %umV", AXP2101_DLDO2_VOL_MAX);
		return false;
	}
	uint16_t val = ReadRegister(AXP2101_LDO_VOL8_CTRL) & 0xE0;
	val |= (millivolt - AXP2101_DLDO2_VOL_MIN) / AXP2101_DLDO2_VOL_STEPS;
	return 0 == WriteRegister(AXP2101_LDO_VOL8_CTRL, val);
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetDLDO2Voltage(void)
{
	int val = ReadRegister(AXP2101_LDO_VOL8_CTRL);
	if(val == -1) return 0;
	val &= 0x1F;
	return val * AXP2101_DLDO2_VOL_STEPS + AXP2101_DLDO2_VOL_MIN;
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetIRQLevelTime(AXP2101_IRQ_Time_e Option)
{
	int val = ReadRegister(AXP2101_IRQ_OFF_ON_LEVEL_CTRL);
	if(val == -1) return;
	val &= 0xCF;
	WriteRegister(AXP2101_IRQ_OFF_ON_LEVEL_CTRL, val | (Option << 4));
}

/////////////////////////////////////////////////////////////////////////////////////

AXP2101_IRQ_Time_e AXP2101::GetIRQLevelTime(void)
{
	return (AXP2101_IRQ_Time_e)((ReadRegister(AXP2101_IRQ_OFF_ON_LEVEL_CTRL) & 0x30) >> 4);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::SetPowerKeyPressOnTime(uint8_t Option)
{
	int val = ReadRegister(AXP2101_IRQ_OFF_ON_LEVEL_CTRL);
	if(val == -1) return false;
	val &= 0xFC;
	return 0 == WriteRegister(AXP2101_IRQ_OFF_ON_LEVEL_CTRL, val | Option);
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t AXP2101::GetPowerKeyPressOnTime(void)
{
	int val = ReadRegister(AXP2101_IRQ_OFF_ON_LEVEL_CTRL);
	if(val == -1) return 0;
	return (val & 0x03);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::SetPowerKeyPressOffTime(uint8_t Option)
{
	int val = ReadRegister(AXP2101_IRQ_OFF_ON_LEVEL_CTRL);
	if(val == -1) return false;
	val &= 0xF3;
	return 0 == WriteRegister(AXP2101_IRQ_OFF_ON_LEVEL_CTRL, val | (Option << 2));
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t AXP2101::GetPowerKeyPressOffTime(void)
{
	return ((ReadRegister(AXP2101_IRQ_OFF_ON_LEVEL_CTRL) & 0x0C) >> 2);
}

/////////////////////////////////////////////////////////////////////////////////////

// ADC Control method
bool AXP2101::EnableGeneralAdcChannel(void)
{
	return SetRegisterBit(AXP2101_ADC_CHANNEL_CTRL, 5);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableGeneralAdcChannel(void)
{
	return ClearRegisterBit(AXP2101_ADC_CHANNEL_CTRL, 5);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableTemperatureMeasure(void)
{
	return SetRegisterBit(AXP2101_ADC_CHANNEL_CTRL, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableTemperatureMeasure(void)
{
	return ClearRegisterBit(AXP2101_ADC_CHANNEL_CTRL, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

// Temperature 14-bit ADC
float AXP2101::GetTemperature(uint16_t *pRaw /*= nullptr*/)
{
	uint16_t Raw = ReadRegisterH6L8(AXP2101_ADC_DATA_RELUST8, AXP2101_ADC_DATA_RELUST9);
	if(Raw == UINT16_MAX || Raw > 16383) return NAN;
	if(pRaw) *pRaw = Raw;
	return AXP2101_CONVERSION(Raw);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableSystemVoltageMeasure(void)
{
	return SetRegisterBit(AXP2101_ADC_CHANNEL_CTRL, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableSystemVoltageMeasure(void)
{
	return ClearRegisterBit(AXP2101_ADC_CHANNEL_CTRL, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetSystemVoltage(void)
{
	return ReadRegisterH6L8(AXP2101_ADC_DATA_RELUST6, AXP2101_ADC_DATA_RELUST7);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableVbusVoltageMeasure(void)
{
	return SetRegisterBit(AXP2101_ADC_CHANNEL_CTRL, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableVbusVoltageMeasure(void)
{
	return ClearRegisterBit(AXP2101_ADC_CHANNEL_CTRL, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetVbusVoltage(void)
{
	if(!IsVbusIn()) {
		return 0;
	}
	return ReadRegisterH6L8(AXP2101_ADC_DATA_RELUST4, AXP2101_ADC_DATA_RELUST5);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableTSPinMeasure(void)
{
	// TS pin is the battery temperature sensor input and will affect the charger
	uint8_t value = ReadRegister(AXP2101_TS_PIN_CTRL);
	value &= 0xE0;
	WriteRegister(AXP2101_TS_PIN_CTRL, value | 0x07);
	return SetRegisterBit(AXP2101_ADC_CHANNEL_CTRL, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableTSPinMeasure(void)
{
	// TS pin is the external fixed input and doesn't affect the charger
	uint8_t value = ReadRegister(AXP2101_TS_PIN_CTRL);
	value &= 0xF0;
	WriteRegister(AXP2101_TS_PIN_CTRL, value | 0x10);
	return ClearRegisterBit(AXP2101_ADC_CHANNEL_CTRL, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableTSPinLowFreqSample(void)
{
	return SetRegisterBit(AXP2101_ADC_CHANNEL_CTRL, 7);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableTSPinLowFreqSample(void)
{
	return ClearRegisterBit(AXP2101_ADC_DATA_RELUST2, 7);
}

/////////////////////////////////////////////////////////////////////////////////////

/**
 * Calculate temperature from TS pin ADC value using Steinhart-Hart equation.
 *
 * @param SteinhartA Steinhart-Hart coefficient A (default: 1.126e-3)
 * @param SteinhartB Steinhart-Hart coefficient B (default: 2.38e-4)
 * @param SteinhartC Steinhart-Hart coefficient C (default: 8.5e-8)
 * @return Temperature in Celsius. Returns 0 if ADC value is 0x2000 (invalid measurement).
 *
 * @details
 * This function converts the ADC reading from the TS pin to temperature using:
 * 1. Voltage calculation: V = ADC_raw × 0.0005 (V)
 * 2. Resistance calculation: R = V / I (Ω), where I = 50μA
 * 3. Temperature calculation: T = 1/(A+B*ln(R)+C*(ln(R))^3) - 273.15 (℃)
 *
 * @note
 * The calculation parameters are from the AXP2101 Datasheet, using the TH11-3H103F NTC resistor
 *     as the Steinhart-Hart equation calculation parameters
 * 1. Coefficients A, B, C should be calibrated for specific NTC thermistor.
 * 2. ADC value 0x2000 indicates sensor fault (e.g., open circuit).
 * 3. Valid temperature range: typically -20℃ to 60℃. Accuracy may degrade outside this range.
 */
float AXP2101::GetTsTemperature(float SteinhartA /*= 1.126e-3*/, float SteinhartB /*= 2.38e-4*/, float SteinhartC /*= 8.5e-8*/)
{
	uint16_t adc_raw = GetTsPinValue();  // Read raw ADC value from TS pin

	// Check for invalid measurement (0x2000 indicates sensor disconnection)
	if(adc_raw == 0x2000) {
		return 0;
	}
	float current_ma = 0.05f;                             // Current source: 50μA
	float voltage = adc_raw * 0.0005f;                    // Convert ADC value to voltage (V)
	float resistance = voltage / (current_ma / 1000.0f);  // Calculate resistance (Ω)
	// Convert resistance to temperature using Steinhart-Hart equation
	return ResistanceToTemperature(resistance, SteinhartA, SteinhartB, SteinhartC);
}

/////////////////////////////////////////////////////////////////////////////////////

// raw value
uint16_t AXP2101::GetTsPinValue(void)
{
	return ReadRegisterH6L8(AXP2101_ADC_DATA_RELUST2, AXP2101_ADC_DATA_RELUST3);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableBattVoltageMeasure(void)
{
	return SetRegisterBit(AXP2101_ADC_CHANNEL_CTRL, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableBattVoltageMeasure(void)
{
	return ClearRegisterBit(AXP2101_ADC_CHANNEL_CTRL, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableBattDetection(void)
{
	return SetRegisterBit(AXP2101_BAT_DET_CTRL, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableBattDetection(void)
{
	return ClearRegisterBit(AXP2101_BAT_DET_CTRL, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetBattVoltage(void)
{
	if(!IsBatteryConnect()) return 0;
	return ReadRegisterH5L8(AXP2101_ADC_DATA_RELUST0, AXP2101_ADC_DATA_RELUST1);
}

/////////////////////////////////////////////////////////////////////////////////////

int AXP2101::GetBatteryPercent(void)
{
	if(!IsBatteryConnect()) return -1;
	return ReadRegister(AXP2101_BAT_PERCENT_DATA);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetChargingLEDMode(uint8_t mode)
{
	int val;
	switch(mode) {
		case AXP2101_CHG_LED_OFF:
		// ClearRegisterBit(AXP2101_CHGLED_SET_CTRL, 0);
		// break;
		case AXP2101_CHG_LED_BLINK_1HZ:
		case AXP2101_CHG_LED_BLINK_4HZ:
		case AXP2101_CHG_LED_ON:
			val = ReadRegister(AXP2101_CHGLED_SET_CTRL);
			if(val == -1) return;
			val &= 0xC8;
			val |= 0x05;  //use manual ctrl
			val |= (mode << 4);
			WriteRegister(AXP2101_CHGLED_SET_CTRL, val);
			break;
		case AXP2101_CHG_LED_CTRL_CHG:
			val = ReadRegister(AXP2101_CHGLED_SET_CTRL);
			if(val == -1) return;
			val &= 0xF9;
			WriteRegister(AXP2101_CHGLED_SET_CTRL, val | 0x01);  // use type A mode
			// WriteRegister(AXP2101_CHGLED_SET_CTRL, val | 0x02); // use type B mode
			break;
		default:
			break;
	}
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t AXP2101::GetChargingLEDMode()
{
	int val = ReadRegister(AXP2101_CHGLED_SET_CTRL);
	if(val == -1) return AXP2101_CHG_LED_OFF;
	val >>= 1;
	if((val & 0x02) == 0x02) {
		val >>= 4;
		return val & 0x03;
	}
	return AXP2101_CHG_LED_CTRL_CHG;
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetPrechargeCurr(AXP2101_PreCharge_e Option)
{
	int val = ReadRegister(AXP2101_IPRECHG_SET);
	if(val == -1) return;
	val &= 0xFC;
	WriteRegister(AXP2101_IPRECHG_SET, val | Option);
}

/////////////////////////////////////////////////////////////////////////////////////

AXP2101_PreCharge_e AXP2101::GetPrechargeCurr(void)
{
	return (AXP2101_PreCharge_e)(ReadRegister(AXP2101_IPRECHG_SET) & 0x03);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::SetChargerConstantCurr(uint8_t Option)
{
	if(Option > AXP2101_CHG_CUR_1000MA) return false;
	int val = ReadRegister(AXP2101_ICC_CHG_SET);
	if(val == -1) return false;
	val &= 0xE0;
	return 0 == WriteRegister(AXP2101_ICC_CHG_SET, val | Option);
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t AXP2101::GetChargerConstantCurr(void)
{
	int val = ReadRegister(AXP2101_ICC_CHG_SET);
	if(val == -1) return 0;
	return val & 0x1F;
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetChargerTerminationCurr(AXP2101_ChargeIterm_e Option)
{
	int val = ReadRegister(AXP2101_ITERM_CHG_SET_CTRL);
	if(val == -1) return;
	val &= 0xF0;
	WriteRegister(AXP2101_ITERM_CHG_SET_CTRL, val | Option);
}

/////////////////////////////////////////////////////////////////////////////////////

AXP2101_ChargeIterm_e AXP2101::GetChargerTerminationCurr(void)
{
	return (AXP2101_ChargeIterm_e)(ReadRegister(AXP2101_ITERM_CHG_SET_CTRL) & 0x0F);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::EnableChargerTerminationLimit(void)
{
	int val = ReadRegister(AXP2101_ITERM_CHG_SET_CTRL);
	if(val == -1) return;
	WriteRegister(AXP2101_ITERM_CHG_SET_CTRL, val | 0x10);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::DisableChargerTerminationLimit(void)
{
	int val = ReadRegister(AXP2101_ITERM_CHG_SET_CTRL);
	if(val == -1) return;
	WriteRegister(AXP2101_ITERM_CHG_SET_CTRL, val & 0xEF);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsChargerTerminationLimit(void)
{
	return GetRegisterBit(AXP2101_ITERM_CHG_SET_CTRL, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::SetChargeTargetVoltage(uint8_t Option)
{
	if(Option >= AXP2101_CHG_VOL_MAX) return false;
	int val = ReadRegister(AXP2101_CV_CHG_VOL_SET);
	if(val == -1) return false;
	val &= 0xF8;
	return 0 == WriteRegister(AXP2101_CV_CHG_VOL_SET, val | Option);
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t AXP2101::GetChargeTargetVoltage(void)
{
	return (ReadRegister(AXP2101_CV_CHG_VOL_SET) & 0x07);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::SetThermaThreshold(AXP2101_Thermal_e Option)
{
	int val = ReadRegister(AXP2101_THE_REGU_THRES_SET);
	if(val == -1) return;
	val &= 0xFC;
	WriteRegister(AXP2101_THE_REGU_THRES_SET, val | Option);
}

/////////////////////////////////////////////////////////////////////////////////////

AXP2101_Thermal_e AXP2101::GetThermaThreshold(void)
{
	return (AXP2101_Thermal_e)(ReadRegister(AXP2101_THE_REGU_THRES_SET) & 0x03);
}

/////////////////////////////////////////////////////////////////////////////////////

uint64_t AXP2101::GetIRQStatus(void)
{
	m_StatusRegisters[0] = ReadRegister(AXP2101_INTSTS1);
	m_StatusRegisters[1] = ReadRegister(AXP2101_INTSTS2);
	m_StatusRegisters[2] = ReadRegister(AXP2101_INTSTS3);
	return (uint32_t)(m_StatusRegisters[0] << 16) | (uint32_t)(m_StatusRegisters[1] << 8) | (uint32_t)(m_StatusRegisters[2]);
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::ClearIRQStatus()
{
	for(int i = 0; i < AXP2101_INTSTS_CNT; i++) {
		WriteRegister(AXP2101_INTSTS1 + i, 0xFF);
		m_StatusRegisters[i] = 0;
	}
}

/////////////////////////////////////////////////////////////////////////////////////

void AXP2101::PrintIntRegister()
{
	for(int i = 0; i < AXP2101_INTSTS_CNT; i++) {
		uint8_t val = ReadRegister(AXP2101_INTEN1 + i);
		printf("INT[%d] HEX:0x%X\n", i, val);
	}
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::EnableIRQ(uint64_t Option)
{
	return SetInterruptImpl(Option, true);
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::DisableIRQ(uint64_t Option)
{
	return SetInterruptImpl(Option, false);
}

/////////////////////////////////////////////////////////////////////////////////////

//IRQ STATUS 0
bool AXP2101::IsDropWarningLevel2IRQ(void)
{
	uint8_t mask = AXP2101_WARNING_LEVEL2_IRQ;
	if(m_IntRegisters[0] & mask) {
		return IsBitSet(m_StatusRegisters[0], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsDropWarningLevel1IRQ(void)
{
	uint8_t mask = AXP2101_WARNING_LEVEL1_IRQ;
	if(m_IntRegisters[0] & mask) {
		return IsBitSet(m_StatusRegisters[0], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsGaugeWdtTimeoutIRQ()
{
	uint8_t mask = AXP2101_WDT_TIMEOUT_IRQ;
	if(m_IntRegisters[0] & mask) {
		return IsBitSet(m_StatusRegisters[0], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsStateOfChargeLowIRQ(void)
{
	uint8_t mask = AXP2101_GAUGE_NEW_SOC_IRQ;
	if(m_IntRegisters[0] & mask) {
		return IsBitSet(m_StatusRegisters[0], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsBatChargerOverTemperatureIRQ(void)
{
	uint8_t mask = AXP2101_BAT_CHG_OVER_TEMP_IRQ;
	if(m_IntRegisters[0] & mask) {
		return IsBitSet(m_StatusRegisters[0], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsBatChargerUnderTemperatureIRQ(void)
{
	uint8_t mask = AXP2101_BAT_CHG_UNDER_TEMP_IRQ;
	if(m_IntRegisters[0] & mask) {
		return IsBitSet(m_StatusRegisters[0], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsBatWorkOverTemperatureIRQ(void)
{
	uint8_t mask = AXP2101_BAT_NOR_OVER_TEMP_IRQ;
	if(m_IntRegisters[0] & mask) {
		return IsBitSet(m_StatusRegisters[0], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsBatWorkUnderTemperatureIRQ(void)
{
	uint8_t mask = AXP2101_BAT_NOR_UNDER_TEMP_IRQ;
	if(m_IntRegisters[0] & mask) {
		return IsBitSet(m_StatusRegisters[0], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

//IRQ STATUS 1
bool AXP2101::IsVbusInsertIRQ(void)
{
	uint8_t mask = AXP2101_VBUS_INSERT_IRQ >> 8;
	if(m_IntRegisters[1] & mask) {
		return IsBitSet(m_StatusRegisters[1], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsVbusRemoveIRQ(void)
{
	uint8_t mask = AXP2101_VBUS_REMOVE_IRQ >> 8;
	if(m_IntRegisters[1] & mask) {
		return IsBitSet(m_StatusRegisters[1], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsBatInsertIRQ(void)
{
	uint8_t mask = AXP2101_BAT_INSERT_IRQ >> 8;
	if(m_IntRegisters[1] & mask) {
		return IsBitSet(m_StatusRegisters[1], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsBatRemoveIRQ(void)
{
	uint8_t mask = AXP2101_BAT_REMOVE_IRQ >> 8;
	if(m_IntRegisters[1] & mask) {
		return IsBitSet(m_StatusRegisters[1], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsPekeyShortPressIRQ(void)
{
	uint8_t mask = AXP2101_PKEY_SHORT_IRQ >> 8;
	if(m_IntRegisters[1] & mask) {
		return IsBitSet(m_StatusRegisters[1], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsPekeyLongPressIRQ(void)
{
	uint8_t mask = AXP2101_PKEY_LONG_IRQ >> 8;
	if(m_IntRegisters[1] & mask) {
		return IsBitSet(m_StatusRegisters[1], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsPekeyNegativeIRQ(void)
{
	uint8_t mask = AXP2101_PKEY_NEGATIVE_IRQ >> 8;
	if(m_IntRegisters[1] & mask) {
		return IsBitSet(m_StatusRegisters[1], mask);
	}
	return false;
}

bool AXP2101::IsPekeyPositiveIRQ(void)
{
	uint8_t mask = AXP2101_PKEY_POSITIVE_IRQ >> 8;
	if(m_IntRegisters[1] & mask) {
		return IsBitSet(m_StatusRegisters[1], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

//IRQ STATUS 2
bool AXP2101::IsWdtExpireIRQ(void)
{
	uint8_t mask = AXP2101_WDT_EXPIRE_IRQ >> 16;
	if(m_IntRegisters[2] & mask) {
		return IsBitSet(m_StatusRegisters[2], mask);
	}
	return false;
}


bool AXP2101::IsLdoOverCurrentIRQ(void)
{
	uint8_t mask = AXP2101_LDO_OVER_CURR_IRQ >> 16;
	if(m_IntRegisters[2] & mask) {
		return IsBitSet(m_StatusRegisters[2], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsBatfetOverCurrentIRQ(void)
{
	uint8_t mask = AXP2101_BATFET_OVER_CURR_IRQ >> 16;
	if(m_IntRegisters[2] & mask) {
		return IsBitSet(m_StatusRegisters[2], mask);
	}
	return false;
}


bool AXP2101::IsBatChargeDoneIRQ(void)
{
	uint8_t mask = AXP2101_BAT_CHG_DONE_IRQ >> 16;
	if(m_IntRegisters[2] & mask) {
		return IsBitSet(m_StatusRegisters[2], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsBatChargeStartIRQ(void)
{
	uint8_t mask = AXP2101_BAT_CHG_START_IRQ >> 16;
	if(m_IntRegisters[2] & mask) {
		return IsBitSet(m_StatusRegisters[2], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsBatDieOverTemperatureIRQ(void)
{
	uint8_t mask = AXP2101_DIE_OVER_TEMP_IRQ >> 16;
	if(m_IntRegisters[2] & mask) {
		return IsBitSet(m_StatusRegisters[2], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsChargeOverTimeoutIRQ(void)
{
	uint8_t mask = AXP2101_CHARGER_TIMER_IRQ >> 16;
	if(m_IntRegisters[2] & mask) {
		return IsBitSet(m_StatusRegisters[2], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::IsBatOverVoltageIRQ(void)
{
	uint8_t mask = AXP2101_BAT_OVER_VOL_IRQ >> 16;
	if(m_IntRegisters[2] & mask) {
		return IsBitSet(m_StatusRegisters[2], mask);
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t AXP2101::GetChipID(void)
{
	return ReadRegister(AXP2101_IC_TYPE);
}

// PROTECTED BELOW THIS

/////////////////////////////////////////////////////////////////////////////////////

uint16_t AXP2101::GetPowerChannelVoltage(uint8_t Channel)
{
	switch(Channel) {
		case AXP2101_DCDC1:
			return GetDC1Voltage();
		case AXP2101_DCDC2:
			return GetDC2Voltage();
		case AXP2101_DCDC3:
			return GetDC3Voltage();
		case AXP2101_DCDC4:
			return GetDC4Voltage();
		case AXP2101_DCDC5:
			return GetDC5Voltage();
		case AXP2101_ALDO1:
			return GetALDO1Voltage();
		case AXP2101_ALDO2:
			return GetALDO2Voltage();
		case AXP2101_ALDO3:
			return GetALDO3Voltage();
		case AXP2101_ALDO4:
			return GetALDO4Voltage();
		case AXP2101_BLDO1:
			return GetBLDO1Voltage();
		case AXP2101_BLDO2:
			return GetBLDO2Voltage();
		case AXP2101_DLDO1:
			return GetDLDO1Voltage();
		case AXP2101_DLDO2:
			return GetDLDO2Voltage();
		case AXP2101_VBACKUP:
			return GetButtonBatteryVoltage();
		default:
			break;
	}
	return 0;
}

/////////////////////////////////////////////////////////////////////////////////////

bool inline AXP2101::EnablePowerOutput(uint8_t Channel)
{
	switch(Channel) {
		case AXP2101_DCDC1:
			return EnableDC1();
		case AXP2101_DCDC2:
			return EnableDC2();
		case AXP2101_DCDC3:
			return EnableDC3();
		case AXP2101_DCDC4:
			return EnableDC4();
		case AXP2101_DCDC5:
			return EnableDC5();
		case AXP2101_ALDO1:
			return EnableALDO1();
		case AXP2101_ALDO2:
			return EnableALDO2();
		case AXP2101_ALDO3:
			return EnableALDO3();
		case AXP2101_ALDO4:
			return EnableALDO4();
		case AXP2101_BLDO1:
			return EnableBLDO1();
		case AXP2101_BLDO2:
			return EnableBLDO2();
		case AXP2101_DLDO1:
			return EnableDLDO1();
		case AXP2101_DLDO2:
			return EnableDLDO2();
		case AXP2101_VBACKUP:
			return EnableButtonBatteryCharge();
		default:
			break;
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool inline AXP2101::DisablePowerOutput(uint8_t Channel)
{
	if(GetProtectedChannel(Channel)) {
		ESP_LOGE(_TAG, "Failed to disable the power channel, the power channel has been protected");
		return false;
	}
	switch(Channel) {
		case AXP2101_DCDC1:
			return DisableDC1();
		case AXP2101_DCDC2:
			return DisableDC2();
		case AXP2101_DCDC3:
			return DisableDC3();
		case AXP2101_DCDC4:
			return DisableDC4();
		case AXP2101_DCDC5:
			return DisableDC5();
		case AXP2101_ALDO1:
			return DisableALDO1();
		case AXP2101_ALDO2:
			return DisableALDO2();
		case AXP2101_ALDO3:
			return DisableALDO3();
		case AXP2101_ALDO4:
			return DisableALDO4();
		case AXP2101_BLDO1:
			return DisableBLDO1();
		case AXP2101_BLDO2:
			return DisableBLDO2();
		case AXP2101_DLDO1:
			return DisableDLDO1();
		case AXP2101_DLDO2:
			return DisableDLDO2();
		case AXP2101_VBACKUP:
			return DisableButtonBatteryCharge();
		case AXP2101_CPULDO:
			return DisableCPUSLDO();
		default:
			break;
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool inline AXP2101::IsPowerChannelEnable(uint8_t Channel)
{
	switch(Channel) {
		case AXP2101_DCDC1:
			return IsEnabledDC1();
		case AXP2101_DCDC2:
			return IsEnabledDC2();
		case AXP2101_DCDC3:
			return IsEnabledDC3();
		case AXP2101_DCDC4:
			return IsEnabledDC4();
		case AXP2101_DCDC5:
			return IsEnabledDC5();
		case AXP2101_ALDO1:
			return IsEnabledALDO1();
		case AXP2101_ALDO2:
			return IsEnabledALDO2();
		case AXP2101_ALDO3:
			return IsEnabledALDO3();
		case AXP2101_ALDO4:
			return IsEnabledALDO4();
		case AXP2101_BLDO1:
			return IsEnabledBLDO1();
		case AXP2101_BLDO2:
			return IsEnabledBLDO2();
		case AXP2101_DLDO1:
			return IsEnabledDLDO1();
		case AXP2101_DLDO2:
			return IsEnabledDLDO2();
		case AXP2101_VBACKUP:
			return IsEnabledButtonBatteryCharge();
		case AXP2101_CPULDO:
			return IsEnabledCPUSLDO();
		default:
			break;
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool inline AXP2101::SetPowerChannelVoltage(uint8_t Channel, uint16_t millivolt)
{
	if(GetProtectedChannel(Channel)) {
		ESP_LOGE(_TAG, "Failed to set the power channel, the power channel has been protected");
		return false;
	}
	switch(Channel) {
		case AXP2101_DCDC1:
			return SetDC1Voltage(millivolt);
		case AXP2101_DCDC2:
			return SetDC2Voltage(millivolt);
		case AXP2101_DCDC3:
			return SetDC3Voltage(millivolt);
		case AXP2101_DCDC4:
			return SetDC4Voltage(millivolt);
		case AXP2101_DCDC5:
			return SetDC5Voltage(millivolt);
		case AXP2101_ALDO1:
			return SetALDO1Voltage(millivolt);
		case AXP2101_ALDO2:
			return SetALDO2Voltage(millivolt);
		case AXP2101_ALDO3:
			return SetALDO3Voltage(millivolt);
		case AXP2101_ALDO4:
			return SetALDO4Voltage(millivolt);
		case AXP2101_BLDO1:
			return SetBLDO1Voltage(millivolt);
		case AXP2101_BLDO2:
			return SetBLDO1Voltage(millivolt);
		case AXP2101_DLDO1:
			return SetDLDO1Voltage(millivolt);
		case AXP2101_DLDO2:
			return SetDLDO1Voltage(millivolt);
		case AXP2101_VBACKUP:
			return SetButtonBatteryChargeVoltage(millivolt);
		case AXP2101_CPULDO:
			return SetCPUSLDOVoltage(millivolt);
		default:
			break;
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::InitImpl(void)
{
	if(GetChipID() == AXP2101_CHIP_ID) {
		DisableTSPinMeasure();  //Disable NTC temperature detection by default
		return true;
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

bool AXP2101::SetInterruptImpl(uint32_t Options, bool Enable)
{
	int res = 0;
	uint8_t data = 0, value = 0;
	ESP_LOGD(_TAG, "%s - HEX:0x %lx \n", Enable ? "ENABLE" : "DISABLE", Options);
	if(Options & 0x0000FF) {
		value = Options & 0xFF;
		// ESP_LOGD(_TAG, "Write INT0: %x\n", value);
		data = ReadRegister(AXP2101_INTEN1);
		m_IntRegisters[0] = Enable ? (data | value) : (data & (~value));
		res |= WriteRegister(AXP2101_INTEN1, m_IntRegisters[0]);
	}
	if(Options & 0x00FF00) {
		value = Options >> 8;
		// ESP_LOGD(_TAG, "Write INT1: %x\n", value);
		data = ReadRegister(AXP2101_INTEN2);
		m_IntRegisters[1] = Enable ? (data | value) : (data & (~value));
		res |= WriteRegister(AXP2101_INTEN2, m_IntRegisters[1]);
	}
	if(Options & 0xFF0000) {
		value = Options >> 16;
		// ESP_LOGD(_TAG, "Write INT2: %x\n", value);
		data = ReadRegister(AXP2101_INTEN3);
		m_IntRegisters[2] = Enable ? (data | value) : (data & (~value));
		res |= WriteRegister(AXP2101_INTEN3, m_IntRegisters[2]);
	}
	return res == 0;
}

/////////////////////////////////////////////////////////////////////////////////////

float AXP2101::ResistanceToTemperature(float resistance, float SteinhartA, float SteinhartB, float SteinhartC)
{
	float ln_r = log(resistance);
	float t_inv = SteinhartA + SteinhartB * ln_r + SteinhartC * pow(ln_r, 3);
	return (1.0f / t_inv) - 273.15f;
}
