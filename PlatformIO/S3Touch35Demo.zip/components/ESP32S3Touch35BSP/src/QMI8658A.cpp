/*
 *              Copyright (c) 2020-2021 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * Driver code for the QMI8658 IMU
 * 
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original WeatherClock
 *
 */

#include "QMI8658A.h"

/////////////////////////////////////////////////////////////////////////////////////

QMI8658A::QMI8658A(void) :
	m_Address(QMI8658_L_SLAVE_ADDRESS),  // default for SD0/SA0 low, 0x6A if high
	m_AccelRange(ACC_RANGE_2G),
	m_GyroRange(GYR_RANGE_16DPS),
	m_AccelODR(ACC_ODR_NORM_250),
	m_GyroODR(GYRO_ODR_NORM_250),
	m_SensorState(SENSOR_STATE_DEFAULT),
	m_AccelLPF(LPF_MODE_0)
{
  CalculateScales();
}

/////////////////////////////////////////////////////////////////////////////////////

void QMI8658A::Write(uint8_t Register, uint8_t Data)
{
uint8_t Buffer[2] = {Register, Data };

  i2c_master_transmit(m_hDevice, Buffer, 2, -1);
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t QMI8658A::Read(uint8_t Register)
{
uint8_t Value;

  i2c_master_transmit_receive(m_hDevice, &Register, 1, &Value, 1, -1);
	return Value;
}

/////////////////////////////////////////////////////////////////////////////////////

// Writes data to CTRL9 (command register) and waits for ACK.
void QMI8658A::CTRL9_Write(uint8_t Command)
{
uint8_t Timeout = 0, Data = Command;
uint8_t Register = QMI8658_STATUSINT, Buffer[2] = {QMI8658_CTRL9, Data };

  i2c_master_transmit(m_hDevice, Buffer, 2, -1);
  do{
    ++Timeout;
    esp_rom_delay_us(5);
    i2c_master_transmit_receive(m_hDevice, &Register, 1, &Data, 1, -1);
  }
	while((Data & 0x80) == 0x00 && Timeout);              // Wait for completion
  if(Timeout == 0) ESP_LOGI(_TAG, "CTRL9 Timedout");
  Buffer[1] = 0;
  i2c_master_transmit(m_hDevice, Buffer, 2, -1);
}

/////////////////////////////////////////////////////////////////////////////////////

void QMI8658A::Initialise(i2c_master_bus_handle_t hi2cBus)
{
i2c_device_config_t i2c_dev_conf;
uint8_t Register = QMI8658_WHO_AM_I, Buffer[2];
 
  memset(&i2c_dev_conf, 0, sizeof(i2c_device_config_t));
  i2c_dev_conf.dev_addr_length = I2C_ADDR_BIT_LEN_7;
  i2c_dev_conf.device_address = m_Address;
  i2c_dev_conf.scl_speed_hz = 400 * 1000;
  i2c_master_bus_add_device(hi2cBus, &i2c_dev_conf, &m_hDevice);

  i2c_master_transmit_receive(m_hDevice, &Register, 1, &Buffer[0], 1, -1);
  Register = QMI8658_REVISION_ID;
  i2c_master_transmit_receive(m_hDevice, &Register, 1, &Buffer[1], 1, -1);
	ESP_LOGI(_TAG, "QMI8658 Device ID:0x%X Rev:0x%X", Buffer[0], Buffer[1]);  // Get chip id & rev
	SetState(SENSOR_STATE_RUNNING);
//	Write(QMI8658_CTRL8, 0xC0);
	SetAccelRange(m_AccelRange);
	SetAccelODR(m_AccelODR);
	SetAccelLPF(LPF_MODE_0);
	SetGyroRange(m_GyroRange);
	SetGyroODR(m_GyroODR);
	SetGyroLPF(LPF_MODE_3);
  CalculateScales();
}

/////////////////////////////////////////////////////////////////////////////////////

void QMI8658A::CalculateScales(void)
{
	switch(m_AccelRange) {
		// Possible accelerometer scales (and their register bit settings) are:
		// 2 Gs (00), 4 Gs (01), 8 Gs (10), and 16 Gs  (11).
		// Here's a bit of an algorith to calculate DPS/(ADC tick) based on that
		// 2-bit value:
		case ACC_RANGE_2G:
			m_AccelScale =  (float)(2 << ACC_RANGE_2G) * QMI8658_SIXTEENBIT_SCALER;
			break;
		case ACC_RANGE_4G:
			m_AccelScale = (float)(2 << ACC_RANGE_4G) * QMI8658_SIXTEENBIT_SCALER;
			break;
		case ACC_RANGE_8G:
			m_AccelScale = (float)(2 << ACC_RANGE_8G) * QMI8658_SIXTEENBIT_SCALER;
			break;
		case ACC_RANGE_16G:
			m_AccelScale = (float)(2 << ACC_RANGE_16G) * QMI8658_SIXTEENBIT_SCALER;
			break;
	}
	switch(m_GyroRange) {
		// Possible gyro scales (and their register bit settings) are:
		// 250 DPS (00), 500 DPS (01), 1000 DPS (10), and 2000 DPS  (11).
		// Here's a bit of an algorith to calculate DPS/(ADC tick) based on that
		// 2-bit value:
		case GYR_RANGE_16DPS:
			m_GyroScale = 16.0 / 32768.0;
			break;
		case GYR_RANGE_32DPS:
			m_GyroScale = 32.0 / 32768.0;
			break;
		case GYR_RANGE_64DPS:
			m_GyroScale = 64.0 / 32768.0;
			break;
		case GYR_RANGE_128DPS:
			m_GyroScale = 128.0 / 32768.0;
			break;
		case GYR_RANGE_256DPS:
			m_GyroScale = 256.0 / 32768.0;
			break;
		case GYR_RANGE_512DPS:
			m_GyroScale = 512.0 / 32768.0;
			break;
		case GYR_RANGE_1024DPS:
			m_GyroScale = 1024.0 / 32768.0;
			break;
	}
}

/////////////////////////////////////////////////////////////////////////////////////

// Set new state of QMI8658.
void QMI8658A::SetState(SensorState_e State)
{
uint8_t ctrl1;

	switch(State) {
		case SENSOR_STATE_RUNNING:
			ctrl1 = Read(QMI8658_CTRL1);
			ctrl1 &= 0xFE;			                // enable 2MHz oscillator
			ctrl1 |= 0x40;			                // enable auto address increment for fast block reads
			Write(QMI8658_CTRL1, ctrl1);
			// enable high speed internal clock, acc and gyro in full mode, and disable syncSample mode
			Write(QMI8658_CTRL7, 0x43);
			Write(QMI8658_CTRL6, 0x00);			// disable AttitudeEngine Motion On Demand
			break;
		case SENSOR_STATE_POWER_DOWN:
			Write(QMI8658_CTRL7, 0x00);			// disable high speed internal clock, acc and gyro powered down
			ctrl1 = Read(QMI8658_CTRL1);
			ctrl1 |= 0x01;			                // disable 2MHz oscillator
			Write(QMI8658_CTRL1, ctrl1);
			break;
		case SENSOR_STATE_LOCKING:
			ctrl1 = Read(QMI8658_CTRL1);
			ctrl1 &= 0xFE;			                // enable 2MHz oscillator
			ctrl1 |= 0x40;			                // enable auto address increment for fast block reads
			Write(QMI8658_CTRL1, ctrl1);
			// enable high speed internal clock, acc and gyro in full mode, and enable syncSample mode
			Write(QMI8658_CTRL7, 0x83);
			Write(QMI8658_CTRL6, 0x00);			// disable AttitudeEngine Motion On Demand
			Write(QMI8658_CAL1_L, 0x01);			// disable internal AHB clock gating:
			CTRL9_Write(0x12);
			Write(QMI8658_CAL1_L, 0x00);			// re-enable clock gating
			CTRL9_Write(0x12);
			break;
		default:
			break;
	}
	m_SensorState = State;
}

/////////////////////////////////////////////////////////////////////////////////////

// Set output data rate (ODR) of accelerometer.
void QMI8658A::SetAccelODR(AccelODR_e ODR)
{
	if(m_SensorState != SENSOR_STATE_DEFAULT){  // If the device is not in the default state
		uint8_t ctrl2 = Read(QMI8658_CTRL2);
		ctrl2 &= ~QMI8658_AODR_MASK;  // clear previous setting
		ctrl2 |= ODR;                 // OR in new setting
		Write(QMI8658_CTRL2, ctrl2);
	}
	m_AccelODR = ODR;
}

/////////////////////////////////////////////////////////////////////////////////////

// Set output data rate (ODR) of gyro.
void QMI8658A::SetGyroODR(GyroODR_e ODR)
{
	if(m_SensorState != SENSOR_STATE_DEFAULT) {
		uint8_t ctrl3 = Read(QMI8658_CTRL3);
		ctrl3 &= ~QMI8658_GODR_MASK;  // clear previous setting
		ctrl3 |= ODR;                 // OR in new setting
		Write(QMI8658_CTRL3, ctrl3);
	}
	m_GyroODR = ODR;
}

/////////////////////////////////////////////////////////////////////////////////////

// Set scale of accelerometer output.
void QMI8658A::SetAccelRange(AccelRange_e Range)
{
	if(m_SensorState != SENSOR_STATE_DEFAULT) {
		uint8_t ctrl2 = Read(QMI8658_CTRL2);
		ctrl2 &= ~QMI8658_ASCALE_MASK;            // clear previous setting
		ctrl2 |= Range << QMI8658_ASCALE_OFFSET;  // OR in new setting
		Write(QMI8658_CTRL2, ctrl2);
	}
	m_AccelRange = Range;
}

/////////////////////////////////////////////////////////////////////////////////////

// Set scale of gyro output.
void QMI8658A::SetGyroRange(GyroRange_e Range)
{
	if(m_SensorState != SENSOR_STATE_DEFAULT) {
		uint8_t ctrl3 = Read(QMI8658_CTRL3);
		ctrl3 &= ~QMI8658_GSCALE_MASK;            // clear previous setting
		ctrl3 |= Range << QMI8658_GSCALE_OFFSET;  // OR in new setting
		Write(QMI8658_CTRL3, ctrl3);
	}
	m_GyroRange = Range;
}

/////////////////////////////////////////////////////////////////////////////////////

// Set new low-pass filter value for accelerometer
void QMI8658A::SetAccelLPF(LPF_e LPF)
{
	if(m_SensorState != SENSOR_STATE_DEFAULT) {
		uint8_t ctrl5 = Read(QMI8658_CTRL5);
		ctrl5 &= !QMI8658_ALPF_MASK;
		ctrl5 |= LPF << QMI8658_ALPF_OFFSET;
		ctrl5 |= 0x01;  // turn on acc low pass filter
		Write(QMI8658_CTRL5, ctrl5);
	}
	m_AccelLPF = LPF;
}

/////////////////////////////////////////////////////////////////////////////////////

// Set new low-pass filter value for gyro
void QMI8658A::SetGyroLPF(LPF_e LPF)
{
	if(m_SensorState != SENSOR_STATE_DEFAULT) {
		uint8_t ctrl5 = Read(QMI8658_CTRL5);
		ctrl5 &= !QMI8658_GLPF_MASK;
		ctrl5 |= LPF << QMI8658_GLPF_OFFSET;
		ctrl5 |= 0x10;  // turn on gyro low pass filter
		Write(QMI8658_CTRL5, ctrl5);
	}
}

/////////////////////////////////////////////////////////////////////////////////////

void QMI8658A::ReadAll(IMUdata_t *pAccel, IMUdata_t *pGyro)
{
uint8_t Register = QMI8658_AX_L, Buffer[12];

  while((Read(QMI8658_STATUSINT) & 0x01) == 0x01) esp_rom_delay_us(3);    // wait for leading edge of ready
  while((Read(QMI8658_STATUSINT) & 0x01) == 0x00) esp_rom_delay_us(3);
  i2c_master_transmit_receive(m_hDevice, (const uint8_t *)&Register, 1, Buffer, 12, -1);
  DecodeAccelerometer(Buffer, pAccel);
  DecodeGyroscope(&Buffer[6], pGyro);
}

/////////////////////////////////////////////////////////////////////////////////////

void QMI8658A::ReadAccelerometer(IMUdata_t *pAccel)
{
uint8_t Register = QMI8658_AX_L, Buffer[6];

  while((Read(QMI8658_STATUSINT) & 0x01) == 0x01) esp_rom_delay_us(3);    // wait for leading edge of ready
  while((Read(QMI8658_STATUSINT) & 0x01) == 0x00) esp_rom_delay_us(3);
  i2c_master_transmit_receive(m_hDevice, (const uint8_t *)&Register, 1, Buffer, 6, -1);
  DecodeAccelerometer(Buffer, pAccel);
}

/////////////////////////////////////////////////////////////////////////////////////

void QMI8658A::ReadGyroscope(IMUdata_t *pGyro)
{
uint8_t Register = QMI8658_GX_L, Buffer[6];

  while((Read(QMI8658_STATUSINT) & 0x01) == 0x01) esp_rom_delay_us(3);    // wait for leading edge of ready
  while((Read(QMI8658_STATUSINT) & 0x01) == 0x00) esp_rom_delay_us(3);
  i2c_master_transmit_receive(m_hDevice, (const uint8_t *)&Register, 1, Buffer, 6, -1);
  DecodeGyroscope(Buffer, pGyro);
}

/////////////////////////////////////////////////////////////////////////////////////

void QMI8658A::ReadMagnatometer(IMUdata_t *pMag)
{
uint8_t Buffer[6] = {0};

  DecodeMagnatometer(Buffer, pMag);
}

/////////////////////////////////////////////////////////////////////////////////////

void QMI8658A::DecodeAccelerometer(uint8_t Buffer[6], IMUdata_t *pAccel)
{
int16_t Reading;

  Reading = Buffer[1];
  Reading <<= 8;
  Reading |= Buffer[0];
	pAccel->x = (float)Reading * m_AccelScale;
  Reading = Buffer[3];
  Reading <<= 8;
  Reading |= Buffer[2];
	pAccel->y = (float)Reading * m_AccelScale;
  Reading = Buffer[5];
  Reading <<= 8;
  Reading |= Buffer[4];
	pAccel->z = (float)Reading * m_AccelScale;
}

/////////////////////////////////////////////////////////////////////////////////////

void QMI8658A::DecodeGyroscope(uint8_t Buffer[6], IMUdata_t *pGyro)
{
int16_t Reading;

  Reading = Buffer[1];
  Reading <<= 8;
  Reading |= Buffer[0];
	pGyro->x = (float)Reading * m_GyroScale;
  Reading = Buffer[3];
  Reading <<= 8;
  Reading |= Buffer[2];
	pGyro->y = (float)Reading * m_GyroScale;
  Reading = Buffer[5];
  Reading <<= 8;
  Reading |= Buffer[4];
	pGyro->z = (float)Reading * m_GyroScale;

}

/////////////////////////////////////////////////////////////////////////////////////

void QMI8658A::DecodeMagnatometer(uint8_t Buffer[6], IMUdata_t *pMag)
{
int16_t Reading;

  Reading = Buffer[1];
  Reading <<= 8;
  Reading |= Buffer[0];
	pMag->x = (float)Reading * m_GyroScale;
  Reading = Buffer[3];
  Reading <<= 8;
  Reading |= Buffer[2];
	pMag->y = (float)Reading * m_GyroScale;
  Reading = Buffer[5];
  Reading <<= 8;
  Reading |= Buffer[4];
	pMag->z = (float)Reading * m_GyroScale;

}
