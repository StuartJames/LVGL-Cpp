/*
 *                LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#include "PCF85063.h"

/////////////////////////////////////////////////////////////////////////////////////

const unsigned char MonthStr[12][4] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov","Dec"};

/////////////////////////////////////////////////////////////////////////////////////

// Initiate Normal Mode, RTC Run, NO reset, No correction , 24hr format, Internal load capacitane 12.5pf
void PCF85063::Initialise(i2c_master_bus_handle_t hi2cBus)
{
uint8_t Buffer[2] = {RTC_CTRL_1_ADDR, RTC_CTRL_1_DEFAULT | RTC_CTRL_1_CAP_SEL };
i2c_device_config_t i2c_dev_conf;

  memset(&i2c_dev_conf, 0, sizeof(i2c_device_config_t));
  i2c_dev_conf.dev_addr_length = I2C_ADDR_BIT_LEN_7;
  i2c_dev_conf.device_address = PCF85063_ADDRESS;
  i2c_dev_conf.scl_speed_hz = 400 * 1000;
  i2c_master_bus_add_device(hi2cBus, &i2c_dev_conf, &m_hDevice);

  i2c_master_transmit(m_hDevice, Buffer, 2, -1);
/*  DateTime_t TestTime = {0};
	TestTime.year = 2024;
	TestTime.month = 9;
	TestTime.day = 20;
	TestTime.dotw = 5;
	TestTime.hour = 9;
	TestTime.minute = 50;
	TestTime.second = 0;
	PCF85063_Set_All(TestTime);*/
}

/////////////////////////////////////////////////////////////////////////////////////

void PCF85063::Reset()
{
uint8_t Buffer[2] = {RTC_CTRL_1_ADDR, RTC_CTRL_1_DEFAULT | RTC_CTRL_1_CAP_SEL | RTC_CTRL_1_SR };

  i2c_master_transmit(m_hDevice, Buffer, 2, -1);
}

/////////////////////////////////////////////////////////////////////////////////////

void PCF85063::Read(DateTime_t *pTime)
{
uint8_t Register = RTC_SECOND_ADDR, Buffer[7] = {0};

  i2c_master_transmit_receive(m_hDevice, &Register, 1, Buffer, 7, -1);
	pTime->second = BCDToDec(Buffer[0] & 0x7F);
	pTime->minute = BCDToDec(Buffer[1] & 0x7F);
	pTime->hour = BCDToDec(Buffer[2] & 0x3F);
	pTime->day = BCDToDec(Buffer[3] & 0x3F);
	pTime->dotw = BCDToDec(Buffer[4] & 0x07);
	pTime->month = BCDToDec(Buffer[5] & 0x1F);
	pTime->year = BCDToDec(Buffer[6])+YEAR_OFFSET;
}

/////////////////////////////////////////////////////////////////////////////////////

void PCF85063::Read(void)
{
  Read(&m_DateTime);
}

/////////////////////////////////////////////////////////////////////////////////////

void PCF85063::Read(tm *pTime)
{

  Read(&m_DateTime);
	pTime->tm_sec = m_DateTime.second;
	pTime->tm_min = m_DateTime.minute;
	pTime->tm_hour = m_DateTime.hour;
	pTime->tm_mday = m_DateTime.day;
	pTime->tm_wday = m_DateTime.dotw;
	pTime->tm_mon = m_DateTime.month;
	pTime->tm_year = m_DateTime.year;
}

/////////////////////////////////////////////////////////////////////////////////////

void PCF85063::SetTime(DateTime_t Time)
{
uint8_t Buffer[4] = {
  RTC_SECOND_ADDR,
	DecToBcd(Time.second),
	DecToBcd(Time.minute),
	DecToBcd(Time.hour)
};

  ESP_ERROR_CHECK(i2c_master_transmit(m_hDevice, Buffer, 4, -1));
}

/////////////////////////////////////////////////////////////////////////////////////

void PCF85063::SetDate(DateTime_t Time)
{
uint8_t Buffer[5] = {
  RTC_DAY_ADDR,
	DecToBcd(Time.day),
	DecToBcd(Time.dotw),
	DecToBcd(Time.month),
	DecToBcd(Time.year - YEAR_OFFSET)
};

  ESP_ERROR_CHECK(i2c_master_transmit(m_hDevice, Buffer, 5, -1));
}

/////////////////////////////////////////////////////////////////////////////////////

void PCF85063::SetClock(DateTime_t Time)
{
uint8_t Buffer[8] = {
  RTC_SECOND_ADDR,
	DecToBcd(Time.second),
	DecToBcd(Time.minute),
	DecToBcd(Time.hour),
	DecToBcd(Time.day),
	DecToBcd(Time.dotw),
	DecToBcd(Time.month),
	DecToBcd(Time.year - YEAR_OFFSET)
};

  ESP_ERROR_CHECK(i2c_master_transmit(m_hDevice, Buffer, 8, -1));
}

/////////////////////////////////////////////////////////////////////////////////////

void PCF85063::SetClock(tm Time)
{
uint8_t Buffer[8] = {
  RTC_SECOND_ADDR,
	DecToBcd(Time.tm_sec),
	DecToBcd(Time.tm_min),
	DecToBcd(Time.tm_hour),
	DecToBcd(Time.tm_yday),
	DecToBcd(Time.tm_wday),
	DecToBcd(Time.tm_mon),
	DecToBcd(Time.tm_year - YEAR_OFFSET)
};

  ESP_ERROR_CHECK(i2c_master_transmit(m_hDevice, Buffer, 8, -1));
}

/////////////////////////////////////////////////////////////////////////////////////

void PCF85063::EnableAlarm()
{
uint8_t Buffer[2] = { RTC_CTRL_2_ADDR, RTC_CTRL_2_DEFAULT | RTC_CTRL_2_AIE};

	Buffer[1] &= ~RTC_CTRL_2_AF;
  ESP_ERROR_CHECK(i2c_master_transmit(m_hDevice, Buffer, 2, -1));
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t PCF85063::GetAlarmFlag()
{
uint8_t Register = RTC_CTRL_2_ADDR, Value = 0;

  ESP_ERROR_CHECK(i2c_master_transmit_receive(m_hDevice, (const uint8_t *)&Register, 1, &Value, 1, -1));
	//printf("Value = 0x%x",Value);
	Value &= RTC_CTRL_2_AF | RTC_CTRL_2_AIE;
	return Value;
}

/////////////////////////////////////////////////////////////////////////////////////

void PCF85063::SetAlarm(DateTime_t Time)
{
	uint8_t Buffer[6] = {
    RTC_SECOND_ALARM,
		static_cast<uint8_t>(DecToBcd(Time.second) & ~RTC_ALARM),	
		static_cast<uint8_t>(DecToBcd(Time.minute) & ~RTC_ALARM),	
		static_cast<uint8_t>(DecToBcd(Time.hour) & ~RTC_ALARM),
		//decToBcd(time.day) & (uint8_t)(~RTC_ALARM),
		//decToBcd(time.dotw) & (uint8_t)(~RTC_ALARM)
		RTC_ALARM, 	//disalbe day
		RTC_ALARM	//disalbe weekday
	};
  ESP_ERROR_CHECK(i2c_master_transmit(m_hDevice, Buffer, 6, -1));
}

/////////////////////////////////////////////////////////////////////////////////////

void PCF85063::ReadAlarm(DateTime_t *pTime)
{
uint8_t Register = RTC_SECOND_ALARM, Buffer[6] = {0};

  ESP_ERROR_CHECK(i2c_master_transmit_receive(m_hDevice, (const uint8_t *)&Register, 1, Buffer, 6, -1));
	pTime->second = BCDToDec(Buffer[0] & 0x7F);
	pTime->minute = BCDToDec(Buffer[1] & 0x7F);
	pTime->hour = BCDToDec(Buffer[2] & 0x3F);
	pTime->day = BCDToDec(Buffer[3] & 0x3F);
	pTime->dotw = BCDToDec(Buffer[4] & 0x07);
}


/////////////////////////////////////////////////////////////////////////////////////

uint8_t PCF85063::DecToBcd(int Val)
{
	return (uint8_t)((Val / 10 * 16) + (Val % 10));
}

/////////////////////////////////////////////////////////////////////////////////////

int PCF85063::BCDToDec(uint8_t Val)
{
	return (int)((Val / 16 * 10) + (Val % 16));
}

/////////////////////////////////////////////////////////////////////////////////////

void PCF85063::DateTimeStr(char *pString, DateTime_t Time)
{
	sprintf(pString, " %d/%d/%d  %d %d:%d:%d ", Time.year, Time.month, Time.day, Time.dotw, Time.hour, Time.minute, Time.second);
}