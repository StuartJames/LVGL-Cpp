/*
 *              Copyright (c) 2020-2021 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original WeatherClock
 *
 */

#pragma once

/////////////////////////////////////////////////////////////////////////////////////

#include <string.h>  // For memset
#include "driver/i2c_master.h"
#include <esp_log.h>

/////////////////////////////////////////////////////////////////////////////////////

#define QMI8658_L_SLAVE_ADDRESS (0x6B)
#define QMI8658_H_SLAVE_ADDRESS (0x6A)

#define QMI8658_WHO_AM_I    0x00  // device identifier
#define QMI8658_REVISION_ID 0x01
#define QMI8658_CTRL1       0x02  // SPI interface and sensor enable
#define QMI8658_CTRL2       0x03  // Accelerometer settings
#define QMI8658_CTRL3       0x04  // Gyro settings
#define QMI8658_CTRL4       0x05  // reserved (we don't use this)
#define QMI8658_CTRL5       0x06  // Low-pass filter settings
#define QMI8658_CTRL6       0x07  // AttitudeEngine settings (we don't use these)
#define QMI8658_CTRL7       0x08  // Sensor enable
#define QMI8658_CTRL8       0x09  // Motion detection control (not in current lib version)
#define QMI8658_CTRL9       0x0A  // Host commands (not in current lib version)

#define QMI8658_CAL1_L      0x0B  // calibration 1 register, lower bits
#define QMI8658_CAL1_H      0x0C  // calibration 1 register, higher bits
#define QMI8658_CAL2_L      0x0D  // calibration 2 register, lower bits
#define QMI8658_CAL2_H      0x0E  // calibration 2 register, higher bits
#define QMI8658_CAL3_L      0x0F  // calibration 3 register, lower bits
#define QMI8658_CAL3_H      0x10  // calibration 3 register, higher bits
#define QMI8658_CAL4_L      0x11  // calibration 4 register, lower bits
#define QMI8658_CAL4_H      0x12  // calibration 4 register, higher bits

#define QMI8658_TEMP_L      0x33  // lower bits of temperature data
#define QMI8658_TEMP_H      0x34  // upper bits of temperature data

#define QMI8658_STATUSINT   0x2D  // status + interrupt register
#define QMI8658_STATUS0     0x2E  // status 0
#define QMI8658_STATUS1     0x2F  // status 1 Command finished

#define QMI8658_AX_L        0x35  // lower bits of x-axis acceleration
#define QMI8658_AX_H        0x36  // upper bits of x-axis acceleration
#define QMI8658_AY_L        0x37  // lower bits of y-axis acceleration
#define QMI8658_AY_H        0x38  // upper bits of y-axis acceleration
#define QMI8658_AZ_L        0x39
#define QMI8658_AZ_H        0x3A
#define QMI8658_GX_L        0x3B  // lower bits of x-axis angular velocity
#define QMI8658_GX_H        0x3C  // upper bits of x-axis angular velocity
#define QMI8658_GY_L        0x3D
#define QMI8658_GY_H        0x3E
#define QMI8658_GZ_L        0x3F
#define QMI8658_GZ_H        0x40

#define QMI8658_AODR_MASK   0x0F    // bits in acc data rate are 1, rest are 0 (CTRL2)
#define QMI8658_GODR_MASK   0x0F    // bits in gyro data rate are 1, rest are 0 (CTRL3)
#define QMI8658_ASCALE_MASK 0x70  // bits in acc scale are 1, rest are 0
#define QMI8658_GSCALE_MASK 0x70  // bits in gyro scale are 1, rest are 0
#define QMI8658_ALPF_MASK   0x06    // bits in acc low pass filter setting
#define QMI8658_GLPF_MASK   0x60    // bits in gyro low pass filter setting
#define QMI8658_ASCALE_OFFSET 4   // offset to acc scale bits
#define QMI8658_GSCALE_OFFSET 4   // offset to gyro scale bits
#define QMI8658_ALPF_OFFSET 1     // offset to acc low pass filter bits
#define QMI8658_GLPF_OFFSET 5     // offset to gyro low pass filter bits

#define QMI8658_COMM_TIMEOUT 50  // communication timeout, in ms


// delay between refreshes of sensor data in us
// applies to individual sensor readings while in locking mode
// has no effect in running mode
#define QMI8658_REFRESH_DELAY 2000

// control clock gating (necessary to use data locking)
#define QMI8658_CTRL_CMD_AHB_CLOCK_GATING 0x12

#define QMI8658_SIXTEENBIT_SCALER 1.0f/32768.0f

/////////////////////////////////////////////////////////////////////////////////////

typedef enum {
	ACC_ODR_NORM_8000 = 0x0,
	ACC_ODR_NORM_4000,
	ACC_ODR_NORM_2000,
	ACC_ODR_NORM_1000,
	ACC_ODR_NORM_500,
	ACC_ODR_NORM_250,
	ACC_ODR_NORM_120,
	ACC_ODR_NORM_60,
	ACC_ODR_NORM_30,
	ACC_ODR_lp_128 = 0xC,
	ACC_ODR_lp_21,
	ACC_ODR_lp_11,
	ACC_ODR_lp_3,
} AccelODR_e;

typedef enum {
	GYRO_ODR_NORM_8000 = 0x0,
	GYRO_ODR_NORM_4000,
	GYRO_ODR_NORM_2000,
	GYRO_ODR_NORM_1000,
	GYRO_ODR_NORM_500,
	GYRO_ODR_NORM_250,
	GYRO_ODR_NORM_120,
	GYRO_ODR_NORM_60,
	GYRO_ODR_NORM_30
} GyroODR_e;

typedef enum {
	ACC_RANGE_2G = 0x0,
	ACC_RANGE_4G,
	ACC_RANGE_8G,
	ACC_RANGE_16G
} AccelRange_e;

typedef enum {
	GYR_RANGE_16DPS = 0x0,
	GYR_RANGE_32DPS,
	GYR_RANGE_64DPS,
	GYR_RANGE_128DPS,
	GYR_RANGE_256DPS,
	GYR_RANGE_512DPS,
	GYR_RANGE_1024DPS
} GyroRange_e;

typedef enum LPF_e{
	LPF_MODE_0 = 0x0,  //2.66% of ODR
	LPF_MODE_1 = 0x2,  //3.63% of ODR
	LPF_MODE_2 = 0x4,  //5.39% of ODR
	LPF_MODE_3 = 0x6   //13.37% of ODR
} LPF_e;

typedef enum SensorState_e{
	SENSOR_STATE_DEFAULT,
	SENSOR_STATE_POWER_DOWN,
	SENSOR_STATE_RUNNING,
	SENSOR_STATE_LOCKING
} SensorState_e;

typedef struct IMUdata_t {
	float x;
	float y;
	float z;
} IMUdata_t;

/////////////////////////////////////////////////////////////////////////////////////

class QMI8658A
{
public:
							QMI8658A();
	void 				Initialise(i2c_master_bus_handle_t hi2cBus);
	void 				SetAccelODR(AccelODR_e ODR);
	void 				SetGyroODR(GyroODR_e ODR);
	void 				SetAccelRange(AccelRange_e Range);
	void 				SetGyroRange(GyroRange_e Range);
	void 				SetAccelLPF(LPF_e LPF);
	void 				SetGyroLPF(LPF_e LPF);
	void 				SetState(SensorState_e State);
  void        CalculateScales(void);
	void 				ReadAll(IMUdata_t *pAccel, IMUdata_t *pGyro);
	void 				ReadAccelerometer(IMUdata_t *pAccel);
	void 				ReadGyroscope(IMUdata_t *pGyro);
	void 				ReadMagnatometer(IMUdata_t *pMag);

private:
	void 				Write(uint8_t Register, uint8_t Data);
	uint8_t 		Read(uint8_t Register);
	void 				CTRL9_Write(uint8_t Command);
  void        DecodeAccelerometer(uint8_t Buffer[6], IMUdata_t *pAccel);
  void        DecodeGyroscope(uint8_t Buffer[6], IMUdata_t *pGyro);
  void        DecodeMagnatometer(uint8_t Buffer[6], IMUdata_t *pMag);

  i2c_master_dev_handle_t m_hDevice;
	float 				m_GyroScale;
	float 				m_AccelScale;
	uint8_t 			m_Readings[12];
	uint32_t 			m_Timestamp;  // timestamp in arduino micros() time
	uint8_t 			m_Address;  // default for SD0/SA0 low, 0x6A if high
	AccelRange_e 	m_AccelRange;
	GyroRange_e 	m_GyroRange;
	AccelODR_e 		m_AccelODR;
	GyroODR_e 		m_GyroODR;
	SensorState_e m_SensorState;
	LPF_e 				m_AccelLPF;
  gpio_num_t    m_Int1GPIO;   // GPIO number of INT1 

	const char *_TAG = "[QMI8658]";

};