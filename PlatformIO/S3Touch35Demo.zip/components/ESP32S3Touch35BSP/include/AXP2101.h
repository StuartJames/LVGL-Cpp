/*
 *                LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by Lewis He (lewishe@outlook.com)
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by Rob Tillaart
 *
 */

#pragma once

#include <stdint.h>
#include <string.h>  // For memcpy
#include <stddef.h>
#include <stdbool.h>
#include "esp_system.h"
#include "esp_sleep.h"
#include "esp_wake_stub.h"
#include <esp_log.h>
#include <driver/gpio.h>
#include <esp_log.h>
#include <math.h>
#include "driver/i2c_master.h"

/////////////////////////////////////////////////////////////////////////////////////

#ifndef CONFIG_PMU_SDA
#define CONFIG_PMU_SDA 21
#endif

#ifndef CONFIG_PMU_SCL
#define CONFIG_PMU_SCL 22
#endif

#ifndef CONFIG_PMU_IRQ
#define CONFIG_PMU_IRQ 35
#endif

#ifdef _BV
#undef _BV
#endif
#define _BV(b)                          (1UL << (uint32_t)(b))

#define SLEEP_MSEC(us) (((uint64_t)us) * 1000L)
#define SLEEP_SEC(us) (((uint64_t)us) * 1000000L)
#define SLEEP_MIN(us) (((uint64_t)us) * 60L * 1000000L)
#define SLEEP_HR(us) (((uint64_t)us) * 60L * 60L * 1000000L)

#define CURRENT_100MA                           (0b0000)
#define CURRENT_190MA                           (0b0001)
#define CURRENT_280MA                           (0b0010)
#define CURRENT_360MA                           (0b0011)
#define CURRENT_450MA                           (0b0100)
#define CURRENT_550MA                           (0b0101)
#define CURRENT_630MA                           (0b0110)
#define CURRENT_700MA                           (0b0111)

#define AXP2101_SLAVE_ADDRESS                    (0x34)
#define AXP2101_CHIP_ID                          (0x4A)

#define AXP2101_STATUS1                          (0x00)
#define AXP2101_STATUS2                          (0x01)
#define AXP2101_IC_TYPE                          (0x03)


#define AXP2101_DATA_BUFFER1                     (0x04)
#define AXP2101_DATA_BUFFER2                     (0x05)
#define AXP2101_DATA_BUFFER3                     (0x06)
#define AXP2101_DATA_BUFFER4                     (0x07)
#define AXP2101_DATA_BUFFER_SIZE                 (4u)

#define AXP2101_COMMON_CONFIG                    (0x10)
#define AXP2101_BATFET_CTRL                      (0x12)
#define AXP2101_DIE_TEMP_CTRL                    (0x13)
#define AXP2101_MIN_SYS_VOL_CTRL                 (0x14)
#define AXP2101_INPUT_VOL_LIMIT_CTRL             (0x15)
#define AXP2101_INPUT_CUR_LIMIT_CTRL             (0x16)
#define AXP2101_RESET_FUEL_GAUGE                 (0x17)
#define AXP2101_CHARGE_GAUGE_WDT_CTRL            (0x18)


#define AXP2101_WDT_CTRL                         (0x19)
#define AXP2101_LOW_BAT_WARN_SET                 (0x1A)


#define AXP2101_PWRON_STATUS                     (0x20)
#define AXP2101_PWROFF_STATUS                    (0x21)
#define AXP2101_PWROFF_EN                        (0x22)
#define AXP2101_DC_OVP_UVP_CTRL                  (0x23)
#define AXP2101_VOFF_SET                         (0x24)
#define AXP2101_PWROK_SEQU_CTRL                  (0x25)
#define AXP2101_SLEEP_WAKEUP_CTRL                (0x26)
#define AXP2101_IRQ_OFF_ON_LEVEL_CTRL            (0x27)

#define AXP2101_FAST_PWRON_SET0                  (0x28)
#define AXP2101_FAST_PWRON_SET1                  (0x29)
#define AXP2101_FAST_PWRON_SET2                  (0x2A)
#define AXP2101_FAST_PWRON_CTRL                  (0x2B)

#define AXP2101_ADC_CHANNEL_CTRL                 (0x30)
#define AXP2101_ADC_DATA_RELUST0                 (0x34)
#define AXP2101_ADC_DATA_RELUST1                 (0x35)
#define AXP2101_ADC_DATA_RELUST2                 (0x36)
#define AXP2101_ADC_DATA_RELUST3                 (0x37)
#define AXP2101_ADC_DATA_RELUST4                 (0x38)
#define AXP2101_ADC_DATA_RELUST5                 (0x39)
#define AXP2101_ADC_DATA_RELUST6                 (0x3A)
#define AXP2101_ADC_DATA_RELUST7                 (0x3B)
#define AXP2101_ADC_DATA_RELUST8                 (0x3C)
#define AXP2101_ADC_DATA_RELUST9                 (0x3D)


//XPOWERS INTERRUPT REGISTER
#define AXP2101_INTEN1                           (0x40)
#define AXP2101_INTEN2                           (0x41)
#define AXP2101_INTEN3                           (0x42)


//XPOWERS INTERRUPT STATUS REGISTER
#define AXP2101_INTSTS1                          (0x48)
#define AXP2101_INTSTS2                          (0x49)
#define AXP2101_INTSTS3                          (0x4A)
#define AXP2101_INTSTS_CNT                       (3)

#define AXP2101_TS_PIN_CTRL                      (0x50)
#define AXP2101_TS_HYSL2H_SET                    (0x52)
#define AXP2101_TS_LYSL2H_SET                    (0x53)


#define AXP2101_VLTF_CHG_SET                     (0x54)
#define AXP2101_VHLTF_CHG_SET                    (0x55)
#define AXP2101_VLTF_WORK_SET                    (0x56)
#define AXP2101_VHLTF_WORK_SET                   (0x57)


#define AXP2101_JIETA_EN_CTRL                    (0x58)
#define AXP2101_JIETA_SET0                       (0x59)
#define AXP2101_JIETA_SET1                       (0x5A)
#define AXP2101_JIETA_SET2                       (0x5B)


#define AXP2101_IPRECHG_SET                      (0x61)
#define AXP2101_ICC_CHG_SET                      (0x62)
#define AXP2101_ITERM_CHG_SET_CTRL               (0x63)

#define AXP2101_CV_CHG_VOL_SET                   (0x64)

#define AXP2101_THE_REGU_THRES_SET               (0x65)
#define AXP2101_CHG_TIMEOUT_SET_CTRL             (0x67)

#define AXP2101_BAT_DET_CTRL                     (0x68)
#define AXP2101_CHGLED_SET_CTRL                  (0x69)

#define AXP2101_BTN_VOL_MIN                      (2600)
#define AXP2101_BTN_VOL_MAX                      (3300)
#define AXP2101_BTN_VOL_STEPS                    (100)


#define AXP2101_BTN_BAT_CHG_VOL_SET              (0x6A)


#define AXP2101_DC_ONOFF_DVM_CTRL                (0x80)
#define AXP2101_DC_FORCE_PWM_CTRL                (0x81)
#define AXP2101_DC_VOL0_CTRL                     (0x82)
#define AXP2101_DC_VOL1_CTRL                     (0x83)
#define AXP2101_DC_VOL2_CTRL                     (0x84)
#define AXP2101_DC_VOL3_CTRL                     (0x85)
#define AXP2101_DC_VOL4_CTRL                     (0x86)


#define AXP2101_LDO_ONOFF_CTRL0                  (0x90)
#define AXP2101_LDO_ONOFF_CTRL1                  (0x91)
#define AXP2101_LDO_VOL0_CTRL                    (0x92)
#define AXP2101_LDO_VOL1_CTRL                    (0x93)
#define AXP2101_LDO_VOL2_CTRL                    (0x94)
#define AXP2101_LDO_VOL3_CTRL                    (0x95)
#define AXP2101_LDO_VOL4_CTRL                    (0x96)
#define AXP2101_LDO_VOL5_CTRL                    (0x97)
#define AXP2101_LDO_VOL6_CTRL                    (0x98)
#define AXP2101_LDO_VOL7_CTRL                    (0x99)
#define AXP2101_LDO_VOL8_CTRL                    (0x9A)


#define AXP2101_BAT_PARAMS                       (0xA1)
#define AXP2101_FUEL_GAUGE_CTRL                  (0xA2)
#define AXP2101_BAT_PERCENT_DATA                 (0xA4)

#define AXP2101_DCDC1_VOL_MIN                    (1500)
#define AXP2101_DCDC1_VOL_MAX                    (3400)
#define AXP2101_DCDC1_VOL_STEPS                  (100u)

#define AXP2101_DCDC2_VOL1_MIN                  (500u)
#define AXP2101_DCDC2_VOL1_MAX                  (1200u)
#define AXP2101_DCDC2_VOL2_MIN                  (1220u)
#define AXP2101_DCDC2_VOL2_MAX                  (1540u)

#define AXP2101_DCDC2_VOL_STEPS1                 (10u)
#define AXP2101_DCDC2_VOL_STEPS2                 (20u)

#define AXP2101_DCDC2_VOL_STEPS1_BASE            (0u)
#define AXP2101_DCDC2_VOL_STEPS2_BASE            (71)


#define AXP2101_DCDC3_VOL1_MIN                  (500u)
#define AXP2101_DCDC3_VOL1_MAX                  (1200u)
#define AXP2101_DCDC3_VOL2_MIN                  (1220u)
#define AXP2101_DCDC3_VOL2_MAX                  (1540u)
#define AXP2101_DCDC3_VOL3_MIN                  (1600u)
#define AXP2101_DCDC3_VOL3_MAX                  (3400u)

#define AXP2101_DCDC3_VOL_MIN                    (500)
#define AXP2101_DCDC3_VOL_MAX                    (3400)

#define AXP2101_DCDC3_VOL_STEPS1                 (10u)
#define AXP2101_DCDC3_VOL_STEPS2                 (20u)
#define AXP2101_DCDC3_VOL_STEPS3                 (100u)

#define AXP2101_DCDC3_VOL_STEPS1_BASE            (0u)
#define AXP2101_DCDC3_VOL_STEPS2_BASE            (71)
#define AXP2101_DCDC3_VOL_STEPS3_BASE            (88)



#define AXP2101_DCDC4_VOL1_MIN                  (500u)
#define AXP2101_DCDC4_VOL1_MAX                  (1200u)
#define AXP2101_DCDC4_VOL2_MIN                  (1220u)
#define AXP2101_DCDC4_VOL2_MAX                  (1840u)

#define AXP2101_DCDC4_VOL_STEPS1                 (10u)
#define AXP2101_DCDC4_VOL_STEPS2                 (20u)

#define AXP2101_DCDC4_VOL_STEPS1_BASE            (0u)
#define AXP2101_DCDC4_VOL_STEPS2_BASE            (71)



#define AXP2101_DCDC5_VOL_1200MV                 (1200)
#define AXP2101_DCDC5_VOL_VAL                    (0x19)
#define AXP2101_DCDC5_VOL_MIN                    (1400)
#define AXP2101_DCDC5_VOL_MAX                    (3700)
#define AXP2101_DCDC5_VOL_STEPS                  (100u)

#define AXP2101_VSYS_VOL_THRESHOLD_MIN          (2600)
#define AXP2101_VSYS_VOL_THRESHOLD_MAX          (3300)
#define AXP2101_VSYS_VOL_THRESHOLD_STEPS        (100)

// ALDO 1~4

#define AXP2101_ALDO1_VOL_MIN                    (500)
#define AXP2101_ALDO1_VOL_MAX                    (3500)
#define AXP2101_ALDO1_VOL_STEPS                  (100u)

#define AXP2101_ALDO2_VOL_MIN                    (500)
#define AXP2101_ALDO2_VOL_MAX                    (3500)
#define AXP2101_ALDO2_VOL_STEPS                  (100u)


#define AXP2101_ALDO3_VOL_MIN                    (500)
#define AXP2101_ALDO3_VOL_MAX                    (3500)
#define AXP2101_ALDO3_VOL_STEPS                  (100u)


#define AXP2101_ALDO4_VOL_MIN                    (500)
#define AXP2101_ALDO4_VOL_MAX                    (3500)
#define AXP2101_ALDO4_VOL_STEPS                  (100u)

// BLDO 1~2

#define AXP2101_BLDO1_VOL_MIN                    (500)
#define AXP2101_BLDO1_VOL_MAX                    (3500)
#define AXP2101_BLDO1_VOL_STEPS                  (100u)

#define AXP2101_BLDO2_VOL_MIN                    (500)
#define AXP2101_BLDO2_VOL_MAX                    (3500)
#define AXP2101_BLDO2_VOL_STEPS                  (100u)

// CPUSLDO

#define AXP2101_CPUSLDO_VOL_MIN                  (500)
#define AXP2101_CPUSLDO_VOL_MAX                  (1400)
#define AXP2101_CPUSLDO_VOL_STEPS                (50)


// DLDO 1~2
#define AXP2101_DLDO1_VOL_MIN                  (500)
#define AXP2101_DLDO1_VOL_MAX                  (3400)
#define AXP2101_DLDO1_VOL_STEPS                (100u)

#define AXP2101_DLDO2_VOL_MIN                  (500)
#define AXP2101_DLDO2_VOL_MAX                  (3400)
#define AXP2101_DLDO2_VOL_STEPS                (100u)


#define AXP2101_CONVERSION(raw)                 (22.0 + (7274 - raw) / 20.0)

/////////////////////////////////////////////////////////////////////////////////////

typedef enum {
    AXP2101_IRQ_TIME_1S,
    AXP2101_IRQ_TIME_1S5,
    AXP2101_IRQ_TIME_2S,
    AXP2101_PRESSOFF_2S5,
} AXP2101_IRQ_Time_e;

typedef enum {
    AXP2101_PRECHARGE_0MA,
    AXP2101_PRECHARGE_25MA,
    AXP2101_PRECHARGE_50MA,
    AXP2101_PRECHARGE_75MA,
    AXP2101_PRECHARGE_100MA,
    AXP2101_PRECHARGE_125MA,
    AXP2101_PRECHARGE_150MA,
    AXP2101_PRECHARGE_175MA,
    AXP2101_PRECHARGE_200MA,
} AXP2101_PreCharge_e;

typedef enum {
    AXP2101_CHG_ITERM_0MA,
    AXP2101_CHG_ITERM_25MA,
    AXP2101_CHG_ITERM_50MA,
    AXP2101_CHG_ITERM_75MA,
    AXP2101_CHG_ITERM_100MA,
    AXP2101_CHG_ITERM_125MA,
    AXP2101_CHG_ITERM_150MA,
    AXP2101_CHG_ITERM_175MA,
    AXP2101_CHG_ITERM_200MA,
} AXP2101_ChargeIterm_e;


typedef enum {
    AXP2101_THREMAL_60DEG,
    AXP2101_THREMAL_80DEG,
    AXP2101_THREMAL_100DEG,
    AXP2101_THREMAL_120DEG,
} AXP2101_Thermal_e;

typedef enum {
    AXP2101_CHG_TRI_STATE,   //tri_charge
    AXP2101_CHG_PRE_STATE,   //pre_charge
    AXP2101_CHG_CC_STATE,    //constant charge
    AXP2101_CHG_CV_STATE,    //constant voltage
    AXP2101_CHG_DONE_STATE,  //charge done
    AXP2101_CHG_STOP_STATE,  //not charge
} AXP2101_ChargeStatus_e;

typedef enum {
    AXP2101_WAKEUP_IRQ_PIN_TO_LOW = _BV(4),
    AXP2101_WAKEUP_PWROK_TO_LOW   = _BV(3),
    AXP2101_WAKEUP_DC_DLO_SELECT  = _BV(2),
} AXP2101_Wakeup_e;

typedef enum {
    AXP2101_FAST_DCDC1,
    AXP2101_FAST_DCDC2,
    AXP2101_FAST_DCDC3,
    AXP2101_FAST_DCDC4,
    AXP2101_FAST_DCDC5,
    AXP2101_FAST_ALDO1,
    AXP2101_FAST_ALDO2,
    AXP2101_FAST_ALDO3,
    AXP2101_FAST_ALDO4,
    AXP2101_FAST_BLDO1,
    AXP2101_FAST_BLDO2,
    AXP2101_FAST_CPUSLDO,
    AXP2101_FAST_DLDO1,
    AXP2101_FAST_DLDO2,
} AXP2101_FastOnOption_e;


typedef enum {
    AXP2101_SEQUENCE_LEVEL_0,
    AXP2101_SEQUENCE_LEVEL_1,
    AXP2101_SEQUENCE_LEVEL_2,
    AXP2101_SEQUENCE_DISABLE,
} AXP2101_StartSequence_e;

typedef enum {
    AXP2101_WDT_IRQ_TO_PIN,             //Just interrupt to pin
    AXP2101_WDT_IRQ_AND_RSET,           //IRQ to pin and reset pmu system
    AXP2101_WDT_IRQ_AND_RSET_PD_PWROK,  //IRQ to pin and reset pmu system,pull down pwrok
    AXP2101_WDT_IRQ_AND_RSET_ALL_OFF,   //IRQ to pin and reset pmu system,turn off dcdc & ldo ,pull down pwrok
} AXP2101_WatchDogConfig_e;

typedef enum {
    AXP2101_WDT_TIMEOUT_1S,
    AXP2101_WDT_TIMEOUT_2S,
    AXP2101_WDT_TIMEOUT_4S,
    AXP2101_WDT_TIMEOUT_8S,
    AXP2101_WDT_TIMEOUT_16S,
    AXP2101_WDT_TIMEOUT_32S,
    AXP2101_WDT_TIMEOUT_64S,
    AXP2101_WDT_TIMEOUT_128S,
} AXP2101_WatchDogTimeout_e;

typedef enum {
    AXP2101_VSYS_VOL_4V1,
    AXP2101_VSYS_VOL_4V2,
    AXP2101_VSYS_VOL_4V3,
    AXP2101_VSYS_VOL_4V4,
    AXP2101_VSYS_VOL_4V5,
    AXP2101_VSYS_VOL_4V6,
    AXP2101_VSYS_VOL_4V7,
    AXP2101_VSYS_VOL_4V8,
} AXP2101_ChargeDPM_e;

typedef enum AXP2101_PressOffTime_e {
    AXP2101_POWEROFF_4S,
    AXP2101_POWEROFF_6S,
    AXP2101_POWEROFF_8S,
    AXP2101_POWEROFF_10S,
} AXP2101_PressOffTime_e;

typedef enum AXP2101_PressOnTime_e {
    AXP2101_POWERON_128MS,
    AXP2101_POWERON_512MS,
    AXP2101_POWERON_1S,
    AXP2101_POWERON_2S,
} AXP2101_PressOnTime_e;

typedef enum AXP2101_ChargeLedMode_e {
    AXP2101_CHG_LED_OFF,
    AXP2101_CHG_LED_BLINK_1HZ,
    AXP2101_CHG_LED_BLINK_4HZ,
    AXP2101_CHG_LED_ON,
    AXP2101_CHG_LED_CTRL_CHG,    // The charging indicator is controlled by the charger
} AXP2101_ChargeLedMode_e;

typedef enum {
    AXP2101_POWERON_SRC_POWERON_LOW,                     //POWERON low for on level when POWERON Mode as POWERON Source
    AXP2101_POWERON_SRC_IRQ_LOW,                         //IRQ PIN Pull-down as POWERON Source
    AXP2101_POWERON_SRC_VBUS_INSERT,                     //Vbus Insert and Good as POWERON Source
    AXP2101_POWERON_SRC_BAT_CHARGE,                      //Vbus Insert and Good as POWERON Source
    AXP2101_POWERON_SRC_BAT_INSERT,                      //Battery Insert and Good as POWERON Source
    AXP2101_POWERON_SRC_ENMODE,                          //POWERON always high when EN Mode as POWERON Source
    AXP2101_POWERON_SRC_UNKONW,                          //Unkonw
} AXP2101_PowerOnSource_e;

typedef enum {
    AXP2101_POWEROFF_SRC_PWEKEY_PULLDOWN,            //POWERON Pull down for off level when POWERON Mode as POWEROFF Source
    AXP2101_POWEROFF_SRC_SOFT_OFF,                   //Software configuration as POWEROFF Source
    AXP2101_POWEROFF_SRC_PWEKEY_LOW,                 //POWERON always low when EN Mode as POWEROFF Source
    AXP2101_POWEROFF_SRC_UNDER_VSYS,                 //Vsys Under Voltage as POWEROFF Source
    AXP2101_POWEROFF_SRC_OVER_VBUS,                  //VBUS Over Voltage as POWEROFF Source
    AXP2101_POWEROFF_SRC_UNDER_VOL,                  //DCDC Under Voltage as POWEROFF Source
    AXP2101_POWEROFF_SRC_OVER_VOL,                   //DCDC Over Voltage as POWEROFF Source
    AXP2101_POWEROFF_SRC_OVER_TEMP,                  //Die Over Temperature as POWEROFF Source
    AXP2101_POWEROFF_SRC_UNKONW,                     //Unkonw
} AXP2101_PowerOffSource_e;

typedef enum {
    AXP2101_PWROK_DELAY_8MS,
    AXP2101_PWROK_DELAY_16MS,
    AXP2101_PWROK_DELAY_32MS,
    AXP2101_PWROK_DELAY_64MS,
} AXP2101_PowerOkDelay_e;

typedef enum __xpowers_axp192_chg_vol {
    AXP2101_CHG_VOL_4V1,
    AXP2101_CHG_VOL_4V15,
    AXP2101_CHG_VOL_4V2,
    AXP2101_CHG_VOL_4V36,
    AXP2101_CHG_VOL_MAX,
} AXP192_ChargeVoltage_e;

typedef enum {
    AXP2101_VBUS_VOL_LIM_3V88,
    AXP2101_VBUS_VOL_LIM_3V96,
    AXP2101_VBUS_VOL_LIM_4V04,
    AXP2101_VBUS_VOL_LIM_4V12,
    AXP2101_VBUS_VOL_LIM_4V20,
    AXP2101_VBUS_VOL_LIM_4V28,
    AXP2101_VBUS_VOL_LIM_4V36,
    AXP2101_VBUS_VOL_LIM_4V44,
    AXP2101_VBUS_VOL_LIM_4V52,
    AXP2101_VBUS_VOL_LIM_4V60,
    AXP2101_VBUS_VOL_LIM_4V68,
    AXP2101_VBUS_VOL_LIM_4V76,
    AXP2101_VBUS_VOL_LIM_4V84,
    AXP2101_VBUS_VOL_LIM_4V92,
    AXP2101_VBUS_VOL_LIM_5V,
    AXP2101_VBUS_VOL_LIM_5V08,
} APX2101VbusVoltageLimit_e;

typedef enum __xpowers_axp2101_chg_curr {
    AXP2101_CHG_CUR_0MA,
    AXP2101_CHG_CUR_100MA = 4,
    AXP2101_CHG_CUR_125MA,
    AXP2101_CHG_CUR_150MA,
    AXP2101_CHG_CUR_175MA,
    AXP2101_CHG_CUR_200MA,
    AXP2101_CHG_CUR_300MA,
    AXP2101_CHG_CUR_400MA,
    AXP2101_CHG_CUR_500MA,
    AXP2101_CHG_CUR_600MA,
    AXP2101_CHG_CUR_700MA,
    AXP2101_CHG_CUR_800MA,
    AXP2101_CHG_CUR_900MA,
    AXP2101_CHG_CUR_1000MA,
} AXP2101_ChargeCurrent_e;

typedef enum {
    AXP2101_VBUS_CUR_LIM_100MA,
    AXP2101_VBUS_CUR_LIM_500MA,
    AXP2101_VBUS_CUR_LIM_900MA,
    AXP2101_VBUS_CUR_LIM_1000MA,
    AXP2101_VBUS_CUR_LIM_1500MA,
    AXP2101_VBUS_CUR_LIM_2000MA,
} APX2101VbusCurrentLimit_e;

typedef enum AXP2101PowerChannel_e {

  AXP2101_DCDC1,
  AXP2101_DCDC2,
  AXP2101_DCDC3,
  AXP2101_DCDC4,
  AXP2101_DCDC5,

  AXP2101_LDO1,
  AXP2101_LDO2,
  AXP2101_LDO3,
  AXP2101_LDO4,
  AXP2101_LDO5,

  AXP2101_LDOIO,

  AXP2101_ALDO1,
  AXP2101_ALDO2,
  AXP2101_ALDO3,
  AXP2101_ALDO4,

  AXP2101_BLDO1,
  AXP2101_BLDO2,

  AXP2101_DLDO1,
  AXP2101_DLDO2,

  AXP2101_VBACKUP,

  AXP2101_CPULDO,

} AXP2101PowerChannel_e;

typedef enum AXP2101_IRQ_e {
    //! IRQ1 REG 40H
    AXP2101_BAT_NOR_UNDER_TEMP_IRQ   = _BV(0),   // Battery Under Temperature in Work
    AXP2101_BAT_NOR_OVER_TEMP_IRQ    = _BV(1),   // Battery Over Temperature in Work mode
    AXP2101_BAT_CHG_UNDER_TEMP_IRQ   = _BV(2),   // Battery Under Temperature in Charge mode IRQ(bcut_irq)
    AXP2101_BAT_CHG_OVER_TEMP_IRQ    = _BV(3),   // Battery Over Temperature in Charge mode IRQ(bcot_irq) enable
    AXP2101_GAUGE_NEW_SOC_IRQ        = _BV(4),   // Gauge New SOC IRQ(lowsoc_irq) enable ???
    AXP2101_WDT_TIMEOUT_IRQ          = _BV(5),   // Gauge Watchdog Timeout IRQ(gwdt_irq) enable
    AXP2101_WARNING_LEVEL1_IRQ       = _BV(6),   // SOC drop to Warning Level1 IRQ(socwl1_irq) enable
    AXP2101_WARNING_LEVEL2_IRQ       = _BV(7),   // SOC drop to Warning Level2 IRQ(socwl2_irq) enable

    //! IRQ2 REG 41H
    AXP2101_PKEY_POSITIVE_IRQ        = _BV(8),   // POWERON Positive Edge IRQ(ponpe_irq_en) enable
    AXP2101_PKEY_NEGATIVE_IRQ        = _BV(9),   // POWERON Negative Edge IRQ(ponne_irq_en) enable
    AXP2101_PKEY_LONG_IRQ            = _BV(10),  // POWERON Long PRESS IRQ(ponlp_irq) enable
    AXP2101_PKEY_SHORT_IRQ           = _BV(11),  // POWERON Short PRESS IRQ(ponsp_irq_en) enable
    AXP2101_BAT_REMOVE_IRQ           = _BV(12),  // Battery Remove IRQ(bremove_irq) enable
    AXP2101_BAT_INSERT_IRQ           = _BV(13),  // Battery Insert IRQ(binsert_irq) enabl
    AXP2101_VBUS_REMOVE_IRQ          = _BV(14),  // VBUS Remove IRQ(vremove_irq) enabl
    AXP2101_VBUS_INSERT_IRQ          = _BV(15),  // VBUS Insert IRQ(vinsert_irq) enable

    //! IRQ3 REG 42H
    AXP2101_BAT_OVER_VOL_IRQ         = _BV(16),  // Battery Over Voltage Protection IRQ(bovp_irq) enable
    AXP2101_CHARGER_TIMER_IRQ         = _BV(17),  // Charger Safety Timer1/2 expire IRQ(chgte_irq) enable
    AXP2101_DIE_OVER_TEMP_IRQ        = _BV(18),  // DIE Over Temperature level1 IRQ(dotl1_irq) enable
    AXP2101_BAT_CHG_START_IRQ        = _BV(19),  // Charger start IRQ(chgst_irq) enable
    AXP2101_BAT_CHG_DONE_IRQ         = _BV(20),  // Battery charge done IRQ(chgdn_irq) enable
    AXP2101_BATFET_OVER_CURR_IRQ     = _BV(21),  // BATFET Over Current Protection IRQ(bocp_irq) enable
    AXP2101_LDO_OVER_CURR_IRQ        = _BV(22),  // LDO Over Current IRQ(ldooc_irq) enable
    AXP2101_WDT_EXPIRE_IRQ           = _BV(23),  // Watchdog Expire IRQ(wdexp_irq) enable

    AXP2101_ALL_IRQ                  = (0xFFFFFFFFUL)
} AXP2101_IRQ_e;

/////////////////////////////////////////////////////////////////////////////////////

class AXP2101
{
public:
                        AXP2101(void);
  virtual               ~AXP2101(void);
  bool                  Initialise(i2c_master_bus_handle_t hi2cBus);
  uint16_t              Status(void);
	void                  Update(void);
	void                  UpdateBrightness(void);
	bool                  GetBatState(void);
	uint8_t               GetBatData(void);
	void                  EnableCoulombcounter(void);
	void                  DisableCoulombcounter(void);
	void                  StopCoulombcounter(void);
	void                  ClearCoulombcounter(void);
	uint32_t              GetCoulombchargeData(void);
	uint32_t              GetCoulombdischargeData(void);
	float                 GetCoulombData(void);
	uint16_t              GetVbatData(void) __attribute__((deprecated));
	uint16_t              GetIchargeData(void) __attribute__((deprecated));
	uint16_t              GetIdischargeData(void) __attribute__((deprecated));
	uint16_t              GetTempData(void) __attribute__((deprecated));
	uint32_t              GetPowerbatData(void) __attribute__((deprecated));
	uint16_t              GetVinData(void) __attribute__((deprecated));
	uint16_t              GetIinData(void) __attribute__((deprecated));
	uint16_t              GetVusbinData(void) __attribute__((deprecated));
	uint16_t              GetIusbinData(void) __attribute__((deprecated));
	uint16_t              GetVapsData(void) __attribute__((deprecated));
	uint8_t               GetBtnPress(void);
	// -- sleep
	void                  SetSleep(void);
	void                  DeepSleep(uint64_t time_in_us = 0);
	void                  LightSleep(uint64_t time_in_us = 0);

	// void                 SetChargeVoltage( uint8_t );
	void                  SetChargeCurrent(uint8_t);
	float                 GetBatCurrent(void);
	float                 GetVinVoltage(void);
	float                 GetVinCurrent(void);
	float                 GetVBusVoltage(void);
	float                 GetVBusCurrent(void);
	float                 GetTempInAXP2101(void);
	float                 GetBatPower(void);
	float                 GetBatChargeCurrent(void);
	float                 GetAPSVoltage(void);
	float                 GetBatCoulombInput(void);
	float                 GetBatCoulombOut(void);
	uint8_t               GetWarningLevel(void);
	void                  SetCoulombClear(void);
	void                  SetLDO2(bool State);
	void                  SetLDO3(bool State);
	void                  SetAdcState(bool State);
	void                  PowerOff(void);
  AXP2101_ChargeStatus_e GetChargerStatus(void);
  void                  EnableInternalDischarge(void);
  void                  DisableInternalDischarge(void);
  void                  EnablePwrOkPinPullLow(void);


  void                  DisablePwrOkPinPullLow(void);
  void                  EnablePwronShutPMIC(void);
  void                  DisablePwronShutPMIC(void);
  void                  Reset(void);
  void                  Shutdown(void);
  void                  EnableBATFET(void);
  void                  DisableBATFET(void);
  void                  SetDieOverTempLevel1(uint8_t Option);
  uint8_t               GetDieOverTempLevel1(void);
  void                  EnableDieOverTempDetect(void);
  void                  DisableDieOverTempDetect(void);
  void                  SetLinearChargerVsysDpm(AXP2101_ChargeDPM_e Option);
  uint8_t               GetLinearChargerVsysDpm(void);
  void                  SetVbusVoltageLimit(uint8_t Option);
  uint8_t               GetVbusVoltageLimit(void);
  bool                  SetVbusCurrentLimit(uint8_t Option);
  uint8_t               GetVbusCurrentLimit(void);
  bool                  WriteGaugeData(uint8_t *data, uint8_t len);
  bool                  CompareGaugeData(uint8_t *data, uint8_t len);
  bool                  EnableButtonBatteryCharge(void);
  bool                  DisableButtonBatteryCharge(void);
  bool                  IsEnabledButtonBatteryCharge(void);
  bool                  SetButtonBatteryChargeVoltage(uint16_t millivolt);
  uint16_t              GetButtonBatteryVoltage(void);
  void                  EnableCellbatteryCharge(void);
  void                  DisableCellbatteryCharge(void);
  void                  EnableWatchdog(void);
  void                  DisableWatchdog(void);
  void                  SetWatchdogConfig(AXP2101_WatchDogConfig_e Option);
  uint8_t               GetWatchConfig(void);
  void                  ClearWatchdog(void);
  void                  SetWatchdogTimeout(AXP2101_WatchDogTimeout_e Option);
  uint8_t               GetWatchdogTimerout(void);
  void                  SetLowBatWarnThreshold(uint8_t percentage);
  uint8_t               GetLowBatWarnThreshold(void);
  void                  SetLowBatShutdownThreshold(uint8_t Option);
  uint8_t               GetLowBatShutdownThreshold(void);
  bool                  IsPoweronAlwaysHighSource(void);
  bool                  IsBattInsertOnSource(void);
  bool                  IsBattNormalOnSource(void);
  bool                  IsVbusInsertOnSource(void);
  bool                  IsIRQLowOnSource(void);
  bool                  IsPwronLowOnSource(void);
  AXP2101_PowerOnSource_e GetPowerOnSource(void);
  bool                  IsOverTemperatureOffSource(void);
  bool                  IsDcOverVoltageOffSource(void);
  bool                  IsDcUnderVoltageOffSource(void);
  bool                  IsVbusOverVoltageOffSource(void);
  bool                  IsVsysUnderVoltageOffSource(void);
  bool                  IsPwronAlwaysLowOffSource(void);
  bool                  IsSwConfigOffSource(void);
  bool                  IsPwrSourcePullDown(void);
  AXP2101_PowerOffSource_e GetPowerOffSource(void);
  void                  EnableOverTemperatureLevel2PowerOff(void);
  void                  DisableOverTemperaturePowerOff(void);
  void                  EnableLongPressShutdown(void);
  void                  DisableLongPressShutdown(void);
  void                  SetLongPressRestart(void);
  void                  SetLongPressPowerOFF(void);
  void                  EnableDCHighVoltageTurnOff(void);
  void                  DisableDCHighVoltageTurnOff(void);
  void                  EnableDC5LowVoltageTurnOff(void);
  void                  DisableDC5LowVoltageTurnOff(void);
  void                  EnableDC4LowVoltageTurnOff(void);
  void                  DisableDC4LowVoltageTurnOff(void);
  void                  EnableDC3LowVoltageTurnOff(void);
  void                  DisableDC3LowVoltageTurnOff(void);
  void                  EnableDC2LowVoltageTurnOff(void);
  void                  DisableDC2LowVoltageTurnOff(void);
  void                  EnableDC1LowVoltageTurnOff(void);
  void                  DisableDC1LowVoltageTurnOff(void);
  bool                  SetSysPowerDownVoltage(uint16_t millivolt);
  uint16_t              GetSysPowerDownVoltage(void);
  void                  EnablePwrOk(void);
  void                  DisablePwrOk(void);
  void                  EnablePowerOffDelay(void);
  void                  DisablePowerOffDelay(void);
  void                  EnablePowerSequence(void);
  void                  DisablePowerSequence(void);
  bool                  SetPwrOkDelay(AXP2101_PowerOkDelay_e Option);
  AXP2101_PowerOkDelay_e GetPwrOkDelay(void);
  void                  WakeupControl(AXP2101_Wakeup_e Option, bool Enable);
  bool                  EnableWakeup(void);
  bool                  DisableWakeup(void);
  bool                  EnableSleep(void);
  bool                  DisableSleep(void);
  void                  SetIRQLevel(uint8_t Option);
  void                  SetOffLevel(uint8_t Option);
  void                  SetOnLevel(uint8_t Option);
  void                  SetDc4FastStartSequence(AXP2101_StartSequence_e Option);
  void                  SetDc3FastStartSequence(AXP2101_StartSequence_e Option);
  void                  SetDc2FastStartSequence(AXP2101_StartSequence_e Option);
  void                  SetDc1FastStartSequence(AXP2101_StartSequence_e Option);
  void                  SetAldo3FastStartSequence(AXP2101_StartSequence_e Option);
  void                  SetAldo2FastStartSequence(AXP2101_StartSequence_e Option);
  void                  SetAldo1FastStartSequence(AXP2101_StartSequence_e Option);
  void                  SetDc5FastStartSequence(AXP2101_StartSequence_e Option);
  void                  SetCpuldoFastStartSequence(AXP2101_StartSequence_e Option);
  void                  SetBldo2FastStartSequence(AXP2101_StartSequence_e Option);
  void                  SetBldo1FastStartSequence(AXP2101_StartSequence_e opt);
  void                  SetAldo4FastStartSequence(AXP2101_StartSequence_e opt);
  void                  SetDldo2FastStartSequence(AXP2101_StartSequence_e opt);
  void                  SetDldo1FastStartSequence(AXP2101_StartSequence_e opt);
  void                  SetFastPowerOnLevel(AXP2101_FastOnOption_e opt, AXP2101_StartSequence_e seq_level);
  void                  DisableFastPowerOn(AXP2101_FastOnOption_e opt);
  void                  EnableFastPowerOn(void);
  void                  DisableFastPowerOn(void);
  void                  EnableFastWakeup(void);
  void                  DisableFastWakeup(void);
  void                  SetDCHighVoltagePowerDown(bool en);
  bool                  GetDCHighVoltagePowerDownEn(void);
  void                  SetDcUVPDebounceTime(uint8_t opt);
  void                  SettDC1WorkModeToPwm(uint8_t Enable);
  void                  SettDC2WorkModeToPwm(uint8_t Enable);
  void                  SettDC3WorkModeToPwm(uint8_t Enable);
  void                  SettDC4WorkModeToPwm(uint8_t Enable);
  void                  SetDCFreqSpreadRange(uint8_t opt);
  void                  SetDCFreqSpreadRangeEn(bool en);
  void                  EnableCCM(void);
  void                  DisableCCM(void);
  bool                  IsEnableCCM(void);
  void                  SetDVMRamp(uint8_t opt);
  bool                  IsEnabledDC1(void);
  bool                  EnableDC1(void);
  bool                  DisableDC1(void);
  bool                  SetDC1Voltage(uint16_t millivolt);
  uint16_t              GetDC1Voltage(void);
  void                  SetDC1LowVoltagePowerDown(bool en);
  bool                  GetDC1LowVoltagePowerDownEn(void);
  bool                  IsEnabledDC2(void);
  bool                  EnableDC2(void);
  bool                  DisableDC2(void);
  bool                  SetDC2Voltage(uint16_t millivolt);
  uint16_t              GetDC2Voltage(void);
  uint8_t               GetDC2WorkMode(void);
  void                  SetDC2LowVoltagePowerDown(bool en);
  bool                  GetDC2LowVoltagePowerDownEn(void);
  bool                  IsEnabledDC3(void);
  bool                  EnableDC3(void);
  bool                  DisableDC3(void);
  bool                  SetDC3Voltage(uint16_t millivolt);
  uint16_t              GetDC3Voltage(void);
  uint8_t               GetDC3WorkMode(void);
  void                  SetDC3LowVoltagePowerDown(bool en);
  bool                  GetDC3LowVoltagePowerDownEn(void);
  bool                  IsEnabledDC4(void);
  bool                  EnableDC4(void);
  bool                  DisableDC4(void);
  bool                  SetDC4Voltage(uint16_t millivolt);
  uint16_t              GetDC4Voltage(void);
  void                  SetDC4LowVoltagePowerDown(bool en);
  bool                  GetDC4LowVoltagePowerDownEn(void);
  bool                  IsEnabledDC5(void);
  bool                  EnableDC5(void);
  bool                  DisableDC5(void);
  bool                  SetDC5Voltage(uint16_t millivolt);
  uint16_t              GetDC5Voltage(void);
  bool                  IsDC5FreqCompensationEn(void);
  void                  EnableDC5FreqCompensation(void);
  void                  DisableFreqCompensation(void);
  void                  SetDC5LowVoltagePowerDown(bool en);
  bool                  GetDC5LowVoltagePowerDownEn(void);
  bool                  IsEnabledALDO1(void);
  bool                  EnableALDO1(void);
  bool                  DisableALDO1(void);
  bool                  SetALDO1Voltage(uint16_t millivolt);
  uint16_t              GetALDO1Voltage(void);
  bool                  IsEnabledALDO2(void);
  bool                  EnableALDO2(void);
  bool                  DisableALDO2(void);
  bool                  SetALDO2Voltage(uint16_t millivolt);
  uint16_t              GetALDO2Voltage(void);
  bool                  IsEnabledALDO3(void);
  bool                  EnableALDO3(void);
  bool                  DisableALDO3(void);
  bool                  SetALDO3Voltage(uint16_t millivolt);
  uint16_t              GetALDO3Voltage(void);
  bool                  IsEnabledALDO4(void);
  bool                  EnableALDO4(void);
  bool                  DisableALDO4(void);
  bool                  SetALDO4Voltage(uint16_t millivolt);
  uint16_t              GetALDO4Voltage(void);
  bool                  IsEnabledBLDO1(void);
  bool                  EnableBLDO1(void);
  bool                  DisableBLDO1(void);
  bool                  SetBLDO1Voltage(uint16_t millivolt);
  uint16_t              GetBLDO1Voltage(void);
  bool                  IsEnabledBLDO2(void);
  bool                  EnableBLDO2(void);
  bool                  DisableBLDO2(void);
  bool                  SetBLDO2Voltage(uint16_t millivolt);
  uint16_t              GetBLDO2Voltage(void);
  bool                  IsEnabledCPUSLDO(void);
  bool                  EnableCPUSLDO(void);
  bool                  DisableCPUSLDO(void);
  bool                  SetCPUSLDOVoltage(uint16_t millivolt);
  uint16_t              GetCPUSLDOVoltage(void);
  bool                  IsEnabledDLDO1(void);
  bool                  EnableDLDO1(void);
  bool                  DisableDLDO1(void);
  bool                  SetDLDO1Voltage(uint16_t millivolt);
  uint16_t              GetDLDO1Voltage(void);
  bool                  IsEnabledDLDO2(void);
  bool                  EnableDLDO2(void);
  bool                  DisableDLDO2(void);
  bool                  SetDLDO2Voltage(uint16_t millivolt);
  uint16_t              GetDLDO2Voltage(void);
  void                  SetIRQLevelTime(AXP2101_IRQ_Time_e opt);
  AXP2101_IRQ_Time_e    GetIRQLevelTime(void);
  bool                  SetPowerKeyPressOnTime(uint8_t opt);
  uint8_t               GetPowerKeyPressOnTime(void);
  bool                  SetPowerKeyPressOffTime(uint8_t opt);
  uint8_t               GetPowerKeyPressOffTime(void);
  bool                  EnableGeneralAdcChannel(void);
  bool                  DisableGeneralAdcChannel(void);
  bool                  EnableTemperatureMeasure(void);
  bool                  DisableTemperatureMeasure(void);
  float                 GetTemperature(uint16_t *raw_ptr = nullptr);
  bool                  EnableSystemVoltageMeasure(void);
  bool                  DisableSystemVoltageMeasure(void);
  uint16_t              GetSystemVoltage(void);
  bool                  EnableVbusVoltageMeasure(void);
  bool                  DisableVbusVoltageMeasure(void);
  uint16_t              GetVbusVoltage(void);
  bool                  EnableTSPinMeasure(void);
  bool                  DisableTSPinMeasure(void);
  bool                  EnableTSPinLowFreqSample(void);
  bool                  DisableTSPinLowFreqSample(void);
  float                 GetTsTemperature(float SteinhartA = 1.126e-3, float SteinhartB = 2.38e-4, float SteinhartC = 8.5e-8);
  uint16_t              GetTsPinValue(void);
  bool                  EnableBattVoltageMeasure(void);
  bool                  DisableBattVoltageMeasure(void);
  bool                  EnableBattDetection(void);
  bool                  DisableBattDetection(void);
  uint16_t              GetBattVoltage(void);
  int                   GetBatteryPercent(void);
  void                  SetChargingLEDMode(uint8_t mode);
  uint8_t               GetChargingLEDMode(void);
  void                  SetPrechargeCurr(AXP2101_PreCharge_e opt);
  AXP2101_PreCharge_e   GetPrechargeCurr(void);
  bool                  SetChargerConstantCurr(uint8_t opt);
  uint8_t               GetChargerConstantCurr(void);
  void                  SetChargerTerminationCurr(AXP2101_ChargeIterm_e opt);
  AXP2101_ChargeIterm_e GetChargerTerminationCurr(void);
  void                  EnableChargerTerminationLimit(void);
  void                  DisableChargerTerminationLimit(void);
  bool                  IsChargerTerminationLimit(void);
  bool                  SetChargeTargetVoltage(uint8_t opt);
  uint8_t               GetChargeTargetVoltage(void);
  void                  SetThermaThreshold(AXP2101_Thermal_e opt);
  AXP2101_Thermal_e     GetThermaThreshold(void);
  uint64_t              GetID(void);
  void                  ClearIRQStatus(void);
  uint64_t              GetIRQStatus(void);
  void                  PrintIntRegister(void);
  bool                  EnableIRQ(uint64_t opt);
  bool                  DisableIRQ(uint64_t opt);
  bool                  IsDropWarningLevel2IRQ(void);
  bool                  IsDropWarningLevel1IRQ(void);
  bool                  IsGaugeWdtTimeoutIRQ(void);
  bool                  IsStateOfChargeLowIRQ(void);
  bool                  IsBatChargerOverTemperatureIRQ(void);
  bool                  IsBatChargerUnderTemperatureIRQ(void);
  bool                  IsBatWorkOverTemperatureIRQ(void);
  bool                  IsBatWorkUnderTemperatureIRQ(void);
  bool                  IsVbusInsertIRQ(void);
  bool                  IsVbusRemoveIRQ(void);
  bool                  IsBatInsertIRQ(void);
  bool                  IsBatRemoveIRQ(void);
  bool                  IsPekeyShortPressIRQ(void);
  bool                  IsPekeyLongPressIRQ(void);
  bool                  IsPekeyNegativeIRQ(void);
  bool                  IsPekeyPositiveIRQ(void);
  bool                  IsWdtExpireIRQ(void);
  bool                  IsLdoOverCurrentIRQ(void);
  bool                  IsBatfetOverCurrentIRQ(void);
  bool                  IsBatChargeDoneIRQ(void);
  bool                  IsBatChargeStartIRQ(void);
  bool                  IsBatDieOverTemperatureIRQ(void);
  bool                  IsChargeOverTimeoutIRQ(void);
  bool                  IsBatOverVoltageIRQ(void);
  uint8_t               GetChipID(void);
  uint16_t              GetPowerChannelVoltage(uint8_t channel);
  bool                  EnablePowerOutput(uint8_t channel);
  bool                  DisablePowerOutput(uint8_t channel);
  bool                  IsPowerChannelEnable(uint8_t channel);
  bool                  SetPowerChannelVoltage(uint8_t channel, uint16_t millivolt);

  bool                  GetBatfetState(void);
  bool                  IsBatteryConnect(void);
  bool                  IsBatInActiveModeState(void);
  bool                  GetThermalRegulationStatus(void);
  bool                  GetCurrentLimitStatus(void);
  bool                  IsCharging(void);
  bool                  IsDischarge(void);
  bool                  IsStandby(void);
  bool                  IsPowerOn(void);
  bool                  IsPowerOff(void);
  bool                  IsVbusIn(void);
  bool                  IsVbusGood(void);

protected:
	float                 m_Brightness;
	float                 m_CurrentBrightness;
  i2c_master_dev_handle_t m_hDevice;
	uint8_t 			        m_Address; 
  gpio_num_t            m_PinIRQ;
  uint32_t              m_ProtectedMask;

private:
  int                   ReadRegister(uint8_t Register);
  int                   WriteRegister(uint8_t Register, uint8_t Value);
  bool                  WriteDataBuffer(uint8_t *data, uint8_t size);
  bool                  ReadDataBuffer(uint8_t *data, uint8_t size);
  void                  ReadBuffer(uint8_t Register, uint8_t Length, uint8_t *pBuffer);
  void                  Write1Byte(uint8_t Register, uint8_t Data);
  uint16_t              ReadRegisterH5L8(uint8_t HighReg, uint8_t LowReg);
  uint16_t              ReadRegisterH6L8(uint8_t HighReg, uint8_t LowReg);
  uint8_t               Read8bit(uint8_t Register);
  uint16_t              Read12Bit(uint8_t Register);
  uint16_t              Read13Bit(uint8_t Register);
  uint16_t              Read16bit(uint8_t Register);
  uint32_t              Read24bit(uint8_t Register);
  uint32_t              Read32bit(uint8_t Register);
  bool                  GetRegisterBit(uint8_t Register, int BitPos);
  bool                  SetRegisterBit(uint8_t Register, int BitPos, bool State = true);
  bool                  ClearRegisterBit(uint8_t Register, int BitPos);
  bool                  GetProtectedChannel(uint8_t Channel);
  void                  SetProtectedChannel(uint8_t Channel);
  void                  SetUnprotectChannel(uint8_t Channel);
  bool                  IsBitSet(uint8_t Data, uint8_t Mask);

  bool                  InitImpl(void);
  bool                  SetInterruptImpl(uint32_t opts, bool enable);

	static const char*    GetStartupReason(void);
  float                 ResistanceToTemperature(float resistance, float SteinhartA, float SteinhartB, float SteinhartC);

  uint8_t               m_StatusRegisters[AXP2101_INTSTS_CNT];
  uint8_t               m_IntRegisters[AXP2101_INTSTS_CNT];

};

#include "AXP2101.inl"

