/*
 *                LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by Lewis He (lewishe@outlook.com)
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by Rob Tillaart
 *
 */

/////////////////////////////////////////////////////////////////////////////////////

inline bool AXP2101::IsVbusGood(void)
{
	return GetRegisterBit(AXP2101_STATUS1, 5);
}

/////////////////////////////////////////////////////////////////////////////////////

inline int AXP2101::ReadRegister(uint8_t Register)
{
uint8_t Value = 0;

  i2c_master_transmit_receive(m_hDevice, (const uint8_t *)&Register, 1, &Value, 1, -1);
  return Value;
}

/////////////////////////////////////////////////////////////////////////////////////

inline int AXP2101::WriteRegister(uint8_t Register, uint8_t Value)
{
uint8_t Buffer[2] = {Register, Value };

  esp_err_t Res = i2c_master_transmit(m_hDevice, Buffer, 2, -1);
  return (Res == ESP_FAIL) ? -1 : 0;
}

/////////////////////////////////////////////////////////////////////////////////////

inline void AXP2101::ReadBuffer(uint8_t Register, uint8_t Length, uint8_t *pBuffer)
{
  i2c_master_transmit_receive(m_hDevice, (const uint8_t *)&Register, 1, pBuffer, Length, -1);
}

/////////////////////////////////////////////////////////////////////////////////////

inline bool AXP2101::WriteDataBuffer(uint8_t *pData, uint8_t Size)
{
uint8_t Buffer[AXP2101_DATA_BUFFER_SIZE + 1];
	if(Size > AXP2101_DATA_BUFFER_SIZE) return false;
  Buffer[0] = AXP2101_DATA_BUFFER1;
  memcpy(&Buffer[1], pData, Size);
  esp_err_t Res = i2c_master_transmit(m_hDevice, Buffer, Size + 1, -1);
  return (Res == ESP_FAIL) ? false : true;
}

/////////////////////////////////////////////////////////////////////////////////////

inline bool AXP2101::ReadDataBuffer(uint8_t *pData, uint8_t Size)
{
uint8_t Register = AXP2101_DATA_BUFFER_SIZE;

	if(Size > AXP2101_DATA_BUFFER_SIZE) return false;
  esp_err_t Res = i2c_master_transmit_receive(m_hDevice, (const uint8_t *)&Register, 1, pData, Size, -1);
	return (Res == ESP_FAIL) ? false : true;
}

/////////////////////////////////////////////////////////////////////////////////////

inline void AXP2101::Write1Byte(uint8_t Register, uint8_t Value)
{
uint8_t Buffer[2] = {Register, Value };

  i2c_master_transmit(m_hDevice, Buffer, 2, -1);
}

/////////////////////////////////////////////////////////////////////////////////////

inline uint16_t AXP2101::ReadRegisterH5L8(uint8_t HighReg, uint8_t LowReg)
{
  int h5 = ReadRegister(HighReg);
  int l8 = ReadRegister(LowReg);
  if (h5 == -1 || l8 == -1) return 0;
  return ((h5 & 0x1F) << 8) | l8;
}

/////////////////////////////////////////////////////////////////////////////////////

inline uint16_t AXP2101::ReadRegisterH6L8(uint8_t HighReg, uint8_t LowReg)
{
  int h6 = ReadRegister(HighReg);
  int l8 = ReadRegister(LowReg);
  if (h6 == -1 || l8 == -1) return 0;
  return ((h6 & 0x3F) << 8) | l8;
}

/////////////////////////////////////////////////////////////////////////////////////

inline uint8_t AXP2101::Read8bit(uint8_t Register)
{
uint8_t Value = 0;

  i2c_master_transmit_receive(m_hDevice, (const uint8_t *)&Register, 1, &Value, 1, -1);
  return Value;
}

/////////////////////////////////////////////////////////////////////////////////////

inline uint16_t AXP2101::Read12Bit(uint8_t Register)
{
uint16_t Data = 0;
uint8_t Buffer[2];

  i2c_master_transmit_receive(m_hDevice, (const uint8_t *)&Register, 1, Buffer, 2, -1);
	Data = ((Buffer[0] << 4) + Buffer[1]);  
	return Data;
}

/////////////////////////////////////////////////////////////////////////////////////

inline uint16_t AXP2101::Read13Bit(uint8_t Register)
{
uint16_t Data = 0;
uint8_t Buffer[2];

  i2c_master_transmit_receive(m_hDevice, (const uint8_t *)&Register, 1, Buffer, 2, -1);
	Data = ((Buffer[0] << 5) + Buffer[1]); 
	return Data;
}

/////////////////////////////////////////////////////////////////////////////////////

inline uint16_t AXP2101::Read16bit(uint8_t Register)
{
uint16_t Data = 0;
uint8_t Buffer[2];

  i2c_master_transmit_receive(m_hDevice, (const uint8_t *)&Register, 1, Buffer, 2, -1);
	Data = (uint16_t)Buffer[0] << 8;
	Data |= Buffer[1];
	return Data;
}

/////////////////////////////////////////////////////////////////////////////////////

inline uint32_t AXP2101::Read24bit(uint8_t Register)
{
uint32_t Data = 0;
uint8_t Buffer[3];

  i2c_master_transmit_receive(m_hDevice, (const uint8_t *)&Register, 1, Buffer, 3, -1);
	for(int i = 0; i < 3; i++) {
		Data <<= 8;
		Data |= Buffer[i];
	}
	return Data;
}

/////////////////////////////////////////////////////////////////////////////////////

inline uint32_t AXP2101::Read32bit(uint8_t Register)
{
uint32_t Data = 0;
uint8_t Buffer[4];

  i2c_master_transmit_receive(m_hDevice, (const uint8_t *)&Register, 1, Buffer, 4, -1);
	for(int i = 0; i < 4; i++) {
		Data <<= 8;
		Data |= Buffer[i];
	}
	return Data;
}

/////////////////////////////////////////////////////////////////////////////////////

inline bool AXP2101::GetRegisterBit(uint8_t Register, int BitPos)
{
uint8_t Data;

  i2c_master_transmit_receive(m_hDevice, (const uint8_t *)&Register, 1, &Data, 1, -1);
  return ((Data >> BitPos) & 1);
}

/////////////////////////////////////////////////////////////////////////////////////

inline bool AXP2101::SetRegisterBit(uint8_t Register, int BitPos, bool State /*= true*/)
{
uint8_t Data, Buffer[2];

  i2c_master_transmit_receive(m_hDevice, (const uint8_t *)&Register, 1, &Data, 1, -1);
  if(State) Data |= (1 << BitPos); // forces nth bit of _b to be 1.  all other bits left alone.
  else Data &= ~(1 << BitPos); // forces nth bit of _b to be 0.  all other bits left alone.
  Buffer[0] = Register;
  Buffer[1] = Data;
  i2c_master_transmit(m_hDevice, Buffer, 2, -1);
  i2c_master_transmit_receive(m_hDevice, (const uint8_t *)&Register, 1, &Data, 1, -1);
  return ((Data >> BitPos) & 1);
}

/////////////////////////////////////////////////////////////////////////////////////

inline bool AXP2101::ClearRegisterBit(uint8_t Register, int BitPos)
{
uint8_t Data, Buffer[2];

  i2c_master_transmit_receive(m_hDevice, (const uint8_t *)&Register, 1, &Data, 1, -1);
  Data &= ~(1 << BitPos); // forces nth bit of _b to be 0.  all other bits left alone.
  Buffer[0] = Register;
  Buffer[1] = Data;
  i2c_master_transmit(m_hDevice, Buffer, 2, -1);
  i2c_master_transmit_receive(m_hDevice, (const uint8_t *)&Register, 1, &Data, 1, -1);
  return ((Data >> BitPos) & 1);
}

/////////////////////////////////////////////////////////////////////////////////////

inline bool AXP2101::GetBatfetState(void)
{
	return GetRegisterBit(AXP2101_STATUS1, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

inline bool AXP2101::IsBatteryConnect(void)
{
	return GetRegisterBit(AXP2101_STATUS1, 3);
}

/////////////////////////////////////////////////////////////////////////////////////

inline bool AXP2101::IsBatInActiveModeState(void)
{
	return GetRegisterBit(AXP2101_STATUS1, 2);
}

/////////////////////////////////////////////////////////////////////////////////////

inline bool AXP2101::GetThermalRegulationStatus(void)
{
	return GetRegisterBit(AXP2101_STATUS1, 1);
}

/////////////////////////////////////////////////////////////////////////////////////

inline bool AXP2101::GetCurrentLimitStatus(void)
{
	return GetRegisterBit(AXP2101_STATUS1, 0);
}

/////////////////////////////////////////////////////////////////////////////////////

inline bool AXP2101::IsCharging(void)
{
	return (ReadRegister(AXP2101_STATUS2) >> 5) == 0x01;
}

/////////////////////////////////////////////////////////////////////////////////////

inline bool AXP2101::IsDischarge(void)
{
	return (ReadRegister(AXP2101_STATUS2) >> 5) == 0x02;
}

/////////////////////////////////////////////////////////////////////////////////////

inline bool AXP2101::IsStandby(void)
{
	return (ReadRegister(AXP2101_STATUS2) >> 5) == 0x00;
}

/////////////////////////////////////////////////////////////////////////////////////

inline bool AXP2101::IsPowerOn(void)
{
	return GetRegisterBit(AXP2101_STATUS2, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

inline bool AXP2101::IsPowerOff(void)
{
	return GetRegisterBit(AXP2101_STATUS2, 4);
}

/////////////////////////////////////////////////////////////////////////////////////

inline bool AXP2101::IsVbusIn(void)
{
	return GetRegisterBit(AXP2101_STATUS2, 3) == 0 && IsVbusGood();
}

/////////////////////////////////////////////////////////////////////////////////////

inline bool AXP2101::GetProtectedChannel(uint8_t Channel)
{
    return m_ProtectedMask & _BV(Channel);
}

/////////////////////////////////////////////////////////////////////////////////////

inline void AXP2101::SetProtectedChannel(uint8_t Channel)
{
    m_ProtectedMask |= _BV(Channel);
}

/////////////////////////////////////////////////////////////////////////////////////

inline void AXP2101::SetUnprotectChannel(uint8_t Channel)
{
    m_ProtectedMask &= (~_BV(Channel));
}

inline bool AXP2101::IsBitSet(uint8_t Data, uint8_t Mask)
{
  return ((Data & Mask) > 0) ? true : false;
}
