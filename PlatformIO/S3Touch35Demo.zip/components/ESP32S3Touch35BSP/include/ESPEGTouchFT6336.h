/*
 *                LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#pragma once

#include "ESPEGTouchController.h"
#include "driver/i2c_master.h"

/////////////////////////////////////////////////////////////////////////////////////

#define I2C_MASTER_FREQ_HZ 									    400000  						// I2C master clock frequency 
#define I2C_MASTER_TX_BUF_DISABLE 					    0 									// I2C master doesn't need buffer 
#define I2C_MASTER_RX_BUF_DISABLE 					    0 									// I2C master doesn't need buffer 
#define I2C_MASTER_TIMEOUT_MS 							    1000

#define LCD_TOUCH_V_RES											    480
#define LCD_TOUCH_H_RES											    320
#define ESP_LCD_TOUCH_IO_I2C_FT6336_ADDRESS     0x38

#define TOUCH_FT6336_DEV_MODE_REG (0x00)
#define TOUCH_FT6336_GEST_ID_REG (0x01)
#define TOUCH_FT6336_POINTS_REG (0x02)
#define TOUCH_FT6336_P1_XH_REG (0x03)
#define TOUCH_FT6336_P1_XL_REG (0x04)
#define TOUCH_FT6336_P1_YH_REG (0x05)
#define TOUCH_FT6336_P1_YL_REG (0x06)

#define TOUCH_FT6336_P2_XH_REG (0x09)
#define TOUCH_FT6336_P2_XL_REG (0x0A)
#define TOUCH_FT6336_P2_YH_REG (0x0B)
#define TOUCH_FT6336_P2_YL_REG (0x0C)

/////////////////////////////////////////////////////////////////////////////////////

#define ESP_LCD_TOUCH_IO_I2C_FT6336_CONFIG()          \
  {                                                   \
    .dev_addr = ESP_LCD_TOUCH_IO_I2C_FT6336_ADDRESS,  \
		.on_color_trans_done = NULL,									    \
		.user_ctx = NULL,														      \
    .control_phase_bytes = 1,                         \
    .dc_bit_offset = 0,                               \
    .lcd_cmd_bits = 8,                                \
		.lcd_param_bits = 16,														  \
    .flags = {                                        \
			.dc_low_on_data = 0,													  \
      .disable_control_phase = 1,                     \
    },                                                \
    .scl_speed_hz = 200 * 1000                        \
  }

/////////////////////////////////////////////////////////////////////////////////////

// I2C settings
const gpio_num_t I2CTouchSclIO_c	 					= GPIO_NUM_7;       // GPIO number used for I2C master clock 
const gpio_num_t I2CTouchSdaIO_c	 					= GPIO_NUM_8;       // GPIO number used for I2C master data  
const gpio_num_t I2CTouchIntIO_c						= GPIO_NUM_NC;      //4 GPIO number used for Interrupt  
const gpio_num_t I2CTouchResetIO_c					= GPIO_NUM_NC;       // GPIO number used for Reset 

/////////////////////////////////////////////////////////////////////////////////////


class ESPGLTouchFT6336 : public ESPGLTouchController
{
public:
                            ESPGLTouchFT6336(void);
  virtual                   ~ESPGLTouchFT6336(void);

  void                      Initialise(void);
  esp_err_t                 Configure(const ESPGL_LCDTouchConfig_t *pConfig);
  esp_err_t                 ReadData(void);
  bool                      GetCoordinates(uint16_t *x, uint16_t *y, uint16_t *strength, uint8_t *point_num, uint8_t max_point_num);

  // FT6336 specific
  esp_err_t                 Reset(void);
  void                      i2cConfig(i2c_master_bus_handle_t hi2cBus);
  esp_err_t                 i2cRead(uint8_t Register, uint8_t *pData, uint8_t Length);
  esp_err_t                 i2cWrite(uint8_t Register, uint8_t *pData, uint8_t Length);

private:
  i2c_master_dev_handle_t   m_hDevice;
};

