/*
 *                LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by Rob Tillaart
 *  URL: https://github.com/RobTillaart/TCA9554
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by Rob Tillaart
 *
 */

#pragma once

#include <string.h>  // For memset
#include "driver/i2c_master.h"
#include <esp_log.h>

/////////////////////////////////////////////////////////////////////////////////////

#define TCA9554_INPUT            0x00
#define TCA9554_OUTPUT           0x01
#define TCA9554_INVALID          -1
#define TCA9554_HIGH             1
#define TCA9554_LOW              0

typedef enum {
  TCA9554_INPUT_REGISTER,       //  Read()
  TCA9554_OUTPUT_REGISTER,      //  Write()
  TCA9554_POLARITY_REGISTER,    //  Get/SetPolarity()
  TCA9554_CONFIGURATION_PORT    //  PinMode()
} TCA9554Registers_e;

typedef enum {
  TCA9554_PIN_NUM_0,       
  TCA9554_PIN_NUM_1,      
  TCA9554_PIN_NUM_2,      
  TCA9554_PIN_NUM_3,      
  TCA9554_PIN_NUM_4,      
  TCA9554_PIN_NUM_5,      
  TCA9554_PIN_NUM_6,      
  TCA9554_PIN_NUM_7,      
} TCA9554Pins_e;

/////////////////////////////////////////////////////////////////////////////////////

class TCA9554
{
public:
                    TCA9554(void);
  bool              Initialise(i2c_master_bus_handle_t hi2cBus, uint8_t Mode = TCA9554_INPUT, uint8_t Mask = 0x00);
  bool              IsConnected();

  bool              PinMode1(uint8_t Pin, bool Input);
  bool              Write1(uint8_t Pin, uint8_t Value);
  uint8_t           Read1(uint8_t Pin);
  bool              SetPolarity(uint8_t Pin, uint8_t Value);    //  input pins only.
  uint8_t           GetPolarity(uint8_t Pin);


  bool              PinMode8(uint8_t Mask);
  bool              Write8(uint8_t Mask);
  uint8_t           Read8();
  bool              SetPolarity8(uint8_t Mask);
  uint8_t           GetPolarity8();
 

protected:
  esp_err_t         Write(uint8_t Register, uint8_t Data);
  esp_err_t         Read(uint8_t Register, uint8_t *pVal);

private:
  i2c_master_dev_handle_t m_hDevice;
	uint8_t 			          m_Address; 
};


