/*
 *              Copyright (c) 2020-2021 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original WeatherClock
 *
 */

#pragma once

#include <nvs_flash.h>
#include <nvs.h>
#include <string.h>
#include <esp_log.h>

esp_err_t   CheckNVS(void);
void        NVSReport(uint8_t Report, const char *pVar = nullptr);
esp_err_t   NVSPutInt8(const char *Tag, const int8_t Var);
esp_err_t   NVSGetInt8(const char *Tag, int8_t *pVar, int8_t Default);
esp_err_t   NVSPutUint8(const char *Tag, const uint8_t Var);
esp_err_t   NVSGetUint8(const char *Tag, uint8_t *pVar, uint8_t Default);
esp_err_t   NVSPutInt16(const char *Tag, const int16_t Var);
esp_err_t   NVSGetInt16(const char *Tag, int16_t *pVar, int16_t Default);
esp_err_t   NVSPutUint16(const char *Tag, const uint16_t Var);
esp_err_t   NVSGetUint16(const char *Tag, uint16_t *pVar, uint16_t Default);
esp_err_t   NVSPutInt32(const char *Tag, const int32_t Var);
esp_err_t   NVSGetInt32(const char *Tag, int32_t *pVar, int Default);
esp_err_t   NVSPutUint32(const char *Tag, const uint32_t Var);
esp_err_t   NVSGetUint32(const char *Tag, uint32_t *pVar, uint32_t Default);
esp_err_t   NVSPutFloat(const char *Tag, const float Var);
esp_err_t   NVSGetFloat(const char *Tag, float *pVar, float Default);
esp_err_t   NVSPutStr(const char *Tag, const char *pVar);
esp_err_t   NVSGetStr(const char *Tag, char *pVar, size_t Size, const char *pDefault);
esp_err_t   NVSPutArray(const char *Tag, const uint8_t *pVar, size_t Count);
esp_err_t   NVSGetArray(const char *Tag, uint8_t *pVar, size_t Count);
