/*
 *              Copyright (c) 2025-2026 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 *  Based on a project from wytr
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original VanMonitor
 *
 */

#pragma once

#include "esp_err.h"
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include "NVSUtils.h"

#define DEFAULT_AP_PASSWORD "12345678"

// brightness settings
esp_err_t LoadBrightness(uint8_t *brightness_out);
esp_err_t save_brightness(uint8_t brightness);

// AES key handling
esp_err_t LoadAESKey(uint8_t key_out[16]);
esp_err_t SaveAESKey(const uint8_t key_in[16]);

// Screensaver settings
esp_err_t LoadScreensaverSettings(bool *enabled, uint8_t *brightness, uint16_t *timeout);
esp_err_t SaveScreensaverSettings(bool enabled, uint8_t brightness, uint16_t timeout);

// Wi‑Fi AP settings handling (NVS namespace: "wifi")
// ssid_out and pass_out must have space for ssid_len and pass_len, respectively.
// On return, *ssid_len and *pass_len are set to the actual string lengths (including null).
esp_err_t load_wifi_config(char *ssid_out, size_t *ssid_len,
                           char *pass_out, size_t *pass_len,
                           uint8_t *enabled_out);

// Save AP settings; ssid and pass should be null‑terminated strings.
esp_err_t save_wifi_config(const char *ssid,
                           const char *pass,
                           uint8_t enabled_out);

// Relay tab configuration persistence
esp_err_t LoadRelayConfig(bool *enabled_out,
                            uint8_t *count_out,
                            uint8_t *pins_out,
                            char (*labels_out)[20],
                            size_t max_pins);

esp_err_t SaveRelayConfig(bool enabled,
                            const uint8_t *pins,
                            const char (*labels)[20],
                            uint8_t count);

// Victron BLE debug flag persistence (NVS namespace: "debug")
esp_err_t LoadVictronDebug(bool *enabled_out);
esp_err_t SaveVictronDebug(bool enabled);
