/*
 *              Copyright (c) 2025-2026 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 *  Based on a project from wytr
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original VanMonitor
 *
 */

#include "SettingsNVS.h"
#include <string.h>

static const char TagAES[] = "AESkey";
static const char TagBacklight[] = "Backlight";
static const char Tag_SSEnable[] = "SSEnable";
static const char TAGSSBright[] = "SSBright";
static const char TagSSTimeout[] = "SSTimeout";
static const char TagRelayEnable[] = "RelayEnable";
static const char TagRelayCount[] = "RelayCount";
static const char TagRelayPins[] = "RelayPins";
static const char TagRelayLabels[] = "RelayLabels";
static const char TagVictronDebug[] = "VictronDebug";
static const char TagRelayMaxPins = 8;
static const char RelayUnusedPin = 0xFF;

esp_err_t LoadBrightness(uint8_t *pValue)
{
  return NVSGetUint8(TagBacklight, pValue, 5);
}

esp_err_t save_brightness(uint8_t Value)
{
  return NVSPutUint8(TagBacklight, Value);
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t LoadAESKey(uint8_t *pValue)
{
  return NVSGetArray(TagAES, pValue, 16);
}

esp_err_t SaveAESKey(const uint8_t *pValue)
{
	return NVSPutArray(TagAES, pValue, 16);
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t LoadScreensaverSettings(bool *pEnable, uint8_t *pBrightness, uint16_t *pTimeout)
{
esp_err_t Res = ESP_FAIL;

  Res = NVSGetUint8(Tag_SSEnable, (uint8_t*)pEnable, 0);
  if(Res == ESP_OK) Res = NVSGetUint8(TAGSSBright, pBrightness, 50);
  if(Res == ESP_OK) Res = NVSGetUint16(TagSSTimeout, pTimeout, 10);
  return Res;
}

esp_err_t SaveScreensaverSettings(bool Enable, uint8_t Brightness, uint16_t Timeout)
{
esp_err_t Res = ESP_FAIL;

  Res = NVSPutUint8(Tag_SSEnable, Enable ? 1 : 0);
  if(Res == ESP_OK) Res = NVSPutUint8(TAGSSBright, Brightness);
  if(Res == ESP_OK) Res = NVSPutInt16(TagSSTimeout, Timeout);
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t LoadRelayConfig(bool *pEnable, uint8_t *pCount, uint8_t *pPins, char (*pLabels)[20], size_t MaxPins)
{
uint8_t Pins[TagRelayMaxPins];
char Labels[TagRelayMaxPins][20];
uint8_t Count;
bool Enable;

	if(pEnable == nullptr || pCount == nullptr || pPins == nullptr || MaxPins == 0) return ESP_ERR_INVALID_ARG;
  esp_err_t Res = NVSGetUint8(TagRelayEnable, (uint8_t*)&Enable, 1);
  if(Res == ESP_OK) Res = NVSGetUint8(TagRelayCount, &Count, 0);
	if(Count > TagRelayMaxPins){
    NVSPutUint8(TagRelayCount, TagRelayMaxPins);
    Count = TagRelayMaxPins;
  }
	memset(Pins, TagRelayMaxPins, sizeof(Pins));
	Res = NVSGetArray(TagRelayPins, Pins, sizeof(Pins));
	if(Res != ESP_OK) {
		memset(Pins, TagRelayMaxPins, sizeof(Pins));
    NVSPutArray(TagRelayPins, Pins, sizeof(Pins));
	}
	Res = NVSGetArray(TagRelayLabels, (uint8_t*)Labels, sizeof(Labels));
	if(Res != ESP_OK) {
		for(size_t i = 0; i < TagRelayMaxPins; ++i) Labels[i][0] = '\0';
    NVSPutArray(TagRelayLabels, (uint8_t*)Labels, sizeof(Labels));
	}
	for(size_t i = 0; i < TagRelayMaxPins; ++i) {
		if(i < Count) pPins[i] = Pins[i];
		else pPins[i] = RelayUnusedPin;
		if(pLabels != nullptr) {
			if(i < Count) {
				strncpy(pLabels[i], Labels[i], 20);
				pLabels[i][19] = '\0';
			}
			else pLabels[i][0] = '\0';
		}
	}
	*pEnable = (Enable != 0);
	*pCount = Count;
	return ESP_OK;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t SaveRelayConfig(bool Enable,	const uint8_t *pPins, const char (*pLabels)[20], uint8_t Count)
{
	if(Count > TagRelayMaxPins) Count = TagRelayMaxPins;
  esp_err_t Res = NVSPutUint8(TagRelayEnable, Enable ? 1 : 0);
  if(Res == ESP_OK) Res = NVSPutUint8(TagRelayCount, Count);
  if(Res == ESP_OK) Res = NVSPutArray(TagRelayPins, pPins, sizeof(pPins));
  if(Res == ESP_OK) Res = NVSPutArray(TagRelayLabels, (uint8_t*)pLabels, sizeof(pLabels));
	return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t LoadVictronDebug(bool *pValue)
{
	if(pValue == nullptr) return ESP_ERR_INVALID_ARG;
  return NVSGetUint8(TagVictronDebug, (uint8_t*)pValue, 0);
}

esp_err_t SaveVictronDebug(bool Enable)
{
  return NVSPutUint8(TagVictronDebug, Enable ? 1 : 0);
}
