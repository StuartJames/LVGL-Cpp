/*
 *              Copyright (c) 2020-2021 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original WeatherClock
 *
 */

////////////////////////////////////////////////////////////////////////////////

#include "NVSUtils.h"

////////////////////////////////////////////////////////////////////////////////

static const char *_TAG = "[NVS   ]";
static const char *Namespace = "storage";

enum{
  NVS_OPEN_ERROR,
  NVS_WRITING,
  NVS_VAL_UNINIT,
  NVS_READ_ERROR
};

///////////////////////////////////////////////////////////////////////////////////

esp_err_t CheckNVS(void)
{
//  ESP_ERROR_CHECK(nvs_flash_erase());
  esp_err_t Res = nvs_flash_init();
  if(Res == ESP_ERR_NVS_NO_FREE_PAGES || Res == ESP_ERR_NVS_NEW_VERSION_FOUND){   // NVS partition was truncated and needs to be erased Retry nvs_flash_init
    ESP_ERROR_CHECK(nvs_flash_erase());
    Res = nvs_flash_init();
  }
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

void NVSReport(uint8_t Report, const char *pVar/* = nullptr*/)
{
  switch(Report){
    case NVS_OPEN_ERROR:
      ESP_LOGI(_TAG, "Error (%s) opening NVS handle!", pVar);
      break;
    case NVS_WRITING:
      ESP_LOGI(_TAG, "Writing to NVS...");
      break;
    case NVS_VAL_UNINIT:
      ESP_LOGI(_TAG, "Value not initialised");
      break;
    case NVS_READ_ERROR:
      ESP_LOGI(_TAG, "Error (%s) reading", pVar);
      break;
  }
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSPutInt8(const char *Tag, int8_t Var)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open(Namespace, NVS_READWRITE, &Handle);
  if(Res != ESP_OK) NVSReport(NVS_OPEN_ERROR, esp_err_to_name(Res));
  else{
    NVSReport(NVS_WRITING);
    Res = nvs_set_i8(Handle, Tag, Var);
    Res = nvs_commit(Handle);
  }
  nvs_close(Handle);
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSGetInt8(const char *Tag, int8_t *Var, int8_t Default)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open(Namespace, NVS_READWRITE, &Handle);
  if(Res != ESP_OK) NVSReport(NVS_OPEN_ERROR, esp_err_to_name(Res));
  else{
    Res = nvs_get_i8(Handle, Tag, Var);
    nvs_close(Handle);
    switch(Res){
      case ESP_OK:
        break;
      case ESP_ERR_NVS_NOT_FOUND:
        NVSReport(NVS_VAL_UNINIT);
        *Var = Default;
        Res = NVSPutInt8(Tag, *Var);
        break;
      default:
        NVSReport(NVS_READ_ERROR, esp_err_to_name(Res));
    }
  }
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSPutUint8(const char *Tag, uint8_t Var)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open(Namespace, NVS_READWRITE, &Handle);
  if(Res != ESP_OK) NVSReport(NVS_OPEN_ERROR, esp_err_to_name(Res));
  else{
    NVSReport(NVS_WRITING);
    Res = nvs_set_u8(Handle, Tag, Var);
    Res = nvs_commit(Handle);
  }
  nvs_close(Handle);
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSGetUint8(const char *Tag, uint8_t *Var, uint8_t Default)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open(Namespace, NVS_READWRITE, &Handle);
  if(Res != ESP_OK) NVSReport(NVS_OPEN_ERROR, esp_err_to_name(Res));
  else{
    Res = nvs_get_u8(Handle, Tag, Var);
    nvs_close(Handle);
    switch(Res){
      case ESP_OK:
        break;
      case ESP_ERR_NVS_NOT_FOUND:
        NVSReport(NVS_VAL_UNINIT);
        *Var = Default;
        Res = NVSPutUint8(Tag, *Var);
        break;
      default:
        NVSReport(NVS_READ_ERROR, esp_err_to_name(Res));
    }
  }
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSPutInt16(const char *Tag, int16_t Var)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open(Namespace, NVS_READWRITE, &Handle);
  if(Res != ESP_OK) NVSReport(NVS_OPEN_ERROR, esp_err_to_name(Res));
  else{
    NVSReport(NVS_WRITING);
    Res = nvs_set_i16(Handle, Tag, Var);
    Res = nvs_commit(Handle);
  }
  nvs_close(Handle);
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSGetInt16(const char *Tag, int16_t *pVar, int16_t Default)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open(Namespace, NVS_READWRITE, &Handle);
  if(Res != ESP_OK) NVSReport(NVS_OPEN_ERROR, esp_err_to_name(Res));
  else{
    Res = nvs_get_i16(Handle, Tag, pVar);
    nvs_close(Handle);
    switch(Res){
      case ESP_OK:
        break;
      case ESP_ERR_NVS_NOT_FOUND:
        NVSReport(NVS_VAL_UNINIT);
        *pVar = Default;
        Res = NVSPutInt16(Tag, *pVar);
        break;
      default:
        NVSReport(NVS_READ_ERROR, esp_err_to_name(Res));
    }
  }
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSPutUint16(const char *Tag, uint16_t Var)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open(Namespace, NVS_READWRITE, &Handle);
  if(Res != ESP_OK) NVSReport(NVS_OPEN_ERROR, esp_err_to_name(Res));
  else{
    NVSReport(NVS_WRITING);
    Res = nvs_set_u16(Handle, Tag, Var);
    Res = nvs_commit(Handle);
  }
  nvs_close(Handle);
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSGetUint16(const char *Tag, uint16_t *pVar, uint16_t Default)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open(Namespace, NVS_READWRITE, &Handle);
  if(Res != ESP_OK) NVSReport(NVS_OPEN_ERROR, esp_err_to_name(Res));
  else{
    Res = nvs_get_u16(Handle, Tag, pVar);
    nvs_close(Handle);
    switch(Res){
      case ESP_OK:
        break;
      case ESP_ERR_NVS_NOT_FOUND:
        NVSReport(NVS_VAL_UNINIT);
        *pVar = Default;
        Res = NVSPutInt16(Tag, *pVar);
        break;
      default:
        NVSReport(NVS_READ_ERROR, esp_err_to_name(Res));
    }
  }
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSPutInt32(const char *Tag, int32_t Var)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open(Namespace, NVS_READWRITE, &Handle);
  if(Res != ESP_OK) NVSReport(NVS_OPEN_ERROR, esp_err_to_name(Res));
  else{
    NVSReport(NVS_WRITING);
    Res = nvs_set_i32(Handle, Tag, Var);
    Res = nvs_commit(Handle);
  }
  nvs_close(Handle);
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSGetInt32(const char *Tag, int32_t *pVar, int Default)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open(Namespace, NVS_READWRITE, &Handle);
  if(Res != ESP_OK) NVSReport(NVS_OPEN_ERROR, esp_err_to_name(Res));
  else{
    Res = nvs_get_i32(Handle, Tag, pVar);
    nvs_close(Handle);
    switch(Res){
      case ESP_OK:
        break;
      case ESP_ERR_NVS_NOT_FOUND:
        NVSReport(NVS_VAL_UNINIT);
        *pVar = Default;
        Res = NVSPutInt32(Tag, *pVar);
        break;
      default:
        NVSReport(NVS_READ_ERROR, esp_err_to_name(Res));
    }
  }
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSPutUint32(const char *Tag, uint32_t Var)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open(Namespace, NVS_READWRITE, &Handle);
  if(Res != ESP_OK) NVSReport(NVS_OPEN_ERROR, esp_err_to_name(Res));
  else{
    NVSReport(NVS_WRITING);
    Res = nvs_set_u32(Handle, Tag, Var);
    Res = nvs_commit(Handle);
  }
  nvs_close(Handle);
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSGetUint32(const char *Tag, uint32_t *pVar, uint32_t Default)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open(Namespace, NVS_READWRITE, &Handle);
  if(Res != ESP_OK) NVSReport(NVS_OPEN_ERROR, esp_err_to_name(Res));
  else{
    Res = nvs_get_u32(Handle, Tag, pVar);
    nvs_close(Handle);
    switch(Res){
      case ESP_OK:
        break;
      case ESP_ERR_NVS_NOT_FOUND:
        NVSReport(NVS_VAL_UNINIT);
        *pVar = Default;
        Res = NVSPutUint32(Tag, *pVar);
        break;
      default:
        NVSReport(NVS_READ_ERROR, esp_err_to_name(Res));
    }
  }
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSPutFloat(const char *Tag, float Var)
{
union{
  int32_t i;
  float   f;
} Corr;

  Corr.f = Var;
  return NVSPutInt32(Tag, Corr.i);
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSGetFloat(const char *Tag, float *pVar, float Default)
{
union{
  int32_t i;
  float   f;
} Corr;

  esp_err_t Res = NVSGetInt32(Tag, &Corr.i, 0);
  if(Res == ESP_OK) *pVar = Corr.f;
  else *pVar = Default;
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSPutArray(const char *Tag, const uint8_t *pVar, size_t Count)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open(Namespace, NVS_READWRITE, &Handle);
  if(Res != ESP_OK) NVSReport(NVS_OPEN_ERROR, esp_err_to_name(Res));
  else{
    NVSReport(NVS_WRITING);
    Res = nvs_set_blob(Handle, Tag, pVar, Count);
    Res = nvs_commit(Handle);
  }
  nvs_close(Handle);
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSGetArray(const char *Tag, uint8_t *pVar, size_t Count)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open(Namespace, NVS_READWRITE, &Handle);
  if(Res != ESP_OK) NVSReport(NVS_OPEN_ERROR, esp_err_to_name(Res));
  else{
    Res = nvs_get_blob(Handle, Tag, pVar, &Count);
    nvs_close(Handle);
    switch(Res){
      case ESP_OK:
        break;
      case ESP_ERR_NVS_NOT_FOUND:
        NVSReport(NVS_VAL_UNINIT);
        break;
      default:
        NVSReport(NVS_READ_ERROR, esp_err_to_name(Res));
        break;
    }
  }
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////


esp_err_t NVSPutStr(const char *Tag, const char *pVar)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open(Namespace, NVS_READWRITE, &Handle);
  if(Res != ESP_OK) NVSReport(NVS_OPEN_ERROR, esp_err_to_name(Res));
  else{
    NVSReport(NVS_WRITING);
    Res = nvs_set_str(Handle, Tag, pVar);
    Res = nvs_commit(Handle);
  }
  nvs_close(Handle);
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSGetStr(const char *Tag, char *pVar, size_t Size, const char *pDefault)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open(Namespace, NVS_READWRITE, &Handle);
  if(Res != ESP_OK) NVSReport(NVS_OPEN_ERROR, esp_err_to_name(Res));
  else{
    size_t Length = 0;
    Res = nvs_get_str(Handle, Tag, NULL, &Length);                                 // get the length of the string in NVS
    if(Length <= Size) Res = nvs_get_str(Handle, Tag, pVar, &Length);              // check for Size
    else{
      ESP_LOGI(_TAG, "String size to big");
      Res = ESP_ERR_NVS_INVALID_LENGTH;
    }
    nvs_close(Handle);
    switch(Res){
     case ESP_OK:
       break;
     case ESP_ERR_NVS_NOT_FOUND:{
       NVSReport(NVS_VAL_UNINIT);
       strncpy(pVar, pDefault, Size);
       Res = NVSPutStr(Tag, pVar);
       break;
     }
     default:{
       NVSReport(NVS_READ_ERROR, esp_err_to_name(Res));
       break;
     }
    }
  }
  return Res;
}


