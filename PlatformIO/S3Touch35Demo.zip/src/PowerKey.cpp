/*
 *              Copyright (c) 2025-2026 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original VanMonitor
 *
 */

#include "LEGLDemo35.h"

/////////////////////////////////////////////////////////////////////////////////////

PowerKey::PowerKey(void)
{
  m_PowerControlPin = GPIO_NUM_NC;
  m_PowerInputPin = GPIO_NUM_NC;
  m_ButtonState = 0;
  m_DeviceState = 0;
  m_LongPress = 0;
}

/////////////////////////////////////////////////////////////////////////////////////

void PowerKey::Read(void)
{
	if(m_ButtonState) {
		if(!gpio_get_level(m_PowerInputPin)) {
			if(m_ButtonState == 2) {
				m_LongPress++;
				if(m_LongPress >= DeviceSleepTime_c){
					if(m_LongPress < DeviceRestartTime_c) m_DeviceState = 1;
					else if((m_LongPress >= DeviceRestartTime_c) && (m_LongPress < DeviceShutdownTime_c)) m_DeviceState = 2;
					else if(m_LongPress >= DeviceShutdownTime_c) Shutdown();
				}
			}
		}
		else {
			if(m_ButtonState == 1) m_ButtonState = 2;
			m_LongPress = 0;
		}
	}
}

/////////////////////////////////////////////////////////////////////////////////////

void PowerKey::FallAsleep(void)
{
}

/////////////////////////////////////////////////////////////////////////////////////

void PowerKey::Restart(void)
{
}

/////////////////////////////////////////////////////////////////////////////////////

void PowerKey::Shutdown(void)
{
	gpio_set_level(m_PowerControlPin, false);
//	g_DisplayObj.SetLevel(0);
}

/////////////////////////////////////////////////////////////////////////////////////

void PowerKey::ConfigurePin(gpio_num_t Pin, gpio_mode_t Mode)
{
	gpio_reset_pin(Pin);
	gpio_set_direction(Pin, Mode);
}

/////////////////////////////////////////////////////////////////////////////////////

void PowerKey::Initialise(gpio_num_t CntrlPin, gpio_num_t InputPin)
{
  m_PowerControlPin = CntrlPin;
  m_PowerInputPin = InputPin;
	ConfigurePin(m_PowerInputPin, GPIO_MODE_INPUT);
	ConfigurePin(m_PowerControlPin, GPIO_MODE_OUTPUT);
	gpio_set_level(m_PowerControlPin, false);
	vTaskDelay(100);
	if(!gpio_get_level(m_PowerInputPin)) {
		m_ButtonState = 1;
		gpio_set_level(m_PowerControlPin, true);
	}
}
