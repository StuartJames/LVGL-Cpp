/*
 *              Copyright (c) 2025-2026 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original VanMonitor
 *
 */

/////////////////////////////////////////////////////////////////////////////////////
#define _MAIN_

#include "LEGLDemo35.h"

extern "C" {
  void app_main(void);
}

/////////////////////////////////////////////////////////////////////////////////////

static const char *_TAG = "[Main  ]";

/////////////////////////////////////////////////////////////////////////////////////

BaseType_t QueueSysEvent(EventMsgID_e Event, void *pData)
{
BaseType_t Status = pdFALSE;
QueueMsg_t Msg;

	if(Event < SYS_MSG_EV_MAX) {
		Msg.EventID = Event;
		Msg.pData = pData;
		Status = xQueueSend(g_EventQueue, &Msg, portMAX_DELAY);
	}
	return Status;
}

/////////////////////////////////////////////////////////////////////////////////////

void Initialise_i2c(gpio_num_t SCL, gpio_num_t SDA, i2c_port_t Port)
{
i2c_master_bus_config_t i2cConfig;
esp_err_t Res;

  memset(&i2cConfig, 0, sizeof(i2c_master_bus_config_t));
  i2cConfig.clk_source = I2C_CLK_SRC_DEFAULT;
  i2cConfig.i2c_port = (i2c_port_num_t)Port;
  i2cConfig.scl_io_num = SCL;
  i2cConfig.sda_io_num = SDA;
  i2cConfig.glitch_ignore_cnt = 7;
  i2cConfig.flags.enable_internal_pullup = true;

  if((Res = i2c_new_master_bus(&i2cConfig, &g_hi2cBus)) != ESP_OK){
		ESP_LOGE(_TAG, "I2C initialize failed: %d.", Res);
		while(true) vTaskDelay(pdMS_TO_TICKS(1000));
	}
	ESP_LOGI(_TAG, "I2C initialized successfully");
}

/////////////////////////////////////////////////////////////////////////////////////

void InitialiseHarware(void)
{
  Initialise_i2c(I2CSCLPin_c, I2CSDAPin_c, I2CPort_c);
  g_Expander.Initialise(g_hi2cBus);
  g_Expander.PinMode8(ExtenderMask_c);    // configure pin directions
  g_Expander.Write1(TCA9554_PIN_NUM_1, 0);
  vTaskDelay(pdMS_TO_TICKS(100));
  g_Expander.Write1(TCA9554_PIN_NUM_1, 1);
  g_Expander.Write1(TCA9554_PIN_NUM_0, 1);
  vTaskDelay(pdMS_TO_TICKS(100));

  g_PowerControl.Initialise(g_hi2cBus);
  vTaskDelay(pdMS_TO_TICKS(200));

  g_RTC.Initialise(g_hi2cBus);
  g_IMU.Initialise(g_hi2cBus);

//  g_SDMMCObj.Initialise(pMountPoint_c);
//	g_SDMMCObj.GetFlashSize();

//  g_PwrKeyObj.Initialise(PowerKeyPin_c, PowerControlPin_c);
}

/////////////////////////////////////////////////////////////////////////////////////

void app_main(void)
{

	ESP_LOGI(_TAG, "***************************");
  ESP_LOGI(_TAG, "*    LEGL Widget Demo     *");
  ESP_LOGI(_TAG, "*  (c) HydraSystems 2026  *");
  ESP_LOGI(_TAG, "* Written by Stuart James *");
  ESP_LOGI(_TAG, "***************************");
  ESP_LOGI(_TAG, "\n\nFree memory: %ld bytes", esp_get_free_heap_size());
  ESP_LOGI(_TAG, "IDF version: %s", esp_get_idf_version());
  esp_log_level_set("gpio", ESP_LOG_NONE);  // Disable default gpio logging messages
  
  if(CheckNVS() == ESP_OK){
    g_NVSAvailable = true;
  }
	g_SystemFlags = xEventGroupCreate();
  if(g_SystemFlags == NULL){
    ESP_LOGE(_TAG, "Failed to create system flags.");
		while(true) vTaskDelay(pdMS_TO_TICKS(1000));
  }

	g_EventQueue = xQueueCreate(GUI_EVENT_QUEUE_LEN, sizeof(QueueMsg_t));
	if(g_EventQueue == NULL) {
		ESP_LOGE(_TAG, "Unable to create event queue.");
		while(true) vTaskDelay(pdMS_TO_TICKS(1000));
	}

  InitialiseHarware();  

	BaseType_t id = xTaskCreatePinnedToCore(DisplayThread, "Display thread", 10240, NULL, 8, NULL, 0);         
  if(id == 0L){
    ESP_LOGE(_TAG, "Failed to create display thread.");
		while(true) vTaskDelay(pdMS_TO_TICKS(1000));
  }
  xEventGroupWaitBits(g_SystemFlags, SYSFLAG_DISPLAY_READY, pdFALSE, pdTRUE, portMAX_DELAY); // wait for display thread to become ready

	xEventGroupSetBits(g_SystemFlags, SYSFLAG_SYSTEM_UP);
	ESP_LOGI(_TAG, "System Initialised.");
  ESP_LOGI(_TAG, "Free memory: %ld bytes", esp_get_free_heap_size());
	while(true) {
		vTaskDelay(pdMS_TO_TICKS(1000));	
	}
}
