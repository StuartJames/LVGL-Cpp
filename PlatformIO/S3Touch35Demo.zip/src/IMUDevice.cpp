
/*
 *              Copyright (c) 2025-2026 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original VanMonitor
 *
 */

#include "LEGLDemo35.h"

/////////////////////////////////////////////////////////////////////////////////////

#define Kp 4.50f  // proportional gain governs rate of convergence to accelerometer/magnetometer
#define Ki 1.0f   // integral gain governs rate of convergence of gyroscope biases

/////////////////////////////////////////////////////////////////////////////////////

void IMUDevice::Initialise(i2c_master_bus_handle_t hi2cBus)
{
	m_IMUSensor.Initialise(hi2cBus);
	//  m_IMUSensor.SetState(SENSOR_STATE_LOCKING);    // doesn't seem to work
	m_Q0 = 1.0f;
	m_Q1 = 0.0f;
	m_Q2 = 0.0f;
	m_Q3 = 0.0f;
}

/////////////////////////////////////////////////////////////////////////////////////

void IMUDevice::Update(EulerAngles_t *pAngles, uint8_t ChipOrientation)
{
float temp;

  m_IMUSensor.ReadAccelerometer(&m_AccelData);
  m_IMUSensor.ReadGyroscope(&m_GyroData);
	m_IMUSensor.ReadMagnatometer(&m_MagnData);
  switch(m_Orientation){
    case OS_UP:{                      // x=<, y=>, -z=v
      m_AccelData.z = -m_AccelData.z;
      break;
    }
    case OS_DOWN:{                    // x=<, y=>, z=^
      break;
    }
    case OS_FRONT:                    // -z=<, -y=>, -x=v  
    case OS_REAR:{                    // -z=<, -y=>, -x=v  
      temp = m_AccelData.x;             
      m_AccelData.x = -m_AccelData.z;
      m_AccelData.y = -m_AccelData.y;
      m_AccelData.z = -temp;
      break;
    }
    case OS_RIGHT:{                   // y=<, z=>, -x=v
      temp = m_AccelData.x;  
      m_AccelData.x = -m_AccelData.y;
      m_AccelData.y = -m_AccelData.z;
      m_AccelData.z = -temp;
      break;
    }
    case OS_LEFT:{                   // -y=<, -z=>, -x=v  
      temp = m_AccelData.x;
      m_AccelData.x = m_AccelData.y;
      m_AccelData.y = m_AccelData.z;
      m_AccelData.z = -temp;
      break;
    }
    default: break;
  }
	Calculate((float)m_GyroData.x * 0.0175, (float)m_GyroData.y * 0.0175, (float)m_GyroData.z * 0.0175,
				(float)m_AccelData.x, (float)m_AccelData.y, (float)m_AccelData.z,
				(float)m_MagnData.x, (float)m_MagnData.y, m_MagnData.z);
	pAngles->Pitch = asin(-2 * m_Q1 * m_Q3 + 2 * m_Q0 * m_Q2) * RADTODEG; 
	pAngles->Roll = atan2(2 * m_Q2 * m_Q3 + 2 * m_Q0 * m_Q1, -2 * m_Q1 * m_Q1 - 2 * m_Q2 * m_Q2 + 1) * RADTODEG; 
	pAngles->Yaw = atan2(-2 * m_Q1 * m_Q2 - 2 * m_Q0 * m_Q3, 2 * m_Q2 * m_Q2 + 2 * m_Q3 * m_Q3 - 1) * RADTODEG;
  m_AccelVector = sqrt(m_AccelData.x * m_AccelData.x + m_AccelData.y * m_AccelData.y + m_AccelData.z * m_AccelData.z);
}

/////////////////////////////////////////////////////////////////////////////////////

void IMUDevice::Calculate(float Gx, float Gy, float Gz, float Ax, float Ay, float Az, float Mx, float My, float Mz)
{
float norm;
float hx, hy, hz, bx, bz;
float vx, vy, vz, wx, wy, wz;
float exInt = 0.0, eyInt = 0.0, ezInt = 0.0;
float ex, ey, ez, halfT = 0.024f;

	float Q0Q0 = m_Q0 * m_Q0;
	float Q0Q1 = m_Q0 * m_Q1;
	float Q0Q2 = m_Q0 * m_Q2;
	float Q0Q3 = m_Q0 * m_Q3;
	float Q1Q1 = m_Q1 * m_Q1;
	float Q1Q2 = m_Q1 * m_Q2;
	float Q1Q3 = m_Q1 * m_Q3;
	float Q2Q2 = m_Q2 * m_Q2;
	float Q2Q3 = m_Q2 * m_Q3;
	float q3q3 = m_Q3 * m_Q3;

	norm = InversSqrt(Ax * Ax + Ay * Ay + Az * Az);
	Ax = Ax * norm;
	Ay = Ay * norm;
	Az = Az * norm;

	norm = InversSqrt(Mx * Mx + My * My + Mz * Mz);
	Mx = Mx * norm;
	My = My * norm;
	Mz = Mz * norm;

	// compute reference direction of flux
	hx = 2 * Mx * (0.5f - Q2Q2 - q3q3) + 2 * My * (Q1Q2 - Q0Q3) + 2 * Mz * (Q1Q3 + Q0Q2);
	hy = 2 * Mx * (Q1Q2 + Q0Q3) + 2 * My * (0.5f - Q1Q1 - q3q3) + 2 * Mz * (Q2Q3 - Q0Q1);
	hz = 2 * Mx * (Q1Q3 - Q0Q2) + 2 * My * (Q2Q3 + Q0Q1) + 2 * Mz * (0.5f - Q1Q1 - Q2Q2);
	bx = sqrt((hx * hx) + (hy * hy));
	bz = hz;

	// estimated direction of gravity and flux (v and w)
	vx = 2 * (Q1Q3 - Q0Q2);
	vy = 2 * (Q0Q1 + Q2Q3);
	vz = Q0Q0 - Q1Q1 - Q2Q2 + q3q3;
	wx = 2 * bx * (0.5 - Q2Q2 - q3q3) + 2 * bz * (Q1Q3 - Q0Q2);
	wy = 2 * bx * (Q1Q2 - Q0Q3) + 2 * bz * (Q0Q1 + Q2Q3);
	wz = 2 * bx * (Q0Q2 + Q1Q3) + 2 * bz * (0.5 - Q1Q1 - Q2Q2);

	// error is sum of cross product between reference direction of fields and direction measured by sensors
	ex = (Ay * vz - Az * vy) + (My * wz - Mz * wy);
	ey = (Az * vx - Ax * vz) + (Mz * wx - Mx * wz);
	ez = (Ax * vy - Ay * vx) + (Mx * wy - My * wx);

	if(ex != 0.0f && ey != 0.0f && ez != 0.0f) {
		exInt = exInt + ex * Ki * halfT;
		eyInt = eyInt + ey * Ki * halfT;
		ezInt = ezInt + ez * Ki * halfT;

		Gx = Gx + Kp * ex + exInt;
		Gy = Gy + Kp * ey + eyInt;
		Gz = Gz + Kp * ez + ezInt;
	}

	m_Q0 = m_Q0 + (-m_Q1 * Gx - m_Q2 * Gy - m_Q3 * Gz) * halfT;
	m_Q1 = m_Q1 + (m_Q0 * Gx + m_Q2 * Gz - m_Q3 * Gy) * halfT;
	m_Q2 = m_Q2 + (m_Q0 * Gy - m_Q1 * Gz + m_Q3 * Gx) * halfT;
	m_Q3 = m_Q3 + (m_Q0 * Gz + m_Q1 * Gy - m_Q2 * Gx) * halfT;

	norm = InversSqrt(m_Q0 * m_Q0 + m_Q1 * m_Q1 + m_Q2 * m_Q2 + m_Q3 * m_Q3);
	m_Q0 = m_Q0 * norm;
	m_Q1 = m_Q1 * norm;
	m_Q2 = m_Q2 * norm;
	m_Q3 = m_Q3 * norm;
}

/////////////////////////////////////////////////////////////////////////////////////

void IMUDevice::ConvertToFull(float EulerAngles[3], float FullAngles[3]) 
{  // Converts from -90/90 to 360 using the direction gravity is pulling
	if((m_AccelData.y > 0) && (m_AccelData.z > 0)) FullAngles[0] = EulerAngles[0];
	if((m_AccelData.y > 0) && (m_AccelData.z < 0)) FullAngles[0] = 180 - EulerAngles[0];
	if((m_AccelData.y < 0) && (m_AccelData.z < 0)) FullAngles[0] = 180 - EulerAngles[0];
	if((m_AccelData.y < 0) && (m_AccelData.z > 0)) FullAngles[0] = 360 + EulerAngles[0];
	if((m_AccelData.x < 0) && (m_AccelData.z > 0)) FullAngles[1] = EulerAngles[1];
	if((m_AccelData.x < 0) && (m_AccelData.z < 0)) FullAngles[1] = 180 - EulerAngles[1];
	if((m_AccelData.x > 0) && (m_AccelData.z < 0)) FullAngles[1] = 180 - EulerAngles[1];
	if((m_AccelData.x > 0) && (m_AccelData.z > 0)) FullAngles[1] = 360 + EulerAngles[1];
}

/////////////////////////////////////////////////////////////////////////////////////

float IMUDevice::InversSqrt(float Value)
{
union {
  float f;
  uint32_t i;
} Conv;

  float HalfVal = 0.5f * Value;
	Conv.f = Value;
	Conv.i = 0x5f3759df - (Conv.i >> 1);         //gives initial guss you
	Conv.f = Conv.f * (1.5f - (HalfVal * Conv.f * Conv.f)); 
	return Conv.f;

}
