/*
 *              Copyright (c) 2025-2026 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original VanMonitor
 *
 */

#pragma once

/////////////////////////////////////////////////////////////////////////////////////

typedef struct EulerAngles_t {
	float Yaw;
	float Pitch;
	float Roll;
} EulerAngles_t;
	

/////////////////////////////////////////////////////////////////////////////////////

class IMUDevice
{
public:
              IMUDevice(void){};
	void        Initialise(i2c_master_bus_handle_t hi2cBus);
	void        Update(EulerAngles_t *pAngles, uint8_t ChipOrientation);
  void        ConvertToFull(float EulerAngles[3], float FullAngles[3]);
  void        SetOrientaion(uint8_t Orientaion){ m_Orientation = Orientaion; };
  QMI8658A*   GetQMIObj(void){ return &m_IMUSensor; };
  IMUdata_t   m_GyroData;
  IMUdata_t   m_AccelData;
  IMUdata_t   m_MagnData;
  float       m_AccelVector;
  uint8_t     m_Orientation;

private:
	void        Calculate(float Gx, float Gy, float Gz, float Ax, float Ay, float Az, float Mx, float My, float Mz);
	float       InversSqrt(float Val);

  QMI8658A    m_IMUSensor;
  float       m_Q0, m_Q1, m_Q2, m_Q3;

};



