/*
 *              Copyright (c) 2025-2026 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original VanMonitor
 *
 */

#pragma once

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <time.h>
#include <math.h>
#include <sys/time.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/event_groups.h>
#include <freertos/semphr.h>
#include <freertos/queue.h>
#include <freertos/timers.h>
//#include <esp_event.h>
#include "driver/i2c_master.h"
#include <nvs_flash.h>
#include <esp_timer.h>
#include <esp_log.h>

#include <esp_system.h>
//#include <esp_vfs.h>
#include <time.h>

#include "S3Touch35BSP.h"
#include "EGL.h"
#include "ui/WidgetsUI.h"

#include "SD_MMC.h"
#include "PowerKey.h"
#include "Display.h"
#include "NVSUtils.h"
#include "IMUDevice.h"

/////////////////////////////////////////////////////////////////////////////////////

#define PI					            3.14159265358979323846
#define RADTODEG  							180 / PI    // Define Radian to Degrees
#define DEG2RAD(x) ((double)(x) * (PI / 180))
#define RAD2DEG(x) ((double)(x) * (180 / PI))

#define SECONDS_TO_TICKS(xTimeInS) ((TickType_t)(xTimeInS) * configTICK_RATE_HZ)
#define TICKS_TO_SECONDS(xTicks) ((TickType_t)(xTicks) / configTICK_RATE_HZ)

#define APP_DISP_DEFAULT_BRIGHTNESS 20

#define SYSFLAG_DISPLAY_READY     0x0001
#define SYSFLAG_SYSTEM_UP         0x0010
#define SYSFLAG_IMU_UPDATE        0x0200
#define SYSFLAG_SLEEPTIMER_EXP    0x8000

#define SCAN_DURATION             5
#define MAX_DISCOVERED_DEVICES    100

#define GPS_TIMER_ID              0
#define WEATHER_TIMER_ID          1

#define WIFI_SSID_SIZE            32
#define WIFI_PW_SIZE              64
#define WIFI_MAXIMUM_RETRY        6
#define CITY_NAME_SIZE            50
#define API_KEY_SIZE              35
#define WIFI_MAXIMUM_RETRY        6
#define MINIMUM_POLL_PERIOD       30
#define MAX_HTTP_RECV_BUFFER      1023
#define MAX_HTTP_OUTPUT_BUFFER    2048

#define GUI_EVENT_QUEUE_LEN       5

#define SECS_PER_MIN              60
#define SECS_PER_DAY              86400

constexpr int WIDGET_OFFSET     = 40;

/////////////////////////////////////////////////////////////////////////////////////

typedef enum {
  SYS_MSG_EV_NONE = 0,
  SYS_MSG_EV_IMU_UPDATE,      // Event for attitude update
  SYS_MSG_EV_TIME_UPDATE,     // Event for updating the time on clock
  SYS_MSG_EV_VICTRON_DATA,     // Event for updating Victron data
  SYS_MSG_EV_MAX,
} EventMsgID_e;

typedef struct QueueMsg_t {
  EventMsgID_e  EventID;
  void          *pData;
} QueueMsg_t;

typedef enum OrientSelect_e : uint8_t {
  OS_UP = 0,
  OS_DOWN,
  OS_FRONT,
  OS_REAR,
  OS_RIGHT,
  OS_LEFT,
  OS_MAX
} OrientSelect_e;

typedef enum AxisIndex_e {
  AI_X = 0,
  AI_Y,
  AI_Z,
  AI_MAX
} AxisIndex_e;

/////////////////////////////////////////////////////////////////////////////////////

const gpio_num_t        BSP_BootButtonPin_c = GPIO_NUM_0;
const gpio_num_t        LCD_SPI_MOSI_Pin_c 	= GPIO_NUM_1;
const gpio_num_t        LCD_SPI_MISO_Pin_c 	= GPIO_NUM_2;
const gpio_num_t        LCD_SPI_CLK_Pin_c 	= GPIO_NUM_5;
const gpio_num_t        LCD_SPI_CS_Pin_c 		= GPIO_NUM_NC;
const gpio_num_t        LCD_DC_Pin_c 				= GPIO_NUM_3;
const gpio_num_t        LCD_RST_Pin_c 			= GPIO_NUM_NC;
const gpio_num_t        LCD_BacklightPin_c 	= GPIO_NUM_6;
const gpio_num_t        SD_D0_Pin_c 				= GPIO_NUM_2;
const gpio_num_t        SD_D1_Pin_c 				= GPIO_NUM_4;
const gpio_num_t        SD_D2_Pin_c 				= GPIO_NUM_12;
const gpio_num_t        SD_D3_Pin_c 				= GPIO_NUM_13;
const gpio_num_t        SD_CMD_Pin_c 				= GPIO_NUM_15;
const gpio_num_t        SD_CLK_Pin_c 				= GPIO_NUM_14;
const gpio_num_t        SD_DET_Pin_c 				= GPIO_NUM_21;

const gpio_num_t 	      I2CSCLPin_c         = GPIO_NUM_7;     // GPIO number used for I2C master clock 
const gpio_num_t 	      I2CSDAPin_c         = GPIO_NUM_8;     // GPIO number used for I2C master data  
const i2c_port_t 	      I2CPort_c           = I2C_NUM_0;       // I2C master i2c port number
const gpio_num_t        PowerKeyPin_c       = GPIO_NUM_NC;
const gpio_num_t        PowerControlPin_c   = GPIO_NUM_NC;

const uint8_t 	        ExtenderMask_c      = 0x74;


/////////////////////////////////////////////////////////////////////////////////////

#ifdef _MAIN_

const char              *pVersionStr_c = "Version 1.a.023";
const char              *pMountPoint_c = "/sdcard";

EventGroupHandle_t      g_SystemFlags = NULL;
QueueHandle_t           g_EventQueue = NULL;

esp_timer_handle_t      g_hOneSecondTimer;
esp_timer_handle_t      g_hOneHourTimer;

i2c_master_bus_handle_t g_hi2cBus;
SDMMCDevice             g_SDMMCObj;
PowerKey                g_PwrKeyObj;
TCA9554                 g_Expander;
AXP2101                 g_PowerControl;
PCF85063                g_RTC;
IMUDevice               g_IMU;

bool                    g_NVSAvailable = false;

#else

extern EventGroupHandle_t   g_SystemFlags;
extern QueueHandle_t        g_EventQueue;

extern esp_timer_handle_t   g_hOneSecondTimer;
extern esp_timer_handle_t   g_hOneHourTimer;

extern i2c_master_bus_handle_t g_hi2cBus;
extern SDMMCDevice          g_SDMMCObj;
extern PowerKey             g_PwrKeyObj;
extern TCA9554              g_Expander;
extern AXP2101              g_PowerControl;
extern PCF85063             g_RTC;
extern IMUDevice            g_IMU;

extern bool                 g_NVSAvailable;

#endif

/////////////////////////////////////////////////////////////////////////////////////

BaseType_t  QueueSysEvent(EventMsgID_e Event, void *pData);
