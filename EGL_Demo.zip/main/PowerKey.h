/*
 *              Copyright (c) 2020-2021 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original WeatherClock
 *
 */

#pragma once

/////////////////////////////////////////////////////////////////////////////////////

const int DeviceSleepTime_c     = 10;
const int DeviceRestartTime_c   = 15;
const int DeviceShutdownTime_c  = 20;

/////////////////////////////////////////////////////////////////////////////////////

class PowerKey
{
public:
              PowerKey(void);
  void        Initialise(gpio_num_t CntrlPin, gpio_num_t InputPin);
  void        Read(void);
  void        FallAsleep(void);
  void        Shutdown(void);
  void        Restart(void);

private:
  void        ConfigurePin(gpio_num_t Pin, gpio_mode_t Mode);

  gpio_num_t  m_PowerControlPin;
  gpio_num_t  m_PowerInputPin;
  uint8_t     m_ButtonState;
  uint8_t     m_DeviceState;
  uint16_t    m_LongPress;
  
  
};