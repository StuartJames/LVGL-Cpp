/*
 *              Copyright (c) 2020-2021 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 *pEventdit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original LEGLDemo
 *
 */

#include "WidgetsUI.h"

#if EG_USE_STDLIB_MALLOC == EG_STDLIB_BUILTIN && EG_MEM_SIZE < (38ul * 1024ul)
#error Insufficient memory for EG_demo_widgets. Please set EG_MEM_SIZE to at least 38KB (38ul * 1024ul).  48KB is recommended.
#endif

typedef enum {
    DISP_SMALL,
    DISP_MEDIUM,
    DISP_LARGE,
} disp_size_t;


/////////////////////////////////////////////////////////////////////////////

static void CreateProfile(EGObject *pTab);
static void CreateAnalytics(EGObject *pTab);
static void CreateShop(EGObject *pTab);
static void CreateColorChanger(EGObject *pTab);

static EGMeter* CreateMeterBox(EGObject *pParent, const char *pTitle, const char *pText1, const char *pText2,
																	const char *pText3);
static EGObject *CreateShopItem(EGObject *pParent, const void *img_src, const char *pName, const char *category,
																	const char *price);

static void ColorChangerEventCB(EGEvent *pEvent);
static void ColorEventCB(EGEvent *pEvent);
static void TexBoxEventCB(EGEvent *pEvent);
static void BirthdayEventCB(EGEvent *pEvent);
static void CalendarEventCB(EGEvent *pEvent);
static void SliderEventCB(EGEvent *pEvent);
static void ChartEventCB(EGEvent *pEvent);
static void ShopChartEventCB(EGEvent *pEvent);
static void Meter1Indicator1AnimateCB(void * var, int32_t v);
static void Meter1Indicator2AnimateCB(void * var, int32_t v);
static void Meter1Indicator3AnimateCB(void * var, int32_t v);
static void Meter2TimerCB(EGTimer *pTimer);
static void Meter3AnimateCB(void * var, int32_t v);

/////////////////////////////////////////////////////////////////////////////

static uint8_t DisplaySize;

static EGDisplay *pDisp = nullptr;
static EGTabView *pTabView = nullptr;
static EGCalendar *pCalendar = nullptr;
static EGStyle StyleTextMuted;
static EGStyle StyleTitle;
static EGStyle StyleIcon;
static EGStyle StyleBullet;

static EGMeter  *pMeter1;
static EGMeter  *pMeter2;
static EGMeter  *pMeter3;

static EG_MeterScale_t *pScale1;
static EG_MeterScale_t *pScale2;
static EG_MeterScale_t *pScale3;

static EGChart *pChart1;
static EGChart *pChart2;
static EGChart *pChart3;

static EG_CharSeries_t *pSeries1;
static EG_CharSeries_t *pSeries2;
static EG_CharSeries_t *pSeries3;
static EG_CharSeries_t *pSeries4;

static const EG_Font_t *pFontLarge;
static const EG_Font_t *pFontNormal;

static uint32_t SessionDesktop = 1000;
static uint32_t SessionTablet = 1000;
static uint32_t SessionMobile = 1000;

static EGTimer *pMeter2Timer = nullptr;

static EG_CalendarDate_t BirthDate = {1990, 01, 01};

/////////////////////////////////////////////////////////////////////////////

void EG_WidgetsDemo(void)
{
	if(EG_HOR_RES <= 320)	DisplaySize = DISP_SMALL;
	else if(EG_HOR_RES < 720)	DisplaySize = DISP_MEDIUM;
	else DisplaySize = DISP_LARGE;
	pFontLarge = EG_FONT_DEFAULT;
	pFontNormal = EG_FONT_DEFAULT;
	int32_t TabHeight;
	if(DisplaySize == DISP_LARGE) {
		TabHeight = 70;
#if EG_FontMontserrat24
		pFontLarge = &EG_FontMontserrat24;
#else
		EG_LOG_WARN("EG_FontMontserrat24 is not enabled for the widgets demo. Using EG_FONT_DEFAULT instead.");
#endif
#if EG_FontMontserrat16
		pFontNormal = &EG_FontMontserrat16;
#else
		EG_LOG_WARN("EG_FontMontserrat16 is not enabled for the widgets demo. Using EG_FONT_DEFAULT instead.");
#endif
	}
	else if(DisplaySize == DISP_MEDIUM) {
		TabHeight = 45;
#if EG_FontMontserrat20
		pFontLarge = &EG_FontMontserrat20;
#else
		EG_LOG_WARN("EG_FontMontserrat20 is not enabled for the widgets demo. Using EG_FONT_DEFAULT instead.");
#endif
#if EG_FontMontserrat14
		pFontNormal = &EG_FontMontserrat14;
#else
		EG_LOG_WARN("EG_FontMontserrat14 is not enabled for the widgets demo. Using EG_FONT_DEFAULT instead.");
#endif
	}
	else { //  DisplaySize == DISP_SMALL 
		TabHeight = 45;
#if EG_FontMontserrat18
		pFontLarge = &EG_FontMontserrat18;
#else
		EG_LOG_WARN("EG_FontMontserrat18 is not enabled for the widgets demo. Using EG_FONT_DEFAULT instead.");
#endif
#if EG_FontMontserrat12
		pFontNormal = &EG_FontMontserrat12;
#else
		EG_LOG_WARN("EG_FontMontserrat12 is not enabled for the widgets demo. Using EG_FONT_DEFAULT instead.");
#endif
	}

	pDisp = EGDisplay::GetDefault();
  pDisp->SetRotation(EG_DISP_ROT_NONE);
#if EG_USE_THEME_DEFAULT
	EGDefTheme::SetTheme(EG_MainPalette(EG_PALETTE_BLUE), EG_MainPalette(EG_PALETTE_RED), EG_THEME_DEFAULT_DARK, EG_FONT_DEFAULT, pDisp);
#endif
  EGGroup *pGroup = EGGroup::Create();
  pGroup->SetAsDefault();
  EGObject *pScreen = EGDisplay::GetActiveScreen(pDisp);
	StyleTextMuted.SetTextOPA(EG_OPA_80);
	StyleTitle.SetTextFont(pFontLarge);
	StyleIcon.SetTextColor(EGDefTheme::GetColorPrimary(nullptr));
	StyleIcon.SetTextFont(pFontLarge);
	StyleBullet.SetBorderWidth(0);
	StyleBullet.SetRadius(EG_RADIUS_CIRCLE);
 	pTabView = new EGTabView(pScreen, EG_DIR_TOP, TabHeight);
 	pScreen->SetStyleTextFont(pFontNormal, 0);
	if(DisplaySize == DISP_LARGE) {
		EGButtonMatrix *pTabButtons = pTabView->GetTabButtons();
		pTabButtons->SetStylePadLeft(EG_HOR_RES / 2, 0);
		EGImage *pLogo = new EGImage(pTabButtons);
		pLogo->SetSource(&ImageLogo);
		pLogo->Align(EG_ALIGN_LEFT_MID, -EG_HOR_RES / 2 + 25, 0);
		EGLabel *pLabel = new EGLabel(pTabButtons);
		pLabel->AddStyle(&StyleTitle, 0);
		pLabel->SetText("LEGL v8");
		pLabel->AlignTo(pLogo, EG_ALIGN_OUT_RIGHT_TOP, 10, 0);

		pLabel = new EGLabel(pTabButtons);
		pLabel->SetText("Widgets demo");
		pLabel->AddStyle(&StyleTextMuted, 0);
		pLabel->AlignTo(pLogo, EG_ALIGN_OUT_RIGHT_BOTTOM, 10, 0);
	}
	EGObject *pTab1 = pTabView->AddTab("Profile");
	EGObject *pTab2 = pTabView->AddTab("Analytics");
	EGObject *pTab3 = pTabView->AddTab("Shop");
	CreateProfile(pTab1);
  CreateAnalytics(pTab2);
	CreateShop(pTab3);
	CreateColorChanger(pTabView);
}

/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////

static void CreateProfile(EGObject *pTab)
{
  g_pTabObj = pTab;
	EGObject *pPanel1 = new EGObject(pTab);
	pPanel1->SetHeight(EG_SIZE_CONTENT);

  EGImage *pAvatar = new EGImage(pPanel1);
	pAvatar->SetSource(&ImageAvatar);

  EGLabel *pName = new EGLabel(pPanel1);
	pName->SetText("Elena Smith");
	pName->AddStyle(&StyleTitle, 0);

  EGLabel *pDiscription = new EGLabel(pPanel1);
	pDiscription->AddStyle(&StyleTextMuted, 0);
	pDiscription->SetText("This is a short description of me. Take a look at my profile!");
	pDiscription->SetLongMode(EG_LABEL_LONG_WRAP);

  EGLabel *pEmailIcon = new EGLabel(pPanel1);
	pEmailIcon->AddStyle(&StyleIcon, 0);
	pEmailIcon->SetText(EG_SYMBOL_ENVELOPE);

  EGLabel *pEmailLabel = new EGLabel(pPanel1);
	pEmailLabel->SetText("elena@smith.com");

  EGLabel *pCallIcon = new EGLabel(pPanel1);
 	pCallIcon->AddStyle(&StyleIcon, 0);
	pCallIcon->SetText(EG_SYMBOL_CALL);

  EGLabel *pCallLabel = new EGLabel(pPanel1);
	pCallLabel->SetText("+79 246 123 4567");

  EGButton *pLogOutButton = new EGButton(pPanel1);
	pLogOutButton->SetHeight(EG_SIZE_CONTENT);

  EGLabel *pLabel = new EGLabel(pLogOutButton);
	pLabel->SetText("Log out");
  pLabel->Center();

  EGButton *pInviteButton = new EGButton(pPanel1);
	pInviteButton->SetState(EG_STATE_DISABLED);
	pInviteButton->SetHeight(EG_SIZE_CONTENT);

  pLabel = new EGLabel(pInviteButton);
	pLabel->SetText("Invite");
	pLabel->Center();

  EGKeyboard *pKeyboard = new EGKeyboard(EGDisplay::GetActiveScreen(nullptr));
	pKeyboard->AddFlag(EG_OBJ_FLAG_HIDDEN);
 
	// Create the second panel
	EGObject *pPanel2 = new EGObject(pTab);
	pPanel2->SetHeight(EG_SIZE_CONTENT);

  EGLabel *pPanel2Title = new EGLabel(pPanel2);
	pPanel2Title->SetText("Your profile");
	pPanel2Title->AddStyle(&StyleTitle, 0);

  EGLabel *pUserNameLabel = new EGLabel(pPanel2);
	pUserNameLabel->SetText("User name:");
	pUserNameLabel->AddStyle(&StyleTextMuted, 0);

  EGEdit *pUserName = new EGEdit(pPanel2);
	pUserName->SetOneLineMode(true);
	pUserName->SetPromptText("Your name");
	EGEvent::AddEventCB(pUserName, TexBoxEventCB, EG_EVENT_ALL, pKeyboard);

  EGLabel *pPasswordLabel = new EGLabel(pPanel2);
	pPasswordLabel->SetText("Password:");
	pPasswordLabel->AddStyle(&StyleTextMuted, 0);

  EGEdit *pPassword = new EGEdit(pPanel2);
	pPassword->SetOneLineMode(true);
	pPassword->SetPasswordMode(true);
	pPassword->SetPromptText("Min. 8 chars.");
	EGEvent::AddEventCB(pPassword, TexBoxEventCB, EG_EVENT_ALL, pKeyboard);

  EGLabel *pGenderLabel = new EGLabel(pPanel2);
	pGenderLabel->SetText("Gender:");
	pGenderLabel->AddStyle(&StyleTextMuted, 0);

  EGDropDown *pGender = new EGDropDown(pPanel2);
	pGender->SetStaticItems("Male\nFemale\nOther");
 
  EGLabel *pBirthdayLabel = new EGLabel(pPanel2);
	pBirthdayLabel->SetText("Birthday:");
	pBirthdayLabel->AddStyle(&StyleTextMuted, 0);

  EGEdit *pBirthdate = new EGEdit(pPanel2);
	pBirthdate->SetOneLineMode(true);
	EGEvent::AddEventCB(pBirthdate, BirthdayEventCB, EG_EVENT_ALL, nullptr);

	// Create the third panel
	EGObject *pPanel3 = new EGObject(pTab);

  EGLabel *pPanel3Title = new EGLabel(pPanel3);
	pPanel3Title->SetText("Your skills");
	pPanel3Title->AddStyle(&StyleTitle, 0);

  EGLabel *pExperienceLabel = new EGLabel(pPanel3);
	pExperienceLabel->SetText("Experience");
	pExperienceLabel->AddStyle(&StyleTextMuted, 0);

  EGSlider *pSlider1 = new EGSlider(pPanel3);
	pSlider1->SetWidth(_EG_PCT(95));
	EGEvent::AddEventCB(pSlider1, SliderEventCB, EG_EVENT_ALL, nullptr);
	pSlider1->RefreshExtDrawSize();

  EGLabel *pTeamPlayerLabel = new EGLabel(pPanel3);
	pTeamPlayerLabel->SetText("Team player");
	pTeamPlayerLabel->AddStyle(&StyleTextMuted, 0);

  EGSwitch *pSwitch1 = new EGSwitch(pPanel3);

  EGLabel *pHardWorkingLabel = new EGLabel(pPanel3);
	pHardWorkingLabel->SetText("Hard-working");
	pHardWorkingLabel->AddStyle(&StyleTextMuted, 0);

  EGSwitch *pSwitch2 = new EGSwitch(pPanel3);

  if(DisplaySize == DISP_LARGE) {
		static EG_Coord_t TabColumnProps[] = {EG_GRID_FR(1), EG_GRID_FR(1), EG_GRID_TEMPLATE_LAST};
		static EG_Coord_t TabRowProps[] = {EG_GRID_CONTENT, EG_GRID_CONTENT, EG_GRID_TEMPLATE_LAST};

		// Create the top panel
		static EG_Coord_t Panel1ColumnProps[] = {EG_GRID_CONTENT, 5, EG_GRID_CONTENT, EG_GRID_FR(2), EG_GRID_FR(1), EG_GRID_FR(1), EG_GRID_TEMPLATE_LAST};
		static EG_Coord_t Panel1RowProps[] = {EG_GRID_CONTENT, EG_GRID_CONTENT, 10, EG_GRID_CONTENT, EG_GRID_CONTENT, EG_GRID_TEMPLATE_LAST};

		static EG_Coord_t Panel2ColumnProps[] = {EG_GRID_FR(1), EG_GRID_FR(1), EG_GRID_TEMPLATE_LAST};
		static EG_Coord_t Panel2RowProps[] = {
			EG_GRID_CONTENT, // Title
			5,               // Separator
			EG_GRID_CONTENT, // Box title
			30,              // Boxes
			5,               // Separator
			EG_GRID_CONTENT, // Box title
			30,              // Boxes
			EG_GRID_TEMPLATE_LAST};

		EGGridLayout::SetObjGridParams(pTab, TabColumnProps, TabRowProps);

		EGGridLayout::SetObjCell(pPanel1, EG_GRID_ALIGN_STRETCH, 0, 2, EG_GRID_ALIGN_CENTER, 0, 1);

		EGGridLayout::SetObjGridParams(pPanel1, Panel1ColumnProps, Panel1RowProps);
		EGGridLayout::SetObjCell(pAvatar, EG_GRID_ALIGN_CENTER, 0, 1, EG_GRID_ALIGN_CENTER, 0, 5);
		EGGridLayout::SetObjCell(pName, EG_GRID_ALIGN_START, 2, 2, EG_GRID_ALIGN_CENTER, 0, 1);
		EGGridLayout::SetObjCell(pDiscription, EG_GRID_ALIGN_STRETCH, 2, 4, EG_GRID_ALIGN_START, 1, 1);
		EGGridLayout::SetObjCell(pEmailIcon, EG_GRID_ALIGN_CENTER, 2, 1, EG_GRID_ALIGN_CENTER, 3, 1);
		EGGridLayout::SetObjCell(pEmailLabel, EG_GRID_ALIGN_START, 3, 1, EG_GRID_ALIGN_CENTER, 3, 1);
		EGGridLayout::SetObjCell(pCallIcon, EG_GRID_ALIGN_CENTER, 2, 1, EG_GRID_ALIGN_CENTER, 4, 1);
		EGGridLayout::SetObjCell(pCallLabel, EG_GRID_ALIGN_START, 3, 1, EG_GRID_ALIGN_CENTER, 4, 1);
		EGGridLayout::SetObjCell(pLogOutButton, EG_GRID_ALIGN_STRETCH, 4, 1, EG_GRID_ALIGN_CENTER, 3, 2);
		EGGridLayout::SetObjCell(pInviteButton, EG_GRID_ALIGN_STRETCH, 5, 1, EG_GRID_ALIGN_CENTER, 3, 2);

		EGGridLayout::SetObjCell(pPanel2, EG_GRID_ALIGN_STRETCH, 0, 1, EG_GRID_ALIGN_START, 1, 1);
		EGGridLayout::SetObjGridParams(pPanel2, Panel2ColumnProps, Panel2RowProps);
		EGGridLayout::SetObjCell(pPanel2Title, EG_GRID_ALIGN_START, 0, 2, EG_GRID_ALIGN_CENTER, 0, 1);
		EGGridLayout::SetObjCell(pUserName, EG_GRID_ALIGN_STRETCH, 0, 1, EG_GRID_ALIGN_CENTER, 3, 1);
		EGGridLayout::SetObjCell(pUserNameLabel, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 2, 1);
		EGGridLayout::SetObjCell(pPassword, EG_GRID_ALIGN_STRETCH, 1, 1, EG_GRID_ALIGN_CENTER, 3, 1);
		EGGridLayout::SetObjCell(pPasswordLabel, EG_GRID_ALIGN_START, 1, 1, EG_GRID_ALIGN_START, 2, 1);
		EGGridLayout::SetObjCell(pBirthdate, EG_GRID_ALIGN_STRETCH, 1, 1, EG_GRID_ALIGN_CENTER, 6, 1);
		EGGridLayout::SetObjCell(pBirthdayLabel, EG_GRID_ALIGN_START, 1, 1, EG_GRID_ALIGN_START, 5, 1);
		EGGridLayout::SetObjCell(pGender, EG_GRID_ALIGN_STRETCH, 0, 1, EG_GRID_ALIGN_CENTER, 6, 1);
		EGGridLayout::SetObjCell(pGenderLabel, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 5, 1);

		EGGridLayout::SetObjCell(pPanel3, EG_GRID_ALIGN_STRETCH, 1, 1, EG_GRID_ALIGN_STRETCH, 1, 1);
		EGGridLayout::SetObjGridParams(pPanel3, Panel2ColumnProps, Panel2RowProps);
		EGGridLayout::SetObjCell(pPanel3Title, EG_GRID_ALIGN_START, 0, 2, EG_GRID_ALIGN_CENTER, 0, 1);
		EGGridLayout::SetObjCell(pSlider1, EG_GRID_ALIGN_CENTER, 0, 2, EG_GRID_ALIGN_CENTER, 3, 1);
		EGGridLayout::SetObjCell(pExperienceLabel, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 2, 1);
		EGGridLayout::SetObjCell(pSwitch2, EG_GRID_ALIGN_START, 1, 1, EG_GRID_ALIGN_CENTER, 6, 1);
		EGGridLayout::SetObjCell(pHardWorkingLabel, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 5, 1);
		EGGridLayout::SetObjCell(pSwitch1, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_CENTER, 6, 1);
		EGGridLayout::SetObjCell(pTeamPlayerLabel, EG_GRID_ALIGN_START, 1, 1, EG_GRID_ALIGN_START, 5, 1);
	}
	else if(DisplaySize == DISP_MEDIUM) {
		static EG_Coord_t TabColumnProps[] = {EG_GRID_FR(1), EG_GRID_FR(1), EG_GRID_TEMPLATE_LAST};
		static EG_Coord_t TabRowProps[] = {EG_GRID_CONTENT, EG_GRID_CONTENT, EG_GRID_TEMPLATE_LAST};

		// Create the top panel
		static EG_Coord_t Panel1ColumnProps[] = {EG_GRID_CONTENT, 1, EG_GRID_CONTENT, EG_GRID_FR(1), EG_GRID_TEMPLATE_LAST};
		static EG_Coord_t Panel1RowProps[] = {
			EG_GRID_CONTENT, // Name
			EG_GRID_CONTENT, // Description
			EG_GRID_CONTENT, // Email
			-20,
			EG_GRID_CONTENT, // Phone
			EG_GRID_CONTENT, // Buttons
			EG_GRID_TEMPLATE_LAST};

		static EG_Coord_t Panel2ColumnProps[] = {EG_GRID_FR(1), EG_GRID_FR(1), EG_GRID_TEMPLATE_LAST};
		static EG_Coord_t Panel2RowProps[] = {
			EG_GRID_CONTENT, // Title
			5,               // Separator
			EG_GRID_CONTENT, // Box title
			40,              // Box
			EG_GRID_CONTENT, // Box title
			40,              // Box
			EG_GRID_CONTENT, // Box title
			40,              // Box
			EG_GRID_CONTENT, // Box title
			40,              // Box
			EG_GRID_TEMPLATE_LAST};

		EGGridLayout::SetObjGridParams(pTab, TabColumnProps, TabRowProps);
		EGGridLayout::SetObjCell(pPanel1, EG_GRID_ALIGN_STRETCH, 0, 2, EG_GRID_ALIGN_CENTER, 0, 1);
		pLogOutButton->SetWidth(120);
		pInviteButton->SetWidth(120);
		EGGridLayout::SetObjGridParams(pPanel1, Panel1ColumnProps, Panel1RowProps);
		EGGridLayout::SetObjCell(pAvatar, EG_GRID_ALIGN_CENTER, 0, 1, EG_GRID_ALIGN_START, 0, 4);
		EGGridLayout::SetObjCell(pName, EG_GRID_ALIGN_START, 2, 2, EG_GRID_ALIGN_CENTER, 0, 1);
		EGGridLayout::SetObjCell(pDiscription, EG_GRID_ALIGN_STRETCH, 2, 2, EG_GRID_ALIGN_START, 1, 1);
		EGGridLayout::SetObjCell(pEmailLabel, EG_GRID_ALIGN_START, 3, 1, EG_GRID_ALIGN_CENTER, 2, 1);
		EGGridLayout::SetObjCell(pEmailIcon, EG_GRID_ALIGN_CENTER, 2, 1, EG_GRID_ALIGN_CENTER, 2, 1);
		EGGridLayout::SetObjCell(pCallIcon, EG_GRID_ALIGN_CENTER, 2, 1, EG_GRID_ALIGN_CENTER, 4, 1);
		EGGridLayout::SetObjCell(pCallLabel, EG_GRID_ALIGN_START, 3, 1, EG_GRID_ALIGN_CENTER, 4, 1);
		EGGridLayout::SetObjCell(pLogOutButton, EG_GRID_ALIGN_START, 1, 1, EG_GRID_ALIGN_CENTER, 5, 1);
		EGGridLayout::SetObjCell(pInviteButton, EG_GRID_ALIGN_END, 3, 1, EG_GRID_ALIGN_CENTER, 5, 1);

		EGGridLayout::SetObjCell(pPanel2, EG_GRID_ALIGN_STRETCH, 0, 1, EG_GRID_ALIGN_START, 1, 1);
		EGGridLayout::SetObjGridParams(pPanel2, Panel2ColumnProps, Panel2RowProps);
		EGGridLayout::SetObjCell(pPanel2Title, EG_GRID_ALIGN_START, 0, 2, EG_GRID_ALIGN_CENTER, 0, 1);
		EGGridLayout::SetObjCell(pUserNameLabel, EG_GRID_ALIGN_START, 0, 2, EG_GRID_ALIGN_START, 2, 1);
		EGGridLayout::SetObjCell(pUserName, EG_GRID_ALIGN_STRETCH, 0, 2, EG_GRID_ALIGN_START, 3, 1);
		EGGridLayout::SetObjCell(pPasswordLabel, EG_GRID_ALIGN_START, 0, 2, EG_GRID_ALIGN_START, 4, 1);
		EGGridLayout::SetObjCell(pPassword, EG_GRID_ALIGN_STRETCH, 0, 2, EG_GRID_ALIGN_START, 5, 1);
		EGGridLayout::SetObjCell(pBirthdayLabel, EG_GRID_ALIGN_START, 0, 2, EG_GRID_ALIGN_START, 6, 1);
		EGGridLayout::SetObjCell(pBirthdate, EG_GRID_ALIGN_STRETCH, 0, 2, EG_GRID_ALIGN_START, 7, 1);
		EGGridLayout::SetObjCell(pGenderLabel, EG_GRID_ALIGN_START, 0, 2, EG_GRID_ALIGN_START, 8, 1);
		EGGridLayout::SetObjCell(pGender, EG_GRID_ALIGN_STRETCH, 0, 2, EG_GRID_ALIGN_START, 9, 1);

		EGGridLayout::SetObjCell(pPanel3, EG_GRID_ALIGN_STRETCH, 1, 1, EG_GRID_ALIGN_STRETCH, 1, 1);
		EGGridLayout::SetObjGridParams(pPanel3, Panel2ColumnProps, Panel2RowProps);
		EGGridLayout::SetObjCell(pPanel3Title, EG_GRID_ALIGN_START, 0, 2, EG_GRID_ALIGN_CENTER, 0, 1);
		EGGridLayout::SetObjCell(pSlider1, EG_GRID_ALIGN_CENTER, 0, 2, EG_GRID_ALIGN_CENTER, 3, 1);
		EGGridLayout::SetObjCell(pExperienceLabel, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 2, 1);
		EGGridLayout::SetObjCell(pHardWorkingLabel, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 4, 1);
		EGGridLayout::SetObjCell(pSwitch2, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 5, 1);
		EGGridLayout::SetObjCell(pTeamPlayerLabel, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 6, 1);
		EGGridLayout::SetObjCell(pSwitch1, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 7, 1);
	}
	else if(DisplaySize == DISP_SMALL) {
		static EG_Coord_t TabColumnProps[] = {EG_GRID_FR(1), EG_GRID_TEMPLATE_LAST};
		static EG_Coord_t TabRowProps[] = {EG_GRID_CONTENT, EG_GRID_CONTENT, EG_GRID_CONTENT, EG_GRID_TEMPLATE_LAST};
		EGGridLayout::SetObjGridParams(pTab, TabColumnProps, TabRowProps);

		// Create the top panel
		static EG_Coord_t Panel1ColumnProps[] = {EG_GRID_CONTENT, EG_GRID_FR(1), EG_GRID_TEMPLATE_LAST};
		static EG_Coord_t Panel1RowProps[] = {EG_GRID_CONTENT, // Avatar
																					EG_GRID_CONTENT, // Name
																					EG_GRID_CONTENT, // Description
																					EG_GRID_CONTENT, // Email
																					EG_GRID_CONTENT, // Phone number
																					EG_GRID_CONTENT, // Button1
																					EG_GRID_CONTENT, // Button2
																					EG_GRID_TEMPLATE_LAST};

		EGGridLayout::SetObjGridParams(pPanel1, Panel1ColumnProps, Panel1RowProps);

		static EG_Coord_t Panel2ColumnProps[] = {EG_GRID_FR(1), EG_GRID_FR(1), EG_GRID_TEMPLATE_LAST};
		static EG_Coord_t Panel2RowProps[] = {
			EG_GRID_CONTENT,          // Title
			5,                        // Separator
			EG_GRID_CONTENT,          // Box title
			40,                       // Box
			EG_GRID_CONTENT,          // Box title
			40,                       // Box
			EG_GRID_CONTENT,          // Box title
			40,                       // Box
			EG_GRID_CONTENT,          // Box title
			40, EG_GRID_TEMPLATE_LAST // Box
		};

		EGGridLayout::SetObjGridParams(pPanel2, Panel2ColumnProps, Panel2RowProps);
		EGGridLayout::SetObjGridParams(pPanel3, Panel2ColumnProps, Panel2RowProps);
		EGGridLayout::SetObjCell(pPanel1, EG_GRID_ALIGN_STRETCH, 0, 1, EG_GRID_ALIGN_CENTER, 0, 1);
		EGGridLayout::SetObjCell(pAvatar, EG_GRID_ALIGN_CENTER, 0, 2, EG_GRID_ALIGN_CENTER, 0, 1);
		EGGridLayout::SetObjCell(pName, EG_GRID_ALIGN_CENTER, 0, 2, EG_GRID_ALIGN_CENTER, 1, 1);
		pDiscription->SetStyleTextAlign(EG_TEXT_ALIGN_CENTER, 0);
		EGGridLayout::SetObjCell(pDiscription, EG_GRID_ALIGN_STRETCH, 0, 2, EG_GRID_ALIGN_START, 2, 1);
		EGGridLayout::SetObjCell(pEmailIcon, EG_GRID_ALIGN_CENTER, 0, 1, EG_GRID_ALIGN_CENTER, 3, 1);
		EGGridLayout::SetObjCell(pEmailLabel, EG_GRID_ALIGN_START, 1, 1, EG_GRID_ALIGN_CENTER, 3, 1);
  	EGGridLayout::SetObjCell(pCallIcon, EG_GRID_ALIGN_CENTER, 0, 1, EG_GRID_ALIGN_CENTER, 4, 1);
		EGGridLayout::SetObjCell(pCallLabel, EG_GRID_ALIGN_START, 1, 1, EG_GRID_ALIGN_CENTER, 4, 1);
		EGGridLayout::SetObjCell(pLogOutButton, EG_GRID_ALIGN_STRETCH, 0, 2, EG_GRID_ALIGN_CENTER, 5, 1);
		EGGridLayout::SetObjCell(pInviteButton, EG_GRID_ALIGN_STRETCH, 0, 2, EG_GRID_ALIGN_CENTER, 6, 1);

		EGGridLayout::SetObjCell(pPanel2, EG_GRID_ALIGN_STRETCH, 0, 1, EG_GRID_ALIGN_START, 1, 1);
	  EGGridLayout::SetObjCell(pPanel2Title, EG_GRID_ALIGN_START, 0, 2, EG_GRID_ALIGN_CENTER, 0, 1);
		EGGridLayout::SetObjCell(pUserNameLabel, EG_GRID_ALIGN_START, 0, 2, EG_GRID_ALIGN_START, 2, 1);
		EGGridLayout::SetObjCell(pUserName, EG_GRID_ALIGN_STRETCH, 0, 2, EG_GRID_ALIGN_START, 3, 1);
		EGGridLayout::SetObjCell(pPasswordLabel, EG_GRID_ALIGN_START, 0, 2, EG_GRID_ALIGN_START, 4, 1);
		EGGridLayout::SetObjCell(pPassword, EG_GRID_ALIGN_STRETCH, 0, 2, EG_GRID_ALIGN_START, 5, 1);
		EGGridLayout::SetObjCell(pBirthdayLabel, EG_GRID_ALIGN_START, 0, 2, EG_GRID_ALIGN_START, 6, 1);
		EGGridLayout::SetObjCell(pBirthdate, EG_GRID_ALIGN_STRETCH, 0, 2, EG_GRID_ALIGN_START, 7, 1);
		EGGridLayout::SetObjCell(pGenderLabel, EG_GRID_ALIGN_START, 0, 2, EG_GRID_ALIGN_START, 8, 1);
		EGGridLayout::SetObjCell(pGender, EG_GRID_ALIGN_STRETCH, 0, 2, EG_GRID_ALIGN_START, 9, 1);

		pPanel3->SetHeight(EG_SIZE_CONTENT);
		EGGridLayout::SetObjCell(pPanel3, EG_GRID_ALIGN_STRETCH, 0, 1, EG_GRID_ALIGN_START, 2, 1);
		EGGridLayout::SetObjCell(pPanel3Title, EG_GRID_ALIGN_START, 0, 2, EG_GRID_ALIGN_CENTER, 0, 1);
		EGGridLayout::SetObjCell(pExperienceLabel, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 2, 1);
		EGGridLayout::SetObjCell(pSlider1, EG_GRID_ALIGN_CENTER, 0, 2, EG_GRID_ALIGN_CENTER, 3, 1);
		EGGridLayout::SetObjCell(pHardWorkingLabel, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 4, 1);
		EGGridLayout::SetObjCell(pSwitch1, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 5, 1);
		EGGridLayout::SetObjCell(pTeamPlayerLabel, EG_GRID_ALIGN_START, 1, 1, EG_GRID_ALIGN_START, 4, 1);
		EGGridLayout::SetObjCell(pSwitch2, EG_GRID_ALIGN_START, 1, 1, EG_GRID_ALIGN_START, 5, 1);
	}
}

/////////////////////////////////////////////////////////////////////////////

static void TexBoxEventCB(EGEvent *pEvent)
{
	EG_EventCode_e Code = pEvent->GetCode();
	EGEdit *pEdit = (EGEdit*)pEvent->GetTarget();
	EGKeyboard *pKeyboard = (EGKeyboard*)pEvent->GetExtParam();
	if(Code == EG_EVENT_FOCUSED) {
		if(EGInputDevice::GetActive()->GetType() != EG_INDEV_TYPE_KEYPAD) {
			pKeyboard->SetEditCtrl(pEdit);
			pKeyboard->SetStyleMaxHeight(EG_HOR_RES * 2 / 3, 0);
			pTabView->UpdateLayout(); // Be sure the sizes are recalculated
			pTabView->SetHeight(EG_VERT_RES - pKeyboard->GetHeight());
			pKeyboard->ClearFlag(EG_OBJ_FLAG_HIDDEN);
			pEdit->ScrollToViewRecursive(EG_ANIM_OFF);
		}
	}
	else if(Code == EG_EVENT_DEFOCUSED) {
		pKeyboard->SetEditCtrl(nullptr);
		pTabView->SetHeight(EG_VERT_RES);
		pKeyboard->AddFlag(EG_OBJ_FLAG_HIDDEN);
		EGInputDevice::Reset(nullptr, pEdit);
	}
	else if(Code == EG_EVENT_READY || Code == EG_EVENT_CANCEL) {
		pTabView->SetHeight(EG_VERT_RES);
		pKeyboard->AddFlag(EG_OBJ_FLAG_HIDDEN);
		pEdit->ClearState(EG_STATE_FOCUSED);
		EGInputDevice::Reset(nullptr, pEdit); // Forget the last clicked object to make it focusable again
	}
}

/////////////////////////////////////////////////////////////////////////////

static void BirthdayEventCB(EGEvent *pEvent)
{
	EG_EventCode_e Code = pEvent->GetCode();
	EGEdit *pEdit = (EGEdit*)pEvent->GetTarget();
	if(Code == EG_EVENT_FOCUSED) {
		if(EGInputDevice::GetActive()->GetType() == EG_INDEV_TYPE_POINTER) {
			if(pCalendar == nullptr) {
        EGObject *pLayer = EGDisplay::GetTopLayer(nullptr);
				pLayer->AddFlag(EG_OBJ_FLAG_CLICKABLE);
				pCalendar = new EGCalendar(pLayer);
				pLayer->SetStyleBackOPA(EG_OPA_50, 0);
				pLayer->SetStyleBackColor(EG_MainPalette(EG_PALETTE_GREY), 0);
				if(DisplaySize == DISP_SMALL)	pCalendar->SetSize(180, 200);
				else if(DisplaySize == DISP_MEDIUM)	pCalendar->SetSize(200, 220);
				else pCalendar->SetSize(300, 330);
				pCalendar->SetVisableDate(BirthDate.Year, BirthDate.Month);
				pCalendar->Align(EG_ALIGN_CENTER, 0, 30);
				EGEvent::AddEventCB(pCalendar, CalendarEventCB, EG_EVENT_ALL, pEdit);
//        pCalendar->CreateDropDownHeader();
        pCalendar->CreateMonthHeader();
			}
		}
	}
}

/////////////////////////////////////////////////////////////////////////////

static void CalendarEventCB(EGEvent *pEvent)
{
	EG_EventCode_e Code = pEvent->GetCode();
//	EGCalendar *pCal = (EGCalendar*)pEvent->GetTarget();
	EGEdit *pEdit = (EGEdit*)pEvent->GetExtParam();
	if(Code == EG_EVENT_VALUE_CHANGED) {
		pCalendar->GetSelectedDate(&BirthDate);
  	char DateStr[32];
		eg_snprintf(DateStr, sizeof(DateStr), "%02d.%02d.%d", BirthDate.Day, BirthDate.Month, BirthDate.Year);
		pEdit->SetEditText(DateStr);
    EGObject::Delete(pCalendar);
		pCalendar = nullptr;
    EGObject *pLayer = EGDisplay::GetTopLayer(nullptr);
		pLayer->ClearFlag(EG_OBJ_FLAG_CLICKABLE);
		pLayer->SetStyleBackOPA(EG_OPA_TRANSP, 0);
	}
}

/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////

static void CreateAnalytics(EGObject *pTab)
{
	EGFlexLayout::SetObjFlow(pTab, EG_FLEX_FLOW_ROW_WRAP);

	static EG_Coord_t ChartRowProps[] = {EG_GRID_CONTENT, EG_GRID_FR(1), 10, EG_GRID_TEMPLATE_LAST};
	static EG_Coord_t ChartColumnProps[] = {20, EG_GRID_FR(1), EG_GRID_TEMPLATE_LAST};

	EGObject *pChartContent = new EGObject(pTab);
	EGFlexLayout::SetObjGrow(pChartContent, 1);
	EGGridLayout::SetObjGridParams(pChartContent, ChartColumnProps, ChartRowProps);
	pChartContent->SetHeight(_EG_PCT(100));
	pChartContent->SetStyleMaxHeight(300, 0);
	EGLabel *pTitle = new EGLabel(pChartContent);
	pTitle->SetText("Unique Visitors");
	pTitle->AddStyle(&StyleTitle, 0);
	EGGridLayout::SetObjCell(pTitle, EG_GRID_ALIGN_START, 0, 2, EG_GRID_ALIGN_START, 0, 1);
	pChart1 = new EGChart(pChartContent);
	EGGroup *pGroup = EGGroup::GetDefault();
  if(pGroup != nullptr) pGroup->AddObject(pChart1);
	pChart1->AddFlag(EG_OBJ_FLAG_SCROLL_ON_FOCUS);
	EGGridLayout::SetObjCell(pChart1, EG_GRID_ALIGN_STRETCH, 1, 1, EG_GRID_ALIGN_STRETCH, 1, 1);
	pChart1->SetAxisTick(EG_CHART_AXIS_PRIMARY_Y, 0, 0, 5, 1, true, 80);
	pChart1->SetAxisTick(EG_CHART_AXIS_PRIMARY_X, 0, 0, 12, 1, true, 50);
	pChart1->SetDivLineCount(0, 12);
	pChart1->SetPointCount(12);
	EGEvent::AddEventCB(pChart1, ChartEventCB, EG_EVENT_ALL, nullptr);
	if(DisplaySize == DISP_SMALL)	pChart1->SetZoomX(256 * 3);
	else if(DisplaySize == DISP_MEDIUM)	pChart1->SetZoomX(256 * 2);
	pChart1->SetStyleBorderSide(EG_BORDER_SIDE_LEFT | EG_BORDER_SIDE_BOTTOM, 0);
	pChart1->SetStyleRadius(0, 0);
	pSeries1 = pChart1->AddSeries(EGTheme::GetColorPrimary(pChart1), EG_CHART_AXIS_PRIMARY_Y);
	pChart1->SetNextValue(pSeries1, EG_Rand(10, 80));
	pChart1->SetNextValue(pSeries1, EG_Rand(10, 80));
	pChart1->SetNextValue(pSeries1, EG_Rand(10, 80));
	pChart1->SetNextValue(pSeries1, EG_Rand(10, 80));
	pChart1->SetNextValue(pSeries1, EG_Rand(10, 80));
	pChart1->SetNextValue(pSeries1, EG_Rand(10, 80));
	pChart1->SetNextValue(pSeries1, EG_Rand(10, 80));
	pChart1->SetNextValue(pSeries1, EG_Rand(10, 80));
	pChart1->SetNextValue(pSeries1, EG_Rand(10, 80));
	pChart1->SetNextValue(pSeries1, EG_Rand(10, 80));
	pChart1->SetNextValue(pSeries1, EG_Rand(10, 80));
	pChart1->SetNextValue(pSeries1, EG_Rand(10, 80));
	pChart1->SetNextValue(pSeries1, EG_Rand(10, 80));

  EGObject *pChartContent2 = new EGObject(pTab);
	pChartContent2->AddFlag(EG_OBJ_FLAG_FLEX_IN_NEW_TRACK);
	EGFlexLayout::SetObjGrow(pChartContent2, 1);
	pChartContent2->SetHeight(_EG_PCT(100));
	pChartContent2->SetStyleMaxHeight(300, 0);
	EGGridLayout::SetObjGridParams(pChartContent2, ChartColumnProps, ChartRowProps);
	pTitle = new EGLabel(pChartContent2);
	pTitle->SetText("Monthly Revenue");
	pTitle->AddStyle(&StyleTitle, 0);
	EGGridLayout::SetObjCell(pTitle, EG_GRID_ALIGN_START, 0, 2, EG_GRID_ALIGN_START, 0, 1);
	pChart2 = new EGChart(pChartContent2);
  if(pGroup != nullptr) pGroup->AddObject(pChart2);
	pChart2->AddFlag(EG_OBJ_FLAG_SCROLL_ON_FOCUS);
	EGGridLayout::SetObjCell(pChart2, EG_GRID_ALIGN_STRETCH, 1, 1, EG_GRID_ALIGN_STRETCH, 1, 1);
	pChart2->SetAxisTick(EG_CHART_AXIS_PRIMARY_Y, 0, 0, 5, 1, true, 80);
	pChart2->SetAxisTick(EG_CHART_AXIS_PRIMARY_X, 0, 0, 12, 1, true, 50);
	pChart2->SetSize(_EG_PCT(100), _EG_PCT(100));
	pChart2->SetType(EG_CHART_TYPE_BAR);
	pChart2->SetDivLineCount(6, 0);
	pChart2->SetPointCount(12);
	EGEvent::AddEventCB(pChart2, ChartEventCB, EG_EVENT_ALL, nullptr);
	pChart2->SetZoomX(256 * 2);
	pChart2->SetStyleBorderSide(EG_BORDER_SIDE_LEFT | EG_BORDER_SIDE_BOTTOM, 0);
	pChart2->SetStyleRadius(0, 0);
	if(DisplaySize == DISP_SMALL) {
		pChart2->SetPaddingGap(0, EG_PART_ITEMS);
		pChart2->SetPaddingGap(2, EG_PART_MAIN);
	}
	else if(DisplaySize == DISP_LARGE) {
		pChart2->SetPaddingGap(16, 0);
	}
	pSeries2 = pChart2->AddSeries(EG_LightPalette(EG_PALETTE_GREY, 1), EG_CHART_AXIS_PRIMARY_Y);
	pChart2->SetNextValue(pSeries2, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries2, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries2, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries2, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries2, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries2, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries2, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries2, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries2, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries2, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries2, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries2, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries2, EG_Rand(10, 80));

	pSeries3 = pChart2->AddSeries(EGTheme::GetColorPrimary(pChart1), EG_CHART_AXIS_PRIMARY_Y);
	pChart2->SetNextValue(pSeries3, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries3, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries3, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries3, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries3, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries3, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries3, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries3, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries3, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries3, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries3, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries3, EG_Rand(10, 80));
	pChart2->SetNextValue(pSeries3, EG_Rand(10, 80));

	pMeter1 = CreateMeterBox(pTab, "Monthly Target", "Revenue: 63%", "Sales: 44%", "Costs: 58%");
	pMeter1->GetParent()->AddFlag(EG_OBJ_FLAG_FLEX_IN_NEW_TRACK);
	pScale1 = pMeter1->AddScale();
	pMeter1->SetScaleRange(pScale1, 0, 100, 270, 90);
	pMeter1->SetScaleTicks(pScale1, 0, 0, 0, EG_ColorBlack());

	EGAnimate Animate;
	Animate.SetValues(20, 100);
	Animate.SetRepeatCount(EG_ANIM_REPEAT_INFINITE);

	EG_Indicator_t *pIndicator = pMeter1->AddArc(pScale1, 15, EG_MainPalette(EG_PALETTE_BLUE), 0);
	Animate.SetExcCB(Meter1Indicator1AnimateCB);
	Animate.SetItem(pIndicator);
	Animate.SetTime(4100);
	Animate.SetPlaybackTime(2700);
	EGAnimate::Create(&Animate);

	pIndicator = pMeter1->AddArc(pScale1, 15, EG_MainPalette(EG_PALETTE_RED), -20);
	Animate.SetExcCB(Meter1Indicator2AnimateCB);
	Animate.SetItem(pIndicator);
	Animate.SetTime(2600);
	Animate.SetPlaybackTime(3200);
	Animate.m_pParam = pIndicator;
	EGAnimate::Create(&Animate);

	pIndicator = pMeter1->AddArc(pScale1, 15, EG_MainPalette(EG_PALETTE_GREEN), -40);
	Animate.SetExcCB(Meter1Indicator3AnimateCB);
	Animate.SetItem(pIndicator);
	Animate.SetTime(2800);
	Animate.SetPlaybackTime(1800);
	EGAnimate::Create(&Animate);

	pMeter2 = CreateMeterBox(pTab, "Sessions", "Desktop: ", "Tablet: ", "Mobile: ");
	if(DisplaySize < DISP_LARGE) pMeter2->GetParent()->AddFlag(EG_OBJ_FLAG_FLEX_IN_NEW_TRACK);
	pScale2 = pMeter1->AddScale();
	pMeter2->SetScaleRange(pScale2, 0, 100, 360, 90);
	pMeter2->SetScaleTicks(pScale2, 0, 0, 0, EG_ColorBlack());

	static EG_Indicator_t *pIndicator2[3];
	pIndicator2[0] = pMeter2->AddArc(pScale2, 20, EG_MainPalette(EG_PALETTE_RED), -10);
	pMeter2->SetIndicatorStartValue(pIndicator2[0], 0);
	pMeter2->SetIndicatorEndValue(pIndicator2[0], 39);

	pIndicator2[1] = pMeter2->AddArc(pScale2, 30, EG_MainPalette(EG_PALETTE_BLUE), 0);
	pMeter2->SetIndicatorStartValue(pIndicator2[1], 40);
	pMeter2->SetIndicatorEndValue(pIndicator2[1], 69);

	pIndicator2[2] = pMeter2->AddArc(pScale2, 10, EG_MainPalette(EG_PALETTE_GREEN), -20);
	pMeter2->SetIndicatorStartValue(pIndicator2[2], 70);
	pMeter2->SetIndicatorEndValue(pIndicator2[2], 99);

	pMeter2Timer = EGTimer::Create(Meter2TimerCB, 100, pIndicator2);

	pMeter3 = CreateMeterBox(pTab, "Network Speed", "Low speed", "Normal Speed", "High Speed");
	if(DisplaySize < DISP_LARGE) pMeter3->GetParent()->AddFlag(EG_OBJ_FLAG_FLEX_IN_NEW_TRACK);

	// Add a special circle to the needle's pivot
	pMeter3->SetHorizontalPadding(10, 0);
	pMeter3->SetStyleSize(10, EG_PART_INDICATOR);
	pMeter3->SetStyleRadius(EG_RADIUS_CIRCLE, EG_PART_INDICATOR);
	pMeter3->SetStyleBackOPA(EG_OPA_COVER, EG_PART_INDICATOR);
	pMeter3->SetStyleBackColor(EG_DarkPalette(EG_PALETTE_GREY, 4), EG_PART_INDICATOR);
	pMeter3->SetStyleOutlineColor(EG_ColorWhite(), EG_PART_INDICATOR);
	pMeter3->SetStyleOutlineWidth(3, EG_PART_INDICATOR);
	pMeter3->SetStyleTextColor(EG_DarkPalette(EG_PALETTE_GREY, 1), EG_PART_TICKS);

	pScale3 = pMeter3->AddScale();
	pMeter3->SetScaleRange(pScale3, 10, 60, 220, 360 - 220);
	pMeter3->SetScaleTicks(pScale3, 21, 3, 17, EG_ColorWhite());
	pMeter3->SetScaleMajorTicks(pScale3, 4, 4, 22, EG_ColorWhite(), 15);

	pIndicator = pMeter3->AddArc(pScale3, 10, EG_MainPalette(EG_PALETTE_RED), 0);
	pMeter3->SetIndicatorStartValue(pIndicator, 0);
	pMeter3->SetIndicatorEndValue(pIndicator, 20);

	pIndicator = pMeter3->AddScaleLines(pScale3, EG_DarkPalette(EG_PALETTE_RED, 3), EG_DarkPalette(EG_PALETTE_RED,	3), true, 0);
	pMeter3->SetIndicatorStartValue(pIndicator, 0);
	pMeter3->SetIndicatorEndValue(pIndicator, 20);

	pIndicator = pMeter3->AddArc(pScale3, 12, EG_MainPalette(EG_PALETTE_BLUE), 0);
	pMeter3->SetIndicatorStartValue(pIndicator, 20);
	pMeter3->SetIndicatorEndValue(pIndicator, 40);

	pIndicator = pMeter3->AddScaleLines(pScale3, EG_DarkPalette(EG_PALETTE_BLUE, 3), EG_DarkPalette(EG_PALETTE_BLUE, 3), true, 0);
	pMeter3->SetIndicatorStartValue(pIndicator, 20);
	pMeter3->SetIndicatorEndValue(pIndicator, 40);

	pIndicator = pMeter3->AddArc(pScale3, 10, EG_MainPalette(EG_PALETTE_GREEN), 0);
	pMeter3->SetIndicatorStartValue(pIndicator, 40);
	pMeter3->SetIndicatorEndValue(pIndicator, 60);

	pIndicator = pMeter3->AddScaleLines(pScale3, EG_DarkPalette(EG_PALETTE_GREEN, 3), EG_DarkPalette(EG_PALETTE_GREEN, 3), true, 0);
	pMeter3->SetIndicatorStartValue(pIndicator, 40);
	pMeter3->SetIndicatorEndValue(pIndicator, 60);

	pIndicator = pMeter3->AddNeedleLine(pScale3, 4, EG_DarkPalette(EG_PALETTE_GREY, 4), -25);

	EGLabel *pLabel = new EGLabel(pMeter3);
	pLabel->SetText("-");
	pLabel->AddStyle(&StyleTitle, 0);

	EGLabel *pUnits = new EGLabel(pMeter3);
	pUnits->SetText("Mbps");

	Animate.SetValues(10, 60);
	Animate.SetRepeatCount(EG_ANIM_REPEAT_INFINITE);
	Animate.SetExcCB(Meter3AnimateCB);
	Animate.SetItem(pIndicator);
	Animate.SetTime(4100);
	Animate.SetPlaybackTime(800);
	EGAnimate::Create(&Animate);

	((EGObject*)pTab)->UpdateLayout();
	if(DisplaySize == DISP_MEDIUM) {
		pMeter1->SetSize(200, 200);
		pMeter2->SetSize(200, 200);
		pMeter3->SetSize(200, 200);
	}
	else {
		EG_Coord_t MeterWidth = pMeter1->GetWidth();
		pMeter1->SetHeight(MeterWidth);
		pMeter2->SetHeight(MeterWidth);
		pMeter3->SetHeight(MeterWidth);
	}
	pLabel->Align(EG_ALIGN_TOP_MID, 10, _EG_PCT(55));
  pUnits->AlignTo(pLabel, EG_ALIGN_OUT_RIGHT_BOTTOM, 10, 0);
}

/////////////////////////////////////////////////////////////////////////////

static void ChartEventCB(EGEvent *pEvent)
{
	EG_EventCode_e Code = pEvent->GetCode();
	EGChart *pChart = (EGChart*)pEvent->GetTarget();
	if(Code == EG_EVENT_PRESSED || Code == EG_EVENT_RELEASED) {
		pChart->Invalidate();   // To make the value boxes visible
	}
	else if(Code == EG_EVENT_DRAW_PART_BEGIN) {
		EGDrawDiscriptor *pDiscriptor = (EGDrawDiscriptor*)pEvent->GetParam();
		// Set the markers' text
		if(pDiscriptor->m_Part == EG_PART_TICKS && pDiscriptor->m_Index == EG_CHART_AXIS_PRIMARY_X) {
			if(pChart->GetType() == EG_CHART_TYPE_BAR) {
				const char *month[] = {"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"};
				eg_snprintf(pDiscriptor->m_pText, pDiscriptor->m_TextLength, "%s", month[pDiscriptor->m_Value]);
			}
			else {
				const char *month[] = {"Jan", "Febr", "March", "Apr", "May", "Jun", "July", "Aug", "Sept", "Oct", "Nov", "Dec"};
				eg_snprintf(pDiscriptor->m_pText, pDiscriptor->m_TextLength, "%s", month[pDiscriptor->m_Value]);
			}
		}
		else if(pDiscriptor->m_Part == EG_PART_ITEMS) {		// Add the faded area before the lines are drawn 
#if EG_DRAW_COMPLEX
			if(pDiscriptor->m_pPoint1 && pDiscriptor->m_pPoint2) {			// Add  a line mask that keeps the area below the line
				MaskLineParam_t LineMask;
				DrawMaskSetLinePoints(&LineMask, pDiscriptor->m_pPoint1->m_X, pDiscriptor->m_pPoint1->m_Y, pDiscriptor->m_pPoint2->m_X, 
                              pDiscriptor->m_pPoint2->m_Y, EG_DRAW_MASK_LINE_SIDE_BOTTOM);
				int16_t LineMaskIndex = DrawMaskAdd(&LineMask, nullptr);
				EG_Coord_t Height = pChart->GetHeight();				// Add a fade effect: transparent bottom covering top
				MaskFadeParam_t FadeMask;
				DrawMaskSetFade(&FadeMask, &pChart->m_Rect, EG_OPA_COVER, pChart->m_Rect.GetY1() + Height / 8, EG_OPA_TRANSP, pChart->m_Rect.GetY2());
				int16_t FadeMaskIndex = DrawMaskAdd(&FadeMask, nullptr);
				EGDrawRect DrawRect;			// Draw a rectangle that will be affected by the mask
				DrawRect.m_BackgroundOPA = EG_OPA_50;
				DrawRect.m_BackgroundColor = pDiscriptor->m_pDrawLine->m_Color;
				const EGRect *pOriginalClip = pDiscriptor->m_pContext->m_pClipRect;
				EGRect ClipRect;
				ClipRect.Intersect(pOriginalClip, &pChart->m_Rect);
				pDiscriptor->m_pContext->m_pClipRect = &ClipRect;
				EGRect Rect(pDiscriptor->m_pPoint1->m_X, EG_MIN(pDiscriptor->m_pPoint1->m_Y, pDiscriptor->m_pPoint2->m_Y), 
                    pDiscriptor->m_pPoint2->m_X - 1, pChart->m_Rect.GetY2()); 
        g_pDrawRect = &DrawRect;
				DrawRect.Draw(pDiscriptor->m_pContext, &Rect);
				pDiscriptor->m_pContext->m_pClipRect = pOriginalClip;
				DrawMaskRemove(LineMaskIndex);				// Remove the masks
				DrawMaskRemove(FadeMaskIndex);
			}
#endif
			const EG_CharSeries_t *pSeries = (EG_CharSeries_t*)pDiscriptor->m_pSubPart;
			if(pChart->GetSelectPoint() == pDiscriptor->m_Index) {
				if(pChart->GetType() == EG_CHART_TYPE_LINE) {
					pDiscriptor->m_pDrawRect->m_OutlineColor = EG_ColorWhite();
					pDiscriptor->m_pDrawRect->m_OutlineWidth = 2;
				}
				else {
					pDiscriptor->m_pDrawRect->m_ShadowColor = pSeries->Color;
					pDiscriptor->m_pDrawRect->m_ShadowWidth = 15;
					pDiscriptor->m_pDrawRect->m_ShadowSpread = 0;
				}
				char buf[8];
				eg_snprintf(buf, sizeof(buf), "%" EG_PRIu32, pDiscriptor->m_Value);
				EGPoint TextSize;
				EG_GetTextSize(&TextSize, buf, pFontNormal, 0, 0, EG_COORD_MAX, EG_TEXT_FLAG_NONE);
				EGRect TextRect;
				if(pChart->GetType() == EG_CHART_TYPE_BAR) {
					TextRect.SetY2(pDiscriptor->m_pRect->GetY1() - EG_DPX(15));
					TextRect.SetY1(TextRect.GetY2() - TextSize.m_Y);
					if(pSeries == pChart->GetSeriesNext(nullptr)) {
						TextRect.SetX1(pDiscriptor->m_pRect->GetX1() + pDiscriptor->m_pRect->GetWidth() / 2);
						TextRect.SetX2(TextRect.GetX1() + TextSize.m_X);
					}
					else {
						TextRect.SetX2(pDiscriptor->m_pRect->GetX1() + pDiscriptor->m_pRect->GetWidth() / 2);
						TextRect.SetX1(TextRect.GetX2() - TextSize.m_X);
					}
				}
				else {
					TextRect.SetX1(pDiscriptor->m_pRect->GetX1() + pDiscriptor->m_pRect->GetWidth() / 2 - TextSize.m_X / 2);
					TextRect.SetX2(TextRect.GetX1() + TextSize.m_X);
					TextRect.SetY2(pDiscriptor->m_pRect->GetY1() - EG_DPX(15));
					TextRect.SetY1(TextRect.GetY2() - TextSize.m_Y);
				}
				EGRect BackRect(TextRect);
        BackRect.Inflate(EG_DPX(8), EG_DPX(8));
				EGDrawRect DrawRect;
				DrawRect.m_BackgroundColor = pSeries->Color;
				DrawRect.m_Radius = EG_DPX(5);
				DrawRect.Draw(pDiscriptor->m_pContext, &BackRect);
        EGDrawLabel DrawLabel;
        DrawLabel.m_Color = EG_ColorWhite();
        DrawLabel.m_pFont = pFontNormal;
        DrawLabel.Draw(pDiscriptor->m_pContext, &TextRect, buf, NULL);
			}
			else {
				pDiscriptor->m_pDrawRect->m_OutlineWidth = 0;
				pDiscriptor->m_pDrawRect->m_ShadowWidth = 0;
			}
		}
	}
}

/////////////////////////////////////////////////////////////////////////////

static EGMeter* CreateMeterBox(EGObject *pTab, const char *pTitle, const char *pText1, const char *pText2,	const char *pText3)
{
	EGObject *pContainer = new EGObject(pTab);
	pContainer->SetHeight(EG_SIZE_CONTENT);
	EGFlexLayout::SetObjGrow(pContainer, 1);

	EGLabel *pTitleLabel = new EGLabel(pContainer);
	pTitleLabel->SetText(pTitle);
	pTitleLabel->AddStyle(&StyleTitle, 0);
	EGMeter *pMeter = new EGMeter(pContainer);
	pMeter->RemoveStyle(nullptr, EG_PART_MAIN);
	pMeter->RemoveStyle(nullptr, EG_PART_INDICATOR);
	pMeter->SetWidth(_EG_PCT(100));

	EGObject *pBullet1 = new EGObject(pContainer);
	pBullet1->SetSize(13, 13);
	pBullet1->RemoveStyle(nullptr, EG_PART_SCROLLBAR);
	pBullet1->AddStyle(&StyleBullet, 0);
	pBullet1->SetStyleBackColor(EG_MainPalette(EG_PALETTE_RED), 0);
	EGLabel *pLabel1 = new EGLabel(pContainer);
	pLabel1->SetText(pText1);

	EGObject *pBullet2 = new EGObject(pContainer);
	pBullet2->SetSize(13, 13);
	pBullet2->RemoveStyle(nullptr, EG_PART_SCROLLBAR);
	pBullet2->AddStyle(&StyleBullet, 0);
	pBullet2->SetStyleBackColor(EG_MainPalette(EG_PALETTE_BLUE), 0);
	EGLabel *pLabel2 = new EGLabel(pContainer);
	pLabel2->SetText(pText2);

	EGObject *pBullet3 = new EGObject(pContainer);
	pBullet3->SetSize(13, 13);
	pBullet3->RemoveStyle(nullptr, EG_PART_SCROLLBAR);
	pBullet3->AddStyle(&StyleBullet, 0);
	pBullet3->SetStyleBackColor(EG_MainPalette(EG_PALETTE_GREEN), 0);
	EGLabel *pLabel3 = new EGLabel(pContainer);
	pLabel3->SetText(pText3);

	if(DisplaySize == DISP_MEDIUM) {
		static EG_Coord_t grid_col_dsc[] = {EG_GRID_CONTENT, EG_GRID_FR(1), EG_GRID_CONTENT, EG_GRID_FR(8), EG_GRID_TEMPLATE_LAST};
		static EG_Coord_t grid_row_dsc[] = {EG_GRID_CONTENT, EG_GRID_FR(1), EG_GRID_CONTENT, EG_GRID_CONTENT, EG_GRID_CONTENT, EG_GRID_FR(1), EG_GRID_TEMPLATE_LAST};

		EGGridLayout::SetObjGridParams(pContainer, grid_col_dsc, grid_row_dsc);
		EGGridLayout::SetObjCell(pTitleLabel, EG_GRID_ALIGN_START, 0, 4, EG_GRID_ALIGN_START, 0, 1);
		EGGridLayout::SetObjCell(pMeter, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 1, 3);
		EGGridLayout::SetObjCell(pBullet1, EG_GRID_ALIGN_START, 2, 1, EG_GRID_ALIGN_CENTER, 2, 1);
		EGGridLayout::SetObjCell(pBullet2, EG_GRID_ALIGN_START, 2, 1, EG_GRID_ALIGN_CENTER, 3, 1);
		EGGridLayout::SetObjCell(pBullet3, EG_GRID_ALIGN_START, 2, 1, EG_GRID_ALIGN_CENTER, 4, 1);
		EGGridLayout::SetObjCell(pLabel1, EG_GRID_ALIGN_STRETCH, 3, 1, EG_GRID_ALIGN_CENTER, 2, 1);
		EGGridLayout::SetObjCell(pLabel2, EG_GRID_ALIGN_STRETCH, 3, 1, EG_GRID_ALIGN_CENTER, 3, 1);
		EGGridLayout::SetObjCell(pLabel3, EG_GRID_ALIGN_STRETCH, 3, 1, EG_GRID_ALIGN_CENTER, 4, 1);
	}
	else {
		static EG_Coord_t grid_col_dsc[] = {EG_GRID_CONTENT, EG_GRID_FR(1), EG_GRID_TEMPLATE_LAST};
		static EG_Coord_t grid_row_dsc[] = {EG_GRID_CONTENT, EG_GRID_CONTENT, EG_GRID_CONTENT, EG_GRID_CONTENT, EG_GRID_CONTENT, EG_GRID_TEMPLATE_LAST};
		EGGridLayout::SetObjGridParams(pContainer, grid_col_dsc, grid_row_dsc);
		EGGridLayout::SetObjCell(pTitleLabel, EG_GRID_ALIGN_START, 0, 2, EG_GRID_ALIGN_START, 0, 1);
		EGGridLayout::SetObjCell(pMeter, EG_GRID_ALIGN_START, 0, 2, EG_GRID_ALIGN_START, 1, 1);
		EGGridLayout::SetObjCell(pBullet1, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 2, 1);
		EGGridLayout::SetObjCell(pBullet2, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 3, 1);
		EGGridLayout::SetObjCell(pBullet3, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 4, 1);
		EGGridLayout::SetObjCell(pLabel1, EG_GRID_ALIGN_STRETCH, 1, 1, EG_GRID_ALIGN_START, 2, 1);
		EGGridLayout::SetObjCell(pLabel2, EG_GRID_ALIGN_STRETCH, 1, 1, EG_GRID_ALIGN_START, 3, 1);
		EGGridLayout::SetObjCell(pLabel3, EG_GRID_ALIGN_STRETCH, 1, 1, EG_GRID_ALIGN_START, 4, 1);
	}
	return pMeter;
}

/////////////////////////////////////////////////////////////////////////////

static void Meter1Indicator1AnimateCB(void *var, int32_t v)
{
	pMeter1->SetIndicatorEndValue((EG_Indicator_t*)var, v);
	EGObject *pContainer = pMeter1->GetParent();
	EGLabel *pLabel = (EGLabel*)pContainer->GetChild(-5);
	pLabel->SetFormatText("Revenue: %" EG_PRId32 " %%", v);
}

/////////////////////////////////////////////////////////////////////////////

static void Meter1Indicator2AnimateCB(void *var, int32_t v)
{
	pMeter1->SetIndicatorEndValue((EG_Indicator_t*)var, v);
	EGObject *pContainer = pMeter1->GetParent();
	EGLabel *pLabel = (EGLabel*)pContainer->GetChild(-3);
	pLabel->SetFormatText("Sales: %" EG_PRId32 " %%", v);
}

/////////////////////////////////////////////////////////////////////////////

static void Meter1Indicator3AnimateCB(void *var, int32_t v)
{
	pMeter1->SetIndicatorEndValue((EG_Indicator_t*)var, v);
	EGObject *pContainer = pMeter1->GetParent();
	EGLabel *pLabel = (EGLabel*)pContainer->GetChild(-1);
	pLabel->SetFormatText("Costs: %" EG_PRId32 " %%", v);
}

/////////////////////////////////////////////////////////////////////////////

static void Meter2TimerCB(EGTimer *pTimer)
{
	EG_Indicator_t **indics = (EG_Indicator_t**)pTimer->m_pParam;

	static bool down1 = false;
	static bool down2 = false;
	static bool down3 = false;

	if(down1) {
		SessionDesktop -= 137;
		if(SessionDesktop < 1400) down1 = false;
	}
	else {
		SessionDesktop += 116;
		if(SessionDesktop > 4500) down1 = true;
	}

	if(down2) {
		SessionTablet -= 3;
		if(SessionTablet < 1400) down2 = false;
	}
	else {
		SessionTablet += 9;
		if(SessionTablet > 4500) down2 = true;
	}

	if(down3) {
		SessionMobile -= 57;
		if(SessionMobile < 1400) down3 = false;
	}
	else {
		SessionMobile += 76;
		if(SessionMobile > 4500) down3 = true;
	}

	uint32_t all = SessionDesktop + SessionTablet + SessionMobile;
	uint32_t pct1 = (SessionDesktop * 97) / all;
	uint32_t pct2 = (SessionTablet * 97) / all;

	pMeter2->SetIndicatorStartValue(indics[0], 0);
	pMeter2->SetIndicatorEndValue(indics[0], pct1);

	pMeter2->SetIndicatorStartValue(indics[1], pct1 + 1);
	pMeter2->SetIndicatorEndValue(indics[1], pct1 + 1 + pct2);

	pMeter2->SetIndicatorStartValue(indics[2], pct1 + 1 + pct2 + 1);
	pMeter2->SetIndicatorEndValue(indics[2], 99);

	EGObject *pContainer = pMeter2->GetParent();

  EGLabel *pLabel = (EGLabel*)pContainer->GetChild(-5);
	pLabel->SetFormatText("Desktop: %" EG_PRIu32, SessionDesktop);

	pLabel = (EGLabel*)pContainer->GetChild(-3);
	pLabel->SetFormatText("Tablet: %" EG_PRIu32, SessionTablet);

	pLabel = (EGLabel*)pContainer->GetChild(-1);
	pLabel->SetFormatText("Mobile: %" EG_PRIu32, SessionMobile);
}

/////////////////////////////////////////////////////////////////////////////

static void Meter3AnimateCB(void *var, int32_t v)
{
	pMeter3->SetIndicatorEndValue((EG_Indicator_t*)var, v);
	EGLabel *pLabel = (EGLabel*)pMeter3->GetChild(0);
	pLabel->SetFormatText("%" EG_PRId32, v);
}

/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////

void CreateShop(EGObject *pTab)
{
	EGFlexLayout::SetObjFlow(pTab, EG_FLEX_FLOW_ROW_WRAP);
	EGObject *pPanel4 = new EGObject(pTab);
	pPanel4->SetSize(_EG_PCT(100), EG_SIZE_CONTENT);
	pPanel4->SetStylePadBottom(30, 0);
	EGLabel *pTitle = new EGLabel(pPanel4);
	pTitle->SetText("Monthly Summary");
	pTitle->AddStyle(&StyleTitle, 0);
	EGLabel *pDate = new EGLabel(pPanel4);
	pDate->SetText("8-15 July, 2021");
	pDate->AddStyle(&StyleTextMuted, 0);
	EGLabel *pAmount = new EGLabel(pPanel4);
	pAmount->SetText("$27,123.25");
	pAmount->AddStyle(&StyleTitle, 0);
	EGLabel *pHint = new EGLabel(pPanel4);
	pHint->SetText(EG_SYMBOL_UP " 17% growth this week");
	pHint->SetStyleTextColor(EG_MainPalette(EG_PALETTE_GREEN), 0);

  pChart3 = new EGChart(pPanel4);
	pChart3->SetAxisTick(EG_CHART_AXIS_PRIMARY_Y, 0, 0, 6, 1, true, 80);
	pChart3->SetAxisTick(EG_CHART_AXIS_PRIMARY_X, 0, 0, 7, 1, true, 50);
	pChart3->SetType(EG_CHART_TYPE_BAR);
	pChart3->SetDivLineCount(6, 0);
	pChart3->SetPointCount(7);
	EGEvent::AddEventCB(pChart3, ShopChartEventCB, EG_EVENT_ALL, nullptr);

	pSeries4 = pChart3->AddSeries(EGTheme::GetColorPrimary(pChart3), EG_CHART_AXIS_PRIMARY_Y);
	pChart3->SetNextValue(pSeries4, EG_Rand(60, 90));
	pChart3->SetNextValue(pSeries4, EG_Rand(60, 90));
	pChart3->SetNextValue(pSeries4, EG_Rand(60, 90));
	pChart3->SetNextValue(pSeries4, EG_Rand(60, 90));
	pChart3->SetNextValue(pSeries4, EG_Rand(60, 90));
	pChart3->SetNextValue(pSeries4, EG_Rand(60, 90));
	pChart3->SetNextValue(pSeries4, EG_Rand(60, 90));
	pChart3->SetNextValue(pSeries4, EG_Rand(60, 90));
	pChart3->SetNextValue(pSeries4, EG_Rand(60, 90));
	pChart3->SetNextValue(pSeries4, EG_Rand(60, 90));
	pChart3->SetNextValue(pSeries4, EG_Rand(60, 90));
	pChart3->SetNextValue(pSeries4, EG_Rand(60, 90));

	if(DisplaySize == DISP_LARGE) {
		static EG_Coord_t Panel4ColumnProps[] = {EG_GRID_FR(1), EG_GRID_FR(1), EG_GRID_TEMPLATE_LAST};
		static EG_Coord_t Panel4RowProps[] = {
			EG_GRID_CONTENT, // Title
			EG_GRID_CONTENT, // Sub title
			20,              // Spacer
			EG_GRID_CONTENT, // Amount
			EG_GRID_CONTENT, // Hint
			EG_GRID_TEMPLATE_LAST};

		pChart3->SetSize(_EG_PCT(100), _EG_PCT(100));
		pChart3->SetStylePadColumn(EG_DPX(30), 0);

		EGGridLayout::SetObjGridParams(pPanel4, Panel4ColumnProps, Panel4RowProps);
		EGGridLayout::SetObjCell(pTitle, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 0, 1);
		EGGridLayout::SetObjCell(pDate, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 1, 1);
		EGGridLayout::SetObjCell(pAmount, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 3, 1);
		EGGridLayout::SetObjCell(pHint, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 4, 1);
		EGGridLayout::SetObjCell(pChart3, EG_GRID_ALIGN_STRETCH, 1, 1, EG_GRID_ALIGN_STRETCH, 0, 5);
	}
	else if(DisplaySize == DISP_MEDIUM) {
		static EG_Coord_t Panel4ColumnProps[] = {EG_GRID_FR(1), EG_GRID_FR(1), EG_GRID_TEMPLATE_LAST};
		static EG_Coord_t Panel4RowProps[] = {
			EG_GRID_CONTENT, // Title + Date
			EG_GRID_CONTENT, // Amount + Hint
			200,             // Chart
			EG_GRID_TEMPLATE_LAST};

    ((EGObject*)pPanel4)->UpdateLayout();
		pChart3->SetWidth(pPanel4->GetContentWidth() - 20);
		pChart3->SetStylePadColumn(EG_DPX(30), 0);

		EGGridLayout::SetObjGridParams(pPanel4, Panel4ColumnProps, Panel4RowProps);
		EGGridLayout::SetObjCell(pTitle, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_CENTER, 0, 1);
		EGGridLayout::SetObjCell(pDate, EG_GRID_ALIGN_START, 1, 1, EG_GRID_ALIGN_CENTER, 0, 1);
		EGGridLayout::SetObjCell(pAmount, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_CENTER, 1, 1);
		EGGridLayout::SetObjCell(pHint, EG_GRID_ALIGN_START, 1, 1, EG_GRID_ALIGN_CENTER, 1, 1);
		EGGridLayout::SetObjCell(pChart3, EG_GRID_ALIGN_END, 0, 2, EG_GRID_ALIGN_STRETCH, 2, 1);
	}
	else if(DisplaySize == DISP_SMALL) {
		static EG_Coord_t Panel4ColumnProps[] = {EG_GRID_FR(1), EG_GRID_TEMPLATE_LAST};
		static EG_Coord_t Panel4RowProps[] = {
			EG_GRID_CONTENT, // Title
			EG_GRID_CONTENT, // Date
			EG_GRID_CONTENT, // Amount
			EG_GRID_CONTENT, // Hint
			EG_GRID_CONTENT, // Chart
			EG_GRID_TEMPLATE_LAST};

		pChart3->SetWidth(_EG_PCT(95));
		pChart3->SetHeight(EG_VERT_RES - 70);
		pChart3->SetStyleMaxHeight(300, 0);
		pChart3->SetZoomX(512);

		EGGridLayout::SetObjGridParams(pPanel4, Panel4ColumnProps, Panel4RowProps);
		EGGridLayout::SetObjCell(pTitle, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 0, 1);
		EGGridLayout::SetObjCell(pDate, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 1, 1);
		EGGridLayout::SetObjCell(pAmount, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 2, 1);
		EGGridLayout::SetObjCell(pHint, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 3, 1);
		EGGridLayout::SetObjCell(pChart3, EG_GRID_ALIGN_END, 0, 1, EG_GRID_ALIGN_START, 4, 1);
	}

	EGObject *pList = new EGObject(pTab);
	if(DisplaySize == DISP_SMALL) {
		pList->AddFlag(EG_OBJ_FLAG_FLEX_IN_NEW_TRACK);
		pList->SetHeight(_EG_PCT(100));
	}
	else {
		pList->SetHeight(_EG_PCT(100));
		pList->SetStyleMaxHeight(300, 0);
	}

	EGFlexLayout::SetObjFlow(pList, EG_FLEX_FLOW_COLUMN);
	EGFlexLayout::SetObjGrow(pList, 1);
	pList->AddFlag(EG_OBJ_FLAG_FLEX_IN_NEW_TRACK);

	pTitle = new EGLabel(pList);
	pTitle->SetText("Top products");
	pTitle->AddStyle(&StyleTitle, 0);

	CreateShopItem(pList, &ImageClothes, "Blue jeans", "Clothes", "$722");
	CreateShopItem(pList, &ImageClothes, "Blue jeans", "Clothes", "$411");
	CreateShopItem(pList, &ImageClothes, "Blue jeans", "Clothes", "$917");
	CreateShopItem(pList, &ImageClothes, "Blue jeans", "Clothes", "$64");
	CreateShopItem(pList, &ImageClothes, "Blue jeans", "Clothes", "$805");

	EGObject *pNotifications = new EGObject(pTab);
	if(DisplaySize == DISP_SMALL) {
		pNotifications->AddFlag(EG_OBJ_FLAG_FLEX_IN_NEW_TRACK);
		pNotifications->SetHeight(_EG_PCT(100));
	}
	else {
		pNotifications->SetHeight(_EG_PCT(100));
		pNotifications->SetStyleMaxHeight(300, 0);
	}

	EGFlexLayout::SetObjFlow(pNotifications, EG_FLEX_FLOW_COLUMN);
	EGFlexLayout::SetObjGrow(pNotifications, 1);

	pTitle = new EGLabel(pNotifications);
	pTitle->SetText("Notification");
	pTitle->AddStyle(&StyleTitle, 0);

	EGCheckbox *pCheck = new EGCheckbox(pNotifications);
	pCheck->SetText("Item purchased");

	pCheck = new EGCheckbox(pNotifications);
	pCheck->SetText("New connection");

	pCheck = new EGCheckbox(pNotifications);
	pCheck->SetText("New subscriber");
	pCheck->AddState(EG_STATE_CHECKED);

	pCheck = new EGCheckbox(pNotifications);
	pCheck->SetText("New message");
	pCheck->AddState(EG_STATE_DISABLED);

	pCheck = new EGCheckbox(pNotifications);
	pCheck->SetText("Milestone reached");
	pCheck->AddState(EG_STATE_CHECKED | EG_STATE_DISABLED);

	pCheck = new EGCheckbox(pNotifications);
	pCheck->SetText("Out of stock");
}

/////////////////////////////////////////////////////////////////////////////

static void ShopChartEventCB(EGEvent *pEvent)
{
	EG_EventCode_e Code = pEvent->GetCode();
	if(Code == EG_EVENT_DRAW_PART_BEGIN) {
		EGDrawDiscriptor *pDiscriptor = (EGDrawDiscriptor*)pEvent->GetParam();
		// Set the markers' text
		if(pDiscriptor->m_Part == EG_PART_TICKS && pDiscriptor->m_Index == EG_CHART_AXIS_PRIMARY_X) {
			const char *month[] = {"Jan", "Febr", "March", "Apr", "May", "Jun", "July", "Aug", "Sept", "Oct", "Nov", "Dec"};
			eg_snprintf(pDiscriptor->m_pText, pDiscriptor->m_TextLength, "%s", month[pDiscriptor->m_Value]);
		}
		if(pDiscriptor->m_Part == EG_PART_ITEMS) {
			pDiscriptor->m_pDrawRect->m_BackgroundOPA = EG_OPA_TRANSP; // We will draw it later
		}
	}
	if(Code == EG_EVENT_DRAW_PART_END) {
		EGDrawDiscriptor *pDiscriptor = (EGDrawDiscriptor*)pEvent->GetParam();
		// Add the faded area before the lines are drawn 
		if(pDiscriptor->m_Part == EG_PART_ITEMS) {
			static const uint32_t Devices[10] = {32, 43, 21, 56, 29, 36, 19, 25, 62, 35};
			static const uint32_t Clothes[10] = {12, 19, 23, 31, 27, 32, 32, 11, 21, 32};
			static const uint32_t Services[10] = {56, 38, 56, 13, 44, 32, 49, 64, 17, 33};

			EG_Coord_t Height = pDiscriptor->m_pRect->GetHeight();
			EGRect Rect(pDiscriptor->m_pRect);
			Rect.SetY2(pDiscriptor->m_pRect->GetY1() + 4 + (Devices[pDiscriptor->m_Index] * Height) / 100); // +4 to overlap the radius
			EGDrawRect DrawRect;
			DrawRect.m_BackgroundColor = EG_MainPalette(EG_PALETTE_RED);
			DrawRect.m_Radius = 4;
			DrawRect.Draw(pDiscriptor->m_pContext, &Rect);

			Rect.SetY1(Rect.GetY2() - 4); // -4 to overlap the radius
			Rect.SetY2(Rect.GetY1() + (Clothes[pDiscriptor->m_Index] * Height) / 100);
			DrawRect.m_BackgroundColor = EG_MainPalette(EG_PALETTE_BLUE);
			DrawRect.m_Radius = 0;
			DrawRect.Draw(pDiscriptor->m_pContext, &Rect);

			Rect.SetY1(Rect.GetY2());
			Rect.SetY2(Rect.GetY1() + (Services[pDiscriptor->m_Index] * Height) / 100);
			DrawRect.m_BackgroundColor = EG_MainPalette(EG_PALETTE_GREEN);
			DrawRect.Draw(pDiscriptor->m_pContext, &Rect);
		}
	}
}

/////////////////////////////////////////////////////////////////////////////

static EGObject *CreateShopItem(EGObject *pParent, const void *img_src, const char *pName, const char *category,
																	const char *price)
{
	static EG_Coord_t grid_col_dsc[] = {EG_GRID_CONTENT, 5, EG_GRID_FR(1), EG_GRID_FR(1), EG_GRID_TEMPLATE_LAST};
	static EG_Coord_t grid_row_dsc[] = {EG_GRID_FR(1), EG_GRID_FR(1), EG_GRID_TEMPLATE_LAST};

	EGObject *pContainer = new EGObject(pParent);
	pContainer->RemoveAllStyles();
	pContainer->SetSize(_EG_PCT(100), EG_SIZE_CONTENT);
	EGGridLayout::SetObjGridParams(pContainer, grid_col_dsc, grid_row_dsc);

	EGImage *pImage = new EGImage(pContainer);
	pImage->SetSource(img_src);
	EGGridLayout::SetObjCell(pImage, EG_GRID_ALIGN_START, 0, 1, EG_GRID_ALIGN_START, 0, 2);

	EGLabel *pLabel = new EGLabel(pContainer);
	pLabel->SetText(pName);
	EGGridLayout::SetObjCell(pLabel, EG_GRID_ALIGN_START, 2, 1, EG_GRID_ALIGN_END, 0, 1);

	pLabel = new EGLabel(pContainer);
	pLabel->SetText(category);
	pLabel->AddStyle(&StyleTextMuted, 0);
	EGGridLayout::SetObjCell(pLabel, EG_GRID_ALIGN_START, 2, 1, EG_GRID_ALIGN_START, 1, 1);

	pLabel = new EGLabel(pContainer);
	pLabel->SetText(price);
	EGGridLayout::SetObjCell(pLabel, EG_GRID_ALIGN_END, 3, 1, EG_GRID_ALIGN_END, 0, 1);
	return pContainer;
}

/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////

static void CreateColorChanger(EGObject *pTabView)
{
static EG_Palette_e Palette[] = {
	EG_PALETTE_BLUE, EG_PALETTE_GREEN, EG_PALETTE_BLUE_GREY, EG_PALETTE_ORANGE,
	EG_PALETTE_RED, EG_PALETTE_PURPLE, EG_PALETTE_TEAL, EG_PALETTE_LAST
};

	EGObject *pContainer = new EGObject(pTabView);
	pContainer->RemoveAllStyles();
	EGFlexLayout::SetObjFlow(pContainer, EG_FLEX_FLOW_ROW);
	EGFlexLayout::SetObjAlign(pContainer, EG_FLEX_ALIGN_SPACE_EVENLY, EG_FLEX_ALIGN_CENTER, EG_FLEX_ALIGN_CENTER);
	pContainer->AddFlag(EG_OBJ_FLAG_FLOATING);

	pContainer->SetStyleBackColor(EG_ColorWhite(), 0);
	pContainer->SetStylePadRight(DisplaySize == DISP_SMALL ? EG_DPX(47) : EG_DPX(55), 0);
	pContainer->SetStyleBackOPA(EG_OPA_COVER, 0);
	pContainer->SetStyleRadius(EG_RADIUS_CIRCLE, 0);

	if(DisplaySize == DISP_SMALL)	pContainer->SetSize(EG_DPX(52), EG_DPX(52));
	else pContainer->SetSize(EG_DPX(60), EG_DPX(60));

	pContainer->Align(EG_ALIGN_BOTTOM_RIGHT, -EG_DPX(10), -EG_DPX(10));

	for(uint32_t i = 0; Palette[i] != EG_PALETTE_LAST; i++) {
		EGButton *pButton = new EGButton(pContainer);
		pButton->SetStyleBackColor(EG_MainPalette(Palette[i]), 0);
		pButton->SetStyleRadius(EG_RADIUS_CIRCLE, 0);
		pButton->SetStyleOPA(EG_OPA_TRANSP, 0);
		pButton->SetSize(20, 20);
		EGEvent::AddEventCB(pButton, ColorEventCB, EG_EVENT_ALL, &Palette[i]);
		pButton->ClearFlag(EG_OBJ_FLAG_SCROLL_ON_FOCUS);
	}

	EGButton *pButton = new EGButton(pTabView);
	pButton->AddFlag(EG_OBJ_FLAG_FLOATING | EG_OBJ_FLAG_CLICKABLE);
	pButton->SetStyleBackColor(EG_ColorWhite(), EG_STATE_CHECKED);
	pButton->SetPaddingAll(10, 0);
	pButton->SetStyleRadius(EG_RADIUS_CIRCLE, 0);
	EGEvent::AddEventCB(pButton, ColorChangerEventCB, EG_EVENT_ALL, pContainer);
	pButton->SetStyleShadowWidth(0, 0);
	pButton->SetStyleBackImageSource(EG_SYMBOL_TINT, 0);

	if(DisplaySize == DISP_SMALL) {
		pButton->SetSize(EG_DPX(42), EG_DPX(42));
		pButton->Align(EG_ALIGN_BOTTOM_RIGHT, -EG_DPX(15), -EG_DPX(15));
	}
	else {
		pButton->SetSize(EG_DPX(50), EG_DPX(50));
		pButton->Align(EG_ALIGN_BOTTOM_RIGHT, -EG_DPX(15), -EG_DPX(15));
	}
}

/////////////////////////////////////////////////////////////////////////////

static void ColorChangerAnimateCB(void *pItem, int32_t Value)
{
EG_Coord_t Width;

 	EGObject *pContainer = (EGObject*)pItem;
	EG_Coord_t MaxWidth = pContainer->GetParent()->GetWidth() - EG_DPX(20);
	if(DisplaySize == DISP_SMALL) {
		Width = EG_Map(Value, 0, 256, EG_DPX(52), MaxWidth);
		pContainer->SetWidth(Width);
		pContainer->Align(EG_ALIGN_BOTTOM_RIGHT, -EG_DPX(10), -EG_DPX(10));
	}
	else {
		Width = EG_Map(Value, 0, 256, EG_DPX(60), MaxWidth);
		pContainer->SetWidth(Width);
		pContainer->Align(EG_ALIGN_BOTTOM_RIGHT, -EG_DPX(10), -EG_DPX(10));
	}
	if(Value > EG_OPA_COVER) Value = EG_OPA_COVER;
	for(uint32_t i = 0; i < pContainer->GetChildCount(); i++) {
		pContainer->GetChild(i)->SetStyleOPA(Value, 0);
	}
}

/////////////////////////////////////////////////////////////////////////////

static void ColorChangerEventCB(EGEvent *pEvent)
{
	if(pEvent->GetCode() == EG_EVENT_CLICKED) {
		EGObject *pContainer = (EGObject*)pEvent->GetExtParam();
	  EGAnimate Animate;
		if(pContainer->GetWidth() < EG_HOR_RES / 2) {
			Animate.SetItem(pContainer);
			Animate.SetExcCB(ColorChangerAnimateCB);
			Animate.SetValues(0, 256);
			Animate.SetTime(200);
			EGAnimate::Create(&Animate);
		}
		else {
			Animate.SetItem(pContainer);
			Animate.SetExcCB(ColorChangerAnimateCB);
			Animate.SetValues(256, 0);
			Animate.SetTime(200);
			EGAnimate::Create(&Animate);
		}
	}
}

/////////////////////////////////////////////////////////////////////////////

static void ColorEventCB(EGEvent *pEvent)
{
	EG_EventCode_e Code = pEvent->GetCode();
	EGButton *pButton = (EGButton*)pEvent->GetTarget();
	if(Code == EG_EVENT_FOCUSED) {
		EGObject *pParent = pButton->GetParent();
		if(pParent->GetWidth() < EG_HOR_RES / 2) {
  		EGAnimate Animate;
			Animate.SetItem(pParent);
			Animate.SetExcCB(ColorChangerAnimateCB);
			Animate.SetValues(0, 256);
			Animate.SetTime(200);
			EGAnimate::Create(&Animate);
		}
	}
	else if(Code == EG_EVENT_CLICKED) {
		EG_Palette_e *pPalettePrimary = (EG_Palette_e*)pEvent->GetExtParam();
		EG_Palette_e PaletteSecondary = pPalettePrimary[3]; // Use other palette as secondary
		if(PaletteSecondary >= EG_PALETTE_LAST) PaletteSecondary = EG_PALETTE_RED;
#if EG_USE_THEME_DEFAULT
    EGDefTheme::SetTheme(EG_MainPalette(*pPalettePrimary), EG_MainPalette(PaletteSecondary),	EG_THEME_DEFAULT_DARK, pFontNormal);
#endif
		EG_Color_t Color = EG_MainPalette(*pPalettePrimary);
		StyleIcon.SetTextColor(Color);
		pChart1->SetSeriesColor(pSeries1, Color);
		pChart2->SetSeriesColor(pSeries3, Color);
	}
}


/////////////////////////////////////////////////////////////////////////////

static void SliderEventCB(EGEvent *pEvent)
{
	EG_EventCode_e Code = pEvent->GetCode();
	EGSlider *pSlider = (EGSlider*)pEvent->GetTarget();
	if(Code == EG_EVENT_REFR_EXT_DRAW_SIZE) {
		EG_Coord_t *pSize = (EG_Coord_t*)pEvent->GetParam();
		*pSize = EG_MAX(*pSize, 60);
	}
	else if(Code == EG_EVENT_DRAW_PART_END) {
		EGDrawDiscriptor *pDiscriptor = (EGDrawDiscriptor*)pEvent->GetParam();
		if(pDiscriptor->m_Part == EG_PART_KNOB && pSlider->HasState(EG_STATE_PRESSED)) {
			char buf[8];
			eg_snprintf(buf, sizeof(buf), "%" EG_PRId32, pSlider->GetValue());
			EGPoint TextSize;
			EG_GetTextSize(&TextSize, buf, pFontNormal, 0, 0, EG_COORD_MAX, EG_TEXT_FLAG_NONE);

			EGRect TextRect;
			TextRect.SetX1(pDiscriptor->m_pRect->GetX1() + pDiscriptor->m_pRect->GetWidth() / 2 - TextSize.m_X / 2);
			TextRect.SetX2(TextRect.GetX1() + TextSize.m_X);
			TextRect.SetY2(pDiscriptor->m_pRect->GetY1() - 10);
			TextRect.SetY1(TextRect.GetY2() - TextSize.m_Y);

			EGRect BackRect;
			BackRect.SetX1(TextRect.GetX1() - EG_DPX(8));
			BackRect.SetX2(TextRect.GetX2() + EG_DPX(8));
			BackRect.SetY1(TextRect.GetY1() - EG_DPX(8));
			BackRect.SetY2(TextRect.GetY2() + EG_DPX(8));

			EGDrawRect DrawRect;
			DrawRect.m_BackgroundColor = EG_DarkPalette(EG_PALETTE_GREY, 3);
			DrawRect.m_Radius = EG_DPX(5);
			DrawRect.Draw(pDiscriptor->m_pContext, &BackRect);

			EGDrawLabel DrawLabel;
			DrawLabel.m_Color = EG_ColorWhite();
			DrawLabel.m_pFont = pFontNormal;
			DrawLabel.Draw(pDiscriptor->m_pContext, &TextRect, buf, NULL);
		}
	}
}

/////////////////////////////////////////////////////////////////////////////

void EG_DemoWidgetsClose(void)
{
	EGAnimate::DeleteAll();
	EGTimer::Delete(pMeter2Timer);
	pMeter2Timer = nullptr;
	EGObject::Clean(EGDisplay::GetActiveScreen(nullptr));
	StyleTextMuted.Reset();
	StyleTitle.Reset();
	StyleIcon.Reset();
	StyleBullet.Reset();
}

