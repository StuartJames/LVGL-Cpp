/*
 *              Copyright (c) 2020-2021 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * This file contains code to implement the core start up code.
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * LoBo  2021/11/08   1.a.1   Original PPPoS example with GSM
 *
 */

#pragma once

#include "LEGLDemo.h"
#include <nvs_flash.h>
#include <nvs.h>

esp_err_t   CheckNVS(void);
esp_err_t   NVSPutInt8(const char *Tag, const uint8_t Var);
esp_err_t   NVSGetInt8(const char *Tag, uint8_t *pVar, uint8_t Default);
esp_err_t   NVSPutShort(const char *Tag, const short Var);
esp_err_t   NVSGetShort(const char *Tag, short *pVar, short Default);
esp_err_t   NVSPutInt(const char *Tag, const int32_t Var);
esp_err_t   NVSGetInt(const char *Tag, int32_t *pVar, int Default);
esp_err_t   NVSPutInt32(const char *Tag, const uint32_t Var);
esp_err_t   NVSGetInt32(const char *Tag, uint32_t *pVar, uint32_t Default);
esp_err_t   NVSPutStr(const char *Tag, const char *pVar);
esp_err_t   NVSGetStr(const char *Tag, char *pVar, size_t Size, const char *pDefault);
esp_err_t   NVSPutArray(const char *Tag, uint8_t *pVar, size_t Count);
esp_err_t   NVSGetArray(const char *Tag, uint8_t *pVar, size_t Count);
