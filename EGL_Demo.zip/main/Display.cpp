/*
 *              Copyright (c) 2020-2021 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original LEGLDemo
 *
 */

#include "LEGLDemo.h"

/////////////////////////////////////////////////////////////////////////////////////

#define APP_DISP_DEFAULT_BRIGHTNESS 20
#define ONE_SECOND_PERIOD_MS				1000

/////////////////////////////////////////////////////////////////////////////////////

static const char *_TAG = "[DISP  ]";

/////////////////////////////////////////////////////////////////////////////////////

static void OneSecondTimer(void)
{
//  QueueSysEvent(SYS_MSG_EV_TIME_UPDATE, NULL);
}

static const esp_timer_create_args_t OneSecondTimerArgs = {
  .callback = (esp_timer_cb_t)&OneSecondTimer,
	.arg = NULL,                     
  .dispatch_method = ESP_TIMER_TASK,
  .name = "One Second Timer",
	.skip_unhandled_events = false
};

/////////////////////////////////////////////////////////////////////////////////////

void DisplayThread(void *arg)
{
esp_timer_handle_t hOneSecondTimer;
DisplayPins_t Pins = {
	.SPI_MOSI = c_LCD_SPI_MOSI_Pin,
	.SPI_MISO = c_LCD_SPI_MISO_Pin,
	.SPI_CLK = c_LCD_SPI_CLK_Pin,
	.SPI_CS = c_LCD_SPI_CS_Pin,
	.LCD_DC = c_LCD_DC_Pin,
	.LCD_RST = c_LCD_RST_Pin,
	.LCD_BCK = c_LCD_BacklightPin,
};

	ESP_ERROR_CHECK(esp_timer_create(&OneSecondTimerArgs, &hOneSecondTimer));
	ESP_ERROR_CHECK(esp_timer_start_periodic(hOneSecondTimer, ONE_SECOND_PERIOD_MS * 1000));  // here time is in micro seconds
	DisplayStart(&Pins);																			// Initialize display and LVGL 
	SetBacklightLevel(APP_DISP_DEFAULT_BRIGHTNESS);	// Set default display brightness 
	DisplayLock(0);
	EG_WidgetsDemo();
	DisplayUnlock();
  xEventGroupSetBits(g_SystemFlags, SYSFLAG_DISPLAY_READY);
	ESP_LOGI(_TAG, "Display thread started.");
//	while(true) vTaskDelay(pdMS_TO_TICKS(1000));
  xEventGroupWaitBits(g_SystemFlags, SYSFLAG_SYSTEM_UP, pdFALSE, pdTRUE, portMAX_DELAY); // wait for system ready
  while(true){
		vTaskDelay(pdMS_TO_TICKS(20));                 // once every 20ms
	}
}

