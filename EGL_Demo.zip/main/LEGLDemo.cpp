/*
 *              Copyright (c) 2020-2021 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original LEGLDemo
 *
 */

/////////////////////////////////////////////////////////////////////////////////////
#define _MAIN_

#define LV_SQUARELINE_MOD__SWIPE 1  //if defined or 1, reverts back to LVGL8.3 swipe-gesture behaviour (LVGL-9.1 abandons swipe too early if it finds/leaves a new object in the swipe-path)

#include "LEGLDemo.h"

extern "C" {
  void app_main(void);
}

/////////////////////////////////////////////////////////////////////////////////////

static const char *_TAG = "[Main  ]";

/////////////////////////////////////////////////////////////////////////////////////

void app_main(void)
{
	ESP_LOGI(_TAG, "***************************");
  ESP_LOGI(_TAG, "*    LEGL Widget Demo     *");
  ESP_LOGI(_TAG, "*  (c) HydraSystems 2025  *");
  ESP_LOGI(_TAG, "* Written by Stuart James *");
  ESP_LOGI(_TAG, "***************************");
  ESP_LOGI(_TAG, "\n\nFree memory: %ld bytes", esp_get_free_heap_size());
  ESP_LOGI(_TAG, "IDF version: %s", esp_get_idf_version());
  esp_log_level_set("gpio", ESP_LOG_NONE);  // Disable default gpio logging messages
  
  if(CheckNVS() == ESP_OK) g_NVSAvailable = true;

	g_SystemFlags = xEventGroupCreate();
  if(g_SystemFlags == NULL){
    ESP_LOGE(_TAG, "Failed to create system flags.");
		while(true) vTaskDelay(pdMS_TO_TICKS(1000));
  }

	g_I2CObj.Initialise(c_I2CSCLPin, c_I2CSDAPin, c_I2CPort);
	g_SDMMCObj.Initialise(c_pMountPoint);
	g_SDMMCObj.GetFlashSize();
	g_PwrKeyObj.Initialise(c_PowerKeyPin, c_PowerControlPin);

	BaseType_t id = xTaskCreatePinnedToCore(DisplayThread, "Display thread", 4096, NULL, 8, NULL, 0);         
  if(id == 0L){
    ESP_LOGE(_TAG, "Failed to create display thread.");
		while(true) vTaskDelay(pdMS_TO_TICKS(1000));
  }
  xEventGroupWaitBits(g_SystemFlags, SYSFLAG_DISPLAY_READY, pdFALSE, pdTRUE, portMAX_DELAY); // wait for display thread to become ready

	xEventGroupSetBits(g_SystemFlags, SYSFLAG_SYSTEM_UP | SYSFLAG_GET_WEATHER);
	ESP_LOGI(_TAG, "System Initialised.");
  ESP_LOGI(_TAG, "Free memory: %ld bytes", esp_get_free_heap_size());
	while(true) {
		vTaskDelay(pdMS_TO_TICKS(1000));	
	}
}
