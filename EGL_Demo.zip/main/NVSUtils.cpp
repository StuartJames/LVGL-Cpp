/*
 *              Copyright (c) 2020-2021 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * This file contains code to implement the core start up code.
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= ===========================================
 * LoBo  2021/11/08   1.a.1   Original PPPoS example with GSM
 *
 */

////////////////////////////////////////////////////////////////////////////////

#include "LEGLDemo.h"

////////////////////////////////////////////////////////////////////////////////

static const char *TAG = "[NVS   ]";

///////////////////////////////////////////////////////////////////////////////////

esp_err_t CheckNVS(void)
{
//    ESP_ERROR_CHECK(nvs_flash_erase());
  esp_err_t Res = nvs_flash_init();
  if(Res == ESP_ERR_NVS_NO_FREE_PAGES || Res == ESP_ERR_NVS_NEW_VERSION_FOUND){   // NVS partition was truncated and needs to be erased Retry nvs_flash_init
    ESP_ERROR_CHECK(nvs_flash_erase());
    Res = nvs_flash_init();
  }
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSPutInt8(const char *Tag, uint8_t Var)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open("storage", NVS_READWRITE, &Handle);
  if(Res != ESP_OK){
    ESP_LOGI(TAG, "Error (%s) opening NVS handle!", esp_err_to_name(Res));
  }
  else{
    ESP_LOGI(TAG, "Writing to NVS ... ");
    Res = nvs_set_u8(Handle, Tag, Var);
    Res = nvs_commit(Handle);
  }
  nvs_close(Handle);
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSGetInt8(const char *Tag, uint8_t *Var, uint8_t Default)
{
nvs_handle_t Handle;
esp_err_t Res;

    Res = nvs_open("storage", NVS_READWRITE, &Handle);
    if(Res != ESP_OK){
      ESP_LOGI(TAG, "Error (%s) opening NVS handle!", esp_err_to_name(Res));
    }
    else{
      Res = nvs_get_u8(Handle, Tag, Var);
      nvs_close(Handle);
      switch(Res){
       case ESP_OK:
         break;
       case ESP_ERR_NVS_NOT_FOUND:
         ESP_LOGI(TAG, "Value not initialised");
         *Var = Default;
         Res = NVSPutInt8(Tag, *Var);
         break;
       default:
         ESP_LOGI(TAG, "Error (%s) reading", esp_err_to_name(Res));
      }
    }
    return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSPutShort(const char *Tag, short Var)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open("storage", NVS_READWRITE, &Handle);
  if(Res != ESP_OK){
    ESP_LOGI(TAG, "Error (%s) opening NVS handle!", esp_err_to_name(Res));
  }
  else{
    ESP_LOGI(TAG, "Writing to NVS ... ");
    Res = nvs_set_i16(Handle, Tag, Var);
    Res = nvs_commit(Handle);
  }
  nvs_close(Handle);
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSGetShort(const char *Tag, short *pVar, short Default)
{
nvs_handle_t Handle;
esp_err_t Res;

    Res = nvs_open("storage", NVS_READWRITE, &Handle);
    if(Res != ESP_OK){
      ESP_LOGI(TAG, "Error (%s) opening NVS handle!", esp_err_to_name(Res));
    }
    else{
      Res = nvs_get_i16(Handle, Tag, pVar);
      nvs_close(Handle);
      switch(Res){
       case ESP_OK:
         break;
       case ESP_ERR_NVS_NOT_FOUND:
         ESP_LOGI(TAG, "Value not initialised");
         *pVar = Default;
         Res = NVSPutShort(Tag, *pVar);
         break;
       default:
         ESP_LOGI(TAG, "Error (%s) reading", esp_err_to_name(Res));
      }
    }
    return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSPutInt(const char *Tag, int32_t Var)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open("storage", NVS_READWRITE, &Handle);
  if(Res != ESP_OK){
    ESP_LOGI(TAG, "Error (%s) opening NVS handle!", esp_err_to_name(Res));
  }
  else{
    ESP_LOGI(TAG, "Writing to NVS ... ");
    Res = nvs_set_i32(Handle, Tag, Var);
    Res = nvs_commit(Handle);
  }
  nvs_close(Handle);
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSGetInt(const char *Tag, int32_t *pVar, int Default)
{
nvs_handle_t Handle;
esp_err_t Res;

    Res = nvs_open("storage", NVS_READWRITE, &Handle);
    if(Res != ESP_OK){
      ESP_LOGI(TAG, "Error (%s) opening NVS handle!", esp_err_to_name(Res));
    }
    else{
      Res = nvs_get_i32(Handle, Tag, pVar);
      nvs_close(Handle);
      switch(Res){
       case ESP_OK:
         break;
       case ESP_ERR_NVS_NOT_FOUND:
         ESP_LOGI(TAG, "Value not initialised");
         *pVar = Default;
         Res = NVSPutInt(Tag, *pVar);
         break;
       default:
         ESP_LOGI(TAG, "Error (%s) reading", esp_err_to_name(Res));
      }
    }
    return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSPutInt32(const char *Tag, uint32_t Var)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open("storage", NVS_READWRITE, &Handle);
  if(Res != ESP_OK){
    ESP_LOGI(TAG, "Error (%s) opening NVS handle!", esp_err_to_name(Res));
  }
  else{
    ESP_LOGI(TAG, "Writing to NVS ... ");
    Res = nvs_set_u32(Handle, Tag, Var);
    Res = nvs_commit(Handle);
  }
  nvs_close(Handle);
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSGetInt32(const char *Tag, uint32_t *pVar, uint32_t Default)
{
nvs_handle_t Handle;
esp_err_t Res;

    Res = nvs_open("storage", NVS_READWRITE, &Handle);
    if(Res != ESP_OK){
      ESP_LOGI(TAG, "Error (%s) opening NVS handle!", esp_err_to_name(Res));
    }
    else{
      Res = nvs_get_u32(Handle, Tag, pVar);
      nvs_close(Handle);
      switch(Res){
       case ESP_OK:
         break;
       case ESP_ERR_NVS_NOT_FOUND:
         ESP_LOGI(TAG, "Value not initialised");
         *pVar = Default;
         Res = NVSPutInt32(Tag, *pVar);
         break;
       default:
         ESP_LOGI(TAG, "Error (%s) reading", esp_err_to_name(Res));
      }
    }
    return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSPutArray(const char *Tag, uint8_t *pVar, size_t Count)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open("storage", NVS_READWRITE, &Handle);
  if(Res != ESP_OK){
    ESP_LOGI(TAG, "Error (%s) opening NVS handle!", esp_err_to_name(Res));
  }
  else{
    ESP_LOGI(TAG, "Writing to NVS ... ");
    Res = nvs_set_blob(Handle, Tag, pVar, Count);
    Res = nvs_commit(Handle);
  }
  nvs_close(Handle);
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSGetArray(const char *Tag, uint8_t *pVar, size_t Count)
{
nvs_handle_t Handle;
esp_err_t Res;

    Res = nvs_open("storage", NVS_READWRITE, &Handle);
    if(Res != ESP_OK){
      ESP_LOGI(TAG, "Error (%s) opening NVS handle!", esp_err_to_name(Res));
    }
    else{
      Res = nvs_get_blob(Handle, Tag, pVar, &Count);
      nvs_close(Handle);
      switch(Res){
       case ESP_OK:
         break;
       case ESP_ERR_NVS_NOT_FOUND:
         ESP_LOGI(TAG, "Value not initialised");
         break;
       default:
         ESP_LOGI(TAG, "Error (%s) reading", esp_err_to_name(Res));
         break;
      }
    }
    return Res;
}

///////////////////////////////////////////////////////////////////////////////////


esp_err_t NVSPutStr(const char *Tag, const char *pVar)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open("storage", NVS_READWRITE, &Handle);
  if(Res != ESP_OK){
    ESP_LOGI(TAG, "Error (%s) opening NVS handle!", esp_err_to_name(Res));
  }
  else{
    ESP_LOGI(TAG, "Writing to NVS ... ");
    Res = nvs_set_str(Handle, Tag, pVar);
    Res = nvs_commit(Handle);
  }
  nvs_close(Handle);
  return Res;
}

///////////////////////////////////////////////////////////////////////////////////

esp_err_t NVSGetStr(const char *Tag, char *pVar, size_t Size, const char *pDefault)
{
nvs_handle_t Handle;
esp_err_t Res;

  Res = nvs_open("storage", NVS_READWRITE, &Handle);
  if(Res != ESP_OK){
    ESP_LOGI(TAG, "Error (%s) opening NVS handle!", esp_err_to_name(Res));
  }
  else{
    size_t Length = 0;
    Res = nvs_get_str(Handle, Tag, NULL, &Length);                                 // get the length of the string in NVS
    if(Length <= Size) Res = nvs_get_str(Handle, Tag, pVar, &Length);              // check for Size
    else{
      ESP_LOGI(TAG, "string Size to big");
      Res = ESP_ERR_NVS_INVALID_LENGTH;
    }
    nvs_close(Handle);
    switch(Res){
     case ESP_OK:
       break;
     case ESP_ERR_NVS_NOT_FOUND:{
       ESP_LOGI(TAG, "Value not initialised");
       strncpy(pVar, pDefault, Size);
       Res = NVSPutStr(Tag, pVar);
       break;
     }
     default:{
       ESP_LOGI(TAG, "Error (%s) reading", esp_err_to_name(Res));
       break;
     }
    }
  }
  return Res;
}


