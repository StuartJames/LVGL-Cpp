/*
 *                LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#include <string.h>
#include "esp_system.h"
#include "esp_log.h"
#include "esp_err.h"
#include "esp_check.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "ESPEGPort.h"
//#include "ESPGLPortPrivate.h"
#include "EGL.h"

static const char *TAG = "[GLPORT]";

#define ESP_LVGL_PORT_TASK_MUX_DELAY_MS 10000

////////////////////////////////////////////////////////////////////////

static void ESPGLPortTask(void *arg)
{
ESPGLPort* pPort = (ESPGLPort*)arg;
uint32_t MaxTaskPeriod = pPort->GetTaskPeriod();
uint32_t TaskDelay = MaxTaskPeriod;

	if(xSemaphoreTake(pPort->GetTaskMux(), 0) != pdTRUE) {	// Take the task semaphore 
		ESP_LOGE(TAG, "Failed to take ESPGL task sem");
		((ESPGLPort*)arg)->TaskDeinitialise();
		vTaskDelete(NULL);
	}
	ESP_LOGI(TAG, "Starting ESPGL task");
	pPort->m_IsRunning = true;
	while(pPort->m_IsRunning) {
		if(pPort->Lock(0)) {
			TaskDelay = EGTimer::TimerHandler();
			pPort->Unlock();
		}
		TaskDelay = (TaskDelay > MaxTaskPeriod) ? MaxTaskPeriod : ((TaskDelay < 5) ? 5 : TaskDelay);
		vTaskDelay(pdMS_TO_TICKS(TaskDelay));
	}
	xSemaphoreGive(pPort->GetTaskMux());	// Give semaphore back 
	vTaskDelete(NULL);	// Close task 
}

////////////////////////////////////////////////////////////////////////

static void TickIncrement(void *arg)
{
	EG_IncrementTick(((ESPGLPort*)arg)->GetTimerPeriod());	// Tell ESPGL how many milliseconds have elapsed 
}

////////////////////////////////////////////////////////////////////////

ESPGLPort::ESPGLPort()
{
  m_TaskMaxSleep = 0; 
  m_TimerPeriod = 0;    
	m_hTask = NULL;
	m_hMux = NULL;
	m_hTaskMux = NULL;
	m_hTickTimer = NULL;
	m_IsRunning = false;
}

////////////////////////////////////////////////////////////////////////

ESPGLPort::~ESPGLPort()
{
}

////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLPort::Initialise(int Priority, int Stack, int Affinity, int SleepPeriod, int TimerPeriod)
{
esp_err_t ret = ESP_OK;
BaseType_t res;

	ESP_GOTO_ON_FALSE(Affinity < (configNUM_CORES), ESP_ERR_INVALID_ARG, err, TAG, "Bad core number for task! Maximum core number is %d", (configNUM_CORES - 1));
	EG_Initialise();
	m_TimerPeriod = TimerPeriod;	// Tick init 
	ESP_RETURN_ON_ERROR(TickInitialise(), TAG, "");
	m_TaskMaxSleep = (SleepPeriod == 0) ? c_TaskMaxSleep : SleepPeriod;	
	m_hMux = xSemaphoreCreateRecursiveMutex();	// ESPGL semaphore 
	ESP_GOTO_ON_FALSE(m_hMux, ESP_ERR_NO_MEM, err, TAG, "Create ESPGL mutex fail!");
	m_hTaskMux = xSemaphoreCreateMutex();	// Task semaphore 
	ESP_GOTO_ON_FALSE(m_hTaskMux, ESP_ERR_NO_MEM, err, TAG, "Create ESPGL task sem fail!");
	if(Affinity < 0) {
		res = xTaskCreate(ESPGLPortTask, "taskESPGL", Stack, this, Priority, &m_hTask);
	}
	else {
		res = xTaskCreatePinnedToCore(ESPGLPortTask, "taskESPGL", Stack, this, Priority, &m_hTask, Affinity);
	}
	ESP_GOTO_ON_FALSE(res == pdPASS, ESP_FAIL, err, TAG, "Create ESPGL task fail!");

err:
	if(ret != ESP_OK) Deinitialise();
	return ret;
}

////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLPort::Resume(void)
{
esp_err_t ret = ESP_ERR_INVALID_STATE;

	if(m_hTickTimer != NULL) {
		EGTimer::EnableAll(true);
		ret = esp_timer_start_periodic(m_hTickTimer, m_TimerPeriod * 1000);
	}
	return ret;
}

////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLPort::Stop(void)
{
esp_err_t ret = ESP_ERR_INVALID_STATE;

	if(m_hTickTimer != NULL) {
		EGTimer::EnableAll(false);
		ret = esp_timer_stop(m_hTickTimer);
	}
	return ret;
}

////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLPort::Deinitialise(void)
{
	if(m_hTickTimer != NULL) {	// Stop and delete timer 
		esp_timer_stop(m_hTickTimer);
		esp_timer_delete(m_hTickTimer);
		m_hTickTimer = NULL;
	}
	if(m_IsRunning) m_IsRunning = false;	// Stop running task 
	if(xSemaphoreTake(m_hTaskMux, pdMS_TO_TICKS(ESP_LVGL_PORT_TASK_MUX_DELAY_MS)) != pdTRUE) {	// Wait for stop task 
		ESP_LOGE(TAG, "Failed to stop ESPGL task");
		return ESP_ERR_TIMEOUT;
	}
	ESP_LOGI(TAG, "Stopped ESPGL task");
	TaskDeinitialise();
	return ESP_OK;
}

////////////////////////////////////////////////////////////////////////

bool ESPGLPort::Lock(uint32_t timeout_ms)
{
	assert(m_hMux && "Initialise must be called first");
	const TickType_t timeout_ticks = (timeout_ms == 0) ? portMAX_DELAY : pdMS_TO_TICKS(timeout_ms);
	return xSemaphoreTakeRecursive(m_hMux, timeout_ticks) == pdTRUE;
}

////////////////////////////////////////////////////////////////////////

void ESPGLPort::Unlock(void)
{
	assert(m_hMux && "Initialise must be called first");
	xSemaphoreGiveRecursive(m_hMux);
}

////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLPort::Wake(lvgl_port_event_type_t event, void *param)
{
	ESP_LOGE(TAG, "Task wake is not supported!");
	return ESP_ERR_NOT_SUPPORTED;
}

////////////////////////////////////////////////////////////////////////

/*IRAM_ATTR bool ESPGLPort::OnNotify(uint32_t value)
{
BaseType_t need_yield = pdFALSE;

	if(xPortInIsrContext() == pdTRUE) {	// Notify ESPGL task
		xTaskNotifyFromISR(lvgl_port_ctx.lvgl_task, value, eNoAction, &need_yield);
	}
	else {
		xTaskNotify(lvgl_port_ctx.lvgl_task, value, eNoAction);
	}
	return (need_yield == pdTRUE);
}*/

////////////////////////////////////////////////////////////////////////

void ESPGLPort::TaskDeinitialise(void)
{
	if(m_hMux) {
		vSemaphoreDelete(m_hMux);
	}
	if(m_hTaskMux) {
		vSemaphoreDelete(m_hTaskMux);
	}
  m_TaskMaxSleep = 0; 
  m_TimerPeriod = 0;    
	m_hTask = NULL;
	m_hMux = NULL;
	m_hTaskMux = NULL;
	m_hTickTimer = NULL;
	m_IsRunning = false;
#if EG_ENABLE_GC || !EG_MEM_CUSTOM
	EG_Deinitialise();	// Deinitialize ESPGL 
#endif
}

////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLPort::TickInitialise(void)	// Tick interface for ESPGL (using esp_timer to generate 2ms periodic event)
{
const esp_timer_create_args_t lvgl_tick_timer_args = {
	.callback = &TickIncrement,
	.arg = this,
	.dispatch_method = ESP_TIMER_TASK,
	.name = "ESPGL tick",
	.skip_unhandled_events = false,
};

	ESP_RETURN_ON_ERROR(esp_timer_create(&lvgl_tick_timer_args, &m_hTickTimer), TAG, "Creating ESPGL timer failed!");
	return esp_timer_start_periodic(m_hTickTimer, m_TimerPeriod * 1000);
}
