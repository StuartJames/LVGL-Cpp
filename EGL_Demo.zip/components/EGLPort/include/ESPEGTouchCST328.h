/*
 *                LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#pragma once

#include "ESPEGTouchController.h"
#include <driver/i2c.h>

/////////////////////////////////////////////////////////////////////////////////////

#define ESP_LCD_TOUCH_IO_I2C_CST328_ADDRESS 		0x1A
//workmode
#define CST328_REG_DEBUG_INFO_MODE 							0xD101
#define CST328_REG_RESET_MODE 									0xD102
#define CST328_REG_DEBUG_RECALIBRATION_MODE 		0xD104
#define CST328_REG_DEEP_SLEEP_MODE 							0xD105
#define CST328_REG_DEBUG_POINT_MODE 						0xD108
#define CST328_REG_NORMAL_MODE 									0xD109

#define CST328_REG_DEBUG_RAWDATA_MODE 					0xD10A
#define CST328_REG_DEBUG_DIFF_MODE 							0xD10D
#define CST328_REG_DEBUG_FACTORY_MODE 					0xD119
#define CST328_REG_DEBUG_FACTORY_MODE_2 				0xD120

/**************** CST328_REG_DEBUG_INFO_MODE address start ***********/
#define CST328_REG_DEBUG_INFO_BOOT_TIME 				0xD1FC
#define CST328_REG_DEBUG_INFO_RES_Y 						0xD1FA
#define CST328_REG_DEBUG_INFO_RES_X 						0xD1F8
#define CST328_REG_DEBUG_INFO_KEY_NUM 					0xD1F7
#define CST328_REG_DEBUG_INFO_TP_NRX 						0xD1F6
#define CST328_REG_DEBUG_INFO_TP_NTX 						0xD1F4

/* CST328 registers */
#define ESP_LCD_TOUCH_CST328_READ_Number_REG 		0xD005
#define ESP_LCD_TOUCH_CST328_READ_XY_REG 				0xD000
#define ESP_LCD_TOUCH_CST328_READ_Checksum_REG 	0x80FF
#define ESP_LCD_TOUCH_CST328_CONFIG_REG 				0x8047

#define I2C_MASTER_FREQ_HZ 									    400000  						// I2C master clock frequency 
#define I2C_MASTER_TX_BUF_DISABLE 					    0 									// I2C master doesn't need buffer 
#define I2C_MASTER_RX_BUF_DISABLE 					    0 									// I2C master doesn't need buffer 
#define I2C_MASTER_TIMEOUT_MS 							    1000

#define LCD_TOUCH_V_RES											    320
#define LCD_TOUCH_H_RES											    240

#define ESP_LCD_TOUCH_IO_I2C_CST328_CONFIG()         \
	{                                                  \
		.dev_addr = ESP_LCD_TOUCH_IO_I2C_CST328_ADDRESS, \
		.on_color_trans_done = NULL,									 \
		.user_ctx = NULL,														 \
		.control_phase_bytes = 1,                        \
		.dc_bit_offset = 0,                              \
		.lcd_cmd_bits = 16,                              \
		.lcd_param_bits = 16,														 \
		.flags = {                                       \
			.dc_low_on_data = 0,													 \
			.disable_control_phase = 1,                    \
		},                                               \
		.scl_speed_hz = 0,															 \
	}

/////////////////////////////////////////////////////////////////////////////////////

// I2C settings
const gpio_num_t I2CTouchSclIO_c	 					= GPIO_NUM_3;       // GPIO number used for I2C master clock 
const gpio_num_t I2CTouchSdaIO_c	 					= GPIO_NUM_1;       // GPIO number used for I2C master data  
const gpio_num_t I2CTouchIntIO_c						= GPIO_NUM_NC;      //4 GPIO number used for Interrupt  
const gpio_num_t I2CTouchResetIO_c					= GPIO_NUM_2;       // GPIO number used for Reset 
const i2c_port_t I2CTouchMaster_c 					=	I2C_NUM_1;      	// I2C master i2c port number, the number of i2c peripheral interfaces available will depend on the chip 

/////////////////////////////////////////////////////////////////////////////////////

class ESPGLTouchCST328 : public ESPGLTouchController
{
public:
                            ESPGLTouchCST328(void);
  virtual                   ~ESPGLTouchCST328(void);

  void                      Initialise(void);
  esp_err_t                 Configure(const esp_lcd_panel_io_handle_t hIO, const ESPGL_LCDTouchConfig_t *pConfig);
  esp_err_t                 I2CInit(void);
  esp_err_t                 ReadData(void);
  bool                      GetCoordinates(uint16_t *x, uint16_t *y, uint16_t *strength, uint8_t *point_num, uint8_t max_point_num);
  #if (CONFIG_ESP_LCD_TOUCH_MAX_BUTTONS > 0)
  esp_err_t                 GetButtonState(uint8_t n, uint8_t *state);
  #endif

  // CST328 specific
  esp_err_t                 Reset(void);
  void                      ReadConfig(void);
  esp_err_t                 i2cRead(uint16_t Register, uint8_t *pData, uint8_t Length);
  esp_err_t                 i2cWrite(uint16_t Register, uint8_t *pData, uint8_t Length);

private:
};


