/*
 *              LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#pragma once

#include "driver/gpio.h"
#include "esp_adc/adc_oneshot.h"
#include "Button.h"

/////////////////////////////////////////////////////////////////////////////////////

#define DEFAULT_VREF 1100
#define NO_OF_SAMPLES CONFIG_ADC_BUTTON_SAMPLE_TIMES  //Multisampling

/*!< Using atten bigger than 6db by default, it will be 11db or 12db in different target */
#define DEFAULT_ADC_ATTEN (adc_atten_t)(ADC_ATTEN_DB_6 + 1)

#define ADC_BUTTON_WIDTH SOC_ADC_RTC_MAX_BITWIDTH
#define ADC_BUTTON_CHANNEL_MAX SOC_ADC_MAX_CHANNEL_NUM
#define ADC_BUTTON_ATTEN DEFAULT_ADC_ATTEN

#define ADC_BUTTON_MAX_CHANNEL CONFIG_ADC_BUTTON_MAX_CHANNEL
#define ADC_BUTTON_MAX_BUTTON CONFIG_ADC_BUTTON_MAX_BUTTON_PER_CHANNEL

// ESP32C3 ADC2 it has been deprecated.
#if(SOC_ADC_PERIPH_NUM >= 2) && !CONFIG_IDF_TARGET_ESP32C3
#define ADC_UNIT_NUM 2
#else
#define ADC_UNIT_NUM 1
#endif

/////////////////////////////////////////////////////////////////////////////////////

class AnalogueButton;

/////////////////////////////////////////////////////////////////////////////////////

typedef enum {
	ADC_NONE_INIT = 0,
	ADC_INIT_BY_ADC_BUTTON,
	ADC_INIT_BY_USER,
} ADCInitialiseInfo_e;

typedef struct {
    adc_oneshot_unit_handle_t *hADC;    // handle of adc unit, if NULL will create new one internal, else will use the handle 
    adc_unit_t      UnitID;             // ADC unit 
    adc_channel_t   ADCChannel;         // Channel of ADC 
    uint8_t         ButtonIndex;        // button index on the channel 
    uint16_t        MinVoltage;         // min voltage in mv corresponding to the button 
    uint16_t        MaxVoltage;         // max voltage in mv corresponding to the button 
} ButtonADCConfig_t;

typedef struct {
	uint16_t      MinVoltage;
	uint16_t      MaxVoltage;
} ButtonData_t;

typedef struct {
	uint8_t       Channel;
	uint8_t       IsInitialised;
	ButtonData_t  Buttons[ADC_BUTTON_MAX_BUTTON]; /* all button on the channel */
	uint64_t      UpdateTime;                        /* the last time of adc sample */
} ButtonChannel_t;

typedef struct {
	ADCInitialiseInfo_e IsConfigured;
	adc_cali_handle_t hCalibration;
	adc_oneshot_unit_handle_t hADC;
	ButtonChannel_t Channel[ADC_BUTTON_MAX_CHANNEL];
	uint8_t         ChannelCount;
} ADCModule_t;

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t NewAnalogueButton(const ButtonConfig_t *pConfig, const ButtonADCConfig_t *pADCConfig, AnalogueButton *pButton);
esp_err_t DeleteAnalogueButton(AnalogueButton *pButton);

/////////////////////////////////////////////////////////////////////////////////////

class AnalogueButton : public ESPButton
{
public:
                      AnalogueButton(void);
  virtual             ~AnalogueButton();
  esp_err_t           Create(const ButtonConfig_t *pConfig, const ButtonADCConfig_t *pADCConfig);
  uint8_t             GetKeyLevel(void);

	adc_unit_t          m_Module;
	adc_channel_t       m_ADCChannel;
	uint32_t            m_ButtonIndex;

private:

  int         FindUnusedChannel(adc_unit_t unit_id);
  int         FindChannel(adc_unit_t unit_id, uint8_t channel);
  bool        InitialiseCalibration(adc_channel_t Channel, adc_cali_handle_t *pHandle);
  bool        DeintialiseCalibration(adc_cali_handle_t hCalibration);
  uint32_t    GetVoltage(adc_unit_t UnitID, adc_channel_t Channel);

  static ADCModule_t    m_ADCModules[ADC_UNIT_NUM];   // array of channels & buttons in use

};

/////////////////////////////////////////////////////////////////////////////////////

inline int AnalogueButton::FindUnusedChannel(adc_unit_t UnitID)
{
	for(size_t i = 0; i < ADC_BUTTON_MAX_CHANNEL; i++) if(m_ADCModules[UnitID].Channel[i].IsInitialised == 0) return i;
	return -1;
}

/////////////////////////////////////////////////////////////////////////////////////

inline int AnalogueButton::FindChannel(adc_unit_t UnitID, uint8_t Channel)
{
	for(size_t i = 0; i < ADC_BUTTON_MAX_CHANNEL; i++) if(m_ADCModules[UnitID].Channel[i].Channel == Channel) return i;
	return -1;
}



