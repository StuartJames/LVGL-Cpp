/*
 *              LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#include "Button.h"

/////////////////////////////////////////////////////////////////////////////////////

static const char *_TAG = "[Button]";
static portMUX_TYPE s_button_lock = portMUX_INITIALIZER_UNLOCKED;
#define BUTTON_ENTER_CRITICAL() portENTER_CRITICAL(&s_button_lock)
#define BUTTON_EXIT_CRITICAL() portEXIT_CRITICAL(&s_button_lock)

/////////////////////////////////////////////////////////////////////////////////////

static const char *button_event_str[] = {
	"BUTTON_PRESS_DOWN",
	"BUTTON_PRESS_UP",
	"BUTTON_PRESS_REPEAT",
	"BUTTON_PRESS_REPEAT_DONE",
	"BUTTON_SINGLE_CLICK",
	"BUTTON_DOUBLE_CLICK",
	"BUTTON_MULTIPLE_CLICK",
	"BUTTON_LONG_PRESS_START",
	"BUTTON_LONG_PRESS_HOLD",
	"BUTTON_LONG_PRESS_UP",
	"BUTTON_PRESS_END",
	"BUTTON_EVENT_MAX",
	"BUTTON_NONE_PRESS",
};

/////////////////////////////////////////////////////////////////////////////////////

ESPButton                  *ESPButton::m_pListHead = NULL;     //button handle list head.
esp_timer_handle_t          ESPButton::m_hTimer = NULL;
bool                        ESPButton::m_TimeIsRunning = false;

static ButtonPowerSaveConfig_t    PowerSaveUserCfg_s = {};

#define TICKS_INTERVAL            CONFIG_BUTTON_PERIOD_TIME_MS
#define DEBOUNCE_TICKS            CONFIG_BUTTON_DEBOUNCE_TICKS  //MAX 8
#define SHORT_TICKS               CONFIG_BUTTON_SHORT_PRESS_TIME_MS / TICKS_INTERVAL
#define LONG_TICKS                CONFIG_BUTTON_LONG_PRESS_TIME_MS / TICKS_INTERVAL
#define SERIAL_TICKS              CONFIG_BUTTON_LONG_PRESS_HOLD_SERIAL_TIME_MS / TICKS_INTERVAL
#define TOLERANCE                 CONFIG_BUTTON_PERIOD_TIME_MS * 4

#define TIME_TO_TICKS(time, congfig_time) (0 == (time)) ? congfig_time : (((time) / TICKS_INTERVAL)) ? ((time) / TICKS_INTERVAL) : 1

/////////////////////////////////////////////////////////////////////////////////////

static void ButtonCB(void *pArgs)
{
ESPButton *pButton;

	bool enter_power_save_flag = true;	// When all buttons enter the BUTTON_NONE_PRESS state, the system enters low-power mode
	for(pButton = ESPButton::m_pListHead; pButton; pButton = pButton->m_pNext) {
		pButton->EventHandler();
		if(!(pButton->m_PowerSave && pButton->m_DebounceCount == 0 && pButton->m_Event == BUTTON_NONE_PRESS)) {
			enter_power_save_flag = false;
		}
	}
	if(enter_power_save_flag) {
		if(ESPButton::m_TimeIsRunning) {		// Stop esp timer for power save 
			esp_timer_stop(ESPButton::m_hTimer);
			ESPButton::m_TimeIsRunning = false;
		}
		for(pButton = ESPButton::m_pListHead; pButton; pButton = pButton->m_pNext) {
			if(pButton->m_PowerSave && pButton->PowerSaveFunc) {
				pButton->PowerSaveFunc(pButton);
			}
		}
		if(PowerSaveUserCfg_s.EnterPowerSaveCB) {// Notify the user that the Button has entered power save mode by calling this callback function. 
			PowerSaveUserCfg_s.EnterPowerSaveCB(PowerSaveUserCfg_s.pUserData);
		}
	}
}

/////////////////////////////////////////////////////////////////////////////////////

size_t ButtonCountCB(ESPButton *pButton)
{
	BTN_CHECK(NULL != pButton, "Pointer of handle is invalid", ESP_ERR_INVALID_ARG);
	size_t ret = 0;
	for(size_t i = 0; i < BUTTON_EVENT_MAX; i++) {
		if(pButton->m_CallbackInfo[i]) {
			ret += pButton->m_EventSize[i];
		}
	}
	return ret;
}

/////////////////////////////////////////////////////////////////////////////////////

size_t ButtonCountEventCB(ESPButton *pButton, ButtonEvent_e Event)
{
	BTN_CHECK(NULL != pButton, "Pointer of handle is invalid", ESP_ERR_INVALID_ARG);
	return pButton->m_EventSize[Event];
}

/////////////////////////////////////////////////////////////////////////////////////

ESPButton::ESPButton(void)
{
}

/////////////////////////////////////////////////////////////////////////////////////

ESPButton::~ESPButton()
{
	for(int i = 0; i < BUTTON_EVENT_MAX; i++) {
		if(m_CallbackInfo[i]) {
			free(m_CallbackInfo[i]);
		}
	}
}

/////////////////////////////////////////////////////////////////////////////////////

ButtonEvent_e ESPButton::GetEvent(void)
{
	return m_Event;
}

/////////////////////////////////////////////////////////////////////////////////////

const char* ESPButton::GetEventString(ButtonEvent_e Event)
{
	BTN_CHECK(Event <= BUTTON_NONE_PRESS && Event >= BUTTON_PRESS_DOWN, "event value is invalid", "invalid event");
	return button_event_str[Event];
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPButton::PrintEvent(void)
{
	ESP_LOGI(_TAG, "%s", GetEventString(m_Event));
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t ESPButton::GetRepeat(void)
{
	return m_Repeat;
}

/////////////////////////////////////////////////////////////////////////////////////

uint32_t ESPButton::GetTicksTime(void)
{
	return (m_Ticks * TICKS_INTERVAL);
}

/////////////////////////////////////////////////////////////////////////////////////

uint16_t ESPButton::GetLongPressHoldCount(void)
{
	return m_LongPressHoldCount;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPButton::SetItemeters(ButtonParam_e Param, void *pValue)
{
	BUTTON_ENTER_CRITICAL();
	switch(Param) {
		case BUTTON_LONG_PRESS_TIME_MS:
			m_LongPressTicks = (int32_t)pValue / TICKS_INTERVAL;
			break;
		case BUTTON_SHORT_PRESS_TIME_MS:
			m_ShortPressTicks = (int32_t)pValue / TICKS_INTERVAL;
			break;
		default:
			break;
	}
	BUTTON_EXIT_CRITICAL();
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t ESPButton::GetKeyLevel(void)
{
  return 0;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPButton::Resume(void)
{
	if(!m_hTimer) {
		return ESP_ERR_INVALID_STATE;
	}
	if(!m_TimeIsRunning) {
		esp_timer_start_periodic(m_hTimer, TICKS_INTERVAL * 1000U);
		m_TimeIsRunning = true;
	}
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPButton::Stop(void)
{
	BTN_CHECK(m_hTimer, "Button timer handle is invalid", ESP_ERR_INVALID_STATE);
	BTN_CHECK(m_TimeIsRunning, "Button timer is not running", ESP_ERR_INVALID_STATE);
	esp_err_t err = esp_timer_stop(m_hTimer);
	BTN_CHECK(ESP_OK == err, "Button timer stop failed", ESP_FAIL);
	m_TimeIsRunning = false;
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPButton::RegisterPowerSaveCB(const ButtonPowerSaveConfig_t *pConfig)
{
	BTN_CHECK(m_pListHead, "No button registered", ESP_ERR_INVALID_STATE);
	BTN_CHECK(pConfig->EnterPowerSaveCB, "Enter power save callback is invalid", ESP_ERR_INVALID_ARG);
	PowerSaveUserCfg_s.EnterPowerSaveCB = pConfig->EnterPowerSaveCB;
	PowerSaveUserCfg_s.pUserData = pConfig->pUserData;
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPButton::Create(const ButtonConfig_t *pConfig)
{
	m_LongPressTicks = TIME_TO_TICKS(pConfig->LongPressTime, LONG_TICKS);
	m_ShortPressTicks = TIME_TO_TICKS(pConfig->ShortPressTime, SHORT_TICKS);
	m_Event = BUTTON_NONE_PRESS;
	m_Level = BUTTON_INACTIVE;
	m_pNext = m_pListHead;
	m_pListHead = this;
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPButton::RegisterCB(ButtonEvent_e Event, ButtonEventArgs_t *pEventArgs, ButtonCB_t Callback, void *pUsrData)
{
	ESP_RETURN_ON_FALSE(Event < BUTTON_EVENT_MAX, ESP_ERR_INVALID_ARG, _TAG, "event is invalid");
	ESP_RETURN_ON_FALSE(NULL != Callback, ESP_ERR_INVALID_ARG, _TAG, "Pointer of cb is invalid");
	ESP_RETURN_ON_FALSE(Event != BUTTON_MULTIPLE_CLICK || pEventArgs, ESP_ERR_INVALID_ARG, _TAG, "event is invalid");
	if(pEventArgs) {
		ESP_RETURN_ON_FALSE(!(Event == BUTTON_LONG_PRESS_START || Event == BUTTON_LONG_PRESS_UP) || pEventArgs->LongPress.PressTime > m_ShortPressTicks * TICKS_INTERVAL, ESP_ERR_INVALID_ARG, _TAG, "event_args is invalid");
		ESP_RETURN_ON_FALSE(Event != BUTTON_MULTIPLE_CLICK || pEventArgs->MultipleClicks.Clicks, ESP_ERR_INVALID_ARG, _TAG, "event_args is invalid");
	}
	if(!m_CallbackInfo[Event]) {
		m_CallbackInfo[Event] = (ButtonCBInfo_t *)calloc(1, sizeof(ButtonCBInfo_t));
		BTN_CHECK(NULL != m_CallbackInfo[Event], "calloc cb_info failed", ESP_ERR_NO_MEM);
		if(Event == BUTTON_LONG_PRESS_START) {
			m_Count[0] = 0;
		}
		else if(Event == BUTTON_LONG_PRESS_UP) {
			m_Count[1] = -1;
		}
	}
	else {
		ButtonCBInfo_t *p = (ButtonCBInfo_t *)realloc(m_CallbackInfo[Event], sizeof(ButtonCBInfo_t) * (m_EventSize[Event] + 1));
		BTN_CHECK(NULL != p, "realloc cb_info failed", ESP_ERR_NO_MEM);
		m_CallbackInfo[Event] = p;
	}
	m_CallbackInfo[Event][m_EventSize[Event]].Callback = Callback;
	m_CallbackInfo[Event][m_EventSize[Event]].pUserData = pUsrData;
	m_EventSize[Event]++;
	// Inserting the event_args in sorted manner */
	if(Event == BUTTON_LONG_PRESS_START || Event == BUTTON_LONG_PRESS_UP) {
		uint16_t PressTime = m_LongPressTicks * TICKS_INTERVAL;
		if(pEventArgs) {
			PressTime = pEventArgs->LongPress.PressTime;
		}
		BTN_CHECK(PressTime / TICKS_INTERVAL > m_ShortPressTicks, "PressTime event_args is less than short_press_ticks", ESP_ERR_INVALID_ARG);
		if(m_EventSize[Event] >= 2) {
			for(int i = m_EventSize[Event] - 2; i >= 0; i--) {
				if(m_CallbackInfo[Event][i].EventArgs.LongPress.PressTime > PressTime) {
					m_CallbackInfo[Event][i + 1] = m_CallbackInfo[Event][i];

					m_CallbackInfo[Event][i].EventArgs.LongPress.PressTime = PressTime;
					m_CallbackInfo[Event][i].Callback = Callback;
					m_CallbackInfo[Event][i].pUserData = pUsrData;
				}
				else {
					m_CallbackInfo[Event][i + 1].EventArgs.LongPress.PressTime = PressTime;
					m_CallbackInfo[Event][i + 1].Callback = Callback;
					m_CallbackInfo[Event][i + 1].pUserData = pUsrData;
					break;
				}
			}
		}
		else {
			m_CallbackInfo[Event][m_EventSize[Event] - 1].EventArgs.LongPress.PressTime = PressTime;
		}
		int32_t press_ticks = PressTime / TICKS_INTERVAL;
		if(m_ShortPressTicks < press_ticks && press_ticks < m_LongPressTicks) {
			SetItemeters(BUTTON_LONG_PRESS_TIME_MS, (void *)(intptr_t)PressTime);
		}
	}
	if(Event == BUTTON_MULTIPLE_CLICK) {
		uint16_t clicks = m_LongPressTicks * TICKS_INTERVAL;
		if(pEventArgs) {
			clicks = pEventArgs->MultipleClicks.Clicks;
		}
		if(m_EventSize[Event] >= 2) {
			for(int i = m_EventSize[Event] - 2; i >= 0; i--) {
				if(m_CallbackInfo[Event][i].EventArgs.MultipleClicks.Clicks > clicks) {
					m_CallbackInfo[Event][i + 1] = m_CallbackInfo[Event][i];

					m_CallbackInfo[Event][i].EventArgs.MultipleClicks.Clicks = clicks;
					m_CallbackInfo[Event][i].Callback = Callback;
					m_CallbackInfo[Event][i].pUserData = pUsrData;
				}
				else {
					m_CallbackInfo[Event][i + 1].EventArgs.MultipleClicks.Clicks = clicks;
					m_CallbackInfo[Event][i + 1].Callback = Callback;
					m_CallbackInfo[Event][i + 1].pUserData = pUsrData;
					break;
				}
			}
		}
		else {
			m_CallbackInfo[Event][m_EventSize[Event] - 1].EventArgs.MultipleClicks.Clicks = clicks;
		}
	}
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPButton::UnregisterCB(ButtonEvent_e Event, ButtonEventArgs_t *pEventArgs)
{
	ESP_RETURN_ON_FALSE(Event < BUTTON_EVENT_MAX, ESP_ERR_INVALID_ARG, _TAG, "event is invalid");
	ESP_RETURN_ON_FALSE(m_CallbackInfo[Event], ESP_ERR_INVALID_STATE, _TAG, "No callbacks registered for the event");
	int check = -1;
	if((Event == BUTTON_LONG_PRESS_START || Event == BUTTON_LONG_PRESS_UP) && pEventArgs) {
		if(pEventArgs->LongPress.PressTime != 0) {
			goto unregister_event;
		}
	}
	if(Event == BUTTON_MULTIPLE_CLICK && pEventArgs) {
		if(pEventArgs->MultipleClicks.Clicks != 0) {
			goto unregister_event;
		}
	}
	if(m_CallbackInfo[Event]) {
		free(m_CallbackInfo[Event]);

		// Reset the counter */
		if(Event == BUTTON_LONG_PRESS_START) {
			m_Count[0] = 0;
		}
		else if(Event == BUTTON_LONG_PRESS_UP) {
			m_Count[1] = -1;
		}
	}
	m_CallbackInfo[Event] = NULL;
	m_EventSize[Event] = 0;
	return ESP_OK;

unregister_event:
	for(int i = 0; i < m_EventSize[Event]; i++) {
		if((Event == BUTTON_LONG_PRESS_START || Event == BUTTON_LONG_PRESS_UP) && pEventArgs->LongPress.PressTime) {
			if(pEventArgs->LongPress.PressTime != m_CallbackInfo[Event][i].EventArgs.LongPress.PressTime) {
				continue;
			}
		}
		if(Event == BUTTON_MULTIPLE_CLICK && pEventArgs->MultipleClicks.Clicks) {
			if(pEventArgs->MultipleClicks.Clicks != m_CallbackInfo[Event][i].EventArgs.MultipleClicks.Clicks) {
				continue;
			}
		}
		check = i;
		for(int j = i; j <= m_EventSize[Event] - 1; j++) {
			m_CallbackInfo[Event][j] = m_CallbackInfo[Event][j + 1];
		}
		if(m_EventSize[Event] != 1) {
			ButtonCBInfo_t *p = (ButtonCBInfo_t *)realloc(m_CallbackInfo[Event], sizeof(ButtonCBInfo_t) * (m_EventSize[Event] - 1));
			BTN_CHECK(NULL != p, "realloc cb_info failed", ESP_ERR_NO_MEM);
			m_CallbackInfo[Event] = p;
			m_EventSize[Event]--;
		}
		else {
			free(m_CallbackInfo[Event]);
			m_CallbackInfo[Event] = NULL;
			m_EventSize[Event] = 0;
		}
		break;
	}
	ESP_RETURN_ON_FALSE(check != -1, ESP_ERR_NOT_FOUND, _TAG, "No such callback registered for the event");
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

void ESPButton::EventHandler(void)
{
uint8_t ReadLevel = GetKeyLevel();

	if((m_State) > PRESS_DOWN_CHECK) {	// ticks counter working.. 
		m_Ticks++;
	}
	if(ReadLevel != m_Level) {	// button debounce handle
		if(++(m_DebounceCount) >= DEBOUNCE_TICKS) {
			m_Level = ReadLevel;
			m_DebounceCount = 0;
		}
	}
	else m_DebounceCount = 0;
	switch(m_State) {	// State machine
		case PRESS_DOWN_CHECK:{
			if(m_Level == BUTTON_ACTIVE) {
				m_Event = BUTTON_PRESS_DOWN;
				CallEventFunctio(BUTTON_PRESS_DOWN);
				m_Ticks = 0;
				m_Repeat = 1;
				m_State = PRESS_UP_CHECK;
			}
			else {
				m_Event = BUTTON_NONE_PRESS;
			}
			break;
    }
		case PRESS_UP_CHECK:{
			if(m_Level != BUTTON_ACTIVE) {
				m_Event = BUTTON_PRESS_UP;
				CallEventFunctio(BUTTON_PRESS_UP);
				m_Ticks = 0;
				m_State = PRESS_REPEAT_DOWN_CHECK;
			}
			else if(m_Ticks >= m_LongPressTicks) {
				m_Event = BUTTON_LONG_PRESS_START;
				m_State = PRESS_LONG_PRESS_UP_CHECK;
				// Calling callbacks for BUTTON_LONG_PRESS_START 
				uint32_t ticks_time = GetTicksTime();
				int32_t diff = ticks_time - m_LongPressTicks * TICKS_INTERVAL;
				if(m_CallbackInfo[m_Event] && m_Count[0] == 0) {
					if(abs(diff) <= TOLERANCE && m_CallbackInfo[m_Event][m_Count[0]].EventArgs.LongPress.PressTime == (m_LongPressTicks * TICKS_INTERVAL)) {
						do {
							m_CallbackInfo[m_Event][m_Count[0]].Callback(this, m_CallbackInfo[m_Event][m_Count[0]].pUserData);
							m_Count[0]++;
							if(m_Count[0] >= m_EventSize[m_Event]) {
								break;
							}
						} while(m_CallbackInfo[m_Event][m_Count[0]].EventArgs.LongPress.PressTime == m_LongPressTicks * TICKS_INTERVAL);
					}
				}
			}
			break;
    }
		case PRESS_REPEAT_DOWN_CHECK:{
			if(m_Level == BUTTON_ACTIVE) {
				m_Event = BUTTON_PRESS_DOWN;
				CallEventFunctio(BUTTON_PRESS_DOWN);
				m_Event = BUTTON_PRESS_REPEAT;
				m_Repeat++;
				CallEventFunctio(BUTTON_PRESS_REPEAT);  // repeat hit
				m_Ticks = 0;
				m_State = PRESS_REPEAT_UP_CHECK;
			}
			else if(m_Ticks > m_ShortPressTicks) {
				if(m_Repeat == 1) {
					m_Event = BUTTON_SINGLE_CLICK;
					CallEventFunctio(BUTTON_SINGLE_CLICK);
				}
				else if(m_Repeat == 2) {
					m_Event = BUTTON_DOUBLE_CLICK;
					CallEventFunctio(BUTTON_DOUBLE_CLICK);  // repeat hit
				}
				m_Event = BUTTON_MULTIPLE_CLICK;
				for(int i = 0; i < m_EventSize[m_Event]; i++) {				// Calling the callbacks for MULTIPLE BUTTON CLICKS 
					if(m_Repeat == m_CallbackInfo[m_Event][i].EventArgs.MultipleClicks.Clicks) {
						m_CallbackInfo[m_Event][i].Callback(this, m_CallbackInfo[m_Event][i].pUserData);
					}
				}
				m_Event = BUTTON_PRESS_REPEAT_DONE;
				CallEventFunctio(BUTTON_PRESS_REPEAT_DONE);  // repeat hit
				m_Repeat = 0;
				m_State = 0;
				m_Event = BUTTON_PRESS_END;
				CallEventFunctio(BUTTON_PRESS_END);
			}
			break;
    }
		case PRESS_REPEAT_UP_CHECK:{
			if(m_Level != BUTTON_ACTIVE) {
				m_Event = BUTTON_PRESS_UP;
				CallEventFunctio(BUTTON_PRESS_UP);
				if(m_Ticks < m_ShortPressTicks) {
					m_Ticks = 0;
					m_State = PRESS_REPEAT_DOWN_CHECK;  //repeat press
				}
				else {
					m_State = PRESS_DOWN_CHECK;
					m_Event = BUTTON_PRESS_END;
					CallEventFunctio(BUTTON_PRESS_END);
				}
			}
			break;
    }
		case PRESS_LONG_PRESS_UP_CHECK:{
			if(m_Level == BUTTON_ACTIVE) {
				if(m_Ticks >= (m_LongPressHoldCount + 1) * SERIAL_TICKS + m_LongPressTicks) {				//continue hold trigger
					m_Event = BUTTON_LONG_PRESS_HOLD;
					m_LongPressHoldCount++;
					CallEventFunctio(BUTTON_LONG_PRESS_HOLD);
				}
				uint32_t ticks_time = GetTicksTime();				// Calling callbacks for BUTTON_LONG_PRESS_START based on PressTime 
				if(m_CallbackInfo[BUTTON_LONG_PRESS_START]) {
					ButtonCBInfo_t *pCBInfo = m_CallbackInfo[BUTTON_LONG_PRESS_START];
					uint16_t time = pCBInfo[m_Count[0]].EventArgs.LongPress.PressTime;
					if(m_LongPressTicks * TICKS_INTERVAL > time) {
						for(int i = m_Count[0] + 1; i < m_EventSize[BUTTON_LONG_PRESS_START]; i++) {
							time = pCBInfo[i].EventArgs.LongPress.PressTime;
							if(m_LongPressTicks * TICKS_INTERVAL <= time) {
								m_Count[0] = i;
								break;
							}
						}
					}
					if(m_Count[0] < m_EventSize[BUTTON_LONG_PRESS_START] && abs((int)ticks_time - (int)time) <= TOLERANCE) {
						m_Event = BUTTON_LONG_PRESS_START;
						do {
							pCBInfo[m_Count[0]].Callback(this, pCBInfo[m_Count[0]].pUserData);
							m_Count[0]++;
							if(m_Count[0] >= m_EventSize[BUTTON_LONG_PRESS_START]) break;
						}
            while(time == pCBInfo[m_Count[0]].EventArgs.LongPress.PressTime);
					}
				}
				if(m_CallbackInfo[BUTTON_LONG_PRESS_UP]) {				// Updating counter for BUTTON_LONG_PRESS_UP PressTime
					ButtonCBInfo_t *pCBInfo = m_CallbackInfo[BUTTON_LONG_PRESS_UP];
					uint16_t time = pCBInfo[m_Count[1] + 1].EventArgs.LongPress.PressTime;
					if(m_LongPressTicks * TICKS_INTERVAL > time) {
						for(int i = m_Count[1] + 1; i < m_EventSize[BUTTON_LONG_PRESS_UP]; i++) {
							time = pCBInfo[i].EventArgs.LongPress.PressTime;
							if(m_LongPressTicks * TICKS_INTERVAL <= time) {
								m_Count[1] = i;
								break;
							}
						}
					}
					if(m_Count[1] + 1 < m_EventSize[BUTTON_LONG_PRESS_UP] && abs((int)ticks_time - (int)time) <= TOLERANCE) {
						do {
							m_Count[1]++;
							if(m_Count[1] + 1 >= m_EventSize[BUTTON_LONG_PRESS_UP]) break;
						} 
            while(time == pCBInfo[m_Count[1] + 1].EventArgs.LongPress.PressTime);
					}
				}
			}
			else {  //releasd
				m_Event = BUTTON_LONG_PRESS_UP;
				if(m_CallbackInfo[m_Event] && m_Count[1] >= 0) {				// calling callbacks for BUTTON_LONG_PRESS_UP PressTime 
					ButtonCBInfo_t *pCBInfo = m_CallbackInfo[m_Event];
					do {
						pCBInfo[m_Count[1]].Callback(this, pCBInfo[m_Count[1]].pUserData);
						if(!m_Count[1]) break;
						m_Count[1]--;
					} 
          while(pCBInfo[m_Count[1]].EventArgs.LongPress.PressTime == pCBInfo[m_Count[1] + 1].EventArgs.LongPress.PressTime);
					m_Count[1] = -1;					// Reset the counter 
				}
				if(m_CallbackInfo[BUTTON_LONG_PRESS_START]) {				// Reset counter 
					m_Count[0] = 0;
				}
				m_Event = BUTTON_PRESS_UP;
				CallEventFunctio(BUTTON_PRESS_UP);
				m_State = PRESS_DOWN_CHECK;  //reset
				m_LongPressHoldCount = 0;
				m_Event = BUTTON_PRESS_END;
				CallEventFunctio(BUTTON_PRESS_END);
			}
			break;
    }
	}
}

/////////////////////////////////////////////////////////////////////////////////////

/* - The first call to this function logs the IoT Button version.
 * - The function initializes a global button timer if it is not already running.
 * - Timer is started only if the driver does not enable power-saving mode. */
esp_err_t NewButton(const ButtonConfig_t *pConfig, ESPButton *pButton)
{
	if(!ESPButton::m_pListHead) {
		//        ESP_LOGI(_TAG, "IoT Button Version: %d.%d.%d", BUTTON_VER_MAJOR, BUTTON_VER_MINOR, BUTTON_VER_PATCH);
	}
	ESP_RETURN_ON_FALSE(pConfig, ESP_ERR_INVALID_ARG, _TAG, "Invalid argument");
  pButton = new ESPButton;
	pButton->Create(pConfig);
	if(!ESPButton::m_hTimer) {
		esp_timer_create_args_t ButtonTimer = {};
		ButtonTimer.arg = pButton;
		ButtonTimer.callback = ButtonCB;
		ButtonTimer.dispatch_method = ESP_TIMER_TASK;
		ButtonTimer.name = "ButtonTimer";
		esp_timer_create(&ButtonTimer, &ESPButton::m_hTimer);
	}
	if(!pButton->m_PowerSave && !ESPButton::m_TimeIsRunning) {
		esp_timer_start_periodic(ESPButton::m_hTimer, TICKS_INTERVAL * 1000U);
		ESPButton::m_TimeIsRunning = true;
	}
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t DeleteButton(ESPButton *pButton)
{
	BTN_CHECK(pButton != NULL, "Pointer to control is invalid", ESP_ERR_INVALID_ARG);
	ESPButton **pList;
	for(pList = &ESPButton::m_pListHead; *pList;) {
		ESPButton *pEntry = *pList;
		if(pEntry == pButton) {
			*pList = pEntry->m_pNext;
			delete pEntry;
		}
		else {
			pList = &pEntry->m_pNext;
		}
	}
  pButton = NULL; // control pointer not valid anymore
	uint16_t Number = 0;	// count button number
	ESPButton *pHead = ESPButton::m_pListHead;
	while(pHead) {
		pHead = pHead->m_pNext;
		Number++;
	}
	ESP_LOGD(_TAG, "remaining button count:%d", Number);
	if((Number == 0) && ESPButton::m_TimeIsRunning) { //  if all button is deleted, stop the timer 
		esp_timer_stop(ESPButton::m_hTimer);
		esp_timer_delete(ESPButton::m_hTimer);
		ESPButton::m_hTimer = NULL;
		ESPButton::m_TimeIsRunning = false;
	}
	return ESP_OK;
}

