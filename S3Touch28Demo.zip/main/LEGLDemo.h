/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= ===========================================
 * SJ    2025/08/18   1.a.1    Original 
 *
 */


#pragma once

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <time.h>
#include <sys/time.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/event_groups.h>
#include <freertos/semphr.h>
#include <freertos/queue.h>
#include <freertos/timers.h>
#include <esp_wifi.h>
#include <esp_wifi_default.h>
#include "esp_http_client.h"
#include <esp_event.h>
#include <nvs_flash.h>
#include <esp_timer.h>
#include <esp_log.h>

#include <esp_system.h>
#include <esp_vfs.h>
#include <time.h>

#include "S3Touch28BSP.h"
#include "EGL.h"

#include "RTCDevice.h"
#include "SD_MMC.h"

#include "BatteryDriver.h"
#include "PowerKey.h"
#include "Display.h"
#include "WidgetsUI.h"

/////////////////////////////////////////////////////////////////////////////////////

#define PI					              3.14159265358979323846
#define DEG2RAD(x) ((double)(x) * (PI / 180))
#define RAD2DEG(x) ((double)(x) * (180 / PI))

#define SECONDS_TO_TICKS(xTimeInS) ((TickType_t)(xTimeInS) * configTICK_RATE_HZ)
#define TICKS_TO_SECONDS(xTicks) ((TickType_t)(xTicks) / configTICK_RATE_HZ)

#define SYSFLAG_DISPLAY_READY     0x0001
#define SYSFLAG_SYSTEM_UP         0x0010
#define SYSFLAG_SLEEPTIMER_EXP    0x8000

#define SECS_PER_MIN              60
#define SECS_PER_DAY              86400

/////////////////////////////////////////////////////////////////////////////////////

const gpio_num_t        c_BSP_BootButtonPin = GPIO_NUM_0;
const gpio_num_t        c_LCD_SPI_MOSI_Pin 	= GPIO_NUM_45;
const gpio_num_t        c_LCD_SPI_MISO_Pin 	= GPIO_NUM_46;
const gpio_num_t        c_LCD_SPI_CLK_Pin 	= GPIO_NUM_40;
const gpio_num_t        c_LCD_SPI_CS_Pin 		= GPIO_NUM_42;
const gpio_num_t        c_LCD_DC_Pin 				= GPIO_NUM_41;
const gpio_num_t        c_LCD_RST_Pin 			= GPIO_NUM_39;
const gpio_num_t        c_LCD_BacklightPin 	= GPIO_NUM_5;
const gpio_num_t        c_SD_D0_Pin 				= GPIO_NUM_2;
const gpio_num_t        c_SD_D1_Pin 				= GPIO_NUM_4;
const gpio_num_t        c_SD_D2_Pin 				= GPIO_NUM_12;
const gpio_num_t        c_SD_D3_Pin 				= GPIO_NUM_13;
const gpio_num_t        c_SD_CMD_Pin 				= GPIO_NUM_15;
const gpio_num_t        c_SD_CLK_Pin 				= GPIO_NUM_14;
const gpio_num_t        c_SD_DET_Pin 				= GPIO_NUM_21;

const gpio_num_t 	      c_I2CSCLPin         = GPIO_NUM_10;     // GPIO number used for I2C master clock 
const gpio_num_t 	      c_I2CSDAPin         = GPIO_NUM_11;     // GPIO number used for I2C master data  
const i2c_port_t 	      c_I2CPort           = I2C_NUM_0;       // I2C master i2c port number
const gpio_num_t        c_PowerKeyPin       = GPIO_NUM_6;
const gpio_num_t        c_PowerControlPin   = GPIO_NUM_7;

/////////////////////////////////////////////////////////////////////////////////////

#ifdef _MAIN_

const char              *c_pVersionStr = "Version 1.a.023";
const char              *c_pMountPoint = "/sdcard";

EventGroupHandle_t      g_SystemFlags = NULL;

esp_timer_handle_t      g_hOneSecondTimer;
esp_timer_handle_t      g_hOneHourTimer;

I2CDriver               g_I2CObj;
SDMMCDevice             g_SDMMCObj;
PowerKey                g_PwrKeyObj;

#else

extern EventGroupHandle_t   g_SystemFlags;

extern esp_timer_handle_t   g_hOneSecondTimer;
extern esp_timer_handle_t   g_hOneHourTimer;

extern I2CDriver            g_I2CObj;
extern SDMMCDevice          g_SDMMCObj;
extern PowerKey             g_PwrKeyObj;

#endif

