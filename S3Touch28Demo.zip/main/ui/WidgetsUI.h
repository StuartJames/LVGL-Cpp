/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= ===========================================
 * SJ    2025/08/18   1.a.1    Original ESP Demo
 *
 */


#include "EGL.h"

#if EG_USE_GRID == 0
#error "LV_USE_GRID needs to be enabled"
#endif

#if EG_USE_FLEX == 0
#error "LV_USE_FLEX needs to be enabled"
#endif

// IMAGES AND IMAGE SETS
EG_IMG_DECLARE(ImageAvatar);
EG_IMG_DECLARE(ImageClothes);
EG_IMG_DECLARE(ImageLogo);

void EG_WidgetsDemo(void);
