/*
 *              EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */


#pragma once

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include "driver/gpio.h"
#include "esp_attr.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "KnobIO.h"

/////////////////////////////////////////////////////////////////////////////////////

#define KNOB_CHECK(a, str, ret_val)                           \
	if(!(a)) {                                                  \
		ESP_LOGE(_TAG, "%s(%d): %s", __FUNCTION__, __LINE__, str); \
		return (ret_val);                                         \
	}

#define KNOB_CHECK_GOTO(a, str, label)                                     \
	if(!(a)) {                                                               \
		ESP_LOGE(_TAG, "%s:%d (%s):%s", __FILE__, __LINE__, __FUNCTION__, str); \
		goto label;                                                            \
	}

#define TICKS_INTERVAL CONFIG_KNOB_PERIOD_TIME_MS
#define DEBOUNCE_TICKS CONFIG_KNOB_DEBOUNCE_TICKS
#define HIGH_LIMIT CONFIG_KNOB_HIGH_LIMIT
#define LOW_LIMIT CONFIG_KNOB_LOW_LIMIT

/////////////////////////////////////////////////////////////////////////////////////

typedef void (* knob_cb_t)(void *, void *);
class ESPQuadKnob;

/////////////////////////////////////////////////////////////////////////////////////

typedef enum {
    KNOB_LEFT = 0,                     // EVENT: Rotate to the left 
    KNOB_RIGHT,                        // EVENT: Rotate to the right 
    KNOB_H_LIM,                        // EVENT: Count reaches maximum limit 
    KNOB_L_LIM,                        // EVENT: Count reaches the minimum limit 
    KNOB_ZERO,                         // EVENT: Count back to 0 
    KNOB_EVENT_MAX,                    // EVENT: Number of events 
    KNOB_NONE,                         // EVENT: No event 
} knob_event_t;

typedef enum {
	KNOB_CHECK = -1,                      // Knob state: check whether the knob is in the right position  
	KNOB_READY = 0,                       // Knob state: ready
	KNOB_PHASE_A,                         // Knob state: phase A arrives first 
	KNOB_PHASE_B,                         // Knob state: phase B arrives first 
} knob_state_t;

typedef struct {
    uint8_t     PhaseDirection;          // 0:positive increase   1:negative increase 
    gpio_num_t  PhasePinA;               // Encoder Pin A 
    gpio_num_t  PhasePinB;               // Encoder Pin B 
    bool        PowerSave;             // Enable power save mode 
} KnobConfig_t;

/////////////////////////////////////////////////////////////////////////////////////

ESPQuadKnob*  NewQuadKnob(const KnobConfig_t *pConfig);
esp_err_t     DeleteQuadKnob(ESPQuadKnob *pKnob);

/////////////////////////////////////////////////////////////////////////////////////

class ESPQuadKnob
{
public:
                      ESPQuadKnob(void);
  virtual             ~ESPQuadKnob();
  esp_err_t           Create(const KnobConfig_t *pConfig);
  void                EventHandler(void);
  knob_event_t        GetEvent(void);
  int                 GetCountValue(void);
  esp_err_t           ClearCountValue(void);
  esp_err_t           Resume(void);
  esp_err_t           Stop(void);

	bool                m_PhaseChangeA;                 // true means Encoder A phase Inverted
	bool                m_PhaseChangeB;                 // true means Encoder B phase Inverted
	bool                m_PowerSave;                    // Enable power save function 
	uint8_t             m_PhaseDirection;               // 0:positive increase   1:negative increase 
	knob_state_t        m_State;                        // knob state machine status 
	uint8_t             m_DebounceCountA;               // Encoder A phase debounce count 
	uint8_t             m_DebounceCountB;               // Encoder B phase debounce count 
	uint8_t             m_PhaseLevelA;                  // Encoder A phase current level 
	uint8_t             m_PhaseLevelB;                  // Encoder B phase current Level 
	knob_event_t        m_Event;                        // Current event 
	uint16_t            m_Ticks;                        // Timer interrupt count 
	int                 m_PhaseChangeCount;             // Knob count 
	gpio_num_t          m_PhasePinA;                    // Encoder A phase gpio number 
	gpio_num_t          m_PhasePinB;                    // Encoder B phase gpio number 
	void               *m_pUserData[KNOB_EVENT_MAX];    // User data for event 
	knob_cb_t           m_CallBacks[KNOB_EVENT_MAX];    // Event callback 
	ESPQuadKnob        *m_pNext;                        // Next pointer 

  static ESPQuadKnob *m_pListHead;
  static bool         m_InterruptServiceInstalled;
  static bool         m_TimerIsRunning;
  static esp_timer_handle_t   m_hTimer;

private:
  void                CallEventCB(knob_event_t Event);
  esp_err_t           RegisterCB(knob_event_t Event, knob_cb_t Callback, void *pUserData);
  esp_err_t           UnregisterCB(knob_event_t Event);
  esp_err_t           InitialiseIO(gpio_num_t GPIONumber);
  esp_err_t           DeinitialiseIO(gpio_num_t GPIONumber);
  uint8_t             GetKeyLevel(gpio_num_t GPIONumber);
  esp_err_t           InitialiseIntrrupt(gpio_num_t GPIONumber, gpio_int_type_t InterruptType, gpio_isr_t isr_handler, void *IOPin);
  esp_err_t           SetInterruptType(gpio_num_t GPIONumber, gpio_int_type_t InterruptType);
  esp_err_t           InterruptControl(gpio_num_t GPIONumber, bool Enable);
  esp_err_t           WakeupControl(gpio_num_t GPIONumber, uint8_t WakeupLevel, bool Enable);
  esp_err_t           InitialiseWakeup(gpio_num_t GPIONumber, uint8_t WakeupLevel);
};

/////////////////////////////////////////////////////////////////////////////////////

inline void ESPQuadKnob::CallEventCB(knob_event_t Event)
{
	if(m_CallBacks[Event]) m_CallBacks[Event](this, m_pUserData[Event]);
}

