/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#include <string.h>
#include "esp_log.h"
#include "esp_err.h"
#include "esp_check.h"
#include "esp_heap_caps.h"
#include "esp_idf_version.h"
#include "esp_lcd_panel_io.h"
#include "esp_lcd_panel_ops.h"
#include "ESPEGPort.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"


static const char *TAG = "[GLPORT]";

////////////////////////////////////////////////////////////////////////

ESPGLDisplay::ESPGLDisplay()
{
  m_hIO = nullptr;    
  m_hPanel = nullptr; 
  m_hControl = nullptr;
  m_pDriver = nullptr;
  m_BufferSize = 0;
  m_DoubleBuffer = false;
  m_TransferSize = 0;
  m_HoriResolution = 0;
  m_VertvResolution = 0;
  m_IsMonochrome = false;   
  m_Rotation = {}; 
  m_BufferDMA = 0;
  m_BuffersPSRAM = 0;
  m_SWRotate = 0; 
  m_FullRefresh = 0;
  m_DirectMode = 0;
#if EG_VERSION_MAJOR >= 9
  m_ColorFormat = 0; 
  m_SwapBytes = 0;  
#endif
}

////////////////////////////////////////////////////////////////////////

ESPGLDisplay::~ESPGLDisplay()
{
}

////////////////////////////////////////////////////////////////////////

EGDisplay* ESPGLDisplay::AddDisplay(esp_lcd_panel_handle_t hPanel, esp_lcd_panel_io_handle_t hIO, ESPGLPortDisplayCfg_t *pConfig)
{
	assert(hPanel != nullptr);
	assert(pConfig != nullptr);
  Configure(hPanel, pConfig);	
  m_hIO = hIO;
  EGDisplay *pDisplay = AddDisplayPrivate(false);
	ESP_LOGI(TAG, "Disp %p", (void*)pDisplay);
	if(pDisplay != nullptr) {
		m_DisplayType = EGL_PORT_DISP_TYPE_OTHER;		// Set display type 
		assert(m_hIO != nullptr);
#if EGL_PORT_HANDLE_FLUSH_READY
		const esp_lcd_panel_io_callbacks_t cbs = {.on_color_trans_done = ESPGLLCDDriver::FlushIOReady };
		esp_lcd_panel_io_register_event_callbacks(m_hIO, &cbs, m_pDriver);		// Register done callback 
#endif
	}
	return pDisplay;
}

////////////////////////////////////////////////////////////////////////

EGDisplay* ESPGLDisplay::AddDisplayDSI(esp_lcd_panel_handle_t hPanel, ESPGLPortDisplayCfg_t *pConfig, const ESPGLPortDSICfg_t *pDSICfg)
{
	assert(hPanel != nullptr);
	assert(pConfig != nullptr);
	assert(pDSICfg != nullptr);
	const bool AvoidTearing = pDSICfg->AvoidTearing;
  Configure(hPanel, pConfig);	
	EGDisplay *pDisplay = AddDisplayPrivate(AvoidTearing);
	if(pDisplay != nullptr) {
		m_DisplayType = EGL_PORT_DISP_TYPE_DSI;		// Set display type 
#if(CONFIG_IDF_TARGET_ESP32P4 && ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(5, 3, 0))
		esp_lcd_dpi_panel_event_callbacks_t cbs = {0};
		if(pDSICfg->flags.avoid_tearing) {
			cbs.on_refresh_done = lvgl_port_flush_dpi_vsync_ready_callback;
		}
		else {
			cbs.on_color_trans_done = lvgl_port_flush_dpi_panel_ready_callback;
		}
		// Register done callback 
		esp_lcd_dpi_panel_register_event_callbacks(pDisplayCtx->panel_handle, &cbs, &pDisplayCtx->disp_drv);
#else
		ESP_RETURN_ON_FALSE(false, NULL, TAG, "MIPI-DSI is supported only on ESP32P4 and from IDF 5.3!");
#endif
	}
	return pDisplay;
}

////////////////////////////////////////////////////////////////////////

EGDisplay* ESPGLDisplay::AddDisplayRGB(esp_lcd_panel_handle_t hPanel, ESPGLPortDisplayCfg_t *pConfig, const ESPGLPortRGBCfg_t *pRGBCfg)
{
	assert(hPanel != NULL);
	assert(pConfig != NULL);
	assert(pRGBCfg != NULL);
	const bool AvoidTearing = pRGBCfg->AvoidTearing;
  Configure(hPanel, pConfig);	
	EGDisplay *pDisplay = AddDisplayPrivate(AvoidTearing);
	if(pDisplay != NULL) {
		m_DisplayType = EGL_PORT_DISP_TYPE_RGB;		// Set display type 
		const esp_lcd_rgb_panel_event_callbacks_t cbs = {		// Register done callback 
#if EXAMPLE_RGB_BOUNCE_BUFFER_SIZE > 0
			.on_vsync = nullptr,
			.on_bounce_empty = nullptr,
			.on_bounce_frame_finish = ESPGLLCDDriver::OnRGBVsyncReady
#else    
			.on_vsync = ESPGLLCDDriver::OnRGBVsyncReady,
			.on_bounce_empty = nullptr,
			.on_bounce_frame_finish = nullptr
#endif
		};
		ESP_ERROR_CHECK(esp_lcd_rgb_panel_register_event_callbacks(m_hPanel, &cbs, &pDisplay->m_pDriver));
	}
	return pDisplay;
}

////////////////////////////////////////////////////////////////////////

void ESPGLDisplay::Configure(esp_lcd_panel_handle_t hPanel, ESPGLPortDisplayCfg_t *pConfig)
{
  m_hPanel = hPanel;
  m_hControl = NULL;
  m_BufferSize = pConfig->BufferSize;
  m_DoubleBuffer = pConfig->DoubleBuffer;
  m_TransferSize = 0;
  m_HoriResolution = pConfig->HoriResolution;
  m_VertvResolution = pConfig->VertvResolution;
  m_IsMonochrome = pConfig->IsMonochrome;
  m_Rotation.SwapXY = pConfig->Rotation.SwapXY;
#ifdef CONFIG_BSP_LCD_ILI9341
  m_Rotation.MirrorX = pConfig->Rotation.MirrorX;
#else
  m_Rotation.MirrorX = pConfig->Rotation.MirrorX;
#endif
  m_Rotation.MirrorY = pConfig->Rotation.MirrorY;
  m_BufferDMA = pConfig->Flags.BufferDMA;
  m_BuffersPSRAM = pConfig->Flags.BuffersPSRAM;
  m_SWRotate = pConfig->Flags.SWRotate;
#if EG_VERSION_MAJOR >= 9
  m_SwapBytes = SwapBytes;
#endif
  m_FullRefresh = pConfig->Flags.FullRefresh;
  m_DirectMode = pConfig->Flags.DirectMode;
}

////////////////////////////////////////////////////////////////////////

EGDisplay* ESPGLDisplay::AddDisplayPrivate(const bool AvoidTearing)
{
esp_err_t ret = ESP_OK;
EG_DisplayDrawBuffer_t *pDisplayBuffer = nullptr;
EG_Color_t *pBuf1 = nullptr;
EG_Color_t *pBuf2 = nullptr;
EG_Color_t *pBuf3 = nullptr;
uint32_t BufferSize = 0;
SemaphoreHandle_t hTransferSemaphore = nullptr;
EGDisplay *pDisplay = nullptr;

	assert(m_hPanel != nullptr);
	assert(m_BufferSize > 0);
	assert(m_HoriResolution > 0);
	assert(m_VertvResolution > 0);
  BufferSize = m_BufferSize; 
	if(AvoidTearing) {	// Use RGB internal buffers for avoid tearing effect 
#if CONFIG_IDF_TARGET_ESP32S3
		BufferSize = m_HoriResolution * m_VertvResolution;
#if (EGL_PORT_LCD_RGB_BUFFER_NUMS == 3) && (BSP_EGL_PORT_ROTATION_DEGREE == 0) && EGL_PORT_FULL_REFRESH
    // With three buffers and full-refresh, one buffer is always available for rendering
    ESP_ERROR_CHECK(esp_lcd_rgb_panel_get_frame_buffer(m_hPanel, 3, (void **)&pRGBLastBuf, (void **)&pBuf1, (void **)&pBuf1));
    pRGBNextBuf = pRGBLastBuf; // Set the next RGB buffer
    pRGBFlushNextBuf = buf2; // Set the flush next buffer
#elif (EGL_PORT_LCD_RGB_BUFFER_NUMS == 3) && (BSP_EGL_PORT_ROTATION_DEGREE != 0)
    // Using three frame buffers, one for EGL rendering and two for RGB driver (one used for rotation)
    void *pFrameBuf[3];
    ESP_ERROR_CHECK(esp_lcd_rgb_panel_get_frame_buffer(m_hPanel, 3, (void **)&pFrameBuf[0], (void **)&pFrameBuf[1], (void **)&pFrameBuf[2]));
    pBuf1 = pFrameBuf[2]; // Set buf1 to the third frame buffer
#else
		ESP_GOTO_ON_ERROR(esp_lcd_rgb_panel_get_frame_buffer(m_hPanel, 2, (void **)&pBuf1, (void **)&pBuf2), err, TAG, "Get RGB buffers failed");
#endif
#elif CONFIG_IDF_TARGET_ESP32P4 
		BufferSize = disp_cfg->hres * disp_cfg->vres;
		ESP_GOTO_ON_ERROR(esp_lcd_dpi_panel_get_frame_buffer(m_hPanel, 2, (void *)&pBuf1, (void *)&pBuf2), err, TAG, "Get RGB buffers failed");
#endif
		hTransferSemaphore = xSemaphoreCreateCounting(1, 0);
		ESP_GOTO_ON_FALSE(hTransferSemaphore, ESP_ERR_NO_MEM, err, TAG, "Failed to create transport counting Semaphore");
		m_hTransferSemaphore = hTransferSemaphore;
	}
	else {
		uint32_t BufferCapability = MALLOC_CAP_DEFAULT;
		if(m_BufferDMA && m_BuffersPSRAM && (0 == m_TransferSize)) {
			ESP_GOTO_ON_FALSE(false, ESP_ERR_NOT_SUPPORTED, err, TAG, "Alloc DMA capable buffer in SPIRAM is not supported!");
		}
		else if(m_BufferDMA) {
			BufferCapability = MALLOC_CAP_DMA;
		}
		else if(m_BuffersPSRAM) {
			BufferCapability = MALLOC_CAP_SPIRAM;
		}
		if(m_TransferSize) {
			pBuf3 = (EG_Color_t*)heap_caps_malloc(m_TransferSize * sizeof(EG_Color_t), MALLOC_CAP_DMA);
			ESP_GOTO_ON_FALSE(pBuf3, ESP_ERR_NO_MEM, err, TAG, "Not enough memory for transfer buffer[3] (%d) allocation!", m_TransferSize * sizeof(EG_Color_t));
			m_pTransferBuffer = pBuf3;
			hTransferSemaphore = xSemaphoreCreateCounting(1, 0);
			ESP_GOTO_ON_FALSE(hTransferSemaphore, ESP_ERR_NO_MEM, err, TAG, "Failed to create transfer counting Semaphore");
			m_hTransferSemaphore = hTransferSemaphore;
		}
		// alloc draw buffers. It's recommended to choose the size of the draw buffer(s) to be at least 1/10 screen sized 
		pBuf1 = (EG_Color_t*)heap_caps_malloc(BufferSize * sizeof(EG_Color_t), BufferCapability);
		ESP_GOTO_ON_FALSE(pBuf1, ESP_ERR_NO_MEM, err, TAG, "Not enough memory for swap buffer[1] (%d) allocation!", BufferSize * sizeof(EG_Color_t));
		if(m_DoubleBuffer) {
			pBuf2 = (EG_Color_t*)heap_caps_malloc(BufferSize * sizeof(EG_Color_t), BufferCapability);
			ESP_GOTO_ON_FALSE(pBuf2, ESP_ERR_NO_MEM, err, TAG, "Not enough memory for swap buffer[2] (%d) allocation!", BufferSize * sizeof(EG_Color_t));
		}
	}
  ESP_LOGI(TAG, "Size:%d, HRes:%d, VRes:%d", BufferSize, m_HoriResolution, m_VertvResolution);
	if(!EGDisplay::InitialiseDrawBuffers(&pDisplayBuffer, pBuf1, pBuf2, BufferSize)){	// create display buffer 
	  ESP_LOGI(TAG, "Not enough memory for display buffer (%d) allocation", sizeof(EG_DisplayDrawBuffer_t));
    goto err;
  }
	ESP_LOGI(TAG, "Create display driver");
  m_pDriver = new ESPGLLCDDriver;
	EGDisplay::InitialiseDriver(m_pDriver);
	m_pDriver->m_HorizontalRes = m_HoriResolution;
	m_pDriver->m_VerticalRes = m_VertvResolution;
	((EGDisplayDriver*)m_pDriver)->FlushCB = ESPGLLCDDriver::Flush;
	m_pDriver->m_pDrawBuffers = pDisplayBuffer;
	m_pDriver->m_pExtData = this;      // Save this display object
	m_pDriver->m_SoftRotate = m_SWRotate;
	if(m_pDriver->m_SoftRotate == false) {
		((EGDisplayDriver*)m_pDriver)->UpdateCB = ESPGLLCDDriver::Update;
	}
  if(m_IsMonochrome) {	// Monochrome display settings. When using monochromatic display, there must be used full bufer! 
		ESP_GOTO_ON_FALSE((m_HoriResolution * m_VertvResolution == BufferSize), ESP_ERR_INVALID_ARG, err, TAG, "Monochromatic display must using full buffer!");
		m_pDriver->m_FullRefresh = 1;
		m_pDriver->SetPixelCB = ESPGLLCDDriver::PixMonochrome;
	}
	else if(m_DirectMode) {	// When using direct_mode, a full buffer must be used 
		ESP_GOTO_ON_FALSE((BufferSize == m_HoriResolution * m_VertvResolution), ESP_ERR_INVALID_ARG, err, TAG, "Direct mode must be using full buffer!");
		m_pDriver->m_DirectMode = 1;
	}
	else if(m_FullRefresh) {		// When using full_refresh, there must be used full bufer! 
		ESP_GOTO_ON_FALSE((BufferSize == m_HoriResolution * m_VertvResolution), ESP_ERR_INVALID_ARG, err, TAG, "Full refresh must using full buffer!");
		m_pDriver->m_FullRefresh = 1;
	}
	ESP_LOGI(TAG, "Register display driver (create display)");
	pDisplay = EGDisplay::RegisterDriver(m_pDriver);
	((EGDisplayDriver*)m_pDriver)->UpdateCB(m_pDriver);	// Apply rotation from initial display configuration 
	return pDisplay;

err:
	if(ret != ESP_OK){
		if(pBuf1) free(pBuf1);
		if(pBuf2) free(pBuf2);
		if(pBuf3) free(pBuf3);
		if(hTransferSemaphore) vSemaphoreDelete(hTransferSemaphore);
	}
	return nullptr;
}

////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLDisplay::RemoveDisplay(EGDisplay *pDisplay)
{
	assert(pDisplay);
	EGDisplayDriver *pDriver = (EGDisplayDriver*)pDisplay->m_pDriver;
	assert(pDriver);
	if(m_hTransferSemaphore) {
		vSemaphoreDelete(m_hTransferSemaphore);
	}
	EGDisplay::Remove(pDisplay);
	if(pDriver) {
		pDriver->InitialiseContext(pDriver->m_pContext);
		if(pDriver->m_pDrawBuffers && pDriver->m_pDrawBuffers->pBuffer1) {
			free(pDriver->m_pDrawBuffers->pBuffer1);
			pDriver->m_pDrawBuffers->pBuffer1 = NULL;
		}
		if(pDriver->m_pDrawBuffers && pDriver->m_pDrawBuffers->pBuffer2) {
			free(pDriver->m_pDrawBuffers->pBuffer2);
			pDriver->m_pDrawBuffers->pBuffer2 = NULL;
		}
		if(pDriver->m_pDrawBuffers) {
			free(pDriver->m_pDrawBuffers);
			pDriver->m_pDrawBuffers = NULL;
		}
	}
	return ESP_OK;
}

////////////////////////////////////////////////////////////////////////
// Driver
////////////////////////////////////////////////////////////////////////

ESPGLLCDDriver::~ESPGLLCDDriver(void)
{
}

////////////////////////////////////////////////////////////////////////

void ESPGLLCDDriver::Update(EGDisplayDriver *pDisplayDriver)
{
	ESPGLDisplay *pGLDisplay = (ESPGLDisplay*)pDisplayDriver->m_pExtData;
	assert(pGLDisplay != NULL);
	esp_lcd_panel_handle_t control_handle = (pGLDisplay->m_hControl ? pGLDisplay->m_hControl : pGLDisplay->m_hPanel);
	switch(pDisplayDriver->m_Rotated) {	// Solve rotation screen and touch 
		case EG_DISP_ROT_NONE:
			esp_lcd_panel_swap_xy(control_handle, pGLDisplay->m_Rotation.SwapXY);
			esp_lcd_panel_mirror(control_handle, pGLDisplay->m_Rotation.MirrorX, pGLDisplay->m_Rotation.MirrorY);
			break;
		case EG_DISP_ROT_90:
			esp_lcd_panel_swap_xy(control_handle, !pGLDisplay->m_Rotation.SwapXY);
			if(pGLDisplay->m_Rotation.SwapXY) {
				esp_lcd_panel_mirror(control_handle, !pGLDisplay->m_Rotation.MirrorX, pGLDisplay->m_Rotation.MirrorY);
			}
			else {
				esp_lcd_panel_mirror(control_handle, pGLDisplay->m_Rotation.MirrorX, !pGLDisplay->m_Rotation.MirrorY);
			}
			break;
		case EG_DISP_ROT_180:
			esp_lcd_panel_swap_xy(control_handle, pGLDisplay->m_Rotation.SwapXY);
			esp_lcd_panel_mirror(control_handle, !pGLDisplay->m_Rotation.MirrorX, !pGLDisplay->m_Rotation.MirrorY);
			break;
		case EG_DISP_ROT_270:
			esp_lcd_panel_swap_xy(control_handle, !pGLDisplay->m_Rotation.SwapXY);
			if(pGLDisplay->m_Rotation.SwapXY) {
				esp_lcd_panel_mirror(control_handle, pGLDisplay->m_Rotation.MirrorX, !pGLDisplay->m_Rotation.MirrorY);
			}
			else {
				esp_lcd_panel_mirror(control_handle, !pGLDisplay->m_Rotation.MirrorX, pGLDisplay->m_Rotation.MirrorY);
			}
			break;
	}
}

////////////////////////////////////////////////////////////////////////

#if EGL_PORT_HANDLE_FLUSH_READY
bool ESPGLLCDDriver::FlushIOReady(esp_lcd_panel_io_handle_t hIO, esp_lcd_panel_io_event_data_t *pEventData, void *pUserContext)
{
BaseType_t taskAwake = pdFALSE;

	assert(pUserContext != nullptr);
	EGDisplayDriver *pDriver = (EGDisplayDriver*)pUserContext;
	assert(pDriver != nullptr);
	EGDisplay::FlushReady(pDriver);
	ESPGLDisplay *pGLDisplay = (ESPGLDisplay*)pDriver->m_pExtData;
	assert(pGLDisplay != nullptr);
	if(pGLDisplay->m_TransferSize && pGLDisplay->m_hTransferSemaphore) {
		xSemaphoreGiveFromISR(pGLDisplay->m_hTransferSemaphore, &taskAwake);
	}
	return false;
}

////////////////////////////////////////////////////////////////////////

#if(CONFIG_IDF_TARGET_ESP32P4 && ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(5, 3, 0))
bool ESPGLLCDDriver::FlushDPIPanelReady(esp_lcd_panel_handle_t hIO, esp_lcd_dpi_panel_event_data_t *pEventData, void *pUserContext)
{
BaseType_t taskAwake = pdFALSE;

	lv_disp_drv_t *pDisplayDriver = (lv_disp_drv_t *)user_ctx;
	assert(pDisplayDriver != NULL);
	ESPGLDisplay *pGLDisplay = (ESPGLDisplay*)pDisplayDriver->user_data;
	assert(pDisplayCtx != NULL);
	lv_disp_flush_ready(disp_drv);
	if(pDisplayCtx->trans_size && pDisplayCtx->m_hTransferSemaphore) {
		xSemaphoreGiveFromISR(pDisplayCtx->m_hTransferSemaphore, &taskAwake);
	}
	return false;
}

////////////////////////////////////////////////////////////////////////

bool ESPGLLCDDriver::FlushDPIVsyncReady(esp_lcd_panel_handle_t hIO, esp_lcd_dpi_panel_event_data_t *pEventData, void *pUserContext)
{
BaseType_t need_yield = pdFALSE;

	lv_disp_drv_t *pDisplayDriver = (lv_disp_drv_t *)pUserContext;
	assert(pDisplayDriver != NULL);
	ESPGLDisplay *pGLDisplay = (ESPGLDisplay*)pDisplayDriver->user_data;
	assert(pGLDisplay != NULL);
	if(pGLDisplay->m_hTransferSemaphore) {
		xSemaphoreGiveFromISR(pGLDisplay->m_hTransferSemaphore, &need_yield);
	}
	return (need_yield == pdTRUE);
}
#endif

////////////////////////////////////////////////////////////////////////

#if(CONFIG_IDF_TARGET_ESP32S3 && ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(5, 0, 0))
IRAM_ATTR bool ESPGLLCDDriver::OnRGBVsyncReady(esp_lcd_panel_handle_t hPanel, const esp_lcd_rgb_panel_event_data_t *pEventData, void *pUserContext)
{
  return ESPGLPort::OnRGBVSyncNotify(); // Notify EGL task
}
#endif
#endif

////////////////////////////////////////////////////////////////////////

#if EGL_PORT_AVOID_TEAR_MODE
#if EGL_PORT_DIRECT_MODE
#if BSP_EGL_PORT_ROTATION_DEGREE != 0

void ESPGLLCDDriver::Flush(EGDisplayDriver *pDisplayDriver, const EGRect *pRect, EG_Color_t *pBuffer)
{
int x_draw_start, x_draw_end;
int y_draw_start, y_draw_end;
int y_start_tmp, y_end_tmp;
int trans_count, trans_line, max_line;
const int x_start = pRect->GetX1();
const int x_end = pRect->GetX2();
const int y_start = pRect->GetY1();
const int y_end = pRect->GetY2();
const int width = x_end - x_start + 1;
const int height = y_end - y_start + 1;
EG_Color_t *pFrom = pBuffer;
EG_Color_t *pTo = nullptr;

	ESPGLDisplay *pGLDisplay = (ESPGLDisplay*)pDisplayDriver->m_pExtData;
	assert(pGLDisplay != nullptr);
	if(pGLDisplay->m_TransferSize == 0) {
		if((pGLDisplay->m_DisplayType == EGL_PORT_DISP_TYPE_RGB || pGLDisplay->m_DisplayType == EGL_PORT_DISP_TYPE_DSI) &&
     (pDisplayDriver->m_DirectMode || pDisplayDriver->m_FullRefresh)) {
			if(EGDisplay::FlushIsLast(pDisplayDriver)) {				// If the interface is I80 or SPI, this step cannot be used for drawing. 
				esp_lcd_panel_draw_bitmap(pGLDisplay->m_hPanel, x_start, y_start, x_end + 1, y_end + 1, pBuffer);
				xSemaphoreTake(pGLDisplay->m_hTransferSemaphore, 0);				// Waiting for the last frame buffer to complete transmission 
				xSemaphoreTake(pGLDisplay->m_hTransferSemaphore, portMAX_DELAY);
			}
		}
		else {
			esp_lcd_panel_draw_bitmap(pGLDisplay->m_hPanel, x_start, y_start, x_end + 1, y_end + 1, pBuffer);
		}
		if(pGLDisplay->m_DisplayType == EGL_PORT_DISP_TYPE_RGB || (pGLDisplay->m_DisplayType == EGL_PORT_DISP_TYPE_DSI && 
      (pDisplayDriver->m_DirectMode || pDisplayDriver->m_FullRefresh))) {
			EGDisplay::FlushReady(pDisplayDriver);
		}
	}
	else {
		y_start_tmp = y_start;
		max_line = ((pGLDisplay->m_TransferSize / width) > height) ? (height) : (pGLDisplay->m_TransferSize / width);
		trans_count = height / max_line + (height % max_line ? (1) : (0));
		for(int i = 0; i < trans_count; i++) {
			trans_line = (y_end - y_start_tmp + 1) > max_line ? max_line : (y_end - y_start_tmp + 1);
			y_end_tmp = (y_end - y_start_tmp + 1) > max_line ? (y_start_tmp + max_line - 1) : y_end;
			pTo = pGLDisplay->m_pTransferBuffer;
			for(int y = 0; y < trans_line; y++) {
				for(int x = 0; x < width; x++) {
					*(pTo + y * (width) + x) = *(pFrom + y * (width) + x);
				}
			}
			x_draw_start = x_start;
			x_draw_end = x_end;
			y_draw_start = y_start_tmp;
			y_draw_end = y_end_tmp;
			esp_lcd_panel_draw_bitmap(pGLDisplay->m_hPanel, x_draw_start, y_draw_start, x_draw_end + 1, y_draw_end + 1, pTo);
			pFrom += max_line * width;
			y_start_tmp += max_line;
			xSemaphoreTake(pGLDisplay->m_hTransferSemaphore, portMAX_DELAY);
		}
	}
}

#else

void ESPGLLCDDriver::Flush(EGDisplayDriver *pDisplayDriver, const EGRect *pRect, EG_Color_t *pBuffer)
{
const int x_start = pRect->GetX1();
const int x_end = pRect->GetX2();
const int y_start = pRect->GetY1();
const int y_end = pRect->GetY2();

	ESPGLDisplay *pGLDisplay = (ESPGLDisplay*)pDisplayDriver->m_pExtData;
	assert(pGLDisplay != nullptr);
  if(EGDisplay::FlushIsLast(pDisplayDriver)) {  // Action after last area refresh 
    esp_lcd_panel_draw_bitmap(pGLDisplay->m_hPanel, x_start, y_start, x_end + 1, y_end + 1, pBuffer);  // Switch the current RGB frame buffer to `color_map` 
      ulTaskNotifyValueClear(NULL, ULONG_MAX);   // Wait for the last frame buffer to complete transmission 
      ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
  }
  EGDisplay::FlushReady(pDisplayDriver); // Mark the display flush as complete
}

#endif

#elif EGL_PORT_FULL_REFRESH && EGL_PORT_LCD_RGB_BUFFER_NUMS == 2

void ESPGLLCDDriver::Flush(EGDisplayDriver *pDisplayDriver, const EGRect *pRect, EG_Color_t *pBuffer)
{
    esp_lcd_panel_handle_t panel_handle = (esp_lcd_panel_handle_t) drv->user_data; // Get the panel handle from driver user data
    const int offsetx1 = area->x1; // Start X coordinate of the area to flush
    const int offsetx2 = area->x2; // End X coordinate of the area to flush
    const int offsety1 = area->y1; // Start Y coordinate of the area to flush
    const int offsety2 = area->y2; // End Y coordinate of the area to flush

    /* Switch the current RGB frame buffer to `color_map` */
    esp_lcd_panel_draw_bitmap(panel_handle, offsetx1, offsety1, offsetx2 + 1, offsety2 + 1, color_map);

    /* Wait for the last frame buffer to complete transmission */
    ulTaskNotifyValueClear(NULL, ULONG_MAX);
    ulTaskNotifyTake(pdTRUE, portMAX_DELAY);

    lv_disp_flush_ready(drv); // Mark the display flush as complete
}

#elif EGL_PORT_FULL_REFRESH && EGL_PORT_LCD_RGB_BUFFER_NUMS == 3

void ESPGLLCDDriver::Flush(EGDisplayDriver *pDisplayDriver, const EGRect *pRect, EG_Color_t *pBuffer)
{
    esp_lcd_panel_handle_t panel_handle = (esp_lcd_panel_handle_t) drv->user_data; // Get the panel handle from driver user data
    const int offsetx1 = area->x1; // Start X coordinate of the area to flush
    const int offsetx2 = area->x2; // End X coordinate of the area to flush
    const int offsety1 = area->y1; // Start Y coordinate of the area to flush
    const int offsety2 = area->y2; // End Y coordinate of the area to flush

#if EXAMPLE_LVGL_PORT_ROTATION_DEGREE != 0
    void *next_fb = get_next_frame_buffer(panel_handle); // Get the next frame buffer

    /* Rotate and copy dirty area from the current LVGL's buffer to the next RGB frame buffer */
    rotate_copy_pixel((uint16_t *)color_map, next_fb, offsetx1, offsety1, offsetx2, offsety2, LV_HOR_RES, LV_VER_RES, EXAMPLE_LVGL_PORT_ROTATION_DEGREE);

    /* Switch the current RGB frame buffer to `next_fb` */
    esp_lcd_panel_draw_bitmap(panel_handle, offsetx1, offsety1, offsetx2 + 1, offsety2 + 1, next_fb);
#else
    drv->draw_buf->buf1 = color_map; // Set buffer 1 to color_map
    drv->draw_buf->buf2 = lvgl_port_flush_next_buf; // Set buffer 2 to the next flush buffer
    lvgl_port_flush_next_buf = color_map; // Update the flush next buffer to color_map

    /* Switch the current RGB frame buffer to `color_map` */
    esp_lcd_panel_draw_bitmap(panel_handle, offsetx1, offsety1, offsetx2 + 1, offsety2 + 1, color_map);

    lvgl_port_rgb_next_buf = color_map; // Update the next RGB buffer
#endif

    lv_disp_flush_ready(drv); // Mark the display flush as complete
}
#endif

#else

void ESPGLLCDDriver::Flush(EGDisplayDriver *pDisplayDriver, const EGRect *pRect, EG_Color_t *pBuffer)
{
const int x_start = pRect->GetX1();
const int x_end = pRect->GetX2();
const int y_start = pRect->GetY1();
const int y_end = pRect->GetY2();

	ESPGLDisplay *pGLDisplay = (ESPGLDisplay*)pDisplayDriver->m_pExtData;
	assert(pGLDisplay != nullptr);
  esp_lcd_panel_draw_bitmap(pGLDisplay->m_hPanel, x_start, y_start, x_end + 1, y_end + 1, pBuffer);  // Switch the current RGB frame buffer to `color_map` 
  EGDisplay::FlushReady(pDisplayDriver); // Mark the display flush as complete
}

#endif 

////////////////////////////////////////////////////////////////////////

void ESPGLLCDDriver::PixMonochrome(EGDisplayDriver *pDisplayDriver, uint8_t *pBuffer, EG_Coord_t buf_w, EG_Coord_t x, EG_Coord_t y, EG_Color_t Color, EG_OPA_t OPA)
{
	if(pDisplayDriver->m_Rotated == EG_DISP_ROT_90 || pDisplayDriver->m_Rotated == EG_DISP_ROT_270){
		EG_Coord_t tmp_x = x;
		x = y;
		y = tmp_x;
	}
	// Write to the buffer as required for the display. It writes only 1-bit for monochrome displays mapped vertically.
	pBuffer += pDisplayDriver->m_HorizontalRes * (y >> 3) + x;
	if(EG_ColorTo1(Color)) (*pBuffer) &= ~(1 << (y % 8));
	else (*pBuffer) |= (1 << (y % 8));
}


