/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#pragma once

#include "esp_err.h"
#include "EGL.h"
#include "esp_timer.h"
#include "ESPEGLCDDriver.h"
#include "ESPEGTouchController.h"
#include "ESPEGPortUSBHid.h"

#include "ESPEGPortCompatibility.h"

/////////////////////////////////////////////////////////////////////////////////////

#define EGL_PORT_TICK_PERIOD_MS     (CONFIG_BSP_EGL_PORT_TICK)                  // The tick timer period in milliseconds

#define EGL_PORT_TASK_MAX_DELAY_MS  (CONFIG_BSP_EGL_PORT_TASK_MAX_DELAY_MS)     // The maximum delay of the LVGL timer task, in milliseconds
#define EGL_PORT_TASK_MIN_DELAY_MS  (CONFIG_BSP_EGL_PORT_TASK_MIN_DELAY_MS)     // The minimum delay of the LVGL timer task, in milliseconds
#define EGL_PORT_TASK_STACK_SIZE    (CONFIG_BSP_EGL_PORT_TASK_STACK_SIZE_KB * 1024) // The stack size of the LVGL timer task, in bytes
#define EGL_PORT_TASK_PRIORITY      (CONFIG_BSP_EGL_PORT_TASK_PRIORITY)         // The priority of the LVGL timer task
#define EGL_PORT_TASK_CORE          (CONFIG_BSP_EGL_PORT_TASK_CORE)             // The core of the LVGL timer task,
                                                                                // `-1` means no core specified

/* EGL buffer related parameters, can be adjusted by users:
 *  (These parameters will be useless if the avoid tearing function is enabled)
 *
 *  - Memory type for buffer allocation:
 *      - MALLOC_CAP_SPIRAM: Allocate LVGL buffer in PSRAM
 *      - MALLOC_CAP_INTERNAL: Allocate LVGL buffer in SRAM
 *      (The SRAM is faster than PSRAM, but the PSRAM has a larger capacity)*/

#if CONFIG_BSP_EGL_PORT_BUF_PSRAM
#define EGL_PORT_BUFFER_MALLOC_CAPS    (MALLOC_CAP_SPIRAM)
#elif CONFIG_BSP_EGL_PORT_BUF_INTERNAL
#define EGL_PORT_BUFFER_MALLOC_CAPS    (MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT)
#endif

#define EGL_PORT_BUFFER_HEIGHT         (CONFIG_BSP_EGL_PORT_BUF_HEIGHT)


// Avoid tearing related configurations, can be adjusted by users.
#ifdef CONFIG_BSP_EGL_PORT_AVOID_TEAR_ENABLE
#define EGL_PORT_AVOID_TEAR_ENABLE     (1) 
#else
#define EGL_PORT_AVOID_TEAR_ENABLE     (0) 
#endif

#if EGL_PORT_AVOID_TEAR_ENABLE

/* Set the avoid tearing mode:
 *      - 0: Disable avoid tearing function
 *      - 1: LCD double-buffer & EGL full-refresh
 *      - 2: LCD triple-buffer & EGL full-refresh
 *      - 3: LCD double-buffer & EGL direct-mode (recommended) */
#define EGL_PORT_AVOID_TEAR_MODE       (CONFIG_BSP_EGL_PORT_AVOID_TEAR_MODE)

/* Set the rotation degree of the LCD panel when the avoid tearing function is enabled:
 *      - 0: 0 degree
 *      - 90: 90 degree
 *      - 180: 180 degree
 *      - 270: 270 degree */
#define BSP_EGL_PORT_ROTATION_DEGREE  (CONFIG_BSP_EGL_PORT_ROTATION_DEGREE)

// Below configurations are automatically set according to the above configurations, users do not need to modify them.
#if EGL_PORT_AVOID_TEAR_MODE == 1
#define EGL_PORT_LCD_RGB_BUFFER_NUMS   (2)
#define EGL_PORT_FULL_REFRESH          (1)
#elif EGL_PORT_AVOID_TEAR_MODE == 2
#define EGL_PORT_LCD_RGB_BUFFER_NUMS   (3)
#define EGL_PORT_FULL_REFRESH          (1)
#elif EGL_PORT_AVOID_TEAR_MODE == 3
#define EGL_PORT_LCD_RGB_BUFFER_NUMS   (2)
#define EGL_PORT_DIRECT_MODE           (1)
#endif 

#if BSP_EGL_PORT_ROTATION_DEGREE == 0
#define BSP_EGL_PORT_ROTATION_0    (1)
#else
#if BSP_EGL_PORT_ROTATION_DEGREE == 90
#define BSP_EGL_PORT_ROTATION_90   (1)
#elif BSP_EGL_PORT_ROTATION_DEGREE == 180
#define BSP_EGL_PORT_ROTATION_180  (1)
#elif BSP_EGL_PORT_ROTATION_DEGREE == 270
#define BSP_EGL_PORT_ROTATION_270  (1)
#endif

#ifdef EGL_PORT_LCD_RGB_BUFFER_NUMS
#undef EGL_PORT_LCD_RGB_BUFFER_NUMS
#define EGL_PORT_LCD_RGB_BUFFER_NUMS   (3)
#endif
#endif
#else
#define EGL_PORT_LCD_RGB_BUFFER_NUMS   (1)
#define EGL_PORT_FULL_REFRESH          (0)
#define EGL_PORT_DIRECT_MODE           (0)
#endif

/////////////////////////////////////////////////////////////////////////////////////

typedef enum {
    EGL_PORT_EVENT_DISPLAY = 0x01,
    EGL_PORT_EVENT_TOUCH   = 0x02,
    EGL_PORT_EVENT_USER    = 0x80,
} ESPEGPortEventType_t;

typedef struct {
    ESPEGPortEventType_t type;
    void *param;
} EGLPortEvent_t;

/////////////////////////////////////////////////////////////////////////////////////

const int c_TaskPriority = EGL_PORT_TASK_PRIORITY;
const int c_TaskStack = EGL_PORT_TASK_STACK_SIZE;
const int c_TaskAffinity = EGL_PORT_TASK_CORE;
const int c_TaskMaxSleep = EGL_PORT_TASK_MAX_DELAY_MS;
const int c_TimerPeriod = EGL_PORT_TICK_PERIOD_MS;


/////////////////////////////////////////////////////////////////////////////////////

class ESPGLPort
{
public:
                      ESPGLPort(void);
  virtual             ~ESPGLPort();
  esp_err_t           Initialise(int Priority, int Stack, int Affinity, int SleepPeriod, int TimerPeriod);
  esp_err_t           Deinitialise(void);
  void                TaskDeinitialise(void);
  bool                Lock(uint32_t timeout_ms);
  void                Unlock(void);
//  void                FlushReady(lv_display_t *disp);
  esp_err_t           Stop(void);
  esp_err_t           Resume(void);
  esp_err_t           Wake(ESPEGPortEventType_t Event, void *pParam);
  SemaphoreHandle_t   GetTaskMux(void){ return m_hTaskMux; };
  int                 GetTaskPeriod(void){ return m_TaskMaxSleep; };
  int                 GetTimerPeriod(void){ return m_TimerPeriod; };

  static bool         OnNotify(uint32_t Value);
  static bool         OnRGBVSyncNotify(void);

 	bool                m_IsRunning;
	static TaskHandle_t m_hTask;

private:
  esp_err_t           TickInitialise(void);	

  int                 m_TaskMaxSleep; // Task sleep period in ms
  int                 m_TimerPeriod;    // timer tick period in ms 
	SemaphoreHandle_t   m_hMux;
	SemaphoreHandle_t   m_hTaskMux;
	esp_timer_handle_t m_hTickTimer;

};
