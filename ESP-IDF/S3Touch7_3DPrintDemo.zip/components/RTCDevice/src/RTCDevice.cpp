/*****************************************************************************
* | File      	:   PCF85063.c
* | Author      :   Waveshare team
* | Function    :   PCF85063 driver
* | Info        :
*----------------
* |	This version:   V1.0
* | Date        :   2024-02-02
* | Info        :   Basic version
*
******************************************************************************/
#include "RTCDevice.h"

/////////////////////////////////////////////////////////////////////////////////////

const unsigned char MonthStr[12][4] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov","Dec"};

/////////////////////////////////////////////////////////////////////////////////////

RTCDevice::RTCDevice() :
	m_Address(PCF85063_ADDRESS)  
{
}

/////////////////////////////////////////////////////////////////////////////////////

// Initiate Normal Mode, RTC Run, NO reset, No correction , 24hr format, Internal load capacitane 12.5pf
void RTCDevice::Initialise(i2c_master_bus_handle_t hi2cBus)
{
i2c_device_config_t i2cDeviceCfg;
uint8_t Value = RTC_CTRL_1_DEFAULT | RTC_CTRL_1_CAP_SEL;

  if(hi2cBus == nullptr) return;
  memset(&i2cDeviceCfg, 0, sizeof(i2c_device_config_t));
  i2cDeviceCfg.dev_addr_length = I2C_ADDR_BIT_LEN_7;
  i2cDeviceCfg.device_address = m_Address;
  i2cDeviceCfg.scl_speed_hz = 400 * 1000;
  i2c_master_bus_add_device(hi2cBus, &i2cDeviceCfg, &m_hDevice);
	Write1(RTC_CTRL_1_ADDR, Value);
/*  DateTime_t TestTime = {0};
	TestTime.year = 2024;
	TestTime.month = 9;
	TestTime.day = 20;
	TestTime.dotw = 5;
	TestTime.hour = 9;
	TestTime.minute = 50;
	TestTime.second = 0;
	PCF85063_Set_All(TestTime);*/
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t RTCDevice::Write1(uint8_t Register, uint8_t Value)
{
uint8_t Buffer[2] = {Register, Value };

  return i2c_master_transmit(m_hDevice, Buffer, 2, -1);
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t RTCDevice::Read1(uint8_t Register, uint8_t *pValue)
{
  return i2c_master_transmit_receive(m_hDevice, &Register, 1, pValue, 1, -1);
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::Reset()
{
	uint8_t Value = RTC_CTRL_1_DEFAULT | RTC_CTRL_1_CAP_SEL | RTC_CTRL_1_SR;
	Write1(RTC_CTRL_1_ADDR, Value);
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::Read(tm *pTime)
{

  Read(&m_DateTime);
	pTime->tm_sec = m_DateTime.second;
	pTime->tm_min = m_DateTime.minute;
	pTime->tm_hour = m_DateTime.hour;
	pTime->tm_mday = m_DateTime.day;
	pTime->tm_wday = m_DateTime.dotw;
	pTime->tm_mon = m_DateTime.month;
	pTime->tm_year = m_DateTime.year;
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::Read(DateTime_t *pTime)
{
uint8_t Buffer[7] = {0};
uint8_t Register = RTC_SECOND_ADDR;

	i2c_master_transmit_receive(m_hDevice, &Register, 1, Buffer, 7, -1);
	pTime->second = BCDToDec(Buffer[0] & 0x7F);
	pTime->minute = BCDToDec(Buffer[1] & 0x7F);
	pTime->hour = BCDToDec(Buffer[2] & 0x3F);
	pTime->day = BCDToDec(Buffer[3] & 0x3F);
	pTime->dotw = BCDToDec(Buffer[4] & 0x07);
	pTime->month = BCDToDec(Buffer[5] & 0x1F);
	pTime->year = BCDToDec(Buffer[6])+YEAR_OFFSET;
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::Read(void)
{
  Read(&m_DateTime);
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::SetTime(DateTime_t Time)
{
uint8_t Buffer[4] = {
  RTC_SECOND_ADDR,
	DecToBcd(Time.second),
	DecToBcd(Time.minute),
	DecToBcd(Time.hour)
};

  i2c_master_transmit(m_hDevice, Buffer, 4, -1);
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::SetDate(DateTime_t Time)
{
uint8_t Buffer[5] = {
  RTC_DAY_ADDR,
	DecToBcd(Time.day),
	DecToBcd(Time.dotw),
	DecToBcd(Time.month),
	DecToBcd(Time.year - YEAR_OFFSET)
};

  i2c_master_transmit(m_hDevice, Buffer, 5, -1);
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::SetClock(DateTime_t Time)
{
uint8_t Buffer[8] = {
  RTC_SECOND_ADDR,
	DecToBcd(Time.second),
	DecToBcd(Time.minute),
	DecToBcd(Time.hour),
	DecToBcd(Time.day),
	DecToBcd(Time.dotw),
	DecToBcd(Time.month),
	DecToBcd(Time.year - YEAR_OFFSET)
};

  i2c_master_transmit(m_hDevice, Buffer, 8, -1);
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::SetClock(tm Time)
{
uint8_t Buffer[8] = {
  RTC_SECOND_ADDR,
	DecToBcd(Time.tm_sec),
	DecToBcd(Time.tm_min),
	DecToBcd(Time.tm_hour),
	DecToBcd(Time.tm_yday),
	DecToBcd(Time.tm_wday),
	DecToBcd(Time.tm_mon),
	DecToBcd(Time.tm_year - YEAR_OFFSET)
};

  i2c_master_transmit(m_hDevice, Buffer, 8, -1);
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::EnableAlarm()
{
uint8_t Value[2] = {
  RTC_CTRL_2_ADDR,
  RTC_CTRL_2_DEFAULT | RTC_CTRL_2_AIE
};

	Value[1] &= ~RTC_CTRL_2_AF;
  i2c_master_transmit(m_hDevice, Value, 2, -1);
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t RTCDevice::GetAlarmFlag()
{
uint8_t Value = 0;
uint8_t Register = RTC_CTRL_2_ADDR;

  i2c_master_transmit_receive(m_hDevice, &Register, 1, &Value, 1, -1);
	//printf("Value = 0x%x",Value);
	Value &= RTC_CTRL_2_AF | RTC_CTRL_2_AIE;
	return Value;
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::SetAlarm(DateTime_t Time)
{

	uint8_t Buffer[6] ={
    RTC_SECOND_ALARM,
		static_cast<uint8_t>(DecToBcd(Time.second) & ~RTC_ALARM),	
		static_cast<uint8_t>(DecToBcd(Time.minute) & ~RTC_ALARM),	
		static_cast<uint8_t>(DecToBcd(Time.hour) & ~RTC_ALARM),
		//decToBcd(time.day) & (uint8_t)(~RTC_ALARM),
		//decToBcd(time.dotw) & (uint8_t)(~RTC_ALARM)
		RTC_ALARM, 	//disalbe day
		RTC_ALARM	//disalbe weekday
	};

  i2c_master_transmit(m_hDevice, Buffer, 6, -1);
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::ReadAlarm(DateTime_t *pTime)
{
uint8_t Buffer[6] = {0};
uint8_t Register = RTC_SECOND_ALARM;

  i2c_master_transmit_receive(m_hDevice, &Register, 1, Buffer, 6, -1);
	pTime->second = BCDToDec(Buffer[0] & 0x7F);
	pTime->minute = BCDToDec(Buffer[1] & 0x7F);
	pTime->hour = BCDToDec(Buffer[2] & 0x3F);
	pTime->day = BCDToDec(Buffer[3] & 0x3F);
	pTime->dotw = BCDToDec(Buffer[4] & 0x07);
}


/////////////////////////////////////////////////////////////////////////////////////

uint8_t RTCDevice::DecToBcd(int Val)
{
	return (uint8_t)((Val / 10 * 16) + (Val % 10));
}

/////////////////////////////////////////////////////////////////////////////////////

int RTCDevice::BCDToDec(uint8_t Val)
{
	return (int)((Val / 16 * 10) + (Val % 16));
}

/////////////////////////////////////////////////////////////////////////////////////

void RTCDevice::DateTimeStr(char *pString, DateTime_t Time)
{
	sprintf(pString, " %d/%d/%d  %d %d:%d:%d ", Time.year, Time.month, Time.day, Time.dotw, Time.hour, Time.minute, Time.second);
}