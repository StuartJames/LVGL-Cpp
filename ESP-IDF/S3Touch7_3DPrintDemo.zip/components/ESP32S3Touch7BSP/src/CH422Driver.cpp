/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by Espressif Systems (Shanghai) CO LTD
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#include "../include/CH422Driver.h"

////////////////////////////////////////////////////////////////////////

const char *TAG = "[CH422G]";

////////////////////////////////////////////////////////////////////////

void CH422Driver::Initialise(i2c_master_bus_handle_t hi2cBus)
{
i2c_device_config_t i2cDeviceCfg;

  if(hi2cBus == nullptr) return;
  memset(&i2cDeviceCfg, 0, sizeof(i2c_device_config_t));
  i2cDeviceCfg.dev_addr_length = I2C_ADDR_BIT_LEN_7;
  i2cDeviceCfg.device_address = CH422G_REG_CONTROL; // any old address will do for the moment
  i2cDeviceCfg.scl_speed_hz = 400 * 1000;
  i2c_master_bus_add_device(hi2cBus, &i2cDeviceCfg, &m_hDevice);
	Reset();
}

////////////////////////////////////////////////////////////////////////

esp_err_t CH422Driver::ReadInput(uint8_t *pValue)
{
  ESP_RETURN_ON_ERROR(i2c_master_device_change_address(m_hDevice, CH422G_REG_IN, -1), TAG, "Failed to set address");
  ESP_RETURN_ON_ERROR(i2c_master_receive(m_hDevice, pValue, 1, -1), TAG, "Read in reg failed");
	return ESP_OK;
}

////////////////////////////////////////////////////////////////////////

esp_err_t CH422Driver::WriteControl(uint8_t Value)
{
  ESP_RETURN_ON_ERROR(i2c_master_device_change_address(m_hDevice, CH422G_REG_CONTROL, -1), TAG, "Failed to set address");
  ESP_RETURN_ON_ERROR(i2c_master_transmit(m_hDevice, &Value, 1, -1), TAG, "Write control reg failed");
	return ESP_OK;
}

////////////////////////////////////////////////////////////////////////

esp_err_t CH422Driver::WriteOutput(uint8_t Value)
{
  ESP_RETURN_ON_ERROR(i2c_master_device_change_address(m_hDevice, CH422G_REG_OUT, -1), TAG, "Failed to set address");
  ESP_RETURN_ON_ERROR(i2c_master_transmit(m_hDevice, &Value, 1, -1), TAG, "Write output reg failed");
	return ESP_OK;
}

////////////////////////////////////////////////////////////////////////

esp_err_t CH422Driver::WriteOC(uint8_t Value)
{
  ESP_RETURN_ON_ERROR(i2c_master_device_change_address(m_hDevice, CH422G_REG_OC, -1), TAG, "Failed to set address");
  ESP_RETURN_ON_ERROR(i2c_master_transmit(m_hDevice, &Value, 1, -1), TAG, "Write output reg failed");
	return ESP_OK;
}

////////////////////////////////////////////////////////////////////////

esp_err_t CH422Driver::Reset(void)
{
  ESP_RETURN_ON_ERROR(WriteControl(0x01), TAG, "Failed to reset");
  ESP_RETURN_ON_ERROR(WriteOutput(OUT_REG_DEFAULT_VAL), TAG, "Failed to reset");
	return ESP_OK;
}

