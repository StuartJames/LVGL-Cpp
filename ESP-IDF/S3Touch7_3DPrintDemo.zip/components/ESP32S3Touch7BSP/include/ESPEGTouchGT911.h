/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#pragma once

#include "ESPEGTouchController.h"
#include "driver/i2c_master.h"
#include "CH422Driver.h"

/////////////////////////////////////////////////////////////////////////////////////

#define ESP_I2C_GT911_ADDRESS      0x5D  // When power-on detects low level of the interrupt gpio, address is 0x5D.
#define ESP_I2C_GT911_ADDRESS_ALT  0x14  // Interrupt gpio is high level, address is 0x14.

// GT911 registers 
#define ESP_LCD_TOUCH_GT911_READ_KEY_REG        0x8093
#define ESP_LCD_TOUCH_GT911_READ_XY_REG         0x814E
#define ESP_LCD_TOUCH_GT911_CONFIG_REG          0x8047
#define ESP_LCD_TOUCH_GT911_PRODUCT_ID_REG      0x8140
#define ESP_LCD_TOUCH_GT911_ENTER_SLEEP         0x8040

// GT911 support key num 
#define ESP_GT911_TOUCH_MAX_BUTTONS             4

#define I2C_MASTER_FREQ_HZ 									    400000  						// I2C master clock frequency 
#define I2C_MASTER_TX_BUF_DISABLE 					    0 									// I2C master doesn't need buffer 
#define I2C_MASTER_RX_BUF_DISABLE 					    0 									// I2C master doesn't need buffer 
#define I2C_MASTER_TIMEOUT_MS 							    1000

#define LCD_TOUCH_V_RES											    800
#define LCD_TOUCH_H_RES											    480

/////////////////////////////////////////////////////////////////////////////////////

// I2C settings
const gpio_num_t  I2CTouchSclIO_c	 					= GPIO_NUM_9;       // GPIO number used for I2C master clock 
const gpio_num_t  I2CTouchSdaIO_c	 					= GPIO_NUM_8;       // GPIO number used for I2C master data  
const gpio_num_t  I2CTouchIntIO_c						= GPIO_NUM_4;       // GPIO number used for Interrupt  
const gpio_num_t  I2CTouchResetIO_c					= GPIO_NUM_NC;      // GPIO number used for Reset 
const i2c_port_t  I2CTouchMaster_c 					=	I2C_NUM_0;      	// I2C master i2c port number, the number of i2c peripheral interfaces available will depend on the chip 
const uint8_t     I2CGlitchIgnore_c 				=	7;      	
const uint16_t    I2CSleepTime_c 					  =	1000;      	

extern CH422Driver  *pCH422;

/////////////////////////////////////////////////////////////////////////////////////

class ESPGLTouchGT911 : public ESPGLTouchController
{
public:
                            ESPGLTouchGT911(void);
  virtual                   ~ESPGLTouchGT911(void);

  esp_err_t                 EnterSleep(void);  
  esp_err_t                 ExitSleep(void);
  void                      Initialise(void);
  esp_err_t                 Configure(const ESPGL_LCDTouchConfig_t *pConfig);
  esp_err_t                 ReadData(void);
  bool                      GetCoordinates(uint16_t *x, uint16_t *y, uint16_t *strength, uint8_t *point_num, uint8_t max_point_num);
  #if (CONFIG_BSP_LCD_TOUCH_MAX_BUTTONS > 0)
  esp_err_t                 GetButtonState(uint8_t Index, uint8_t *pState);
  #endif

  // GT911 specific
  esp_err_t                 Reset(void);
  void                      ReadConfig(void);
  void                      i2cConfig(i2c_master_bus_handle_t hi2cBus);
  esp_err_t                 i2cRead(uint16_t Register, uint8_t *pData, uint8_t Length);
  esp_err_t                 i2cWrite(uint16_t Register, uint8_t *pData, uint8_t Length);

private:
  uint32_t                  m_IntPinLevel;

};


