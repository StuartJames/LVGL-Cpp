/*
 *              EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#pragma once

#include "esp_err.h"
#include "Button.h"

typedef struct {
    gpio_num_t  GPIONumber;       // num of gpio 
    uint8_t     ActiveLevel;      // gpio level when press down 
    bool        PowerSave;        // enable power save mode 
    bool        DisableBias;      // disable internal pull up or down
} GPIOButtonConfig_t;

class GPIOButton;

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t NewGPIOButton(const ButtonConfig_t *pConfig, const GPIOButtonConfig_t *pIOConfig, GPIOButton *pButton);
void      DeleteGPIOButton(GPIOButton *pButton);

/////////////////////////////////////////////////////////////////////////////////////

class GPIOButton : public ESPButton
{
public:
                      GPIOButton(void);
  virtual             ~GPIOButton();
  esp_err_t           Create(const ButtonConfig_t *pConfig, const GPIOButtonConfig_t *pIOConfig);
  uint8_t             GetKeyLevel(void);
  esp_err_t           EnableWakeup(uint8_t ActiveLevel, bool Enable);
  esp_err_t           SetInterrupt(gpio_int_type_t InterruptType, gpio_isr_t Handler);
  esp_err_t           EnterPowerSave(void);

	gpio_num_t          m_GPIONumber;   // num of gpio 
	uint8_t             m_ActiveLevel;  // gpio level when press down 
	bool                m_PowerSave;    // enable power save 

private:
};

