/*
 *                EGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= ===========================================
 * SJ    2025/08/18   1.a.1    Original 
 *
 */


/////////////////////////////////////////////////////////////////////////////////////
#define _MAIN_

#include "LEGLDemo28.h"

extern "C" {
  void app_main(void);
}

/////////////////////////////////////////////////////////////////////////////////////

static const char *_TAG = "[Main  ]";

/////////////////////////////////////////////////////////////////////////////////////

void Initialise_i2c(gpio_num_t SCL, gpio_num_t SDA, i2c_port_t Port)
{
i2c_master_bus_config_t i2cConfig;
esp_err_t Res;

  memset(&i2cConfig, 0, sizeof(i2c_master_bus_config_t));
  i2cConfig.clk_source = I2C_CLK_SRC_DEFAULT;
  i2cConfig.i2c_port = (i2c_port_num_t)Port;
  i2cConfig.scl_io_num = SCL;
  i2cConfig.sda_io_num = SDA;
  i2cConfig.glitch_ignore_cnt = 7;
  i2cConfig.flags.enable_internal_pullup = true;

  if((Res = i2c_new_master_bus(&i2cConfig, &g_hi2cBus)) != ESP_OK){
		ESP_LOGE(_TAG, "I2C initialize failed: %d.", Res);
		while(true) vTaskDelay(pdMS_TO_TICKS(1000));
	}
	ESP_LOGI(_TAG, "I2C initialized successfully");
}

/////////////////////////////////////////////////////////////////////////////////////

void InitialiseHarware(void)
{
  Initialise_i2c(c_I2CSCLPin, c_I2CSDAPin, c_I2CPort);
  g_SDMMCObj.Initialise(c_pMountPoint);
	g_SDMMCObj.GetFlashSize();
	g_PwrKeyObj.Initialise(c_PowerKeyPin, c_PowerControlPin);
}

/////////////////////////////////////////////////////////////////////////////////////

void app_main(void)
{
	ESP_LOGI(_TAG, "***************************");
  ESP_LOGI(_TAG, "*    LEGL Widget Demo     *");
  ESP_LOGI(_TAG, "*  (c) HydraSystems 2026  *");
  ESP_LOGI(_TAG, "* Written by Stuart James *");
  ESP_LOGI(_TAG, "***************************");
  ESP_LOGI(_TAG, "\n\nFree memory: %ld bytes", esp_get_free_heap_size());
  ESP_LOGI(_TAG, "IDF version: %s", esp_get_idf_version());
  esp_log_level_set("gpio", ESP_LOG_NONE);  // Disable default gpio logging messages
  
	g_SystemFlags = xEventGroupCreate();
  if(g_SystemFlags == nullptr){
    ESP_LOGE(_TAG, "Failed to create system flags.");
		while(true) vTaskDelay(pdMS_TO_TICKS(1000));
  }

  InitialiseHarware();  

	BaseType_t id = xTaskCreatePinnedToCore(DisplayThread, "Display thread", 4096, NULL, 8, NULL, 0);         
  if(id == 0L){
    ESP_LOGE(_TAG, "Failed to create display thread.");
		while(true) vTaskDelay(pdMS_TO_TICKS(1000));
  }
  xEventGroupWaitBits(g_SystemFlags, SYSFLAG_DISPLAY_READY, pdFALSE, pdTRUE, portMAX_DELAY); // wait for display thread to become ready

	xEventGroupSetBits(g_SystemFlags, SYSFLAG_SYSTEM_UP);
	ESP_LOGI(_TAG, "System Initialised.");
  ESP_LOGI(_TAG, "Free memory: %ld bytes", esp_get_free_heap_size());
	while(true) {
		vTaskDelay(pdMS_TO_TICKS(1000));	
	}
}
