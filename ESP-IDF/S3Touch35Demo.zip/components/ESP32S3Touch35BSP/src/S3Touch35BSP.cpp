/*
 *                LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#include <stdio.h>
#include "esp_vfs_fat.h"
#include "esp_log.h"
#include "esp_check.h"
#include "esp_spiffs.h"
#include "esp_lcd_panel_io.h"
#include "esp_lcd_panel_vendor.h"
#include "esp_lcd_panel_ops.h"
#include "driver/spi_master.h"
#include "driver/ledc.h"

#include "S3Touch35BSP.h"
#include "bsp_err_check.h"
#include "ESPEGPort.h"

/////////////////////////////////////////////////////////////////////////////////////

#define LCD_CMD_BITS 		8
#define LCD_PARAM_BITS 	8
#define LCD_LEDC_CH 		CONFIG_BSP_DISPLAY_BRIGHTNESS_LEDC_CH

static ESPGLPort GLPort;
static ESPGLDisplay *g_pEGDisplay = nullptr;
static ESPGLTouchFT6336 *g_pTouchController = nullptr;

/////////////////////////////////////////////////////////////////////////////////////

static const char *_TAG = "[BSP   ]";

sdmmc_card_t *pSDCard = nullptr;  // Global uSD card handler

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t LED_Initialise(void)
{
const gpio_config_t led_io_config = {
	.pin_bit_mask = BIT64(BSP_LED_RED) | BIT64(BSP_LED_GREEN) | BIT64(BSP_LED_BLUE),
	.mode = GPIO_MODE_OUTPUT,
	.pull_up_en = GPIO_PULLUP_DISABLE,
	.pull_down_en = GPIO_PULLDOWN_DISABLE,
	.intr_type = GPIO_INTR_DISABLE
};

	BSP_ERROR_CHECK_RETURN_ERR(gpio_config(&led_io_config));
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t Set_LED(const bsp_led_t LEDRef, const bool State)
{
	BSP_ERROR_CHECK_RETURN_ERR(gpio_set_level((gpio_num_t)LEDRef, (uint32_t)State));
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t MountSPIFFS(void)
{
esp_vfs_spiffs_conf_t Config = {
	.base_path = CONFIG_BSP_SPIFFS_MOUNT_POINT,
	.partition_label = CONFIG_BSP_SPIFFS_PARTITION_LABEL,
	.max_files = CONFIG_BSP_SPIFFS_MAX_FILES,
#ifdef CONFIG_BSP_SPIFFS_FORMAT_ON_MOUNT_FAIL
	.format_if_mount_failed = true,
#else
	.format_if_mount_failed = false,
#endif
};

	esp_err_t ret_val = esp_vfs_spiffs_register(&Config);
	BSP_ERROR_CHECK_RETURN_ERR(ret_val);
	size_t total = 0, used = 0;
	ret_val = esp_spiffs_info(Config.partition_label, &total, &used);
	if(ret_val != ESP_OK) {
		ESP_LOGE(_TAG, "Failed to get SPIFFS partition information (%s)", esp_err_to_name(ret_val));
	}
	else {
		ESP_LOGI(_TAG, "Partition size: total: %d, used: %d", total, used);
	}
	return ret_val;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t UnmountSPIFFS(void)
{
	return esp_vfs_spiffs_unregister(CONFIG_BSP_SPIFFS_PARTITION_LABEL);
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t MountSDCard(void)
{
const esp_vfs_fat_sdmmc_mount_config_t Config = {
#ifdef CONFIG_BSP_uSD_FORMAT_ON_MOUNT_FAIL
	.format_if_mount_failed = true,
#else
	.format_if_mount_failed = false,
#endif
	.max_files = 5,
	.allocation_unit_size = 16 * 1024,
	.disk_status_check_enable = 0,
	.use_one_fat = 0,
};

	sdmmc_host_t Host = SDMMC_HOST_DEFAULT();
	sdmmc_slot_config_t SlotConfig = SDMMC_SLOT_CONFIG_DEFAULT();
	SlotConfig.width = 4;
	return esp_vfs_fat_sdmmc_mount(BSP_SD_MOUNT_POINT, &Host, &SlotConfig, &Config, &pSDCard);
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t UnmountSDCard(void)
{
	return esp_vfs_fat_sdcard_unmount(BSP_SD_MOUNT_POINT, pSDCard);
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t BacklightIntialise(gpio_num_t BackLightPin)
{
// Setup LEDC peripheral for PWM backlight control
const ledc_channel_config_t BacklightChannel = {
	.gpio_num = BackLightPin,
	.speed_mode = LEDC_LOW_SPEED_MODE,
	.channel = (ledc_channel_t)LCD_LEDC_CH,
	.intr_type = LEDC_INTR_DISABLE,
	.timer_sel = (ledc_timer_t)1,
	.duty = 0,
	.hpoint = 0,
  .sleep_mode = LEDC_SLEEP_MODE_NO_ALIVE_NO_PD,
	.flags = {
		.output_invert = 1,
	},
  .deconfigure = false
};
const ledc_timer_config_t BacklightTimer = {
	.speed_mode = LEDC_LOW_SPEED_MODE,
	.duty_resolution = LEDC_TIMER_10_BIT,
	.timer_num = (ledc_timer_t)1,
	.freq_hz = 5000,
	.clk_cfg = LEDC_AUTO_CLK,
	.deconfigure = 0,
};

	BSP_ERROR_CHECK_RETURN_ERR(ledc_timer_config(&BacklightTimer));
	BSP_ERROR_CHECK_RETURN_ERR(ledc_channel_config(&BacklightChannel));
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t SetBacklightLevel(int Intensity)
{
	Intensity = (Intensity > 100) ? 0 : ((Intensity < 0) ? 100 : 100 - Intensity);
//	ESP_LOGI(_TAG, "Setting LCD backlight: %d%%", Intensity);
	uint32_t DutyCycle = (1023 * Intensity) / 100;	// LEDC resolution set to 10bits, thus: 100% = 1023
	BSP_ERROR_CHECK_RETURN_ERR(ledc_set_duty(LEDC_LOW_SPEED_MODE, (ledc_channel_t)LCD_LEDC_CH, DutyCycle));
	BSP_ERROR_CHECK_RETURN_ERR(ledc_update_duty(LEDC_LOW_SPEED_MODE, (ledc_channel_t)LCD_LEDC_CH));
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t BacklightOff(void)
{
	return SetBacklightLevel(0);
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t BacklightOn(void)
{
	return SetBacklightLevel(100);
}

/////////////////////////////////////////////////////////////////////////////////////

void SoftResetOnce(void)
{
  if(esp_reset_reason() == ESP_RST_POWERON){
    fflush(stdout);
    esp_restart();
  }
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t InitialiseDisplayIO(const DisplayPins_t *pPins, esp_lcd_panel_handle_t *hPanel, esp_lcd_panel_io_handle_t *hIO)
{
esp_err_t Ret = ESP_OK;

	ESP_RETURN_ON_ERROR(BacklightIntialise(pPins->LCD_BCK), _TAG, "Brightness init failed");
  spi_bus_config_t SPIBusCfg = {};
	SPIBusCfg.mosi_io_num = pPins->SPI_MOSI;
	SPIBusCfg.miso_io_num = pPins->SPI_MISO;
	SPIBusCfg.sclk_io_num = pPins->SPI_CLK;
	SPIBusCfg.quadwp_io_num = GPIO_NUM_NC;
	SPIBusCfg.quadhd_io_num = GPIO_NUM_NC;
  SPIBusCfg.data_io_default_level = true;
	SPIBusCfg.max_transfer_sz = BSP_LCD_DRAW_BUFF_SIZE;
//  SPIBusCfg.dma_burst_size = 0,
	SPIBusCfg.flags = SPICOMMON_BUSFLAG_MASTER;
	SPIBusCfg.isr_cpu_id = ESP_INTR_CPU_AFFINITY_AUTO;
	SPIBusCfg.intr_flags = 0;
	assert(SPIBusCfg.max_transfer_sz > 0);
	ESP_LOGD(_TAG, "Initialize SPI bus");
	ESP_RETURN_ON_ERROR(spi_bus_initialize(BSP_LCD_SPI_Num_c, &SPIBusCfg, SPI_DMA_CH_AUTO), _TAG, "SPI init failed");

  esp_lcd_panel_io_spi_config_t PanelIOCfg = {};
	PanelIOCfg.cs_gpio_num = pPins->SPI_CS;
	PanelIOCfg.dc_gpio_num = pPins->LCD_DC;
	PanelIOCfg.spi_mode = 0;
	PanelIOCfg.pclk_hz = BSP_LCD_PIXEL_CLOCK_HZ;
	PanelIOCfg.trans_queue_depth = 10;
	PanelIOCfg.on_color_trans_done = nullptr;
	PanelIOCfg.user_ctx = nullptr;
	PanelIOCfg.lcd_cmd_bits = LCD_CMD_BITS;
	PanelIOCfg.lcd_param_bits = LCD_PARAM_BITS;
	ESP_LOGD(_TAG, "Install panel IO");
	Ret = esp_lcd_new_panel_io_spi((int)BSP_LCD_SPI_Num_c, &PanelIOCfg, hIO);

  SoftResetOnce();
  
  esp_lcd_panel_dev_config_t PanelCfg = {};
	PanelCfg.rgb_ele_order = LCD_RGB_ELEMENT_ORDER_BGR;  // LCD_RGB_ELEMENT_ORDER_RGB or LCD_RGB_ELEMENT_ORDER_BGR
	PanelCfg.data_endian = LCD_RGB_DATA_ENDIAN_LITTLE; // LCD_RGB_DATA_ENDIAN_BIG or LCD_RGB_DATA_ENDIAN_LITTLE
	PanelCfg.bits_per_pixel = BSP_LCD_BITS_PER_PIXEL;
	PanelCfg.reset_gpio_num = pPins->LCD_RST;
  PanelCfg.vendor_config = nullptr;
	if(Ret == ESP_OK){
		ESP_LOGD(_TAG, "Install LCD driver");
		if((Ret = esp_lcd_new_panel_st7796(*hIO, &PanelCfg, hPanel)) == ESP_OK){
			esp_lcd_panel_reset(*hPanel);
			esp_lcd_panel_init(*hPanel);
			esp_lcd_panel_invert_color(*hPanel, true);
      esp_lcd_panel_disp_on_off(*hPanel, true);
			return Ret;
		}
		else ESP_LOGE(_TAG, "New panel failed");
	}
	else ESP_LOGE(_TAG, "New panel IO failed");
	if(*hPanel) esp_lcd_panel_del(*hPanel);
	if(*hIO) esp_lcd_panel_io_del(*hIO);
	spi_bus_free(BSP_LCD_SPI_Num_c);
	return Ret;
}

/////////////////////////////////////////////////////////////////////////////////////

static EGDisplay *LCD_Initialise(const DisplayPins_t *pPins)
{
esp_lcd_panel_io_handle_t hIO = nullptr;
esp_lcd_panel_handle_t hPanel = nullptr;
ESPGLPortDisplayCfg_t PortConfig = {
  .BufferSize = BSP_LCD_DRAW_BUFF_SIZE,
  .DoubleBuffer = BSP_LCD_DRAW_BUFF_DOUBLE,
  .TransferSize = 0,
  .HoriResolution = BSP_LCD_H_RES,
  .VertvResolution = BSP_LCD_V_RES,
  .IsMonochrome = false,
  // Rotation values must be same as used in esp_lcd for initial settings of the screen 
  .Rotation = {
    .SwapXY = false,
    .MirrorX = true,
    .MirrorY = false,
  },
  .Flags = {
    .BufferDMA = true,
    .BuffersPSRAM = false,
    .SWRotate = 0,
    .FullRefresh = 0,
    .DirectMode = 0,
  }
};

	assert(pPins != nullptr);
	BSP_ERROR_CHECK_RETURN_NULL(InitialiseDisplayIO(pPins, &hPanel, &hIO));
	esp_lcd_panel_disp_on_off(hPanel, true);
	ESP_LOGD(_TAG, "Add LCD screen");	// Add LCD screen 
	return g_pEGDisplay->AddDisplay(hPanel, hIO, &PortConfig); // merge the display harware and software
}

/////////////////////////////////////////////////////////////////////////////////////

EGDisplay* DisplayStart(DisplayPins_t *pPins, i2c_master_bus_handle_t hi2cBus)
{
EGDisplay *pDisplay;

  g_pEGDisplay = new ESPGLDisplay; // get a new display hardware object
  g_pTouchController = new ESPGLTouchFT6336;
  GLPort.Initialise(c_TaskPriority, c_TaskStack, c_TaskAffinity, c_TaskMaxSleep, c_TimerPeriod); 
	BSP_NULL_CHECK(pDisplay = LCD_Initialise(pPins), nullptr);
  g_pTouchController->i2cConfig(hi2cBus);
	TouchpadInitialise(g_pTouchController, pDisplay);
	return pDisplay;
}

/////////////////////////////////////////////////////////////////////////////////////

EGInputDevice *GetInputDevice(void)
{
	return nullptr;
}

/////////////////////////////////////////////////////////////////////////////////////

void DisplayRotate(EGDisplay *pDisplay, EG_DisplayRotation_e Rotation)
{
	pDisplay->SetRotation((EG_DisplayRotation_t)Rotation);
}

/////////////////////////////////////////////////////////////////////////////////////

bool DisplayLock(uint32_t Timeout)
{
	return GLPort.Lock(Timeout);
}

/////////////////////////////////////////////////////////////////////////////////////

void DisplayUnlock(void)
{
	GLPort.Unlock();
}
